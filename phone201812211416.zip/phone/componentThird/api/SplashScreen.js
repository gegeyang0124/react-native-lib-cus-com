import SplashScreenIos from "./SplashScreenIos";
import SplashScreenAndroid from "./SplashScreenAndroid";
import {Platform} from "react-native";

/**
 * app启动隐藏，处理app启动闪白 API
 * **/
export class SplashScreen {
    static hide()
    {

        if(Platform.OS == "ios")
        {
            SplashScreenIos.hide()
        }
        else
        {
            SplashScreenAndroid.close({
                animationType: SplashScreenAndroid.animationType.scale,
                duration: 850,
                delay: 500,
            });
        }
    }
}

module.exports = SplashScreen;