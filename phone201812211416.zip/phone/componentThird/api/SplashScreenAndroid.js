import SplashScreen from 'react-native-smart-splash-screen'
module.exports = SplashScreen;