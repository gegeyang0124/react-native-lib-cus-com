import SplashScreen from "react-native-splash-screen";

module.exports = SplashScreen;