/**
 * Created by Administrator on 2018/4/11.
 */
import Storage from 'react-native-storage';
import SplashScreen from "./SplashScreen";
import {
    StackNavigator,
    DrawerNavigator,
    TabNavigator,
    TabBarBottom,
    TabBarTop,
    DrawerItems,
} from 'react-navigation';
import Toast from 'react-native-root-toast';
import ImagePicker from 'react-native-image-crop-picker';
import  VideoMgr from 'react-native-image-picker'; //第三方相机和录像
/**
 * A TimerEnhance for React Native app (es6) which replaced TimerMixin (es5)
 * provides timer functions for executing code in the future
 * that are safely cleaned up when the component unmounts
 * **/
import TimerEnhance from 'react-native-smart-timer-enhance';
import RNFS from 'react-native-fs';
/**
 * react-native-doc-viewer
 * 可以在手机上直接打开文档，支持远程和本地文档。
 * 支持的文档格式：xls,ppt,doc,xlsx,pptx,docx,png,jpg,pdf,mp4。
 * 支持iOS和Android(有bug,哥正在修复中)。
 * **/
import OpenFile from "react-native-doc-viewer";
import CardStackStyleInterpolator from 'react-navigation/src/views/CardStack/CardStackStyleInterpolator';
import Picker from 'react-native-picker';
import Orientation from 'react-native-orientation';

const api = {

    get Storage() {
        return Storage;
    },
    get SplashScreen() {
        return  SplashScreen ;//启动图控制;
    },
    get StackNavigator() {
        return  StackNavigator ;//页面跳转导航api 用来跳转页面和传递参数
    },
    get DrawerNavigator() {
        return  DrawerNavigator ;//侧滑菜单导航栏，用于轻松设置带抽屉导航的屏幕
    },
    get TabNavigator() {
        return  TabNavigator ;//类似底部导航栏，用来在同一屏幕下切换不同界面
    },
    get TabBarTop() {
        return  TabBarTop ;//导航栏，顶部组件
    },
    get TabBarBottom() {
        return  TabBarBottom ;//导航栏，底部组件
    },
    get DrawerItems() {
        return  DrawerItems ;//导航栏，左边组件
    },
    get Toast() {
        return  Toast ;//Toast提示框
    },
    get ImagePicker() {
        return  ImagePicker ;//图片选择
    },
    get VideoMgr() {
        return  VideoMgr ;//视频拍摄
    },
    get TimerEnhance() {
        return  TimerEnhance ;
    },
    get RNFS() {
        return  RNFS ;
    },
    get OpenFile() {
        return  OpenFile ;
    },
    get CardStackStyleInterpolator() {
        return  CardStackStyleInterpolator ;
    },
    get Picker() {
        return  Picker ;
    },
    get Orientation() {
        return  Orientation ;
    },

};

module.exports = api;