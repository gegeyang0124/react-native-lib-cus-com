/**
 * Created by Administrator on 2018/4/11.
 */
import {
    SideMenu,
    ImageViewer,
    Video,
    Barcode,
    Progress,
    Spinner,
    LinearGradient,
    Echarts,
    CustomActionSheet,
    DatePicker,
    Swiper,
    CheckBox,
    SwipeListView,
    SwipeRow,
    GiftedChat,
} from "./ui/ui";
import {
    Storage,
    SplashScreen,
    StackNavigator,
    DrawerNavigator,
    TabNavigator,
    TabBarBottom,
    TabBarTop,
    DrawerItems,
    Toast,
    ImagePicker,
    VideoMgr,
    TimerEnhance,
    RNFS,
    OpenFile,
    CardStackStyleInterpolator,
    Picker,
    Orientation,
} from "./api/api";

const compoent = {

    /**
     * ui
     * **/
    get SideMenu() {
        return SideMenu;
    },
    get ImageViewer() {
        return  ImageViewer;
    },
    get Spinner() {
        return  Spinner;
    },
    get Video() {
        return  Video;
    },
    get Barcode() {
        return  Barcode;
    },
    get Progress() {
        return  Progress;
    },
    get LinearGradient() {
        return  LinearGradient;
    },
    get Echarts() {
        return  Echarts;
    },
    get CustomActionSheet() {
        return  CustomActionSheet;
    },
    get DatePicker() {
        return  DatePicker;
    },
    get Swiper() {
        return  Swiper;
    },
    get CheckBox() {
        return  CheckBox;
    },
    get SwipeListView() {
        return SwipeListView;
    },
    get SwipeRow() {
        return SwipeRow;
    },
    get GiftedChat() {
        return GiftedChat;
    },

    /**
     * API
     * **/
    get Toast() {
        return Toast;
    },
    get VideoMgr() {
        return VideoMgr;
    },
    get Storage() {
        return Storage;
    },
    get SplashScreen() {
        return  SplashScreen;
    },
    get StackNavigator() {
        return  StackNavigator ;//页面跳转导航api 用来跳转页面和传递参数
    },
    get DrawerNavigator() {
        return  DrawerNavigator ;//侧滑菜单导航栏，用于轻松设置带抽屉导航的屏幕
    },
    get TabNavigator() {
        return  TabNavigator ;//类似底部导航栏，用来在同一屏幕下切换不同界面
    },
    get TabBarTop() {
        return  TabBarTop ;//导航栏，顶部组件
    },
    get TabBarBottom() {
        return  TabBarBottom ;//导航栏，底部组件
    },
    get DrawerItems() {
        return  DrawerItems ;//导航栏，左边组件
    },
    get ImagePicker() {
        return  ImagePicker ;//图片选择
    },
    get TimerEnhance() {
        return  TimerEnhance ;
    },
    get RNFS() {
        return  RNFS ;
    },
    get OpenFile() {
        return  OpenFile ;
    },
    get CardStackStyleInterpolator() {
        return  CardStackStyleInterpolator ;
    },
    get Picker() {
        return  Picker ;
    },
    get Orientation() {
        return  Orientation ;
    },
};

module.exports = compoent;