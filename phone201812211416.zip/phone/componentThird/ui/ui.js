/**
 * Created by Administrator on 2018/4/11.
 */
import SideMenu from 'react-native-side-menu';
import Spinner from "react-native-spinkit";
import ImageViewer from 'react-native-image-zoom-viewer';
import Video from 'react-native-video';
import Barcode from 'react-native-smart-barcode';
import * as Progress from 'react-native-progress';
import LinearGradient from 'react-native-linear-gradient';
/**
 * 修改底层
 * android 在滚动，需要设置scalesPageToFit={true}
 * echarts的底层的要换成echarts内库要换成echarts 4.x
 * **/
import Echarts from 'native-echarts';
import CustomActionSheet from 'react-native-custom-action-sheet';//需要修改底层
/**
 * 修改DatePicker底层增加属性hideHeader //隐藏头部显示内容，默认是false
 * **/
import DatePicker from 'react-native-datepicker';
/**
 * 底层有bug,修改初始化状态，bug:子UI传入时若为空（【】）会初始化错误；
 * 修改：子UI在传入空（【】）不进行组件初始化，直接返回空；子UI非空时才返回组件实例渲染
 * **/
import Swiper from 'react-native-swiper';
/**
 * 需要修改js封装层 leftText rightText 样式中flex去掉 ，
 * onClick事件传出是否选中，true或false ,改PropTypes.func.isRequired为非必须传入 PropTypes.func
 * leftText和rightText样式删掉
 * rightTextStyle和leftTextStyle样式改成PropTypes.oneOfType([
 PropTypes.array,
 PropTypes.object,
 PropTypes.number
 ])
 * **/
import CheckBox from 'react-native-check-box';
/**
 * 侧滑组件
 * **/
import {SwipeListView, SwipeRow} from 'react-native-swipe-list-view';
/**
 * react-native-gifted-chat 修改了底层 增加了'取消'按钮 增加了取消回调事件onCancel
 * 增加了属性leftContentStyle（改变左边内容框样式）
 * **/
import { GiftedChat } from 'react-native-gifted-chat';

const ui = {

    get SideMenu() {
        return SideMenu;
    },
    get Spinner() {
        return Spinner;
    },
    get ImageViewer() {
        return ImageViewer;
    },
    get Video() {
        return Video;
    },
    get Barcode() {
        return Barcode;
    },
    get Progress() {
        return Progress;
    },
    get LinearGradient() {
        return LinearGradient;
    },
    get Echarts() {
        return Echarts;
    },
    get CustomActionSheet() {
        return CustomActionSheet;
    },
    get DatePicker() {
        return DatePicker;
    },
    get Swiper() {
        return Swiper;
    },
    get CheckBox() {
        return CheckBox;
    },
    get SwipeListView() {
        return SwipeListView;
    },
    get SwipeRow() {
        return SwipeRow;
    },
    get GiftedChat() {
        return GiftedChat;
    },

};

module.exports = ui;