/**侧滑菜单
 * **/

import PropTypes from 'prop-types';
import React, {Component} from 'react';
import {
    ScrollView,
    View,
    Image,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
} from "../../component/component";
import ImageIcon from './../../res/images/icon.png';

export default class MenuSlide extends Component {
    static propTypes = {
        onItemSelected: PropTypes.func.isRequired,//菜单项点击事件
    };


    render() {
        let cutVersion = this.props.versionTxt != null
        && this.props.versionTxt.indexOf("运营") > -1
            ? '切换：门投版'
            :'切换：运营版';

        return (
            <ScrollView style={styles.menu} scrollsToTop={false}>

                <View style={styles.avatarContainer}>
                    <Image style={styles.avatar}
                           source={ImageIcon}/>
                    <Text style={styles.nickName}>设置</Text>
                </View>

                <View style={styles.menuChild}>
                    <Text style={styles.item}
                          onPress={() => this.props.onItemSelected(0,cutVersion)}>
                        {cutVersion}
                    </Text>

                    <Text style={styles.item}
                          onPress={() => this.props.onItemSelected(1)}>
                        拍照
                    </Text>

                    <Text style={styles.item}
                          onPress={() => this.props.onItemSelected(2)}>
                        拍摄视频
                    </Text>

                    <Text style={styles.item}
                          onPress={() => this.props.onItemSelected(3)}>
                        选择照片
                    </Text>

                    <Text style={styles.item}
                          onPress={() => this.props.onItemSelected(4)}>
                        选择视频
                    </Text>


                </View>

            </ScrollView>
        );
    }
}

const styles = StyleSheetAdapt.create({
    menu: {
        flex: 1,
        width: null,
        height: null,
        backgroundColor: 'gray',
        padding: 40,
    },
    avatarContainer: {
        marginBottom: 20,
        marginTop: 20,
        marginLeft:10,
    },
    avatar: {
        width: 100,
        height: 100,
        borderRadius: 50,
        resizeMode:Image.resizeMode.contain,
    },
    nickName: {
        position: 'absolute',
        left: 160,
        top: 30,
        fontSize: 40,
    },
    menuChild: {
        justifyContent: 'center',
        alignItems: 'center',
    },
    item: {
        fontSize: 25,
        fontWeight: '300',
        paddingTop: 40,
    }
});

