import React, {
    PureComponent,
    Component,
} from 'react';

import {
    Image,
    ImageBackground,
    Text,
    KeyboardAvoidingView,
    CameraRoll,
    Platform,
    View,
    TouchableOpacity,
} from 'react-native';

//import * as launchImage from 'react-native-launch-image';
//import (引入) * (所有export属性) as (到) types (types变量) from (从) '../constants/ActionTypes' (ActionTypes)

import {
    TextInputIcon,
    ButtonChange,
    StyleSheetAdapt,
    Tools,
    HttpUrls,
    LocalStorage,
    BaseComponent,
    Progress,
    SlideMenuDrawer,
    JPush,
    Media,
    ImageBrower,
    ImageViewWatermark,
    HotUpdate,
    HotUpdateCus,
    TextIcon,
    ProgressBarApi,
    Alert,
    ImageViewApi,
} from "com";
import {
    SplashScreen,
}from "comThird";
import MenuSlide from "./MenuSlide";
import {Service} from "./Service";

import Loading from "react-native-kactivityindicator";
import DeviceInfo from "react-native-device-info";
import TextInputAuto from "react-native-autocomplete-input";

const dismissKeyboard = require('dismissKeyboard');//react-native自带

type Props = {};
export default class PageLogin extends BaseComponent<Props> {

    /* // 配置页面导航选项
     static navigationOptions = ({navigation}) => ({
         header:null,
     });*/

    onceExe = true;

    constructor(props) {
        super(props);//这一句不能省略，照抄即可

        Tools.page = this;
        //console.info("PageLogin","PageLogin");

        this.executing = false;

        this.state = {
            countListHistory:[],
            showResults:false,
            isOpen: false,
            selectedItem: '',

            count: '',
            password:'',

            // count: '13602447237',//郑浩元
            // password:'19920623',//郑浩元

            // count: '17602870417',// 杨觅劲
            // password:'19900511',//杨觅劲

            //count: '13811999727',//安得利
            //password:'19840515',//安得利

            // count: '15915899123', //登录时账户、手机号 王平1 员工
            // password:'19841018', //密码 王平1

            // count: '15810715822', //登录时账户、手机号 门店运营中心 杨俏俏
            // password:'19860712', //密码  门店运营中心 杨俏俏

            // count: '17326120966',// 账户 陈双双
            // password: '19870502',//密码 陈双双

            // count: '13922715780',// 账户
            // password: '19770920',//密码

            //count: '15112133699', //登录时账户、手机号 赵丽平 分公司经理
            //password:'19840605', //密码 赵丽平

            // count: '18898639399', //登录时账户、手机号 营运中心级别 林岳亮
            // password:'19760812', //密码 营运中心级别 林岳亮

            versionTxt:Tools.app_config.versionTxt,//显示版本号
        }
    }

    onMenuItemSelected = (index,item) => {
        if(index > 0){
            this.setState({
                isOpen: false,
                selectedItem: index == 1 ? this.state.selectedItem : item,
            });
        }

        switch (index)
        {
            case 0:{
                // this.goPage('DrawerClose',{},false); // close drawer

                let url = item.indexOf("运营") > -1 ? HttpUrls.IPConfig.IP : HttpUrls.IPConfig.IPTest;
                LocalStorage.save(HttpUrls.IPConfig.namekey,url);

                this.onceExe = true;
                Tools.app_config.versionTxt = null;
                HttpUrls.urlSets = null;
                Tools.init();
                HttpUrls.getIP();

                this.setState({
                    isOpen: false,
                    selectedItem: index == 1 ? this.state.selectedItem : item,
                },()=>{this.getVersion()});
                break;
            }
            case 1:{
                // Http.getAddress(23.09863836095986,113.31420850684037)
                /*  Tools.openDoc(Http.destDownload + "/unzip/lx_yyt_app/assets/phone/res/images/bg.jpg");
                  return;*/
                Media.takeImage()
                    .then((results)=>{
                        // Tools.toast(JSON.stringify(results));
                        // alert(JSON.stringify(results));
                    });
                break;
            }
            case 2:{
                /* FileSystem.deleteDirOrFile(RNFS.MainBundlePath + "/assets/phone/res/images/bg.jpg")
                     .then(()=>{
                         RNFS.copyFile(Http.destDownload + "/unzip/lx_yyt_app/assets/phone/res/images/bg.jpg",
                             RNFS.MainBundlePath + "/assets/phone/res/images/bg.jpg")
                             .then(()=>{
                                 Tools.toast("success");
                             })
                             .catch(()=>{
                                 Tools.toast("error");
                             });
                     });

                 return;*/
                Media.takeVideo().then(results=>{
                    // alert(JSON.stringify(results));
                    // Http.upLoadFileToService([results.path]).then(results=>{
                    //     alert(JSON.stringify(results));
                    // });
                });
                // let path = "/Users/lx/Library/Developer/CoreSimulator/Devices/5F049077-A8BA-41FA-AB5F-D598E1BEE759/data/Containers/Data/Application/5B4DC6F8-8AD8-404A-8959-E2A5D96D602B/Documents/0B816A2B-1520-47E8-9B21-F0A82109FC37.jpg";

                // Tools.openDoc(path);
                /*IamgeWaterMark.markText(path,'任务：巡店任务-老店下店')
                    .then(src=>{
                       Tools.openDoc(src);
                    });*/

                break;
            }
            case 3:{
                // FileSystem.readDir()
                /* Tools.openDoc(RNFS.MainBundlePath + "/assets/phone/res/images/bg.jpg");
                 return;*/
                Media.pickImage(undefined,undefined,true)
                    .then((results)=>{

                        /*Http.upLoadFileToService([results.path])
                           .then(results=>{
                               console.info("results",results);
                       });*/
                        /* setTimeout(()=>{
                             console.info("results",results);
                             Tools.openDoc(results.path)
                         },400)*/
                        // Tools.openDoc(results.path);
                    });


                break;
            }
            case 4:{
                Media.pickVideo();

                /*Tools.imageViewWatermark.show(require('images/bg.jpg'),true,{
                    city:null,//城市名
                    cityCode:null,//城市代码
                    address:"fdsafdsafdsafdsafdsafdsa",//地址
                    lat:23.66656,//维度
                    lng:113.66655,//经度
                    timestamp:new Date().getTime(),
                }).then(results=>{
                    console.info("results",results);
                    // Tools.toast(JSON.stringify(results));
                });*/
                break;
            }
        }

        // BaseComponent.goPage('DrawerOpen'); // open drawer

    }

    updateMenuState(obj) {
        let state = {isOpen: obj};
        // console.info("obj",obj)
        obj = typeof (obj) == 'object' ? obj : state;
        this.setState(obj)
    }

    login(isShow = false){
        if(!this.executing){
            this.executing = true;
            // console.log("mima->"+this.state.password)
            Service.get(this.state.count == "123"
                ? '18898639399'
                : this.state.count,
                this.state.password == '123'
                    ? '19760812'
                    : this.state.password,
                isShow)
                .then((retJson) =>{

                    // HotUpdate.update.execute = true;
                    HotUpdateCus.update.execute = true;
                    HotUpdateCus.appID = Tools.userConfig.userInfo.id;

                    this.executing = false;
                    if(!isShow)
                    {
                        setTimeout(function () {
                            SplashScreen.hide();//关闭启动屏幕
                        },700);
                    }
                    // this.props.navigation.navigate("PageHome");
                    JPush.openAppCheck().then(result=>{
                    })
                        .catch(()=>{
                            this.goPage('PageHome');
                        });



                })
                .catch((err) =>{
                    this.executing = false;
                    // alert("err: " + JSON.stringify(err) + "\nisShow:" + isShow);
                    if(!isShow)
                    {
                        SplashScreen.hide();//关闭启动屏幕
                    }
                });

        }
    }

    getVersion(){
        const interval = setInterval(() => {
            if(Tools.app_config.versionTxt != null  && this.onceExe)
            {
                this.onceExe = false;
                clearInterval(interval);
                this.updateMenuState({versionTxt:Tools.app_config.versionTxt});

            }
            else if(!this.onceExe)
            {
                clearInterval(interval);
            }

        },50);

    }

    componentWillMount(){
        // console.info("Tools.cutLogin 1",Tools.cutLogin);



        /* const interval = setInterval(() => {

             if(Tools.userConfig.userInfo == ''
                 || (Tools.userConfig.userInfo != null && Tools.userConfig.userInfo.id == ''))
             {
                 clearInterval(interval);
                 SplashScreen.hide();//关闭启动屏幕
             }
             else if(Tools.userConfig.userInfo != null
                 && Tools.userConfig.userInfo != ''
                 && Tools.userConfig.userInfo.id != ''
                 && Tools.userConfig.userInfo.password != '')
             {
                 clearInterval(interval);
                 this.updateMenuState({count:Tools.userConfig.userInfo.count,password:Tools.userConfig.userInfo.password});

                 this.login(false);

             }

         },50);*/

        /*setTimeout(() => {
         clearInterval(interval);
         },200);*/
    }

    componentDidMount(){
        // 随便做点什么，包括可以用await去做异步调用。
        // SplashScreen.hide();//关闭启动屏幕
        //launchImage.hide();
        // Alert.alert();
        /*console.info("device getDeviceId","" + DeviceInfo.getDeviceId())*/
        // console.info("device getSystemVersion","" + DeviceInfo.getDeviceId());
        // console.info("device s","" + DeviceInfo.getSystemName());

        if(Tools.cutLogin){
            if(__DEV__){
                SplashScreen.hide();//关闭启动屏幕
            }

            let timeBool = true;
            let timeout = setTimeout(()=>{
                if(timeBool){
                    SplashScreen.hide();//关闭启动屏幕
                }
            },10000);

            const interval = setInterval(() => {
                // console.info("Tools.app_config.serviceConfig.closeVersion",Tools.app_config.serviceConfig.closeVersion);
                if(Tools.app_config.serviceConfig.closeVersion != null)
                {
                    timeBool = false;
                    let isClose = false;
                    let reason = "";
                    let version = DeviceInfo.getDeviceId().indexOf("iPad") > -1
                        ? "iPad-" + DeviceInfo.getVersion()
                        : "iPhone-" + DeviceInfo.getVersion();

                    if(Tools.app_config.serviceConfig.closeVersion.length > 0){
                        Tools.app_config.serviceConfig
                            .closeVersion.forEach((v,i,a)=>{
                            if(version == v.version){
                                isClose = true;
                                reason = v.reason;
                            }
                        });
                    }

                    // console.info("Tools.userConfig.userInfo",Tools.userConfig.userInfo);

                    if(!__DEV__&&isClose){
                        clearInterval(interval);
                        SplashScreen.hide();//关闭启动屏幕
                        // Loading.show(false,"抱歉运营通2.0暂不提供服务");
                        Loading.show(false,reason);
                    }
                    else
                    {
                        if(Tools.userConfig.userInfo == ''
                            || (Tools.userConfig.userInfo != null
                                && Tools.userConfig.userInfo.id == ''))
                        {
                            clearInterval(interval);
                            SplashScreen.hide();//关闭启动屏幕

                            this.updateMenuState({count:Tools.userConfig.userInfo.count,password:Tools.userConfig.userInfo.password});
                            // HotUpdate.update.execute = true;
                            HotUpdateCus.update.execute = true;
                        }
                        else if(Tools.userConfig.userInfo != null
                            && Tools.userConfig.userInfo != ''
                            && Tools.userConfig.userInfo.id != ''
                            && Tools.userConfig.userInfo.password != '')
                        {
                            clearInterval(interval);
                            this.updateMenuState({count:Tools.userConfig.userInfo.count,password:Tools.userConfig.userInfo.password});
                            // SplashScreen.hide();//关闭启动屏幕
                            HotUpdateCus.appID = Tools.userConfig.userInfo.id;
                            HotUpdateCus.update.execute = true;
                            this.login(false);

                            /*HotUpdate.checkUpdate(()=>{
                                HotUpdate.update.execute = true;
                                this.login(false);
                            },()=>{
                                SplashScreen.hide();//关闭启动屏幕
                            })*/

                        }
                    }
                }

            },50);
        }
        else
        {
            //console.info("Tools.cutLogin 2",Tools.cutLogin);
        }

        this.getVersion();

    }

    onPressItem(item){
        dismissKeyboard();
        this.setState(item);
    }

    renderItem = (item,tag,i)=>{
        // console.info("item",item);

        return(<TextIcon icon={item.userLogo}
                         frameStyle={styles.rowItem}
                         iconStyle={styles.imgIcon}
                         textStyle={styles.rowText}
                         onPress={()=>this.onPressItem(item)}
                         text={item.name + " " + item.count}/>);
    }

    onChangeText = (count)=>{

        if(typeof Tools.userConfig.userInfo == 'object'
            && Tools.userConfig.userInfo != null){

            let countListHistory = [];
            if(Tools.userConfig.userInfo.countListHistory){
                Tools.userConfig.userInfo.countListHistory
                    .forEach((v,i,a)=>{
                        if(v.count.indexOf(count) > -1){
                            countListHistory.push(v);
                        }
                    });

                this.setState({
                    count:count,
                    countListHistory:countListHistory,
                    showResults:true
                });
            }
            else {
                this.setState({count});
            }

            return;
        }
        this.setState({count});
    };

    onBlur = ()=>{
        const {countListHistory,count} = this.state;
        let obj = {
            showResults:false,
            password:''
        };
        for (let i = 0; i < countListHistory.length;i++){
            if(countListHistory[i].count == count){
                obj.password = countListHistory[i].password;
            }
        }

        this.setState(obj);
    };

    chkUpdate = ()=>{
        // ImageViewApi.show(["http://yyt.lexin580.com:8081/app_config/img/banner.gif"]);
        // Alert.alert("FF","dfsaf",null,null,"http://yyt.lexin580.com:8081/app_config/img/banner.gif");
        this.onMenuItemSelected(0,this.state.versionTxt.indexOf("门投") > -1 ? "运营" : "门投");
    }
    
    render() {

        const {countListHistory,showResults} = this.state;
        const menu = <MenuSlide onItemSelected={this.onMenuItemSelected}
                                versionTxt={this.state.versionTxt} />;


        return (
            <SlideMenuDrawer menu={menu}
                             isOpen={this.state.isOpen}
                             onChange={(isOpen) => this.updateMenuState(isOpen)}>

                <ImageBackground style={styles.backgroundImage}
                                 source={require('images/bg.jpg')}>

                    <TouchableOpacity onPress={()=>{ dismissKeyboard()}}
                                      activeOpacity={1}>
                        <Progress />

                        <ImageBrower />

                        <ImageViewWatermark/>

                        <View style={styles.logoImage} />

                        <KeyboardAvoidingView behavior={"padding"}
                                              style={styles.containerKeyboard}>

                            <TextInputAuto
                                inputContainerStyle={[styles.containerTAuto,styles.inputRowStyle]}
                                data={countListHistory}
                                renderItem={this.renderItem}
                                hideResults={!showResults}
                                listStyle={countListHistory.length > 7 ? styles.listStyle2 : styles.listStyle}
                                renderTextInput={(props)=> <TextInputIcon //style={styles.inputRowStyle}// keyboardType="number-pad"
                                    keyboardType={"numeric"}
                                    icon={require('images/user.png')}
                                    iconFrameStyle={styles.iconFrameStyle}
                                    iconStyle={styles.iconStyle}
                                    textInputStyle={styles.textInputStyle}
                                    value={this.state.count}
                                    onBlur={this.onBlur}
                                    onChangeText={this.onChangeText}
                                    placeholder={'账户'} />}
                            />

                            <TextInputIcon style={styles.inputRowStyle2}
                                           secureTextEntry={true}
                                           icon={require('images/password.png')}
                                           iconFrameStyle={styles.iconFrameStyle}
                                           iconStyle={styles.iconStyle}
                                           textInputStyle={styles.textInputStyle}
                                           value={this.state.password}
                                           onChangeText={(password) => this.setState({password})}
                                           placeholder={'密码'} />

                            <ButtonChange text={"登录"}
                                          style={styles.btnStyle}
                                          textStyle={styles.btnTextStyle}
                                          onPress={() => this.login(true)} />

                            <TouchableOpacity style={styles.versionStyle}
                                              onPress={this.chkUpdate}>
                                <Text style={styles.versionText}>
                                    {this.state.versionTxt}
                                </Text>
                            </TouchableOpacity>


                        </KeyboardAvoidingView>

                    </TouchableOpacity>



                </ImageBackground>

            </SlideMenuDrawer>
        );
    }
}

const styles = StyleSheetAdapt.create({
    listStyle2:{
        padding:5,
        borderRadius:10,
        height:280,
    },
    listStyle:{
        padding:5,
        borderRadius:10,
    },
    rowText:{
        marginLeft:5,
    },
    rowItem:{
        height:45,
        alignItems:"center",
    },
    imgIcon:{
        height:"35dw",
        width:35,
        borderRadius:17.5,
        resizeMode:"stretch",
    },
    containerTAuto:{
        borderWidth:0,
    },

    container: {
        flex: 1,
    },
    containerKeyboard: {
        justifyContent:'center',
        alignItems:'center',
    },
    backgroundImage:{
        flex:1,
        alignItems:'center',
        //width:null,
        //height:null,
        //不加这句，就是按照屏幕高度自适应
        //加上这几，就是按照屏幕自适应
        //resizeMode:Image.resizeMode.contain,
        //resizeMode:"contain",
        //祛除内部元素的白色背景
        //backgroundColor:'rgba(0,0,0,0)',
        //backgroundColor:'white',
    },
    logoImage:{
        width: 180,
        height: 180,
        marginTop:60,
        // resizeMode:Image.resizeMode.contain,
    },

    /**
     * 图标框样式
     */
    iconFrameStyle: {
        height:45,
        width:50,
        backgroundColor:'#FF6B01',
        //borderRadius:22.5,
        borderTopLeftRadius:30,
        borderBottomLeftRadius:30,
        borderBottomRightRadius:0,
        borderTopRightRadius:0,

    },
    /**
     * 图标样式
     */
    iconStyle:{
        height:30,
        width:30,
        marginTop:5,
        marginLeft:15,
        //resizeMode:Image.resizeMode.contain,
        resizeMode:"contain",
    },
    /**
     * 输入样式
     */
    textInputStyle:{

        height:45,
        width:250,
        backgroundColor:'white',
        //alignItems:'center',
        //justifyContent:'center',

        //marginTop:100,
        borderBottomRightRadius:40,
        borderTopRightRadius:40,
        paddingLeft:3,
        fontSize:20,

        // marginBottom:1,
        // 内容居中
        // textAlign:'center'
    },

    /**
     * 输入框样式。
     */
    inputRowStyle: {
        height:45,
        //width:300,
        justifyContent:'center',
        alignItems:'center',
        marginTop:200,
    },
    inputRowStyle2: {
        marginTop:20,
    },


    btnStyle:{
        height:45,
        width:300,
        marginTop:20,
        backgroundColor:'#FF6B01',
        justifyContent:'center',
        alignItems:'center',
        borderRadius:22.5
    },
    btnTextStyle:{
        color:'white',
        fontSize:20,
        fontWeight:'bold'
    },

    versionStyle:{
        marginTop:300,
        borderWidth:1,
        padding:10,
        paddingLeft:50,
        paddingRight:50,
        borderRadius:23,
        borderColor:"#5b5b5b",
        justifyContent:'center',
        alignItems:'center',
    },
    versionText:{
        fontSize:20,
        color:"#5b5b5b",
    },

});
