import {
    Tools,
    Http,
    HttpUrls,
    LocalStorage,
    JPush,
} from "com-api";
import DeviceInfo from 'react-native-device-info';

/**
 * 登陆页接口处理
 * **/
export class Service {
    /**
     * 登陆
     * @param username string,//用户名
     * @param password string,//密码
     * @param isShow bool,//是否显示加载条，true:显示，false：不显示
     * **/
    static get(username, password,isShow) {

        /*return new Promise(function (resolve, reject) {
            Http.post(HttpUrls.urlSets.urlLogin, {
                username: username,
                password: password
            })
                .then((retJson) => {

                    Tools.userConfig.token = retJson.retData.token;

                    Http.post(HttpUrls.urlSets.urlLoginInfo, {}).then((retJson) => {

                        retJson.retData["token"] = Tools.userConfig.token;
                        retJson.retData["count"] = username;
                        retJson.retData["password"] = password;
                        retJson.retData["id"] = retJson.retData.userid;
                        retJson.retData["full_name"] = retJson.retData.username;
                        retJson.retData["position_name"] = retJson.retData.position;
                        retJson.retData["department_id"] = retJson.retData.framework_id;
                        retJson.retData["isDoorInvest"] = Tools.isDoorInvest(retJson.retData.framework_id);
                        retJson.retData["department_name"] = retJson.retData.framework_name;
                        retJson.retData.phone = retJson.retData.isDoorInvest ? Tools.strReplaceOperate.replace(retJson.retData.phone, 3, 7) : retJson.retData.phone;

                        resolve(retJson.retData);

                    })
                        .catch((status) => {
                            reject(status);
                        });

                })
                .catch((status) => {
                    reject(status);
                });
        });*/

        return  new Promise(function (resolve, reject){
            Http.post(HttpUrls.urlSets.urlLogin, {
                username: username,
                password: password
            },isShow)
                .then((retJson) => {
                    //alert(JSON.stringify(retJson))
                    Tools.userConfig.token = retJson.retData.token;

                    Http.post(HttpUrls.urlSets.urlLoginInfo)
                        .then((retJson) => {

                            let has = true;
                            if(typeof Tools.userConfig.userInfo == 'object'
                                && Tools.userConfig.userInfo != null)
                            {

                                retJson.retData["countListHistory"] = Tools.userConfig.userInfo.countListHistory
                                    ? Tools.userConfig.userInfo.countListHistory
                                    : [];
                            }
                            else {
                                retJson.retData["countListHistory"] = [];
                            }

                            for(let i = 0; i < retJson.retData.countListHistory.length; i ++){
                                if(retJson.retData.countListHistory[i].count == username){
                                    has = false;
                                    retJson.retData.countListHistory[i].password = password;
                                    retJson.retData.countListHistory[i].name = retJson.retData.username;
                                    retJson.retData.countListHistory[i].userLogo = retJson.retData.picture;
                                }
                            }

                            if(has){
                                retJson.retData.countListHistory.push({
                                    password:password,
                                    name:retJson.retData.username,
                                    userLogo:retJson.retData.picture,
                                    count:username
                                });
                            }

                            retJson.retData["token"] = Tools.userConfig.token;
                            retJson.retData["count"] = username;
                            retJson.retData["password"] = password;
                            retJson.retData["id"] = retJson.retData.userid;
                            retJson.retData["full_name"] = retJson.retData.username;
                            retJson.retData["position_name"] = retJson.retData.position;
                            retJson.retData["department_id"] = retJson.retData.framework_id;
                            retJson.retData["isDoorInvest"] = Tools.isDoorInvest(retJson.retData.framework_id);
                            retJson.retData["department_name"] = retJson.retData.framework_name;
                            //department_level:1、运营中心；2、大区；3、省区（个人）
                            retJson.retData.phone = retJson.retData.isDoorInvest
                                ? Tools.replaceStr(retJson.retData.phone, 3, 7)
                                : retJson.retData.phone;

                            Tools.userConfig.userInfo = retJson.retData;
                            LocalStorage.save(Tools.userConfig.namekey,
                                Tools.userConfig.userInfo);

                            let tags = [DeviceInfo.getVersion()].concat(Tools.userConfig.userInfo.tags);
                            Tools.userConfig.userInfo.tags = tags;

                            Tools.userConfig.userCutAccount = Tools.userConfig.userInfo.userCutAccount;

                            Tools.userConfig.userCutAccount
                                .forEach((v,i,a)=>{
                                    v.id_parent = Tools.userConfig.userInfo.id;
                                    v.id_child = v.userId;
                                });
                            JPush.startJPush(Tools.userConfig.userInfo.id,Tools.userConfig.userInfo.tags);


                            resolve(retJson.retData);

                        })
                        .catch((status) => {
                            reject(status);
                        });

                })
                .catch((status) => {
                    reject(status);
                });
        });


    }


}