/**
 * Created by Administrator on 2018/6/16.
 */
import React, {Component} from 'react';
import {
    Platform,
    Image,
} from 'react-native';
import {
    StyleSheetAdapt,
    Theme,
    BaseComponent,
} from 'com';
import {
    TabNavigator,
    TabBarBottom,
} from 'comThird';

import PageHomes from './pageHomes/PageHomes';
import PageMines from "./pageMines/PageMines";
import PageTask from "./pageTask/PageTask";
import PageApplys from "./pageApplys/PageApplys";
import PageCustomeres from "./pageCustomer/PageCustomer";


const styles = StyleSheetAdapt.create({
    iconTab:{
        width:40,
        height:40,
        resizeMode:"contain",
    },
    iconLeft:{
        width:25,
        height:25,
        resizeMode:"contain",
        marginLeft:20,
    },
});

const TabRouteConfigs = {
    PageHomes: {
        screen: PageHomes,
        // screen:PageHome,
        // screen: PageInform,
        navigationOptions: ({navigation}) => ({
            title:'首页',
            tabBarLabel: '首页',
            tabBarIcon: ({focused, tintColor}) => (
                <Image
                    // tintColor={tintColor}
                    focused={focused}
                    style={[styles.iconTab,{
                        // tintColor:tintColor
                    }]}
                    source={focused ? require('./../../res/images/homeActive.png')
                        : require('./../../res/images/home.png')}
                />
            ),
        }),
    },
    PageTask: {
        screen: PageTask,
        navigationOptions: {
            // title: '任务',
            // swipeEnabled:false,
            tabBarLabel: '任务',
            tabBarOnPress:(opt)=>{
                if(BaseComponent.tabIndex === 0){
                    BaseComponent.tabIndex = null;
                    BaseComponent.goPage("PageIndex");
                }else{
                    opt.defaultHandler();
                }
            },
            tabBarIcon: ({focused, tintColor}) => (
                <Image
                    // tintColor={tintColor}
                    focused={focused}
                    style={[styles.iconTab,{
                        // tintColor:tintColor
                    }]}
                    source={focused ? require('./../../res/images/taskActive.png')
                        : require('./../../res/images/task.png')}
                />
            ),
        },
    },
    PageCustomeres: {
        // screen: PageHome,
        screen: PageCustomeres,
        navigationOptions: {
            title: '客户',
            tabBarLabel: '客户',
            tabBarOnPress:(opt)=>{
                opt.defaultHandler();
            },
            tabBarIcon: ({focused, tintColor}) => (
                <Image
                    // tintColor={tintColor}
                    focused={focused}
                    style={[styles.iconTab,{
                        // tintColor:tintColor
                    }]}
                    source={focused ? require('./../../res/images/customerActive.png')
                        : require('./../../res/images/customer.png')}
                />
            ),
        },

    },
    PageApplys: {
        screen: PageApplys,
        navigationOptions: {
            // title: '工具',
            tabBarLabel: '应用',
            tabBarOnPress:(opt)=>{
                opt.defaultHandler();
            },
            tabBarIcon: ({focused, tintColor}) => (
                <Image
                    // tintColor={tintColor}
                    focused={focused}
                    style={[styles.iconTab,{
                        // tintColor:tintColor
                    }]}
                    source={focused ? require('./../../res/images/applyActive.png')
                        : require('./../../res/images/apply.png')}
                />
            ),
        },
    },
    PageMines: {
        screen: PageMines,
        // screen: PageGoodsKnowledge,
        navigationOptions: {
            // title: '我的',
            tabBarLabel: '我的',
            tabBarIcon: ({focused, tintColor}) => (
                <Image
                    // tintColor={tintColor}
                    focused={focused}
                    style={[styles.iconTab,{
                        // tintColor:tintColor
                    }]}
                    source={focused ? require('./../../res/images/mineActive.png')
                        : require('./../../res/images/mine.png')}
                />
            ),
        },

    },
}

const TabNavigatorConfigs = {
    // initialRouteName: 'PageHome',getOnPress
    tabBarComponent: TabBarBottom,
    // tabBarComponent: props => <TabBarBottom {...props}/>,
    tabBarPosition: 'bottom',
    lazy: true,
    swipeEnabled:false,
    animationEnabled:true,
    // backBehavior: 'none', // 按 back 键是否跳转到第一个Tab(首页)， none 为不跳转
    tabBarOptions:{
        activeTintColor:Theme.Colors.themeColor,
        activeBackgroundColor:Theme.Colors.themeColorLight,//激活 活动标签的背景颜色
        style:{
            height:StyleSheetAdapt.getHeight(Theme.Height.heightGuideBottom),
            alignItems: "center",
            justifyContent: "center",
            // backgroundColor:"#f8f1f3",
            backgroundColor:Theme.Colors.foregroundColor,
            // background:"rgba(0, 0, 0, 0)",
        },
        labelStyle:{
            flex:1,
            fontSize:StyleSheetAdapt.getWidth(22),
            // backgroundColor:"red",
            marginLeft:0,

        },
        tabStyle:{
            flexDirection: 'column',
            // backgroundColor:"yellow",
            alignItems: "center",
            justifyContent: "center",
        },
    }
};

const pages = TabNavigator(TabRouteConfigs, TabNavigatorConfigs);

module.exports = pages;