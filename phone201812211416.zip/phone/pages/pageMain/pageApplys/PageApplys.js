/**
 * Created by Administrator on 2018/4/30.
 */
import {
    Theme
} from "com";
import {
    TabNavigator,
} from "comThird";
import PageStudyCenter from './pageStudyCenter/PageStudyCenter';
import PageGoodsDynamic from './pageGoodsDynamic/PageGoodsDynamic';
import PageResultAnalyze from './pageResultAnalyze/PageResultAnalyze';
import PageApply from "./pageApply/PageApply";

/**
 * 工具页面页面 引入集合
 **/
const TabRouteConfigs = {
    PageApply: {
        screen: PageApply,
        navigationOptions: {
            title:'应用',
            tabBarLabel : '应用',
        },
    },
    PageStudyCenter: {
        screen: PageStudyCenter,
        navigationOptions: {},
    },
    PageGoodsDynamic: {
        screen: PageGoodsDynamic,
        navigationOptions: {},
    },
    PageResultAnalyze: {
        screen: PageResultAnalyze,
        navigationOptions: {},
    },
   /* PageSynergyWork: {
        screen: PageSynergyWork,
        navigationOptions: {},
    },*/
    /*PageReportAnalyze: {
        screen: PageReportAnalyze,
        navigationOptions: {},
    },*/
}

/*const TabNavigatorConfigs = {
    initialRouteName: 'PageApply',
    tabBarComponent: props => <View >
        <ScrollView horizontal={true}>
            <TabBarTop {...props}/>
        </ScrollView>
    </View>,
    tabBarPosition: 'top',
    lazy: true,
    swipeEnabled:false,
    animationEnabled:true,
    // backBehavior: 'none', // 按 back 键是否跳转到第一个Tab(首页)， none 为不跳转
    tabBarOptions:{
        activeTintColor:"#FF6B01",
        inactiveTintColor:'#000000',
        style:{
            // height:StyleSheetAdapt.getHeight(60),
            height:0,
            backgroundColor:Theme.Colors.backgroundColor,
        },
        labelStyle:{
            // flex:1,
            fontSize:StyleSheetAdapt.getWidth(22),
            // width:StyleSheetAdapt.getWidth(150),

        },
    }
};*/

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);


module.exports = pages;