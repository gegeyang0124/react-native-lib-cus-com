/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    ViewTitle,
    BaseComponent,
    ScrollViewRowList,
    Theme,
    StyleSheetAdapt,
    Tools,
} from "com";

import {Service} from './Service';
// import TouchID from 'react-native-touch-id'

type Props = {};
export default class  extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.state = {
            textToast:0,
            dataList:[
                {
                    text:'学习中心',
                    row: [
                        {icon: require("images/1111.png"), text: "1111工程",
                            onPress:() => {
                                this.goPage("PageProj1111");
                            }},
                        {icon: require("images/fightPlan.png"), text: "争锋计划",
                            imageFrameStyle:styles.imageFrame,
                            onPress:() =>{
                                this.goPage("PageFightPlan");
                            }},
                        {icon: require("images/goodsKnowledge.png"), text: "商品知识",
                            isProgress:true,onPress:() =>{
                                this.goPage("PageGoodsKnowledge");
                            }},
                        {icon: require("images/businessCollege.png"), text: "应知应会",
                            imageFrameStyle:styles.imageFrame,
                            iconToast:require('images/readNo.png'),
                            textToast:0,
                            onPress:() =>{
                                this.goPage("PageShouldKnows");
                            }}
                    ]
                },
                {
                    text:'商品动态',
                    row: [
                        {icon: require("images/goodsNew.png"), text: "新品推荐",
                            onPress:() =>{
                                this.goPage("PageGoodsNewRecommend");
                            }},
                        {icon: require("images/goodsHot.png"), text: "爆款推荐",
                            imageFrameStyle:styles.imageFrame,onPress:() =>{
                                this.goPage("PageGoodsHotRecommend");
                            }},
                        {icon: require("images/goodsImportant.png"), text: "重点推荐",
                            onPress:() =>{
                                this.goPage("PageGoodsImportantRecommend");
                            }},
                        {icon: require("images/goodsPromotion.png"), text: "促销活动",
                            imageFrameStyle:styles.imageFrame,onPress:() =>{
                                this.goPage("PageGoodsPromotion");
                            }},
                    ]
                },
                {
                    text:'报表分析',
                    row: [
                        {icon: require("images/resultOrder.png"), text: "业绩进度",
                            onPress:() => {
                                if(Tools.userConfig.userInfo.department_level == 1){
                                    this.goPage("PageResultAnalyzeProgressCenter");
                                    // this.goPage("PageResultAnalyzeProgressAreaProvince");
                                }
                                else if(Tools.userConfig.userInfo.department_level == 2){
                                    this.goPage("PageResultAnalyzeProgressAreaRegions");
                                }
                                else {
                                    this.goPage("PageResultAnalyzeProgressAreaProvince2", {
                                            id:Tools.userConfig.userInfo.department_id,
                                            name:Tools.userConfig.userInfo.department_name
                                        }
                                    );
                                }

                            }},
                        {icon: require("images/resultDiagnose.png"), text: "诊断报告",
                            imageFrameStyle:styles.imageFrame,onPress:() =>{
                                this.goPage("PageResultAnalyzeDiagnose");
                            }},
                        {icon: require("images/taskAnalyze.png"), text: "巡店分析",
                            onPress:() =>{
                                if(Tools.userConfig.userInfo.department_level < 3){
                                    this.goPage("PageResultAnalyzeGuide");
                                }
                                else {
                                    this.goPage("PageResultAnalyzeGuideProvince",{});
                                }
                            }},
                        {icon: require("images/customerAnalyze.png"), text: "客户分析",
                            imageFrameStyle:styles.imageFrame,onPress:() =>{
                                Tools.toast("功能完善中，敬请期待！");
                                //this.goPage("PageResultAnalyzeCustomer");
                            }}
                    ]
                },
               /* {
                    text:'店铺工具',
                    row: [
                        {icon: require("images/dailyPaper.png"), text: "陈列诊断",
                            onPress:() =>{
                                // this.goPage("PageMine");
                                /!* //config is optional to be passed in on Android
                                 const optionalConfigObject = {
                                     title: "Authentication Required", // Android
                                     color: "#e00606", // Android,
                                     failbackLabel: "Show Passcode" // iOS (if empty, then label is hidden)
                                 };
                                 TouchID.authenticate('to demo this react-native component', optionalConfigObject)
                                     .then(success => {
                                         // Success code
                                         alert(JSON.stringify(success));
                                     })
                                     .catch(error => {
                                         // Failure code
                                         alert(JSON.stringify(error));
                                     });*!/
                            }},
                        {icon: require("images/weeklyPaper.png"), text: "商品结构诊断",
                            imageFrameStyle:styles.imageFrame,onPress:() =>{

                            }},
                        {icon: require("images/monthlyPaper.png"), text: "商品资质查询",
                            onPress:() =>{

                            }},
                        {icon: require("images/customerFeedback.png"), text: "商品信息查询",
                            imageFrameStyle:styles.imageFrame,onPress:() =>{

                            }}
                    ]
                }*/
                /*{
                    text:'工作汇报',
                    row: [
                        {icon: require("images/dailyPaper.png"), text: "日报",onPress:() =>{
                                // this.goPage("PageMine");
                            }},
                        {icon: require("images/weeklyPaper.png"), text: "周报",onPress:() =>{

                            }},
                        {icon: require("images/monthlyPaper.png"), text: "月报",onPress:() =>{

                            }}
                    ]
                },*/
                /* {
                     text:'协同办公',
                     row: [
                         {icon: require("images/customerFeedback.png"), text: "客户反馈",onPress:() =>{
                                 this.goPage('PageCustomerFeedback');
                             }},
                         {icon: require("images/customerComplaint.png"), text: "客户投诉",onPress:() =>{
                                 this.goPage("PageCustomerComplaint");
                             }},
                         {icon: require("images/questionnaire.png"), text: "调查问卷",onPress:() =>{
                                 this.goPage("PageSurveyPSQ");
                             }}
                     ]
                 }*/
            ]
        };
    }

    getData(){

        Service.getMyCourse(Tools.userConfig.userInfo.phone)
            .then(retJson=>{

                let {dataList} = this.state;
                let retObj = {
                    dataList:[]
                };

                dataList.forEach((v,i,a)=>{

                     v.row.forEach((v1,i1,a1)=>{
                         if(v1.text == "应知应会"){
                             v1.textToast = retJson.unlearnedNumber;
                         }
                     });

                    retObj.dataList.push(v);
                });

                this.setState(retObj);
            });
    }

    componentDidMount() {
        this.getData();
    }

    renderView = (item,index)=>{

        return (
            <ScrollViewRowList key={index}
                               frameStyle={styles.frameStyle}
                               imageFrameStyle={styles.imageFrameStyle}
                               isScroll={false}
                               text={item.text}
                               dataList={item.row}/>
        );
    }

    render() {

        const {dataList} = this.state;

        return (
            <ViewTitle isDefaultOnPressLeft={false}
                       isNavigator={false}>
                {
                    dataList.map(this.renderView)
                }
            </ViewTitle>
        );
    }
}
const styles = StyleSheetAdapt.create({
    frameStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
    imageFrame:{
        paddingTop:20,
        paddingBottom:20,
        backgroundColor:Theme.Colors.themeColorLight,
    },
    imageFrameStyle:{
        //width:200,
        //height:200,
    },
});
