import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     * 获取我的课程
     * **/
    static getMyCourse(val){
        return Http.get(HttpUrls.urlSets.urlMyCourse,{
            phone:val
        },false)
            .then(retJson=>retJson.retData);
    }

    /**
     * 读取学习中心进度
     * **/
    static get(){
        return Http.post(HttpUrls.urlSets.urlSchoolStudyProgress)
            .then(retJson=>{
                //0：1111工程 1：争锋计划 2：商品知识 3：应知应会
                let retObj = {
                    progress:[
                        {
                            progress:0,//类型：String  必有字段  备注：无
                            moduleId:"0" //0：1111工程
                        },
                        {
                            progress:0,//类型：String  必有字段  备注：无
                            moduleId:"1" //0：1111工程
                        },
                        {
                            progress:0,//类型：String  必有字段  备注：无
                            moduleId:"2" //0：1111工程
                        },
                        {
                            progress:0,//类型：String  必有字段  备注：无
                            moduleId:"3" //0：1111工程
                        }
                    ]//小数 进度 4个 与UI顺序一致
                };

                retObj.progress.forEach((v,i,a)=>{
                    retJson.retData.forEach((v1,i1,a1)=>{
                        if(v1.moduleId == v.moduleId){
                            v.progress = parseFloat(v1.progress);
                            v.progress = parseInt(v.progress * 1000) / 1000;
                        }
                    });
                });

                // console.info("retObj.progress:",retObj.progress);
                return retObj.progress;
            });
    }

}
