/**
 * Created by Administrator on 2018/5/5.
 */

import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird';
import PageGoodsNewRecommend from "./pageGoodsNewRecommend/PageGoodsNewRecommend";
import PageGoodsHotRecommend from "./pageGoodsHotRecommend/PageGoodsHotRecommend";
import PageGoodsImportantRecommend from "./pageGoodsImportantRecommend/PageGoodsImportantRecommend";
import PageGoodsPromotion from "./pageGoodsPromotion/PageGoodsPromotion";
import PageGoodsDetail from "./pageGoodsDetail/PageGoodsDetail";
import PageBuyShopsCar from "./pageBuyShopsCar/PageBuyShopsCar";
import PageSettleAccounts from "./pageSettleAccounts/PageSettleAccounts";

/**
 * 商品动态页面 引入集合
 **/
const TabRouteConfigs = {
    PageGoodsNewRecommend: {
        screen: PageGoodsNewRecommend,
        navigationOptions: {
            title:'新品推荐',
            tabBarLabel : '新品推荐',
        },

    },
    PageGoodsHotRecommend: {
        screen: PageGoodsHotRecommend,
        navigationOptions: {
            title:'爆款推荐',
            tabBarLabel : '爆款推荐',
        },

    },
    PageGoodsImportantRecommend: {
        screen: PageGoodsImportantRecommend,
        navigationOptions: {
            title:'重点推荐',
            tabBarLabel : '重点推荐',
        },

    },
    PageGoodsPromotion: {
        screen: PageGoodsPromotion,
        navigationOptions: {
            title:'促销活动',
            tabBarLabel : '促销活动',
        },

    },
    PageGoodsDetail: {
        screen: PageGoodsDetail,
        navigationOptions: {
            title:'商品详情',
            tabBarLabel : '商品详情',
        },
    },
    PageBuyShopsCar: {
        screen: PageBuyShopsCar,
        navigationOptions: {
            title:'购物车',
            tabBarLabel : '购物车',
        },
    },
    PageSettleAccounts: {
        screen: PageSettleAccounts,
        navigationOptions: {
            title:'结算',
            tabBarLabel : '结算',
        },
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;