/**
 * Created by Administrator on 2018/5/6.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    Theme,
    BaseComponent,
    Tools,
    ItemRowBuyCar,
    TextChange,
    ViewTitle,
    FlatListView,
} from "../../../../../component/component";
import {
    CheckBox
} from "../../../../../componentThird/component";

import {Service} from './Service';

type Props = {};
export default class PageBuyShopsCar extends BaseComponent<Props> {

    execFirst = true;
    guideTextRight:TextChange;

    constructor(props) {
        super(props);

        this.state = {
            dataList:[],//数组列表
            isInput:false,//是否输入
            total:0,//商品总数
            moneyTotal:0,//合计
            isChecked:false,//是否全选
            // textGuideRight:'编辑',//导航栏右边按钮文本
        }

        this.setParams({
            headerLeft: true,
            headerLeftHandle:()=>{
                this.execFirst = true;
            },
            headerRight:<TextChange text={'编辑'}
                                    onExportThis={(self)=>{
                                        this.guideTextRight = self;
                                    }}
                                    onPress={()=>this.onGuideRightPress()}
                                    style={styles.guideRightFrame}
                                    textStyle={styles.guideRightText}/>
        });
    }

    getMoneyTotal(){
        let moneyTotal = 0;
        this.state.dataList.forEach((v,i,a)=>{
            if(v.isChecked)
            {
                moneyTotal += v.amount * v.quote_price;
            }
        });

        moneyTotal = parseInt(moneyTotal * 100) / 100;
        return moneyTotal;
    }

    //验证订单数量
    verifyOrderNum(text,item) {

        var reg = /^[1-9][0-9]*$/;

        if(!reg.test(text)){
            Tools.toast("请填写数字");
            text = item.amount;
            return;
        }

        let val = parseInt(text);
        if(val < item.min_order_qty){
            Tools.toast("抱歉，下单数量，不得低于订单下限！");
            return;
        }else {
            item.amount = val;
        }

        var c = item.amount % item.min_order_qty;

        if(c != 0){
            Tools.toast("抱歉，下单数量，需是最小订货量的倍数！");
            item.amount = item.amount - c;
            return;
        }

        item.text = item.amount;
        return item;
    }

    onCheckBoxViewBottom(isChecked){

        if(isChecked)
        {
            this.state.dataList.forEach((v,i,a)=>{
                v.isChecked = true;
            });
        }
        else
        {
            this.state.dataList.forEach((v,i,a)=>{
                v.isChecked = false;
                // moneyTotal += v.amount * v.quote_price;
            });
        }

        this.setState({
            dataList:this.state.dataList,
            moneyTotal:this.getMoneyTotal(),
            isChecked:isChecked,
        });
    }

    onGuideRightPress(){
        let isInput = !this.state.isInput;
        this.setState({
            isInput:isInput,
            dataList:this.state.dataList,
            // textGuideRight:isInput ? '完成' : '编辑'
        });
        this.guideTextRight.setText((isInput ? '完成' : '编辑'));

       if(!isInput)
       {
           let productList = [];
           this.state.dataList.forEach((v,i,a)=>{
               productList.push({
                   productNumber:v.product_code,//产品id
                   productAmount:v.amount//产品预订数量
               });
           })

           Service.addOrderProductAmount(productList)
       }
    }

    onPressChecked(isChecked,index){
        // alert(index);
        let isCheckedTotal = true;
        this.state.dataList[index].isChecked = isChecked;
        this.state.dataList.forEach((v,i,a)=>{
            if(!v.isChecked)
            {
                isCheckedTotal = false;
            }
        });
        this.setState({
            dataList:this.state.dataList,
            moneyTotal:this.getMoneyTotal(),
            isChecked:isCheckedTotal,
        });
    }

    onTextChanged(text,item,index,self){
        item = this.verifyOrderNum(text,item);
        this.state.dataList[index] = item;
        // alert(item.amount);
        self.setText(item.text + '');

    }

    onPressRight1(item,index,self){
        let text = parseInt(item.amount) - parseInt(item.min_order_qty);
        item = this.verifyOrderNum(text,item);
        this.state.dataList[index] = item;
        // alert(item.amount);
        self.setText(item.text + '');
    }

    onPressRight2(item,index,self){
        let text = parseInt(item.amount) + parseInt(item.min_order_qty);
        item = this.verifyOrderNum(text,item);
        this.state.dataList[index] = item;
        // alert(item.amount);
        self.setText(item.text + '');
    }

    onPressAccount(){
        this.execFirst = true;
        let params = {
            dataList:[],//数组列表
            moneyTotal:this.state.moneyTotal,//合计
            isInput:false,//是否输入
            total:0,//商品总数
            isChecked:false//是否全选
        };
        this.state.dataList.forEach((v,i,a)=>{
            if(v.isChecked)
            {
                v.index = params.dataList.length;
                params.dataList.push(v);
            }
        });

        if(params.dataList.length == 0)
        {
            Tools.toast("请选择商品");
            return;
        }

        this.goPage("PageSettleAccounts",params);
    }

    onItemPress(item){
        // alert(item.product_code)
        this.goPage("PageGoodsDetail",{product_code:item.product_code});
        // Tools.toast(JSON.stringify(item))
    }

    renderItem(item,index) {
        return (
            <ItemRowBuyCar id={index}
                           isChecked={item.isChecked}
                           icon={{uri:item.product_picturepath}}
                           onPressChecked={(isChecked)=>this.onPressChecked(isChecked,index)}
                           onTextBlur={(text,self)=>{this.onTextChanged(text,item,index,self)}}
                           onPressLeft={() => this.onItemPress(item)}
                           onPressCenter={() => this.onItemPress(item)}
                           onPressRight1={(self)=>this.onPressRight1(item,index,self)}
                           onPressRight2={(self)=>this.onPressRight2(item,index,self)}
                           valueInput={'' + item.amount}
                           isInput={this.state.isInput}
                           text1_1={item.product_name}
                           text4_1={"￥" + item.quote_price}
                           textRight={"x" + item.amount}/>
        );
    }

    getData(){

        Service.get(true).then((retJson)=>{
            // this.guideTextRight.setText((this.state.isInput ? '完成' : '编辑'));
            this.setState({
                isInput:false,//是否输入
                total:0,//商品总数
                moneyTotal:0,//合计
                isChecked:false,//是否全选
                dataList:retJson.retListData
            });
        });
    }

    componentWillMount(){

        // this.getData();
    }

    render() {

        if(this.execFirst)
        {
            this.execFirst = false;
            this.getData();
        }

        return (
            <ViewTitle isScroll={false}
                       viewBottom={
                           <View style={styles.viewBottomFrame}>

                               <View style={styles.viewBottomFrame1}>
                                   <CheckBox rightText={"全选"}
                                             isChecked={this.state.isChecked}
                                             onClick={(isChecked)=>this.onCheckBoxViewBottom(isChecked)}
                                             rightTextStyle={styles.viewBottomFrameTextLeft}
                                             checkBoxColor={Theme.Colors.themeColor}/>
                               </View>

                               <View style={styles.viewBottomFrame2}>

                                   <View style={styles.viewBottomFrame2_1}>
                                       <Text style={styles.viewBottomFrameTextLeft}>合计：</Text>
                                       <Text style={[styles.viewBottomFrameTextLeft,styles.viewBottomFrameTextRight]}>
                                           ￥{this.state.moneyTotal}
                                       </Text>
                                   </View>

                                   <TextChange style={styles.viewBottomFrameBtnRightFrame}
                                               onPress={()=>this.onPressAccount()}
                                               text={"结算"}/>
                               </View>

                           </View>
                       }>

                <FlatListView
                    data={this.state.dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,item.index)}
                    // onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    guideRightText:{
        color:"#FFFFFF",
        fontWeight:'bold',
    },
    guideRightFrame:{
        marginRight:20,
    },

    viewBottomFrame:{
        flexDirection:'row',
        justifyContent:'space-between',
        marginBottom:10,
    },
    viewBottomFrame1:{
        marginLeft:30,
    },
    viewBottomFrame2:{
        flexDirection:'row',
        marginRight:30,
        alignItems:"center",
        justifyContent:'center',
    },
    viewBottomFrame2_1:{
        flexDirection:'row',
    },
    viewBottomFrameTextLeft:{
        fontSize:Theme.Font.fontSize,
    },
    viewBottomFrameTextRight:{
        color:Theme.Colors.themeColor,
    },
    viewBottomFrameBtnRightFrame:{
        marginLeft:20,
        width:150,
        height:40,
        borderRadius:10,
        backgroundColor:Theme.Colors.backgroundColorBtn,
    },
});