import {
    Http,
    HttpUrls,
    Tools,
} from "./../../../../../component/api/api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级品类
            type2:'',//下拉选中值 二级品类
            type3:'',//下拉选中值 三级品类
            name:'',//商品名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取购物车列表
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(init) {

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        return Http.post(HttpUrls.urlSets.urlInfoGetOrderCarList,{},init)
            .then((retJson) => {

                this.base.retJson.total = retJson.retData.length;
                if(retJson.retData == undefined || retJson.retData.length == 0)
                {
                    retJson.retData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                // alert(JSON.stringify(retJson));
                retJson.retData.forEach((val,i,arr) =>{
                    val.isChecked = false;
                    val.index = i;
                    if(val.amount < val.min_order_qty)
                    {
                        val.amount = val.min_order_qty;
                    }
                    this.base.retJson.retListData.push(val);
                });

                // this.base.retJson.retListData.concat(retJson.retListData);
                // console.info("base:",this.base);
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }

    /**
     * 获取商品类别
     * @param goodsParentType int,//商品父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    static getGoodsTypes(goodsParentType,type){

        return Http.post(HttpUrls.urlSets.urlInfoProductTypeList, {parent_type_code:goodsParentType},false)
            .then((retJson) => {

                let types = {
                    keyList:[(type == 0
                        ? "一"
                        : type == 1
                            ? '二'
                            : type == 2
                                ? '三'
                                : '')
                    + "级品类"],
                    keyValPair:{},
                    clearDrop:false,
                };

                if(retJson.retListData == undefined)
                {
                    retJson.retListData = [];
                }
                else
                {
                    types.keyValPair[types.keyList[0]] = '';
                }

                retJson.retListData.forEach((val,i,arr) =>{
                    types.keyList.push(val.type_name);
                    types.keyValPair[val.type_name] = val.type_code;

                });



                return types;

            });
    }

    /**
     * 添加所购产品的数量
     * **/
    static addOrderProductAmount(productList){

       /* var item = {
            productNumber:'',//产品id
            productAmount:''//产品预订数量
        };*/

        Http.post(HttpUrls.urlSets.urlInfoAddOrderToCar2,{
            productList:productList
        }).then((retJson)=>{
            Tools.toast("提交成功！");
            return retJson;
        });
    }
}