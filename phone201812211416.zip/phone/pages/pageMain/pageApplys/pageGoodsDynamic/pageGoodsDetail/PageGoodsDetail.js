import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
} from "com";
import { Service } from "./Service";

/**
 * 促销活动
 * **/
type Props = {};
export default class PageGoodsDetail extends BaseComponent<Props> {

    execFirst = true;

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            product_code:this.getPageParams().product_code,//产品编码
            dataObj:{
                textList:[],//文本数组列表
                pictures:[],//图片列表
                imageList:[],//图片列表
                text1:'',
                text2:'',
                text3:'',
                text4:'',
                text5:'',
                text6:'',
                html:'',
            },
        }
    }

    renderItem(item,index){
        return(
            <TextDoubleIcon key={index}
                            style={styles.textFrame2_1}
                            frameStyleRight={styles.textFrame3}
                            textLeft={item.textLeft}
                            textRight={item.textRight}/>
        );

    }

    /**
     * 图片点击
     * **/
    onPressImage(imageList,i) {
      /*  let lst = [imageList[i]];
        imageList.splice(i,1);
        imageList = lst.concat(imageList);*/
        // alert(JSON.stringify(imageList) + "      " + i);
        ImageView.show(true,imageList,i);
    }


    /**
     * 获取商品详细数据
     * **/
    getData(){

        Service.get(this.state.product_code)
            .then(retJson =>{
                console.log(retJson)
                // alert(JSON.stringify(retJson));
                retJson.dataObj.pictures.forEach((val,i,arr)=>{
                    retJson.dataObj.imageList.push({
                        icon:val,
                        imageList:arr,
                        // onPress:this.onPressImage,
                    });
                });
                this.setState(retJson);
            });
    }

    componentWillMount(){
        /*if(!Tools.platformType){
         this.getData();
         }*/
        // alert(this.pageParams.product_code)

    }

    onPressSwiper(){

    }


    render() {

        let param = this.getPageParams();
        // console.info('getPageParams:',param);
        if(this.state.product_code == param.product_code){

            if(this.execFirst)
            {
                this.execFirst = false;
                this.getData();
            }

            return (
                <ViewTitle>

                    <SwiperImage imageList={this.state.dataObj.imageList}/>

                    <View style={[styles.textFrame,styles.textFrame0]}>
                        <Text style={[styles.text,styles.text1]}>
                            {this.state.dataObj.text1}
                        </Text>
                        <Text style={styles.text}>
                            {this.state.dataObj.text2}
                        </Text>
                        <Text style={[styles.text,styles.text3]}>
                            {this.state.dataObj.text3}
                        </Text>

                        <View style={styles.textFrame1}>
                            <Text style={[styles.text,styles.text4]}>
                                {this.state.dataObj.text4}
                            </Text>
                            <Text style={[styles.text,styles.text4]}>
                                {this.state.dataObj.text5}
                            </Text>
                            <Text style={[styles.text,styles.text4]}>
                                {this.state.dataObj.text6}
                            </Text>
                        </View>

                    </View>

                    <View style={styles.textFrame}>

                        {
                            this.state.dataObj.textList.map(this.renderItem)
                        }

                    </View>

                    <WebViewCus isModal={false}
                                source={{html:WebViewCus.getHtml(this.state.dataObj.html)}}
                                // source={{html:this.state.dataObj.html}}
                    />

                </ViewTitle>
            );
        }
        else
        {
            this.execFirst = true;
            setTimeout(()=>{
                this.setState({product_code:param.product_code})
            },0)
            return (
                <ViewTitle>

                </ViewTitle>
            );
        }

    }

}

const styles = StyleSheetAdapt.create({
    textFrame:{
        flexDirection:'column',
    },
    textFrame0:{
        borderColor:Theme.Colors.borderColor,
        borderBottomWidth:Theme.Border.borderWidth,
        // paddingLeft:10,
    },
    textFrame1:{
        flexDirection:'row',
    },
    textFrame2:{
        justifyContent:'space-between',
        flexDirection:'row',
    },
    textFrame2_1:{
        borderBottomWidth:0,
    },
    textFrame3:{
        alignItems:"flex-start",
    },
    text:{
        fontSize:Theme.Font.fontSize,
        padding:15,
        paddingTop:0,
    },
    text1:{
        fontSize:Theme.Font.fontSize1,
    },
    text3:{
        color:Theme.Colors.themeColor,
    },
    text4:{
        flex:1,
    },
});
