import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "./../../../../../component/api/api";

/**
 * 接口处理
 * **/
export class Service{

    /**
     * 获取商品详细数据
     * @param productCode int,//产品编码
     * **/
    static get(productCode) {

        return Http.post(HttpUrls.urlSets.urlInfoProductNewDetail, {
            userId:Tools.userConfig.userInfo.id,//用户id,
            product_code:productCode,//产品id
        })
            .then((retJson) => {
                retJson.retData.boxspecification = parseInt(retJson.retData.boxspecification);

                // alert(JSON.stringify(retJson.retData.pictures));
                retJson.retData.pictures = retJson.retData.pictures != undefined && retJson.retData.pictures != null ?
                    retJson.retData.pictures != '' && retJson.retData.pictures != 'null'
                        ? retJson.retData.pictures : [] : [];
                let retDataJson = {
                    dataObj:{
                        textList:[],//文本数组列表
                        pictures:retJson.retData.pictures,//产品图片
                        imageList:[],//产品图片
                        text1:retJson.retData.product_name,//产品名称
                        text2:retJson.retData.product_des,//产品描述
                        text3:'￥' + retJson.retData.quote_price,//产品价格
                        text4:"库存：" + retJson.retData.inventory_count ,//库存inventory_count
                        text5:"最小起订量：" + retJson.retData.min_order_qty,//最小订货量
                        text6:"最小出货倍数：" + retJson.retData.boxspecification,//最小出货倍数
                        html:retJson.retData.detailinfo,//商品详情
                    },
                    has:false,//是否有数据，true:有，false:没有，默认是false
                };//后台返回数据

                retDataJson.dataObj.textList.push({
                    textLeft:'SKU码：' + retJson.retData.product_code,//suk
                    textRight:'品牌：' + retJson.retData.product_brand//品牌
                });
                retDataJson.dataObj.textList.push({
                    textLeft:'产地：' + retJson.retData.product_place,//产地
                    textRight:'自主品牌：' + retJson.retData.product_owned_brand_name//自主品牌
                });
                retDataJson.dataObj.textList.push({
                    // textLeft:'季节：' + retJson.retData.season_name,//季节
                    textLeft:'使用性别：' +  retJson.retData.sex_name,//使用性别
                    textRight:'使用年龄段：' + retJson.retData.use_age,//使用年龄段
                });
                retDataJson.dataObj.textList.push({
                    textLeft:'使用阶段：' + retJson.retData.shiyongjieduan,//使用阶段
                    textRight:''
                });
                retDataJson.dataObj.textList.push({
                    textLeft:'使用方法：' + retJson.retData.usage_method_name,//使用方法
                    textRight:''
                });
                retDataJson.dataObj.textList.push({
                    textLeft:'注意事项：' + retJson.retData.note_name,//注意事项
                    textRight:''
                });

               /* retJson.retData.pictures.forEach((val,i,arr)=>{
                    retDataJson.dataObj.imageList.push({
                        icon:val,
                        onPress:()=>{
                            alert("dsds")
                        }
                    });
                });*/

                return retDataJson;

            })
            .catch((status) => {
                return status;
            });

    }

}