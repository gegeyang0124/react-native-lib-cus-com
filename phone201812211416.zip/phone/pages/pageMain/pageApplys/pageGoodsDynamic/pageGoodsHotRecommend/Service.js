import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "./../../../../../component/api/api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级品类
            type2:'',//下拉选中值 二级品类
            type3:'',//下拉选中值 三级品类
            name:'',//商品名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取新品推荐商品列表
     * @param selectValue object,//搜索参数
     * selectValue = {
        type1:'',//下拉选中值 一级品类
        type2:'',//下拉选中值 二级品类
        type3:'',//下拉选中值 三级品类
        name:'',//商品名称输入值
    }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(selectValue,init) {

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        this.base.paramsFetch.selectValue = selectValue == undefined
            ? this.base.paramsFetch.selectValue
            : selectValue;

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retListData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        return Http.post(HttpUrls.urlSets.urlInfoProductHotList, {
            userId:Tools.userConfig.userInfo.id,//用户id,
            // task_id:accountInfo().id,//用户id,//测试
            sort:'create_time',
            order:'desc',
            pageNumber: this.base.paramsFetch.pageNumber,//页码
            pageSize: 20,//每页条数,
            // l1_code:this.base.paramsFetch.selectValue.type1,//	一级品类
            // l2_code	:this.base.paramsFetch.selectValue.type2,//	二级品类
            // l3_code:this.base.paramsFetch.selectValue.type3,//	三级品类
            filter:{
                product_type_one : this.base.paramsFetch.type1, // 一级品类
                product_type_two : this.base.paramsFetch.type2, // 二级品类
                product_type_three : this.base.paramsFetch.type3, // 三级品类
                name:this.base.paramsFetch.selectValue.name,//搜索商品名称输入值
            },//筛选条件
        },init)
            .then((retJson) => {

                this.base.retJson.total = retJson.retData.total;
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                // alert(JSON.stringify(retJson));
                retJson.retListData.forEach((val,i,arr) =>{
                    val.quote_price = "￥" + val.quote_price;
                    val.minOrderAmount = "最小起订量：" + val.min_order_qty;
                    val.minOutAmount = "最小出货倍数：" + val.min_order_qty;

                    this.base.retJson.retListData.push(val);
                });

                // this.base.retJson.retListData.concat(retJson.retListData);
                // console.info("base:",this.base);
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }

    /**
     * 获取商品类别
     * @param goodsParentType int,//商品父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    static getGoodsTypes(goodsParentType,type){

        return Http.post(HttpUrls.urlSets.urlInfoProductTypeList, {parent_type_code:goodsParentType},false)
            .then((retJson) => {

                let types = {
                    keyList:[(type == 0
                        ? "一"
                        : type == 1
                            ? '二'
                            : type == 2
                                ? '三'
                                : '')
                    + "级品类"],
                    keyValPair:{},
                    clearDrop:false,
                };

                if(retJson.retListData == undefined)
                {
                    retJson.retListData = [];
                }
                else
                {
                    types.keyValPair[types.keyList[0]] = '';
                }

                retJson.retListData.forEach((val,i,arr) =>{
                    types.keyList.push(val.type_name);
                    types.keyValPair[val.type_name] = val.type_code;

                });



                return types;

            });
    }
}