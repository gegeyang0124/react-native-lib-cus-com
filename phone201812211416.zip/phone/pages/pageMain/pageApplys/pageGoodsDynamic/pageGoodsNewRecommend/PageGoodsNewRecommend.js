/**
 * Created by Administrator on 2018/5/5.
 */
import React, {Component} from 'react';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    FlatListView,
    SearchDDDIpt,
    ItemRowGoods,
    Theme,
} from "com";
import { Service } from "./Service";
import { ServiceCommon } from "./../ServiceCommon";

/**
 * 新品推荐
 * **/
type Props = {};
export default class PageGoodsNewRecommend extends BaseComponent<Props> {

    dropList = {
        types1:{
            keyList:["一级品类"],
            keyValPair:{},
            clearDrop:false,
        },//一级品类 数据
        types2:{
            keyList:["二级品类"],
            keyValPair:{},
            clearDrop:false,
        },//二级品类 数据
        types3:{
            keyList:["三级品类"],
            keyValPair:{},
            clearDrop:false,
        },//三级品类 数据

    };
    selectValue = {
        type1:'',//下拉选中值 一级品类
        type2:'',//下拉选中值 二级品类
        type3:'',//下拉选中值 三级品类
        name:'',//商品名称输入值
        execFirst:true,//是否是第一次执行
    };

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerRight:require('./../../../../../res/images/buyCar.png'),//buyCar.png
            headerRightHandle:()=>{
                this.goPage("PageBuyShopsCar",{});
                },
        });

        this.state = {
            total:0,//商品总数
            dataList:[],//数组列表
            refresh:false,//是否刷新
            clearDrop:false,
        }
    }

    onItemPress(item){

        // Tools.toast(JSON.stringify(item))
        this.goPage("PageGoodsDetail",{product_code:item.product_code});
    }

    onItemPressRight(item){
        ServiceCommon.addToGoodsBuyCar(item.product_code,item.min_order_qty);
    }

    renderItem(item,index){
        /*if(!item.product_picturepath){
            Tools.toast("" + index);
        }*/
        return(
            <ItemRowGoods id={index}
                          icon={{uri:item.product_picturepath}}
                          text1_1={item.product_name}
                          text2_1={item.minOrderAmount}
                          text2_2={item.quote_price}
                          text3_1={item.minOutAmount}
                          onPressLeft={() => this.onItemPress(item)}
                          onPressCenter={() => this.onItemPress(item)}
                          onPressRight={() => this.onItemPressRight(item)}/>
        );

    }

    /**
     * 获取商品列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue){

        if(!this.selectValue.execFirst)
        {
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        Service.get(selectValue,this.selectValue.execFirst)
            .then(retJson =>{

                if(!this.selectValue.execFirst && !retJson.has)
                {
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                }
                else
                {
                    // console.info("retJson",retJson);
                    this.selectValue.execFirst = false;
                    this.setState({
                        total:retJson.total,
                        dataList:retJson.retListData
                    });

                    Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                }


            })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });
    }

    /**
     * 获取商品类别
     * @param goodsParentType int,//商品父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    getDataGoodsTypes(goodsParentType,type){
        ServiceCommon.getGoodsTypes(goodsParentType,type).then(retJson =>{
            if(type == 0){
                this.dropList.types1 = retJson;

            }
            else  if(type == 1){
                this.dropList.types2 = retJson;
                // alert(JSON.stringify(this.dropList.types2))
            }
            else  if(type == 2){
                this.dropList.types3 = retJson;
            }

            this.setState({
                refresh:true,
                clearDrop:false
            });

        });
    }

    onSelectDrop(i,val,type){
        switch (type)
        {
            case 1 :
            {
                this.dropList.types2.keyList = [];
                this.dropList.types2.clearDrop = true;
                this.selectValue.type2 = '';

                this.dropList.types3.keyList = [];
                this.dropList.types3.clearDrop = true;
                this.selectValue.type3 = '';

                this.selectValue.type1 = this.dropList.types1.keyValPair[val];
                if(this.selectValue.type1 != '')
                {
                    this.getDataGoodsTypes(this.selectValue.type1,type);
                }

                this.setState({
                    refresh:false,
                    clearDrop:true
                });

                break;
            }
            case 2 :
            {
                this.dropList.types3.keyList = [];
                this.dropList.types3.clearDrop = true;
                this.selectValue.type3 = '';

                this.selectValue.type2 = this.dropList.types2.keyValPair[val];
                if(this.selectValue.type2 != '')
                {
                    this.getDataGoodsTypes(this.selectValue.type2,type);
                }

                this.setState({
                    refresh:false,
                    clearDrop:false
                });
                break;
            }
            case 3 :
            {
                this.selectValue.type3 = this.dropList.types3.keyValPair[val];
                break;
            }
        }


    }

    onTextChange(val){
        // Tools.toast(JSON.stringify(val));
        this.selectValue.name = val;
    }

    onSearch(){
        // alert(JSON.stringify(this.selectValue));
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            total:0,
            dataList:[]
        });
        this.getData(this.selectValue);
    }

    componentWillMount(){
        /*if(!Tools.platformType){
            this.getData();
        }*/
        this.getData();

        this.getDataGoodsTypes(0,0);

    }

    render() {

        return (
            <ViewTitle isScroll={false}>

                <SearchDDDIpt refresh={this.state.refresh}
                              options1={{
                                  defaultValue:this.dropList.types1.keyList[0],
                                  options:this.dropList.types1.keyList,
                                  clearDrop:this.dropList.types1.clearDrop,
                                  onSelect:(i,val)=>this.onSelectDrop(i,val,1)
                              }}
                              options2={{
                                  defaultValue:this.dropList.types2.keyList[0] == undefined
                                      ? '二级品类'
                                      : this.dropList.types2.keyList[0],
                                  options:this.dropList.types2.keyList,
                                  clearDrop:this.state.clearDrop,
                                  onSelect:(i,val)=>this.onSelectDrop(i,val,2)
                              }}
                              options3={{
                                  defaultValue:this.dropList.types3.keyList[0] == undefined
                                      ? '三级品类'
                                      : this.dropList.types3.keyList[0],
                                  options:this.dropList.types3.keyList,
                                  clearDrop:this.dropList.types3.clearDrop,
                                  onSelect:(i,val)=>this.onSelectDrop(i,val,3)
                              }}
                              textChange={(val) => this.onTextChange(val)}
                              onPressSearch={() => this.onSearch()}/>


                <FlatListView
                    data={this.state.dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}
                    onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    itemRowFrame:{
        // height:100,
        flexDirection:'row',
    },
    itemRowFrame1:{
        flex:9,
        backgroundColor:'blue',
    },
    itemRowFrame2:{
        flex:1,
        backgroundColor:'red',
    },
    itemRowFrame3:{
        flex:1,
        backgroundColor:'yellow',
    },
    itemRowIcon:{
        width:100,
        height:100,
    },
});
