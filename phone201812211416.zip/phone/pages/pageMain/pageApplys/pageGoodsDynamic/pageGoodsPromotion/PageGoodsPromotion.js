/**
 * Created by Administrator on 2018/5/5.
 */
import React, {Component} from 'react';

import {
    ViewTitle,
    BaseComponent,
    Tools,
    FlatListView,
    ItemRowGoodsPromotion,
    WebViewCus,
    Theme,
} from "../../../../../component/component";
import { Service } from "./Service";


/**
 * 促销活动
 * **/
type Props = {};
export default class PageGoodsPromotion extends BaseComponent<Props> {

    selectValue = {
        execFirst:true,//是否是第一次执行
    };

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            total:0,//商品总数
            dataList:[],//数组列表
            refresh:false,//是否刷新
            clearDrop:false,
        }
    }

    onItemPress(item){

        WebViewCus.show(true,item.m_Url);
        // Tools.toast(JSON.stringify(item))
    }

    onItemPressLeft(item){
        Tools.toast(JSON.stringify(item));
    }

    onItemPressRight(item){

        Tools.toast(JSON.stringify(item))
    }

    renderItem(item,index){
        return(
            <ItemRowGoodsPromotion id={index}
                                   text1={item.text1}
                                   text2={item.text2}
                                   icon={{uri:item.imgSrc}}
                                   onPressLeft={()=>this.onItemPress(item)}
                                   onPressRight={()=>this.onItemPressRight(item)}
                                   onPressImage={() =>this.onItemPress(item)}/>
        );

    }

    /**
     * 获促销活动
     * **/
    getData(){

        if(!this.selectValue.execFirst)
        {
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        Service.get(this.selectValue.execFirst)
            .then(retJson =>{
                // alert(JSON.stringify(retJson));
                if(!this.selectValue.execFirst && !retJson.has)
                {
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                }
                else
                {
                    this.selectValue.execFirst = false;
                    this.setState({
                        total:retJson.total,
                        dataList:retJson.retListData
                    });

                    Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                }


            })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }

            });
    }

    onSelectDrop(i,val,type){
        switch (type)
        {
            case 1 :
            {
                this.dropList.types2.keyList = [];
                this.dropList.types2.clearDrop = true;
                this.selectValue.type2 = '';

                this.dropList.types3.keyList = [];
                this.dropList.types3.clearDrop = true;
                this.selectValue.type3 = '';

                this.selectValue.type1 = this.dropList.types1.keyValPair[val];
                if(this.selectValue.type1 != '')
                {
                    this.getDataGoodsTypes(this.selectValue.type1,type);
                }

                this.setState({
                    refresh:false,
                    clearDrop:true
                });

                break;
            }
            case 2 :
            {
                this.dropList.types3.keyList = [];
                this.dropList.types3.clearDrop = true;
                this.selectValue.type3 = '';

                this.selectValue.type2 = this.dropList.types2.keyValPair[val];
                if(this.selectValue.type2 != '')
                {
                    this.getDataGoodsTypes(this.selectValue.type2,type);
                }

                this.setState({
                    refresh:false,
                    clearDrop:false
                });
                break;
            }
            case 3 :
            {
                this.selectValue.type3 = this.dropList.types3.keyValPair[val];
                break;
            }
        }

    }

    onTextChange(val){
        // Tools.toast(JSON.stringify(val));
        this.selectValue.name = val;
    }

    onSearch(){
        // alert(JSON.stringify(this.selectValue));
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            total:0,
            dataList:[]
        });
        this.getData(this.selectValue);
    }

    componentWillMount(){
        /*if(!Tools.platformType){
            this.getData();
        }*/

        this.getData();

    }

    /*addStyleNode(str){
        str = str == undefined ? "img{width: 100%;height:auto;}" : str;

        var styleNode=document.createElement("style");
        var styleNode=document.createElement("style");
        styleNode.type="text/css";

        if( styleNode.styleSheet){         //
            styleNode.styleSheet.cssTex= str;//ie下要通过 styleSheet.cssText写入.
        }
        else
        {
            styleNode.innerHTML = str;       //在ff中， innerHTML是可读写的，但在ie中，它是只读的.
        }
        document.getElementsByTagName("head")[0].appendChild( styleNode );
    }*/

    addStyleNode(){

        return '';
       /* return `(function (str){
        str = str == undefined ? "img{width: 100%;height:auto;}" : str;

        var styleNode=document.createElement("style");
        styleNode.type="text/css";

        if( styleNode.styleSheet){         
            styleNode.styleSheet.cssTex= str;
        }
        else
        {
            styleNode.innerHTML = str;      
        }
        document.getElementsByTagName("head")[0].appendChild( styleNode );
    })();`;*/
    }

    render() {


        return (
            <ViewTitle isScroll={false}>

                <WebViewCus />

                <FlatListView
                    data={this.state.dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,i}) => this.renderItem(item,i)}
                    onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

