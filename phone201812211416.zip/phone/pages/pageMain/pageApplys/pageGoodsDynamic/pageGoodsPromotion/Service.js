import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "./../../../../../component/api/api";
/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取新品推荐商品列表
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(init) {

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retListData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        return Http.post(HttpUrls.urlSets.urlInfoProductLastPromotionList, {
            userId:Tools.userConfig.userInfo.id,//用户id,
            sort:'create_time',
            order:'desc',
            pageNumber: this.base.paramsFetch.pageNumber,//页码
            pageSize: 20,//每页条数,
        },init)
            .then((retJson) => {

                // this.base.retJson.total = retJson.retData.total;
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                // alert(JSON.stringify(retJson));
                retJson.retListData.forEach((val,i,arr) =>{
                    val.imgSrc = val.m_ImgUrl;
                    val.text1 = "已经查看客户(20...)";
                    val.text2 = "未查看客户(20...)";

                    this.base.retJson.retListData.push(val);
                });

                // this.base.retJson.retListData.concat(retJson.retListData);

                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }

}