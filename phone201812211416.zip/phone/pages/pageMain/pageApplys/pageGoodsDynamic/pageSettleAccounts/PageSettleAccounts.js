/**
 * Created by Administrator on 2018/5/6.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    Alert,
} from 'react-native';
import {
    StyleSheetAdapt,
    Theme,
    BaseComponent,
    Tools,
    ItemRowBuyCar,
    TextChange,
    ViewTitle,
    FlatListView,
    PickDropdown,
} from "../../../../../component/component";

import {Service} from './Service';

type Props = {};
export default class PageSettleAccounts extends BaseComponent<Props> {

    execFirst = true;
    guideTextRight:TextChange;

    constructor(props) {
        super(props);

        this.objectIdList = [];//选中客户列表

        this.state = {
            dataList:[],//数组列表
            isInput:false,//是否输入
            total:0,//商品总数
            moneyTotal:0,//合计
            isChecked:false,//是否全选
            typesList:[],
        }

        this.setParams({
            headerLeft: true,
            headerLeftHandle:()=>{
                this.execFirst = true;
            },
            headerRight:<TextChange text={'编辑'}
                                    onExportThis={(self)=>{
                                        this.guideTextRight = self;
                                    }}
                                    onPress={()=>this.onGuideRightPress()}
                                    style={styles.guideRightFrame}
                                    textStyle={styles.guideRightText}/>
        });
    }

    getMoneyTotal(){
        let moneyTotal = 0;
        this.state.dataList.forEach((v,i,a)=>{
            if(v.isChecked)
            {
                moneyTotal += v.amount * v.quote_price;
            }
        });

        moneyTotal = parseInt(moneyTotal * 100) / 100;
        return moneyTotal;
    }

    onSelectDrop(val,type){
        /* switch (type)
         {
             case 1 :
             {
                 this.dropList.types2.keyList = [];
                 this.dropList.types2.clearDrop = true;
                 this.selectValue.type2 = '';

                 this.dropList.types3.keyList = [];
                 this.dropList.types3.clearDrop = true;
                 this.selectValue.type3 = '';

                 this.selectValue.type1 = this.dropList.types1.keyValPair[val];
                 if(this.selectValue.type1 != '')
                 {
                     this.getDataGoodsTypes(this.selectValue.type1,type);
                 }

                 this.setState({
                     refresh:false,
                     clearDrop:true
                 });

                 break;
             }
             case 2 :
             {
                 this.dropList.types3.keyList = [];
                 this.dropList.types3.clearDrop = true;
                 this.selectValue.type3 = '';

                 this.selectValue.type2 = this.dropList.types2.keyValPair[val];
                 if(this.selectValue.type2 != '')
                 {
                     this.getDataGoodsTypes(this.selectValue.type2,type);
                 }

                 this.setState({
                     refresh:false,
                     clearDrop:false
                 });
                 break;
             }
             case 3 :
             {
                 this.selectValue.type3 = this.dropList.types3.keyValPair[val];
                 break;
             }
         }*/

        this.objectIdList = val;
        // alert(JSON.stringify(val));
    }

    //验证订单数量
    verifyOrderNum(text,item) {


        var reg = /^[1-9][0-9]*$/;

        if(!reg.test(text)){
            Tools.toast("请填写数字");
            text = item.amount;
            return;
        }

        let val = parseInt(text);
        if(val < item.min_order_qty){
            Tools.toast("抱歉，下单数量，不得低于订单下限！");
            return;
        } else{
            item.amount = val;
        }

        var c = item.amount % item.min_order_qty;

        if(c != 0){
            Tools.toast("抱歉，下单数量，需是最小订货量的倍数！");
            item.amount = item.amount - c;
            return;
        }

        item.text = item.amount;
        return item;
    }

    onCheckBoxViewBottom(isChecked){
        // alert(isChecked);
        // let moneyTotal = 0;
        if(isChecked)
        {
            this.state.dataList.forEach((v,i,a)=>{
                v.isChecked = true;
                // moneyTotal += v.amount * v.quote_price;
            });
        }
        else
        {
            this.state.dataList.forEach((v,i,a)=>{
                v.isChecked = false;
                // moneyTotal += v.amount * v.quote_price;
            });
        }

        // moneyTotal = parseInt(moneyTotal * 100) / 100;
        this.setState({
            dataList:this.state.dataList,
            moneyTotal:this.getMoneyTotal(),
            isChecked:isChecked,
        });
    }

    onGuideRightPress(){
        let isInput = !this.state.isInput;
        // alert(this.state.dataList.length)
        this.setState({
            isInput:isInput,
            dataList:this.state.dataList,
            moneyTotal:this.getMoneyTotal()
        });
        this.guideTextRight.setText((isInput ? '完成' : '编辑'));

        if(!isInput)
        {
            let productList = [];
            this.state.dataList.forEach((v,i,a)=>{
                productList.push({
                    productNumber:v.product_code,//产品id
                    productAmount:v.amount//产品预订数量
                });
            })

            Service.addOrderProductAmount(productList)
        }
    }

    onPressChecked(isChecked,index){
        // alert(index);
        let isCheckedTotal = true;
        this.state.dataList[index].isChecked = isChecked;
        this.state.dataList.forEach((v,i,a)=>{
            if(!v.isChecked)
            {
                isCheckedTotal = false;
            }
        });
        this.setState({
            dataList:this.state.dataList,
            moneyTotal:this.getMoneyTotal(),
            isChecked:isCheckedTotal,
        });
    }

    onTextChanged(text,item,index,self){
        item = this.verifyOrderNum(text,item);
        this.state.dataList[index] = item;
        // alert(item.amount);
        self.setText(item.text + '');

    }

    onPressRight1(item,index,self){
        let text = parseInt(item.amount) - parseInt(item.min_order_qty);
        item = this.verifyOrderNum(text,item);
        this.state.dataList[index] = item;
        // alert(item.amount);
        self.setText(item.text + '');
    }

    onPressRight2(item,index,self){
        let text = parseInt(item.amount) + parseInt(item.min_order_qty);
        item = this.verifyOrderNum(text,item);
        this.state.dataList[index] = item;
        // alert(item.amount);
        self.setText(item.text + '');
    }

    onPressAccount(){

        Alert.alert(
            "是否确认",
            "点击确认提交订单，如需检查请点击返回",
            [
                // {text: 'Ask me later', onPress: () => console.log('Ask me later pressed')},
                {text: '返回', onPress: () => {}, style: 'cancel'},
                {text: '确定', onPress: () => {
                        Service.addPushToClients(this.objectIdList,this.state.dataList)
                            .then((retJson)=>{
                                // Tools.toast("推送成功！")
                                this.goBack();
                            });
                    }},
            ],
            { cancelable: false }
        );


    }

    onItemPress(item){
        // alert(item.product_code)
        this.goPage("PageGoodsDetail",{product_code:item.product_code});
        // Tools.toast(JSON.stringify(item))
    }

    renderItem(item,index) {
        return (
            <ItemRowBuyCar id={index}
                           isShowCheckBox={false}
                           isChecked={item.isChecked}
                           icon={{uri:item.product_picturepath}}
                           onPressChecked={(isChecked)=>this.onPressChecked(isChecked,index)}
                           onTextBlur={(text,self)=>{this.onTextChanged(text,item,index,self)}}
                           onPressLeft={() => this.onItemPress(item)}
                           onPressCenter={() => this.onItemPress(item)}
                           onPressRight1={(self)=>this.onPressRight1(item,index,self)}
                           onPressRight2={(self)=>this.onPressRight2(item,index,self)}
                           valueInput={'' + item.amount}
                           isInput={this.state.isInput}
                           text1_1={item.product_name}
                           text4_1={"￥" + item.quote_price}
                           textRight={"x" + item.amount}/>
        );
    }

    getData(){
        /*Service.get(true).then((retJson)=>{
            this.setState({
                // total:retJson.total,
                dataList:retJson.retListData
            });
        });*/
        let params = this.getPageParams();
        // alert(params.dataList.length)
        this.setState({
            dataList:params.dataList,//数组列表
            moneyTotal:params.moneyTotal,//合计
            isInput:false,//是否输入
            total:0,//商品总数
            isChecked:false//是否全选
        });

        /* let interval = setInterval(()=>{
             if(this.guideTextRight != undefined)
             {
                 clearInterval(interval);
                 this.guideTextRight.setText((this.state.isInput ? '完成' : '编辑'));
             }
         },20)*/
    }

    getClientList(){
        Service.getClientList().then((retJson)=>{
            console.log(retJson)
            this.setState({

                typesList:retJson
            });
        });
    }

    componentWillMount(){
        this.getClientList();
    }

    render() {

        if(this.execFirst)
        {
            this.execFirst = false;
            this.getData();
        }

        return (
            <ViewTitle isScroll={false}
                       viewBottom={
                           <View style={styles.viewBottomFrame}>

                               <View style={styles.viewBottomFrame1}></View>

                               <View style={styles.viewBottomFrame2}>

                                   <View style={styles.viewBottomFrame2_1}>
                                       <Text style={styles.viewBottomFrameTextLeft}>合计：</Text>
                                       <Text style={[styles.viewBottomFrameTextLeft,styles.viewBottomFrameTextRight]}>
                                           ￥{this.state.moneyTotal}
                                       </Text>
                                   </View>

                                   <TextChange style={styles.viewBottomFrameBtnRightFrame}
                                               onPress={()=>this.onPressAccount()}
                                               text={"推送"}/>
                               </View>

                           </View>
                       }>

                <View style={styles.dropdwonFrame}>
                    <Text style={styles.dropdwonText}>
                        推送客户：
                    </Text>
                    <PickDropdown options={this.state.typesList}
                                  multiple={true}
                                  style={styles.dropdwon}
                                  onSelect={(v)=>this.onSelectDrop(v)}
                                  defaultValue={"请选择客户"}/>
                </View>

                <FlatListView
                    data={this.state.dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,i}) => this.renderItem(item,item.index)}
                    // onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    dropdwonFrame:{
        flexDirection:'row',
        alignItems:'center',
        // justifyContent:'center',
        padding:10,
    },
    dropdwonText:{
        fontSize:Theme.Font.fontSize,
    },
    dropdwon:{
        // flex:1
        width:400,
    },
    guideRightText:{
        color:"#FFFFFF",
        fontWeight:'bold',
    },
    guideRightFrame:{
        marginRight:20,
    },

    viewBottomFrame:{
        flexDirection:'row',
        justifyContent:'space-between',
        marginBottom:10,
    },
    viewBottomFrame1:{
        marginLeft:30,
    },
    viewBottomFrame2:{
        flexDirection:'row',
        marginRight:30,
        alignItems:"center",
        justifyContent:'center',
    },
    viewBottomFrame2_1:{
        flexDirection:'row',
    },
    viewBottomFrameTextLeft:{
        fontSize:Theme.Font.fontSize,
    },
    viewBottomFrameTextRight:{
        color:Theme.Colors.themeColor,
    },
    viewBottomFrameBtnRightFrame:{
        marginLeft:20,
        width:150,
        height:40,
        borderRadius:10,
        backgroundColor:Theme.Colors.backgroundColorBtn,
    },
});