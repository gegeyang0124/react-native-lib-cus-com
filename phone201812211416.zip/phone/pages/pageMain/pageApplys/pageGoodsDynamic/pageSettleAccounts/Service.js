import {
    Http,
    HttpUrls,
    Tools,
} from "./../../../../../component/api/api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级品类
            type2:'',//下拉选中值 二级品类
            type3:'',//下拉选中值 三级品类
            name:'',//商品名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 推送产品给客户
     * @param objectIdList array,//客户ID列表
     * @param productList array,//产品列表
     * **/
    static addPushToClients(objectIdList,productList){
        var requestData = {
            remarks:'',//备注
            productList:[],//产品数组
            // objectIdList:[],//目标客户id数组
            objectIdList:objectIdList,//目标客户id数组
        };

        productList.forEach((v,i,a)=>{
            var item = {
                product_name:v.product_name,//产品名称
                product_number:v.product_code,//产品编号
                photo_url:v.product_picturepath,//产品url
                unit_price:v.quote_price,//单价
                amount:v.amount,//数量
                money:v.amount * v.quote_price,//金额
            }
            requestData.productList.push(item);
        });

        if(requestData.objectIdList.length == 0)
        {
            Tools.toast("请选择目标客户");
            return new Promise(function (resolve, reject) {
                reject();
            });
        }

        // prompt("ll:",JSON.stringify(requestData));
        return Http.post(HttpUrls.urlSets.urlInfoAddOrder,requestData);
    }

    /**
     * 获取客户列表
     * **/
    static getClientList(){

        return Http.post(HttpUrls.urlSets.urlClientList, {
            user_id:Tools.userConfig.userInfo.id,
            pageSize:10000
        })
            .then((retJson) => {

                let typesList = [];

                if(retJson.retListData == undefined)
                {
                    retJson.retListData = [];
                }

                retJson.retListData.forEach((val,i,arr) =>{
                    typesList.push({
                        name:val.name,
                        value:val.storecode
                    });
                });



                return typesList;

            });
    }

    /**
     * 添加所购产品的数量
     * **/
    static addOrderProductAmount(productList){

        /* var item = {
             productNumber:'',//产品id
             productAmount:''//产品预订数量
         };*/

        Http.post(HttpUrls.urlSets.urlInfoAddOrderToCar2,{
            productList:productList
        }).then((retJson)=>{
            Tools.toast("提交成功！");
            return retJson;
        });
    }
}