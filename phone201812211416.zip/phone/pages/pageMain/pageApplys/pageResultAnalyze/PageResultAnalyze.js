import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird'
import PageResultAnalyzeProgress from "./pageResultAnalyzeProgress/PageResultAnalyzeProgress";
import PageResultAnalyzeDiagnose from "./pageResultAnalyzeDiagnose/PageResultAnalyzeDiagnose";
import PageResultAnalyzeGuide from "./pageResultAnalyzeGuide/PageResultAnalyzeGuide";
import PageResultAnalyzeCustomer from "./pageResultAnalyzeCustomer/PageResultAnalyzeCustomer";

const TabRouteConfigs = {
    PageResultAnalyzeProgress: {
        screen: PageResultAnalyzeProgress,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '业绩进度',
        },
    },
    PageResultAnalyzeDiagnose: {
        screen: PageResultAnalyzeDiagnose,
        navigationOptions: {
            title:'诊断报告',
            tabBarLabel : '诊断报告',
        },
    },
    PageResultAnalyzeGuide: {
        screen: PageResultAnalyzeGuide,
        navigationOptions: {
            title:'巡店分析',
            tabBarLabel : '巡店分析',
        },
    },
    PageResultAnalyzeCustomer: {
        screen: PageResultAnalyzeCustomer,
        navigationOptions: {
            title:'客户分析',
            tabBarLabel : '客户分析',
        },
    },

};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;