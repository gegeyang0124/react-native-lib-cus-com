import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    Theme,
    ItemRowGuideTripApply,
    SearchDDDIpt,
    FlatListView,
} from "com";
import {
    CheckBox
} from 'comThird';

import { Service } from "./Service";

type Props = {};
export default class PageResultAnalyzeCustomer extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            execFirst:true,
            executing:false,
        };

        this.state = {
            time: new Date().getTime(),//
            dataList:[],
            departmentListOne:[],
            departmentListTwo:[],
            clearDropOne:true,
            clearDropTwo:true,
            username:'',//客户名

            regionid:Tools.userConfig.userInfo.department_level == 3
                ? Tools.userConfig.userInfo.department_id
                : '',//省区ID
            regionname:Tools.userConfig.userInfo.department_level == 3
                ? Tools.userConfig.userInfo.department_name
                : "全部",//省区名
            companyid:Tools.userConfig.userInfo.department_level == 2
                ? Tools.userConfig.userInfo.department_id
                : '',//大区id
            companyname:Tools.userConfig.userInfo.department_level == 2
                ? Tools.userConfig.userInfo.department_name
                : "全部",//大区名


            exception:1,//异常分析 1:未勾选(查全部) 2:已勾选(查异常)
        };

        this.setParams({
            headerLeft: true,
            headerRight:false
        });
    }

    componentWillEnter(param){
        if(param){
            param.clearDropOne = true;
            param.clearDropTwo = true;
            // alert(JSON.stringify(param))
            this.setState(param);

            this.getData();
        }
    }

    getData(){

        if(!this.selectedValue.executing)
        {
            this.selectedValue.executing = true;

            if(!this.selectedValue.execFirst)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
            }

            Service.getCustomerAnalyze(
                Tools.timeFormatConvert(this.state.time,"YYYY-MM"),
                this.state.companyid,
                this.state.regionid,
                this.state.username,
                this.state.exception,
                this.selectedValue.execFirst
            ).then(retJson=>{
                this.selectedValue.executing = false;
                if(!this.selectedValue.execFirst && !retJson.has)
                {
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);

                }
                else
                {
                    console.info("retListData: ",retJson.retListData)
                    this.selectedValue.execFirst = false;
                    this.setState({
                        dataList:retJson.retListData
                    });

                    Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                }
            })
                .catch((status) =>{
                    this.selectedValue.executing = false;
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }


    }

    onSearch = ()=>{
        this.selectedValue.execFirst = true;
        this.getData();
    }

    onSelectedTime = (time)=>{
        this.state.time = time == undefined ? this.state.time : time;
        this.selectedValue.execFirst = true;
        this.getData();
    }


    getDepartmentsOne(){
        Service.getDepartmentsOne()
            .then(retJson=>{
                let retObj = {
                    departmentListOne:retJson
                };

                retObj.companyname = retJson[Tools.userConfig.userInfo.department_level > 1 ? 1 : 0].name;
                retObj.companyid = retJson[Tools.userConfig.userInfo.department_level > 1 ? 1 : 0].id;
                if(Tools.userConfig.userInfo.department_level == 2){
                    this.getDepartmentsTwo();
                }

                this.setState(retObj);
            });
    }

    getDepartmentsTwo(){
        Service.getDepartmentsTwo(this.state.companyid)
            .then(retJson=>{

                this.setState({
                    clearDropTwo:true,
                    departmentListTwo:retJson
                });
            });
    }

    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
        this.getDepartmentsOne();
        // alert(typeof true)
    }

    renderRowItem = (item,i)=>{

        return(
            <ItemRowGuideTripApply key={i}
                                   frameStyle={styles.tableFrame}
                                   text1Style={styles.text1Style}
                                   text1={item.companyName}
                                   text2={item.regionName}
                                   text3={item.customerName}
                                   text4={this.getTitleHeader(
                                       null,
                                       item.regionalPhoneVisitNum,
                                       item.regionalVisitNum
                                   )}
                                   text5={this.getTitleHeader(
                                       null,
                                       item.provincialPhoneVisitNum,
                                       item.provincialVisitNum
                                   )}
                                   text6={this.getTitleHeader(
                                       null,
                                       item.customerPhoneVisitNum,
                                       item.customerVisitNum
                                   )}
                                   text7={this.getTitleHeader(
                                       null,
                                       item.operationPhoneVisitNum,
                                       item.operationVisitNum
                                   )}/>
        );
    }

    onSelectDrop(val,i,type){
        if(type == 0){
            this.state.companyid = val.id;
            this.state.regionid = null;
            if(this.state.clearDropOne){
                this.setState({
                    clearDropOne:false
                });
            }
            this.getDepartmentsTwo();

        }
        else {
            this.state.regionid = val.id;
            if(this.state.clearDropTwo){
                this.setState({
                    clearDropTwo:false
                });
            }
        }
    }

    onChecked = (isChecked)=>{
        this.state.exception = isChecked ? 2 : 1;
    }


    getTitleHeader(t1,t2,t3){
        return(
            <View style={styles.tbFrame}>
                {
                    t1 &&  <View style={[styles.tbFrame_1]}>
                        <Text style={styles.tbFrame_Text}>
                            {t1}
                        </Text>
                    </View>
                }


                <View style={[styles.tbFrame_1]}>
                    <View style={[styles.tbFrame_1_0,styles.tbFrame_1_1]}>
                        <Text style={styles.tbFrame_Text}>
                            {t2}
                        </Text>
                    </View>
                    <View style={styles.tbFrame_1_0}>
                        <Text style={styles.tbFrame_Text}>
                            {t3}
                        </Text>
                    </View>
                </View>

            </View>
        );
    }

    render() {
        const {dataList,departmentListOne,clearDropOne,companyname,regionname,
            clearDropTwo,departmentListTwo} = this.state;

        return (
            <ViewTitle isScroll={false}>
                <View style={styles.headerFrame}>
                    <TitleRow frameStyle={styles.titleFrame}
                              onPressLeft={this.onSelectedTime}
                              onPressRight={this.onSelectedTime}
                              onPressCenter={this.onSelectedTime}
                              textLeft={"上一月"}
                              textRight={"下一月"}/>

                    <View style={styles.searchFrame}>
                        <SearchDDDIpt isPickDropdown3={false}
                                      placeholder={"--姓名--"}
                                      textChange={(text)=>this.state.username = text}
                                      options1={{
                                          style:styles.dpFrame,
                                          defaultValue:companyname,
                                          options:departmentListOne,
                                          onDropdownWillShow:()=>Tools.userConfig.userInfo.department_level == 1 || false,
                                          clearDrop:clearDropOne,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,0)
                                      }}
                                      options2={{
                                          style:styles.dpFrame,
                                          defaultValue:regionname,
                                          options:departmentListTwo,
                                          onDropdownWillShow:()=>Tools.userConfig.userInfo.department_level < 3 || false,
                                          clearDrop:clearDropTwo,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                      }}
                                      onPressSearch={this.onSearch}/>

                        <CheckBox rightText={"异常分析"}
                                  style={styles.chkFrame}
                                  onClick={this.onChecked}
                                  rightTextStyle={styles.chkText}
                                  imageStyle={styles.chkImage}/>
                    </View>
                </View>

                <View style={styles.cntFrame}>

                    <View style={styles.table}>

                        <ItemRowGuideTripApply frameStyle={styles.tableFrame}
                                               text1={"大区"}
                                               text2={"省区"}
                                               text3={"客户"}
                                               text4={this.getTitleHeader("大区总监","回访","拜访")}
                                               text5={this.getTitleHeader("省区总监","回访","拜访")}
                                               text6={this.getTitleHeader("客户经理","回访","拜访")}
                                               text7={this.getTitleHeader("运营助理","回访","拜访")}/>

                        <FlatListView data={dataList}
                                      style={styles.flatListView}
                                      keyExtractor = {(item, index) => ("key" + index)}
                                      renderItem={({item,index}) => this.renderRowItem(item,index)}
                                      onEndReached={() =>this.getData()}/>

                    </View>

                </View>



            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    flatListView:{
        // marginBottom:160,
    },

    tbFrame_1_0:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    tbFrame_1_1:{
        borderColor:Theme.Colors.minorColor,
        borderRightWidth:Theme.Border.borderWidth,
        // backgroundColor:'blue',
    },
    tbFrame_Text:{
        color:Theme.Colors.minorColor,
        fontSize:Theme.Font.fontSize_2,
    },
    tbFrame_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        flexDirection:'row',
    },
    tbFrame:{
        flex:2,
        // alignItems:'center',
        // justifyContent:'center',
        borderColor:Theme.Colors.minorColor,
        borderBottomWidth:Theme.Border.borderWidth,
        borderRightWidth:Theme.Border.borderWidth,
    },

    cntFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginBottom:150,
        // height:300,
    },

    dpFrame:{
        width:120,
    },
    chkFrame:{
        marginLeft:20,
    },
    chkText:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    chkImage:{
        tintColor:Theme.Colors.themeColor,
        width:Theme.Font.fontSize_1_1 + 5,
        height:Theme.Font.fontSize_1_1 + 5 + 'dw',
    },
    headerFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
    searchFrame:{
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',
    },
    titleFrame:{
        marginTop:10,
    },


    text1Style:{
        color:Theme.Colors.themeColor,
    },
    table:{
        borderTopWidth:Theme.Border.borderWidth,
        borderLeftWidth:Theme.Border.borderWidth,
        borderColor:Theme.Colors.minorColor,
        marginLeft:20,
        marginRight:20,
        marginBottom:40,
        marginTop:10,
    },
    tableFrame:{
        // paddingLeft:20,
        // paddingRight:20,
    },

});
