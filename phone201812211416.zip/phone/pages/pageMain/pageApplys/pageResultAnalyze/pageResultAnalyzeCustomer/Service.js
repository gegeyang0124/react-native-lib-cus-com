import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     *  获取区域数据 数据
     * @param month string,//年月
     * @param companyid string,//大区ID
     * @param regionid string,//省区ID
     * @param customerName string,//客户名
     * @param exception int,//异常分析 //异常分析 1:未勾选(查全部) 2:已勾选(查异常)
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static getCustomerAnalyze(month,companyid,regionid,customerName,exception,init){

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }


        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retJson.retListData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        return Http.get(HttpUrls.urlSets.urlResultAnalyzeCustomer, {
            number:this.base.paramsFetch.pageNumber,//页码 当前页数
            size: 20,//每页条数
            companyId:companyid,//大区id(部门表)
            regionId:regionid,//省区id(部门表)
            customerName:customerName,
            exception:exception,//异常分析 1:未勾选(查全部) 2:已勾选(查异常)
            jobGrade:Tools.userConfig.userInfo.job_grade,//员工岗位级别
            month:month
        },init)
            .then((retJson) => {

                if(retJson.retData.content == undefined || retJson.retData.content.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                /*retJson.retListData.forEach((v,i,a)=>{
                    v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY-MM-DD HH:mm");
                    v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY-MM-DD HH:mm");
                    // v.isProTask = Tools.userConfig.userInfo.id ==  v.executor_id ? true : false;

                    this.base.retJson.retListData.push(v);
                });*/

                this.base.retJson.retListData = this.base.retJson.retListData.concat(retJson.retData.content)

                return this.base.retJson;
            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });
    }

    /**
     * 获取省区数据
     * @param companyid string,//分公司/大区id
     * **/
    static getProvinceAnalyze(companyid,month){
        return Http.post(HttpUrls.urlSets.urlGuideAnalyzeBusinessCheck,{
            companyid:companyid,//分公司/大区id
            month:month,//查询月份
            queryType:1 + '',//查询级别，1、大区；2、省区；3、客户经理 //1.按照区域分组，2.不按照区域分组
            job_grade:Tools.userConfig.userInfo.job_grade,//职位级别
        })
            .then(retJson=>{


                return retJson.retListData;

            });
    }

    /**
     * 获取一级部门选择列表
     * **/
    static getDepartmentsOne(){

        /** department_level:1、运营中心；2、大区；3、区域
         **/
        return  Http.post(HttpUrls.urlSets.urlGetDepartmentListByType2,{
            userId:Tools.userConfig.userInfo.id
        })
            .then((retJson)=>{

                var retObj = [{
                    name:'全部',
                    id:''
                }];

                if(retJson.retListData.length > 0)
                {
                    retObj = retObj.concat(retJson.retListData);
                }

                return retObj;

            });

    }

    /**
     * 获取二级部门选择列表
     * @param parent_id string,//一级部门ID
     * **/
    static getDepartmentsTwo(parent_id){

        return Http.post(HttpUrls.urlSets.urlGetDepartmentListByParentId,{
            parent_id:parent_id
        },false)
            .then((retJson)=>{
                // alert(HttpUrls.urlSets.urlGetDepartmentListByParentId)
                // setTimeout(()=>{Tools.progress.show(false)},500);
                var lst = [
                    {
                        name:'全部',
                        id:parent_id
                    }
                ];
                retJson.retListData = lst.concat(retJson.retListData);
                // modelTrip.set("areaLst",retJson.retListData);

                return retJson.retListData;
            });

        // modelTrip.set("area",'');

    }


}
