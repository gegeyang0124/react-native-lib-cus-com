import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    Theme,
    PickDropdownMonth,
    ChartCircleProgressList,
    ItemRowGuideTripApply,
    ItemRowTableSwitch,
    SearchDDDIpt,
} from "com";
import { Service } from "./Service";

type Props = {};
export default class PageResultAnalyzeDiagnose extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            deptId:Tools.userConfig.userInfo.department_id,//选中的部门ID
            time:new Date().getTime(),//当前时间戳
            companyId:Tools.userConfig.userInfo.department_level == 1
                ? Tools.userConfig.userInfo.department_id
                : null,// 大区ID
            regionId:Tools.userConfig.userInfo.department_level != 1
                ? Tools.userConfig.userInfo.department_id
                : null,// 省区ID
        };

        this.state = {
            dataList:[],
            store_count:null,//门店数量
            user_count:null,//员工数量
            departmentListOne:[],//部门1
            departmentListTwo:[],//部门2
            isPickDropdown2:false,
            clearDrop:true,

            challenge_target:null,
            challenge_finish:null,
            challenge_finish_rate:null,
            base_target:null,
            base_finish:null,
            base_finish_rate:null,
            operations_target:null,
            operations_finish:null,
            operations_finish_rate:null,
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });
    }

    getData = ()=>{

        Service.getTarget(Tools.timeFormatConvert(this.selectedValue.time,"YYYY-MM"),
            this.selectedValue.companyId,
            this.selectedValue.regionId)
            .then(retJson=>{
                this.setState(retJson);
            });

        Service.getShops(this.selectedValue.deptId,
            Tools.timeFormatConvert(this.selectedValue.time,"YYYY-MM"))
            .then(retJson=>{
            this.setState(retJson);
        });

       Service.getIndicatorData(this.selectedValue.deptId,
           Tools.timeFormatConvert(this.selectedValue.time,"YYYY-MM"))
           .then(retJson=>{
               console.info("d:",retJson);
               this.setState({
                   dataList:retJson
               });
           });
    }

    getDepartmentsOne(){
        Service.getDepartmentsOne()
            .then(retJson=>{
                // console.info("departmentListOne: ",retJson);
                this.setState({
                    departmentListOne:retJson
                });
            });
    }

    getDepartmentsTwo(){
        Service.getDepartmentsTwo(this.selectedValue.deptId)
            .then(retJson=>{
                this.setState({
                    clearDrop:true,
                    isPickDropdown2:true,
                    departmentListTwo:retJson
                });
            });
    }

    getDepartments(){
        if(Tools.userConfig.userInfo.department_level == 1){
            this.getDepartmentsOne();
        }
        else if(Tools.userConfig.userInfo.department_level == 2){
            Service.getDepartmentsTwo();
        }

    }

    componentWillMount(){
        // this.goPage()
    }

    componentDidMount(){
        this.getData();
        this.getDepartments();
    }

    renderItem = (item,i)=>{
        return(
            <ItemRowTableSwitch key={"target" + i}
                                dataList={item.dataList}
                                title={item.title}
                                frameStyle={styles.itemRowFrame}/>
        );
    }

    onChangeMonth = (time)=>{
        this.selectedValue.time = time;
        // alert(time)
    }

    onSelectDrop(val,i,type){
        if(type == 1){
            if(this.selectedValue.companyId != val.id){
                this.selectedValue.companyId = val.id;
                this.selectedValue.deptId = this.selectedValue.companyId;

                this.getDepartmentsTwo();
            }

        }
        else {
            this.selectedValue.regionId = val.id;
            this.selectedValue.deptId = this.selectedValue.regionId;
            if(this.state.clearDrop){
                this.setState({
                    clearDrop:false
                });
            }
        }
    }

    onSearch = ()=>{
        // console.info("selectedValue:",this.selectedValue)
        this.getData();
    }

    render() {
        const {dataList,store_count,user_count,departmentListOne,
            departmentListTwo,isPickDropdown2,clearDrop,challenge_target,
            challenge_finish,challenge_finish_rate,base_target,base_finish,
            base_finish_rate} = this.state;

        return (
            <ViewTitle>

                <View  style={styles.titleFrame}>

                    <View style={styles.titleFrame_0}>
                        <View style={styles.titleFrame_1}>
                            <Text style={styles.titleFrame_Text0}>
                                统计月份:
                            </Text>
                            <PickDropdownMonth onChange={this.onChangeMonth}/>
                        </View>

                        <View style={styles.titleFrame_2}>
                            <Text style={styles.titleFrame_Text}>
                                门店:{store_count}            员工:{user_count}
                            </Text>
                        </View>
                    </View>

                    {
                        Tools.userConfig.userInfo.department_level <= 3 &&
                        <View>
                            <SearchDDDIpt isTextInput={false}
                                          frameStyle={styles.searchFrame}
                                          options1={{
                                              onSelect:(i,val)=>this.onSelectDrop(val,i,1),
                                              style:styles.dpFrame,
                                              options:departmentListOne,
                                              defaultValue:Tools.userConfig.userInfo.department_name,
                                          }}
                                          isPickDropdown1={
                                              Tools.userConfig.userInfo.department_level == 1
                                                  ? true
                                                  : false
                                          }
                                          isPickDropdown3={false}
                                          options2={{
                                              onSelect:(i,val)=>this.onSelectDrop(val,i,2),
                                              style:styles.dpFrame,
                                              options:departmentListTwo,
                                              clearDrop:Tools.userConfig.userInfo.department_level == 1
                                                  ? clearDrop
                                                  : false,
                                              defaultValue:departmentListTwo.length == 0
                                                  ? "正在加载"
                                                  : departmentListTwo[0].name,
                                          }}
                                          onPressSearch={this.onSearch}
                                          isPickDropdown2={isPickDropdown2}/>
                        </View>
                    }

                </View>

                <ChartCircleProgressList frameStyle={styles.cpFrame}
                                         dataList={[
                                             {
                                                 title1Progress:challenge_finish_rate,//圆形图表进程
                                                 titleCenter:"挑 战",//圆形中心文本
                                                 title1:"完成进度",//提示1文本
                                                 title2:"用时进度",//提示2文本
                                                 titleBlockList:[
                                                     {
                                                         textCenter:challenge_target,
                                                         textDown:"挑战目标",//按钮文字 下边
                                                         textRight:"万元",//按钮文字 中间
                                                         color:Theme.Colors.appRedColor,
                                                     },
                                                     {
                                                         textCenter:challenge_finish,
                                                         textDown:"完成业绩",//按钮文字 下边
                                                         textRight:"万元",//按钮文字 中间
                                                     }
                                                 ]
                                             },
                                             {
                                                 title1Progress:this.state.operations_finish_rate,//圆形图表进程
                                                 titleCenter:"运 营",//圆形中心文本
                                                 title1:"完成进度",//提示1文本
                                                 title2:"用时进度",//提示2文本
                                                 titleBlockList:[
                                                     {
                                                         textCenter:this.state.operations_target,
                                                         textDown:"运营目标",//按钮文字 下边
                                                         textRight:"万元",//按钮文字 中间
                                                     },
                                                     {
                                                         textCenter:this.state.operations_finish,
                                                         textDown:"完成业绩",//按钮文字 下边
                                                         textRight:"万元",//按钮文字 中间
                                                     }
                                                 ]
                                             }
                                         ]}/>

                <View>
                    <ItemRowGuideTripApply frameStyle={styles.tableFrame}
                                           text3={"指标"}
                                           text4={"完成值"}
                                           text5={"参考区间"}
                                           text6={"单位"}
                                           text2={false}
                                           text7={false}
                                           text1={false}/>

                    {
                        dataList.map(this.renderItem)
                    }
                </View>

            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    dpFrame:{
        width:150,
    },

    itemRowFrameBottom:{
        marginBottom:10,
    },

    searchFrame:{
        justifyContent:'flex-start',
        marginLeft:-10,
    },

    itemRowFrame:{
        marginBottom:10,
    },

    tableFrame:{
        backgroundColor:Theme.Colors.themeColorLight1,
        marginTop:10,
    },

    cpFrame:{
        marginTop:10,
        padding:10,
    },

    titleFrame_Text0:{
        fontSize:Theme.Font.fontSize_1,
        marginRight:5,
    },
    titleFrame_Text:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.themeColor,
    },
    titleFrame_1:{
        flexDirection:'row',
        flex:1,
        alignItems:'center',
        justifyContent:'flex-start',
    },
    titleFrame_2:{
        flex:1,
        alignItems:'center',
        justifyContent:'flex-start',
    },
    titleFrame_0:{
        flexDirection:'row',
    },
    titleFrame:{
        padding:10,
        flex:1,
        backgroundColor:Theme.Colors.foregroundColor,
    },
});
