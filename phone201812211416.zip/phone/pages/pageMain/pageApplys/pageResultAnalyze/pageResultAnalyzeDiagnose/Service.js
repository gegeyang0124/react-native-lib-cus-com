import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     * 获取运营中心业绩目标 数据
     * @param month string,//年月
     * @param companyId string,// 大区ID
     * @param regionId string,// 大区ID
     * **/
    static getTarget(month,companyId,regionId){

        return Http.post(HttpUrls.urlSets.urlResultProgressCenter,{
            companyId:companyId,// 大区id
            regionId:regionId,// 省区id
            //目标参数
            month:month,//查询月份
            //完成参数
            pageNumber: 1,
            pageSize: 10000
        })
            .then(retJson=>{
                let retObj = {
                    challenge_target:retJson.retData.challenge_target.toFixed(2),
                    challenge_finish:retJson.retData.month_achievement.toFixed(2),
                    challenge_finish_rate:retJson.retData.month_achievement
                    / (retJson.retData.challenge_target
                        ? retJson.retData.challenge_target
                        : retJson.retData.month_achievement),
                    base_target:retJson.retData.base_target.toFixed(2),
                    base_finish:retJson.retData.month_achievement.toFixed(2),
                    base_finish_rate:retJson.retData.month_achievement
                    / (retJson.retData.base_target
                        ? retJson.retData.base_target
                        : retJson.retData.month_achievement),
                    operations_target:retJson.retData.operations_target.toFixed(2),
                    operations_finish:retJson.retData.month_achievement.toFixed(2),
                    operations_finish_rate:retJson.retData.month_achievement
                    / (retJson.retData.operations_target
                        ? retJson.retData.operations_target
                        : retJson.retData.month_achievement)
                };

                retObj.challenge_finish_rate = retObj.challenge_finish_rate > 1
                    ? 1
                    : retObj.challenge_finish_rate;
                retObj.base_finish_rate = retObj.base_finish_rate > 1
                    ? 1
                    : retObj.base_finish_rate;
                retObj.operations_finish_rate = retObj.operations_finish_rate > 1
                    ? 1
                    : retObj.operations_finish_rate;

                return retObj;
            });

    }

    /**
     * 获取门店数据
     * @param deptId string,// 大区ID
     * @param month string,// YYYY-MM
     * **/
    static getShops(deptId,month){
        return Http.post(HttpUrls.urlSets.urlReportGetRerformancePre,{
            framework_id:deptId,
            month:month
        })
            .then(retJson=>{
                return {
                    store_count:retJson.retData.store_count,
                    user_count:retJson.retData.user_count
                };
            });
    }

    /**
     * 获取一级部门选择列表
     * **/
    static getDepartmentsOne(){

        /** department_level:1、运营中心；2、大区；3、区域
         **/
        return  Http.post(HttpUrls.urlSets.urlGetDepartmentListByType2,{
            userId:Tools.userConfig.userInfo.id
        })
            .then((retJson)=>{

                var retObj = [{
                    name:'全部',
                    id:Tools.userConfig.userInfo.department_id
                }];

                if(retJson.retListData.length > 0)
                {
                    retObj = retObj.concat(retJson.retListData);
                }

                return retObj;

            });

    }

    /**
     * 获取二级部门选择列表
     * @param parent_id string,//一级部门ID
     * **/
    static getDepartmentsTwo(parent_id){

        return Http.post(HttpUrls.urlSets.urlGetDepartmentListByParentId,{
            parent_id:parent_id
        },false)
            .then((retJson)=>{
                // alert(HttpUrls.urlSets.urlGetDepartmentListByParentId)
                // setTimeout(()=>{Tools.progress.show(false)},500);
                var lst = [
                    {
                        name:'全部',
                        id:parent_id
                    }
                ];
                retJson.retListData = lst.concat(retJson.retListData);
                // modelTrip.set("areaLst",retJson.retListData);

                return retJson.retListData;
            });

        // modelTrip.set("area",'');

    }

    /**
     * 获取指标
     * @param deptId string,// 大区ID
     * @param month string,// YYYY-MM
     * **/
    static getIndicatorData(deptId,month){
        return Http.post(HttpUrls.urlSets.urlReportGetIndexTableAndAdvice, {
            framework_id:deptId,
            month:month
        }).then(retJson=>{
            let retObj = [];

            retJson.retData.reportList
                .forEach((v,i,a)=>{
                    let item = {
                        title:v.name,
                        dataList:[]
                    };

                    v.data.forEach((v1,i1,a1)=>{
                        item.dataList.push({
                            text1:v1.name,
                            text2:v1.dict_value,
                            text3:v1.value_range,
                            text4:v1.unit,
                        });
                    });

                    retObj.push(item);
                });

            return retObj;
        });
    }


}
