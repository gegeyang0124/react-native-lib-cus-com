import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird'

import PageResultAnalyzeGuideArea from "./pageResultAnalyzeGuideArea/PageResultAnalyzeGuideArea";
import PageResultAnalyzeGuideProvince from "./pageResultAnalyzeGuideProvince/PageResultAnalyzeGuideProvince";
import PageResultAnalyzeGuideOrders from "./pageResultAnalyzeGuideOrders/PageResultAnalyzeGuideOrders";

const TabRouteConfigs = {
    PageResultAnalyzeGuideArea: {
        screen: PageResultAnalyzeGuideArea,
        navigationOptions: {
            title:'巡店分析',
            tabBarLabel : '大区分析',
        },
    },
    PageResultAnalyzeGuideProvince: {
        screen: PageResultAnalyzeGuideProvince,
        navigationOptions: {
            title:'巡店分析',
            tabBarLabel : '省区分析',
        },
    },
    PageResultAnalyzeGuideOrders: {
        screen: PageResultAnalyzeGuideOrders,
        navigationOptions: {
            title:'门店充值单明细',
            tabBarLabel : '门店充值单明细',
        },
    },

};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;