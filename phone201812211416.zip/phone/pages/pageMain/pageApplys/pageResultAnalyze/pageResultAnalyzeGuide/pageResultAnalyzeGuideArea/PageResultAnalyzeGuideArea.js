import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    ResultProgressBlock,
    Theme,
    TitleBlockTarget,
    ItemRowGuideTripApply,
} from "com";
import { Service } from "./Service";

import ImageOrderRank from 'images/orderRank.png';

type Props = {};
export default class PageResultAnalyzeGuideArea extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.dataList = [];

        this.state = {
            dataList:[],
        };

        this.setParams({
            headerLeft: true,
            headerRight:false
        });
    }

    getProvinceAnalyze(companyid,month,index){
        Service.getProvinceAnalyze(companyid,month)
            .then(retJson=>{
                let count = 0;
                retJson.forEach((v,i,a)=>{
                    count += v.validTaskCount;
                    v.companyid = this.dataList[index].companyid;
                    v.companyname = this.dataList[index].companyname;
                });

                this.dataList[index].effectiveCount = count;
                this.dataList[index].privinceAreaList = retJson;

                let retObj = {
                    dataList:[]
                };
                this.dataList.map((v,i,a)=>{
                    retObj.dataList.push(v);
                });
                this.setState(retObj);
            });
    };

    getData = (time)=>{
        time = time == undefined ? new Date().getTime() : time;
        time = Tools.timeFormatConvert(time,"YYYY-MM")
        Service.getRegionAnalyze(time)
            .then(retJson=>{
                this.dataList = retJson;
                this.setState({dataList:retJson});

                retJson.forEach((v,i,a)=>{
                    this.getProvinceAnalyze(v.companyid,time,i);
                });

            });
        // this.setState({"targetSpurtTBL":[{"textRight":"万元","textCenter":880.7,"textDown":"挑战目标:0.7万元","color":"red"},{"textRight":"万元","textCenter":289.78,"textDown":"老客户目标:0.19万元","color":"#FF6B01"},{"textRight":"万元","textCenter":590.92,"textDown":"新客户目标:0.51万元","color":"#1aff84"}],"targetSpurtProgress":[{"textLeft":"老  客  户","progress":1,"textRight":"152515.79%","colors1":"#FF6B01"},{"textLeft":"老  客  户","progress":1,"textRight":"115866.67%","colors1":"#1aff84"}],"targetOperateTBL":[{"textRight":"万元","textCenter":880.7,"textDown":"运营目标:0万元","color":"red"},{"textRight":"万元","textCenter":289.78,"textDown":"老客户目标:0万元","color":"#FF6B01"},{"textRight":"万元","textCenter":590.92,"textDown":"新客户目标:0万元","color":"#1aff84"}],"targetOperateProgress":[{"textLeft":"达成占比","progress":1,"textRight":"100.00%","colors1":"red"},{"textLeft":"老  客  户","progress":1,"textRight":"100.00%","colors1":"#FF6B01"},{"textLeft":"老  客  户","progress":1,"textRight":"100.00%","colors1":"#1aff84"}],"operateProgress":[{"textLeft":"挑战目标","textRight":"0.7/万元","progress":1,"colors1":"red"},{"textLeft":"运营目标","textRight":"0/万元","progress":1,"colors1":"#FF6B01"}],"progressFinish":1,"custemrCount":0});

    }

    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
    }

    onPressRow(item,i,type){
        if(type == 0){
            // alert("区域");
           this.goPage("PageResultAnalyzeGuideProvince",{
               regionid:item.regionid,
               regionname:item.regionname,
               companyid:item.companyid,
               companyname:item.companyname
           });
        }
        else {
            this.goPage("PageResultAnalyzeGuideOrders",{
                isProvince:true,
                id:item.regionid,
            });
        }
    }

    renderRowItem = (item,i)=>{
        return(
            <ItemRowGuideTripApply key={i}
                                   frameStyle={styles.tableFrame}
                                   text1Style={styles.text1Style}
                                   text2Style={styles.text2Style}
                                   text7Style={styles.text7Style}
                                   onPress1={()=>this.onPressRow(item,i,0)}
                                   onPress7={()=>this.onPressRow(item,i,1)}
                                   text1={item.regionname}
                                   text2={item.customerCount}
                                   text3={item.taskCount}
                                   text4={item.taskCount - item.validTaskCount}
                                   text5={item.taskPercentage}
                                   text6={item.validTaskCount}
                                   text7={item.totalChargeMoney}/>
        );
    }

    renderItem = (item,i)=>{

        return(
            <TitleBlockTarget key={i}
                              textCenterBlockStyle={styles.textCenterBlockStyle}
                              textBlockStyle={styles.textBlockStyle}
                              frameStyle={styles.targetFrame}
                              title={item.companyname}
                              progressTopList={[
                                  {
                                      textLeft:"业务人员",
                                      progress:item.userPer,
                                      textRight:item.userCount + "人",
                                      colors1:Theme.Colors.backgroundColor3
                                  },
                                  {
                                      textLeft:"客户数量",
                                      progress:item.customerPer,
                                      textRight:item.customerCount + "人",
                                      colors1:Theme.Colors.themeColor
                                  }
                              ]}
                              titleBlockList={[
                                  {
                                      textRight:"次",
                                      textCenter:item.taskCount,
                                      textDown:"巡店次数",
                                      color:Theme.Colors.themeColor
                                  },
                                  {
                                      textRight:"%",
                                      textCenter:(item.taskPercentage * 100).toFixed(2),
                                      textDown:"拜访率",
                                      color:Theme.Colors.barGreen
                                  },
                                  {
                                      textRight:"次",
                                      textCenter:item.effectiveCount,
                                      textDown:"有效巡店次数",
                                      color:Theme.Colors.backgroundColor3
                                  },
                                  {
                                      textRight:"元",
                                      textCenter:item.chargeMoney,
                                      textDown:"门店充值金额",
                                      color:Theme.Colors.appRedColor
                                  }
                              ]}>

                <View style={styles.table}>

                    <ItemRowGuideTripApply frameStyle={styles.tableFrame}
                                           text1={"省区"}
                                           text2={"客户数量"}
                                           text3={"巡店次数"}
                                           text4={"未巡店次数"}
                                           text5={"拜访率"}
                                           text6={"有效拜访次数"}
                                           text7={"巡店回款"}/>

                    {
                        item.privinceAreaList&&item.privinceAreaList.map(this.renderRowItem)
                    }

                </View>

            </TitleBlockTarget>
        );
    }

    render() {
        const {dataList} = this.state;
        // let dataList = [1];
        return (
            <ViewTitle>
                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>

                {
                    dataList.map(this.renderItem)
                }

            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    textBlockStyle:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    textCenterBlockStyle:{
        fontSize:Theme.Font.fontSize1,
    },

    text7Style:{
        color:Theme.Colors.themeColor,
    },
    text2Style:{
        color:Theme.Colors.backgroundColor3,
    },
    text1Style:{
        color:Theme.Colors.themeColor,
    },
    table:{
        borderTopWidth:Theme.Border.borderWidth,
        borderLeftWidth:Theme.Border.borderWidth,
        borderColor:Theme.Colors.minorColor,
        marginLeft:20,
        marginRight:20,
        marginBottom:10,
    },
    tableFrame:{
        // paddingLeft:20,
        // paddingRight:20,
    },

    targetFrame:{
        marginTop:10,
    },


    titleFrame:{
        marginTop:10,
    },
});
