import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     *  获取区域数据 数据
     * @param month string,//年月
     * **/
    static getRegionAnalyze(month){

        return Http.post(HttpUrls.urlSets.urlGuideAnalyzeArea,{
            //目标参数
            month:month,//查询月份
            //完成参数
            pageNumber: 1,
            pageSize: 10000
        })
            .then(retJson=>{
                let maxUserCount = retJson.retListData[0].userCount;
                let maxCustomerCount = retJson.retListData[0].customerCount;

                retJson.retListData
                    .forEach((v,i,a)=>{
                        maxUserCount = v.userCount > maxUserCount
                            ? v.userCount
                            : maxUserCount;

                        maxCustomerCount = v.customerCount > maxCustomerCount
                            ? v.customerCount
                            : maxCustomerCount;
                    });

                retJson.retListData
                    .forEach((v,i,a)=>{
                        v.userPer = v.userCount / maxUserCount;
                        v.userPer = v.userPer > 1 ? 1 : v.userPer;
                        v.customerPer = v.customerCount / maxCustomerCount;
                        v.customerPer = v.customerPer > 1 ? 1 : v.customerPer;
                    });

                return retJson.retListData;

            });

    }

    /**
     * 获取省区数据
     * @param companyid string,//分公司/大区id
     * **/
    static getProvinceAnalyze(companyid,month){
        return Http.post(HttpUrls.urlSets.urlGuideAnalyzeBusinessCheck,{
            companyid:companyid,//分公司/大区id
            month:month,//查询月份
            queryType:1 + '',//查询级别，1、大区；2、省区；3、客户经理 //1.按照区域分组，2.不按照区域分组
            job_grade:Tools.userConfig.userInfo.job_grade,//职位级别
        })
            .then(retJson=>{


                return retJson.retListData;

            });
    }

}
