import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    Theme,
    ItemRowGuideTripApply,
} from "com";

import { Service } from "./Service";

type Props = {};
export default class PageResultAnalyzeGuideOrders extends BaseComponent<Props> {


    constructor(props) {
        super(props);


        this.state = {
            dataList:[],
        };

        this.setParams({
            headerLeft: true,
            headerRight:false
        });
    }


    componentWillEnter(param){
          this.getData(param.id,param.isProvince);
    }

    getData(id,isProvince){
        // id = "1009";
        Service.get(id,isProvince)
            .then(retJson=>{
                this.setState({dataList:retJson});
            });

    }


    componentWillMount(){

    }

    componentDidMount(){
        // this.getData();
    }

    renderRowItem = (item,i)=>{


        return(
            <ItemRowGuideTripApply key={i}
                                   text1Style={styles.text1Style}
                                   text2={item.createTime}
                                   text4={item.userName}
                                   text5={item.storeName}
                                   frameChild6Style={styles.frameChild6Style}
                                   text6Style={styles.text6Style}
                                   text6={item.money + "/元"}/>
        );
    }



    render() {
        const {dataList} = this.state;

        return (
            <ViewTitle>

                <View style={styles.cntFrame}>

                    <View style={styles.table}>

                        <ItemRowGuideTripApply frameStyle={styles.tableFrame}
                                               frameStyleChild={styles.frameStyleChild}
                                               text2={"日期"}
                                               text4={"客户经理"}
                                               text5={"客户名称"}
                                               text6={"充值金额"}/>


                        {
                            dataList.map(this.renderRowItem)
                        }
                    </View>

                </View>



            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    frameChild6Style:{
        borderRightWidth:0,
    },
    text6Style:{
        color:Theme.Colors.themeColor,
    },

    frameStyleChild:{
        borderBottomWidth:0,
        borderRightWidth:0,
    },

    cntFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },

    text1Style:{
        color:Theme.Colors.themeColor,
    },
    table:{
        // borderTopWidth:Theme.Border.borderWidth,
        // borderLeftWidth:Theme.Border.borderWidth,
        // borderColor:Theme.Colors.minorColor,
        marginLeft:20,
        marginRight:20,
        marginBottom:10,
        marginTop:10,
    },
    tableFrame:{
        borderBottomWidth:Theme.Border.borderWidth1,
        borderBottomColor:Theme.Colors.themeColor,
    },

});
