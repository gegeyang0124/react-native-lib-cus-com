import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     *  获取门店充值明细数据 数据
     * @param id string,//个人id\省区id
     * @param isProvince bool,//是否是省区 默认false 不是
     * **/
    static get(id,isProvince){

        return Http.get(HttpUrls.urlSets.urlGuideAnalyzeRechargeDetail,{
            userId:isProvince ? 0 : id,//个人id,无就是0 275
            provinceId:isProvince ? id : 0,//省区id,无就是0
            isNotUser:true,
        })
            .then(retJson=>{

                return retJson.retData;

            });

    }

}
