import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    Theme,
    ItemRowGuideTripApply,
    SearchDDDIpt,
    ItemRowTitle,
} from "com";
import {
    CheckBox
} from 'comThird';

import { Service } from "./Service";

type Props = {};
export default class PageResultAnalyzeGuideProvince extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            regionid:null,//省区ID
            regionname:"正在加载",//省区名
            companyid:null,//大区id
            companyname:"正在加载",//大区名
        };

        this.state = {
            time: new Date().getTime(),//
            dataList:[],
            departmentListOne:[],
            departmentListTwo:[],
            clearDropOne:true,
            clearDropTwo:true,
            username:Tools.userConfig.userInfo.department_level == 3
                ? Tools.userConfig.userInfo.full_name
                : '',//用户名

            regionid:Tools.userConfig.userInfo.department_level == 3
                ? Tools.userConfig.userInfo.department_id
                : '',//省区ID
            regionname:Tools.userConfig.userInfo.department_level == 3
                ? Tools.userConfig.userInfo.department_name
                : "正在加载",//省区名
            companyid:Tools.userConfig.userInfo.department_level == 2
                ? Tools.userConfig.userInfo.department_id
                : '',//大区id
            companyname:Tools.userConfig.userInfo.department_level == 2
                ? Tools.userConfig.userInfo.department_name
                : "正在加载",//大区名

            isShow:false,//是否只显示异常 默认false 显示全部
        };

        this.setParams({
            headerLeft: true,
            headerRight:false
        });
    }

    componentWillEnter(param){

        if(param){
            param.clearDropOne = true;
            param.clearDropTwo = true;
            // alert(JSON.stringify(param))
            this.setState(param);
                this.state.regionid=param.regionid,
                this.state.regionname=param.regionname,
                this.state.companyid=param.companyid,
                this.state.companyname=param.companyname

        }

        this.getData();
        this.getDepartmentsTwo()
    }

    getData = (time)=>{

        time = time == undefined ? this.state.time : time;
        this.state.time = time;

        Service.getPersonalAnalyze(Tools.timeFormatConvert(this.state.time,"YYYY-MM"),
            this.state.companyid,
            this.state.regionid,
            this.state.username)
            .then(retJson=>{
                this.setState({dataList:retJson});
            });

    }

    getDepartmentsOne(){
        Service.getDepartmentsOne()
            .then(retJson=>{
                let retObj = {
                    departmentListOne:retJson
                };

                if(Tools.userConfig.userInfo.department_level > 1 ){
                    retObj.companyname = retJson[1].name;
                }
                this.setState(retObj);
            });
    }

    getDepartmentsTwo(){
        Service.getDepartmentsTwo(this.state.companyid)
            .then(retJson=>{

                this.setState({
                    regionname:retJson[0].name,
                    clearDropTwo:true,
                    departmentListTwo:retJson
                });
            });
    }

    componentWillMount(){

    }

    componentDidMount(){
        // this.getData();
        this.getDepartmentsOne();
    }

    onPressRow(item,i,type){
        this.goPage("PageResultAnalyzeGuideOrders",{
            isProvince:false,
            id:item.userid,
        });
    }

    renderRowItem = (item,i)=>{

        let isShow = !this.state.isShow || item.exception == 2;// 异常 1:正常 2:异常
        return(
            isShow && <ItemRowGuideTripApply key={i}
                                             frameStyle={styles.tableFrame}
                                             text1Style={styles.text1Style}
                                             onPress1={()=>this.onPressRow(item,i,0)}
                                             text1={item.username}
                                             text2={item.customerCount}
                                             text3={item.taskCount}
                                             text4={item.untaskCustomerCount}
                                             text5={item.taskPercentage * 100 + "%"}
                                             text6={item.validTaskCount}
                                             text7={item.totalChargeMoney}/>
        );
    }

    onSelectDrop(val,i,type){
        if(type == 0){
            this.state.companyid = val.id;
            this.state.regionid = null;
            if(this.state.clearDropOne){
                this.setState({
                    clearDropOne:false
                });
            }
            this.getDepartmentsTwo();

        }
        else {
            this.state.regionid = val.id;
            if(this.state.clearDropTwo){
                this.setState({
                    clearDropTwo:false
                });
            }
        }
    }

    onChecked = (isChecked)=>{
        this.setState({
            isShow:isChecked
        });
    }

    render() {
        const {dataList,departmentListOne,clearDropOne,companyname,regionname,
            clearDropTwo,departmentListTwo} = this.state;

        return (
            <ViewTitle>
                <View style={styles.headerFrame}>
                    <TitleRow frameStyle={styles.titleFrame}
                              onPressLeft={this.getData}
                              onPressRight={this.getData}
                              onPressCenter={this.getData}
                              textLeft={"上一月"}
                              textRight={"下一月"}/>

                    <View style={styles.searchFrame}>
                        <SearchDDDIpt isPickDropdown3={false}
                                      placeholder={"--姓名--"}
                                      textChange={(text)=>this.state.username = text}
                                      options1={{
                                          style:styles.dpFrame,
                                          defaultValue:companyname,
                                          options:departmentListOne,
                                          onDropdownWillShow:()=>Tools.userConfig.userInfo.department_level == 1 || false,
                                          clearDrop:clearDropOne,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,0)
                                      }}
                                      options2={{
                                          style:styles.dpFrame,
                                          defaultValue:regionname,
                                          options:departmentListTwo,
                                          onDropdownWillShow:()=>Tools.userConfig.userInfo.department_level < 3 || false,
                                          clearDrop:clearDropTwo,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                      }}
                                      isTextInput={Tools.userConfig.userInfo.department_level < 3 || false}
                                      isSearch={Tools.userConfig.userInfo.department_level < 3 || false}
                                      onPressSearch={()=>this.getData()}/>
                        <CheckBox rightText={"异常分析"}
                                  style={styles.chkFrame}
                                  onClick={this.onChecked}
                                  rightTextStyle={styles.chkText}
                                  imageStyle={styles.chkImage}/>
                    </View>
                </View>

                <View style={styles.cntFrame}>
                    <ItemRowTitle text1={"业务员巡店分析"}/>

                    <View style={styles.table}>

                        <ItemRowGuideTripApply frameStyle={styles.tableFrame}
                                               text1={"省区"}
                                               text2={"客户数量"}
                                               text3={"巡店次数"}
                                               text4={"未巡客户"}
                                               text5={"拜访率"}
                                               text6={"有效拜访次数"}
                                               text7={"巡店回款"}/>


                        {
                            dataList.map(this.renderRowItem)
                        }
                    </View>

                </View>



            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    cntFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },

    dpFrame:{
        width:120,
    },
    chkFrame:{
        marginLeft:20,
    },
    chkText:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    chkImage:{
        tintColor:Theme.Colors.themeColor,
        width:Theme.Font.fontSize_1_1 + 5,
        height:Theme.Font.fontSize_1_1 + 5 + 'dw',
    },
    headerFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
    searchFrame:{
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',
    },
    titleFrame:{
        marginTop:10,
    },


    text1Style:{
        color:Theme.Colors.themeColor,
    },
    table:{
        borderTopWidth:Theme.Border.borderWidth,
        borderLeftWidth:Theme.Border.borderWidth,
        borderColor:Theme.Colors.minorColor,
        marginLeft:20,
        marginRight:20,
        marginBottom:10,
    },
    tableFrame:{
        // paddingLeft:20,
        // paddingRight:20,
    },

});
