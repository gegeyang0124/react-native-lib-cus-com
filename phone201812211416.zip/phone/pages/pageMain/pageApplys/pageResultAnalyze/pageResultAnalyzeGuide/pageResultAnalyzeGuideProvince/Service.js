import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     *  获取区域数据 数据
     * @param month string,//年月
     * @param companyid string,//大区ID
     * @param regionid string,//省区ID
     * @param username string,//用户名
     * **/
    static getPersonalAnalyze(month,companyid,regionid,username){

        return Http.post(HttpUrls.urlSets.urlGuideAnalyzeBusinessCheck,{
            month:month, //月
            department_level:Tools.userConfig.userInfo.department_level + '',
            framework_id:Tools.userConfig.userInfo.department_id + '',
            companyid:companyid,// 	分公司/大区id
            regionid:regionid,//	省区id
            username:username,//员工姓名
            queryType:2 + '',//查询级别，1、大区；2、省区；3、客户经理 //1.按照区域分组，2.不按照区域分组
            job_grade:Tools.userConfig.userInfo.job_grade,//职位级别
        })
            .then(retJson=>{

                return retJson.retListData;

            });

    }

    /**
     * 获取省区数据
     * @param companyid string,//分公司/大区id
     * **/
    static getProvinceAnalyze(companyid,month){
        return Http.post(HttpUrls.urlSets.urlGuideAnalyzeBusinessCheck,{
            companyid:companyid,//分公司/大区id
            month:month,//查询月份
            queryType:1 + '',//查询级别，1、大区；2、省区；3、客户经理 //1.按照区域分组，2.不按照区域分组
            job_grade:Tools.userConfig.userInfo.job_grade,//职位级别
        })
            .then(retJson=>{
                return retJson.retListData;

            });
    }

    /**
     * 获取一级部门选择列表
     * **/
    static getDepartmentsOne(){

        /** department_level:1、运营中心；2、大区；3、区域
         **/
        return  Http.post(HttpUrls.urlSets.urlGetDepartmentListByType2,{
            userId:Tools.userConfig.userInfo.id
        })
            .then((retJson)=>{

                var retObj = [];

                if(retJson.retListData.length > 0)
                {
                    retObj = retObj.concat(retJson.retListData);
                }

                return retObj;

            });

    }

    /**
     * 获取二级部门选择列表
     * @param parent_id string,//一级部门ID
     * **/
    static getDepartmentsTwo(parent_id){

        return Http.post(HttpUrls.urlSets.urlGetDepartmentListByParentId,{
            parent_id:parent_id
        })
            .then((retJson)=>{

                var lst = [
                    {
                        name:'全部',
                        id:''
                    }
                ];
                retJson.retListData = lst.concat(retJson.retListData);

                return retJson.retListData;
            });

    }


}
