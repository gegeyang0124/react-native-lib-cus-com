import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird'
import PageResultAnalyzeProgressCenter from "./pageResultAnalyzeProgressCenter/PageResultAnalyzeProgressCenter";
import PageResultAnalyzeProgressArea from "./pageResultAnalyzeProgressArea/PageResultAnalyzeProgressArea";

const TabRouteConfigs = {
    PageResultAnalyzeProgressCenter: {
        screen: PageResultAnalyzeProgressCenter,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '业绩中心',
        },
    },
    PageResultAnalyzeProgressArea: {
        screen: PageResultAnalyzeProgressArea,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '区域业绩',
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;