import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird'
import PageResultAnalyzeProgressAreaRegion from "./pageResultAnalyzeProgressAreaRegion/PageResultAnalyzeProgressAreaRegion";
import PageResultAnalyzeProgressAreaProvince from "./pageResultAnalyzeProgressAreaProvince/PageResultAnalyzeProgressAreaProvince";
import PageResultAnalyzeProgressAreaCustomer from "./pageResultAnalyzeProgressAreaCustomer/PageResultAnalyzeProgressAreaCustomer";
import PageResultAnalyzeProgressAreaRank from "./pageResultAnalyzeProgressAreaRank/PageResultAnalyzeProgressAreaRank";

const TabRouteConfigsRegion = {
    PageResultAnalyzeProgressAreaRegion: {
        screen: PageResultAnalyzeProgressAreaRegion,
        navigationOptions: {
            // tabBarVisible: false, // 隐藏Tab导航栏
            title:'业绩进度',
            tabBarLabel : '大区',
        },
    },
    PageResultAnalyzeProgressAreaProvince: {
        screen: PageResultAnalyzeProgressAreaProvince,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '省区',
        },
    },
    PageResultAnalyzeProgressAreaCustomer: {
        screen: PageResultAnalyzeProgressAreaCustomer,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '客户经理',
        },
    },
};
const pagesRegions = TabNavigator(TabRouteConfigsRegion, Theme.TabNavigatorConfigsTop);

const TabRouteConfigsProvince = {
    PageResultAnalyzeProgressAreaProvince2: {
        screen: PageResultAnalyzeProgressAreaProvince,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '省区',
        },
    },
    PageResultAnalyzeProgressAreaCustomer2: {
        screen: PageResultAnalyzeProgressAreaCustomer,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '客户经理',
        },
    },


};
const pagesProvinces = TabNavigator(TabRouteConfigsProvince, Theme.TabNavigatorConfigsTop);

const TabRouteConfigs = {
    PageResultAnalyzeProgressAreaRegions: {
        screen: pagesRegions,
        navigationOptions: {
            title:'业绩进度',
        },
    },
    PageResultAnalyzeProgressAreaProvinces: {
        screen: pagesProvinces,
        navigationOptions: {
            title:'业绩进度',
        },
    },
    PageResultAnalyzeProgressAreaRank: {
        screen: PageResultAnalyzeProgressAreaRank,
        navigationOptions: {
            title:'业绩进度',
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;