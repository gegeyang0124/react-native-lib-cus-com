import React, {Component} from 'react';
import moment from 'moment';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    ResultProgressBlock,
    Theme,
    TitleBlockTargetArea,
    SearchDDDIpt,
    FlatListView,
} from "com";
import { Service } from "./Service";

import ImageOrderRank from 'images/orderRank.png';

type Props = {};
export default class PageResultAnalyzeProgressAreaCustomer extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            branchOffice:'',//选中的大区
            area:'',//选中的省区
            username:'',//客户经理的名字
            time:new Date().getTime(),
            nameOne:null,//大区名 默认
            nameTwo:null, //省区名 默认
            isExe:false,//是否执行
        };

        this.state = {
            dataList:[],//数据列表
            timeCircle:undefined,
            branchOfficeLst:[{
                name:'大区',
                id:''
            }],
            areaLst:[{
                name:'省区',
                id:''
            }],
            clearDrop:true,
            clearDropOne:true,
        };

        this.setParams({
            headerLeft: true,
            headerRight:ImageOrderRank,
            headerRightHandle:this.onPressHeaderRight
        });
    }

    onPressHeaderRight = (item,i)=>{
        this.goPage("PageResultAnalyzeProgressAreaRank");
    }

    getData = (time)=>{
        time = time == undefined ? this.selectedValue.time : time;
        //如果传入的时间小于当前时间则设置时间进度为100%
        let now = moment(new Date()).startOf('month').format("YYYY-MM-DD");

        //减去8小时
        now = new Date(now).getTime()-28800000;

        if(time < now){
            this.state.timeCircle = 1.0;
        }else{
            this.state.timeCircle = undefined;
        }

        this.selectedValue.time = time;
        Service.getProgresRegion(Tools.timeFormatConvert(this.selectedValue.time,"YYYY-MM"),
            this.selectedValue.branchOffice,
            this.selectedValue.area,
            this.selectedValue.username)
            .then(retJson=>{

                this.setState({
                    dataList:retJson
                });
            });
    }

    componentWillEnter(params,action,page){
        params = params == undefined ? {} : params;
        // alert(JSON.stringify(params))
        if(params.id){
            this.selectedValue.branchOffice = params.idOne;
            this.selectedValue.area = params.id;
            this.selectedValue.nameOne = params.nameOne;
            this.selectedValue.nameTwo = params.nameTwo;
            this.setState({
                clearDrop:true,
                clearDropOne:true,
                branchOfficeLst:[]
            });

            this.getData();
        }
        else if(!this.selectedValue.isExe){
            this.selectedValue.isExe = true;
            this.getData();
        }
    }

    getDepartmentsOne(){
        Service.getDepartmentsOne()
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    getDepartmentsTwo(){
        // Tools.toast(this.selectedValue.branchOffice)
        Service.getDepartmentsTwo(this.selectedValue.branchOffice)
            .then(retJson=>{
                this.setState({
                    clearDrop:true,
                    areaLst:retJson
                });
            });
    }

    onSelectDrop(val,i,type){
        this.selectedValue.nameOne = null;
        this.selectedValue.nameTwo = null;
        switch (type){
            case 0:{

                this.selectedValue.branchOffice = val.id;
                this.selectedValue.area = '';
                if(this.state.clearDropOne){
                    this.setState({
                        clearDropOne:false
                    });
                }
                this.getDepartmentsTwo();
                break;
            }
            case 1:{
                this.selectedValue.area = val.id;
                if(this.state.clearDrop){
                    this.setState({
                        clearDrop:false
                    });
                }
                break;
            }
            case 2:{
                this.selectedValue.username = val;
                break;
            }
        }
    }

    componentWillMount(){

    }

    componentDidMount(){
        // this.getData();
        this.getDepartmentsOne();
    }

    renderItem = (item,i)=>{
        var preJd = item.progressCircle;

        var date = "";
        if(this.state.timeCircle != undefined){
            var res = moment(this.selectedValue.time).endOf('month').format("YYYY-MM-DD");
            date = new Date(res);
        }else{
            date = new Date();
        }

        var day = moment(date).format('DD');
        var monthDay = moment(date).daysInMonth();
        var jd = day/monthDay;
        item.status = 0;

        if(preJd < jd && preJd > (jd-0.1)){
            item.status = 2;
        }else if(preJd < jd){
            item.status = 1;
        }
        return(
            <TitleBlockTargetArea key={i}
                                  status={item.status}
                                  title={item.name}
                                  timeCircle={this.state.timeCircle}
                                  frameStyle={i&&styles.areaFrame}
                                  progressCircle={item.progressCircle}
                                  progressResultList={item.progressResultList}
                                  progressTargetList={item.progressTargetList}/>
        );
    }

    render() {
        const {dataList,branchOfficeLst,areaLst,clearDrop,clearDropOne} = this.state;
        let {nameOne,nameTwo} = this.selectedValue;

        nameOne = nameOne != null
            ? nameOne
            : Tools.userConfig.userInfo.department_level == 1
                ? '大区'
                : Tools.userConfig.userInfo.department_name;
        nameTwo = nameTwo != null
            ? nameTwo
            : Tools.userConfig.userInfo.department_level == 1
                ? '省区'
                : Tools.userConfig.userInfo.department_name;

        return (
            <ViewTitle isScroll={false}>

                {
                    (Tools.userConfig.userInfo.department_level < 3)
                    &&<SearchDDDIpt frameStyle={styles.searchFrame}
                                    isPickDropdown3={false}
                                    placeholder={'--姓名--'}
                                    textChange={(text)=>this.onSelectDrop(text,2,2)}
                                    options1={{
                                        frameStyle:styles.searchFrameDropdown,
                                        style:styles.searchFrameDropdown,
                                        defaultValue:nameOne,
                                        options:branchOfficeLst,
                                        clearDrop:clearDropOne,
                                        onSelect:(i,val)=>this.onSelectDrop(val,i,0)
                                    }}
                                    options2={{
                                        frameStyle:styles.searchFrameDropdown,
                                        style:styles.searchFrameDropdown,
                                        defaultValue:nameTwo,
                                        options:areaLst,
                                        clearDrop:clearDrop,
                                        onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                    }}
                                    onPressSearch={this.getData}/>
                }


                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>

                <FlatListView
                    style={styles.flatListView}
                    data={dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}
                    // onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    flatListView:{
        marginTop:10,
        marginBottom:10,
    },
    searchFrameDropdown:{
        flex:1,
    },
    searchFrame:{
        paddingLeft:20,
        paddingRight:20,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    areaFrame:{
        marginTop:10,
    },

    titleFrame:{
        marginTop:10,
    },
});
