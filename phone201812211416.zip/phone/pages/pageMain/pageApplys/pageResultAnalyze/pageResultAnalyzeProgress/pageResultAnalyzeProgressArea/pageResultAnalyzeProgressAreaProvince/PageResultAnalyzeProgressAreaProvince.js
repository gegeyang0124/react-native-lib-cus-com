import React, {Component} from 'react';
import {Text, View,} from 'react-native';
import moment from 'moment';
import {
    BaseComponent,
    ResultProgressBlock,
    SearchDDDIpt,
    StyleSheetAdapt,
    Theme,
    TitleBlockTargetArea,
    TitleRow,
    Tools,
    ViewTitle,
    FlatListView,
} from "com";
import {Service} from "./Service";

import ImageOrderRank from 'images/orderRank.png';

type Props = {};
export default class PageResultAnalyzeProgressAreaProvince extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            branchOffice:'',//选中的大区
            area:'',//选中的省区
            time:new Date().getTime(),
            nameOne:null,//大区名 默认
            isExe:false,//是否执行
            timeCircle:undefined,
        };

        this.state = {
            dataList:[],//数据列表
            branchOfficeLst:[{
                name:'大区',
                id:''
            }],
            areaLst:[{
                name:'省区',
                id:''
            }],
            clearDrop:true,
            clearDropOne:true,
        };

        this.setParams({
            headerLeft: true,
            headerRight:ImageOrderRank,
            headerRightHandle:this.onPressHeaderRight
        });
    }

    componentWillEnter(params,action,page){
        params = params == undefined ? {} : params;
        if(params.id){
            this.selectedValue.branchOffice = params.id;
            this.selectedValue.nameOne = params.name;
            this.setState({
                clearDropOne:true,
            });

            this.getData();
        }
        else if(!this.selectedValue.isExe){
            this.selectedValue.isExe = true;
            this.getData();
        }

    }

    onPressHeaderRight = (item,i)=>{
        this.goPage("PageResultAnalyzeProgressAreaRank");
    }

    onPressItemRight = (item,i)=>{
        let page = "PageResultAnalyzeProgressAreaCustomer";
        if(Tools.userConfig.userInfo.department_level != 1){
            page = "PageResultAnalyzeProgressAreaCustomer2";
        }

        this.goPage(page,
            {
                id:item.id,
                idOne:item.idOne,
                nameOne:item.nameOne,
                nameTwo:item.name
            });
    }

    getData = (time)=>{
        time = time == undefined ? this.selectedValue.time : time;

        //如果传入的时间小于当前时间则设置时间进度为100%
        let now = moment(new Date()).startOf('month').format("YYYY-MM-DD");

        //减去8小时
        now = new Date(now).getTime()-28800000;

        if(time < now){
            this.state.timeCircle = 1.0;
        }else{
            this.state.timeCircle = undefined;
        }

        this.selectedValue.time = time;
        Service.getProgresRegion(Tools.timeFormatConvert(this.selectedValue.time,"YYYY-MM"),
            this.selectedValue.branchOffice,
            this.selectedValue.area)
            .then(retJson=>{
                var preJd = retJson.progressFinish;
                var date = "";
                if(this.state.timeCircle != undefined){
                    var res = moment(time).endOf('month').format("YYYY-MM-DD");
                    date = new Date(res);
                }else{
                    date = new Date();
                }

                var day = moment(date).format('DD');
                var monthDay = moment(date).daysInMonth();
                var jd = day/monthDay;
                retJson.status = 0;

                if(preJd < jd && preJd > (jd-0.1)){
                    retJson.status = 2;
                }else if(preJd < jd){
                    retJson.status = 1;
                }
                this.setState({
                    dataList:retJson
                });
            });
    }

    getDepartmentsOne(){
        Service.getDepartmentsOne()
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    getDepartmentsTwo(){
        // Tools.toast(this.selectedValue.branchOffice)
        Service.getDepartmentsTwo(this.selectedValue.branchOffice)
            .then(retJson=>{
                this.setState({
                    clearDrop:true,
                    areaLst:retJson
                });
            });
    }

    onSelectDrop(val,i,type){
        this.selectedValue.nameOne = null;
        switch (type){
            case 0:{

                this.selectedValue.branchOffice = val.id;
                this.selectedValue.area = '';
                if(this.state.clearDropOne){
                    this.setState({
                        clearDropOne:false
                    });
                }
                this.getDepartmentsTwo();
                break;
            }
            case 1:{
                this.selectedValue.area = val.id;
                if(this.state.clearDrop){
                    this.setState({
                        clearDrop:false
                    });
                }
                break;
            }
        }
    }


    componentWillMount(){

    }

    componentDidMount(){
        this.getDepartmentsOne();
    }

    renderItem = (item,i)=>{

        var preJd = item.progressCircle;

        var date = "";
        if(this.state.timeCircle != undefined){
            var res = moment(this.selectedValue.time).endOf('month').format("YYYY-MM-DD");
            date = new Date(res);
        }else{
            date = new Date();
        }
        var day = moment(date).format('DD');
        var monthDay = moment(date).daysInMonth();
        var jd = day/monthDay;
        item.status = 0;

        if(preJd < jd && preJd > (jd-0.1)){
            item.status = 2;
        }else if(preJd < jd){
            item.status = 1;
        }

        return(
            <TitleBlockTargetArea key={i}
                                  title={item.name}
                                  timeCircle={this.state.timeCircle}
                                  status={item.status}
                                  frameStyle={i&&styles.areaFrame}
                                  progressCircle={item.progressCircle}
                                  progressResultList={item.progressResultList}
                                  onPressTitleRight={()=>this.onPressItemRight(item,i)}
                                  progressTargetList={item.progressTargetList}/>
        );
    }

    render() {
        const {dataList,branchOfficeLst,areaLst,clearDrop,clearDropOne} = this.state;
        const {nameOne} = this.selectedValue;

        return (
            <ViewTitle isScroll={false}>

                {
                    (Tools.userConfig.userInfo.department_level < 3)
                    &&<SearchDDDIpt isTextInput={false}
                                    frameStyle={styles.searchFrame}
                                    isPickDropdown3={false}
                                    options1={{
                                        frameStyle:styles.searchFrameDropdown,
                                        style:styles.searchFrameDropdown,
                                        defaultValue:nameOne != null ? nameOne
                                            : Tools.userConfig.userInfo.department_level == 1
                                                ? '大区'
                                                : Tools.userConfig.userInfo.department_name,
                                        options:branchOfficeLst,
                                        clearDrop:clearDropOne,
                                        onSelect:(i,val)=>this.onSelectDrop(val,i,0)
                                    }}
                                    options2={{
                                        frameStyle:styles.searchFrameDropdown,
                                        style:styles.searchFrameDropdown,
                                        defaultValue:Tools.userConfig.userInfo.department_level == 1
                                            ? '省区'
                                            : Tools.userConfig.userInfo.department_name,
                                        options:areaLst,
                                        clearDrop:clearDrop,
                                        onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                    }}
                                    onPressSearch={this.getData}/>
                }


                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>


                <FlatListView
                    style={styles.flatListView}
                    data={dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}
                    // onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    flatListView:{
        marginTop:10,
        marginBottom:10,
    },
    searchFrameDropdown:{
        flex:1,
    },
    searchFrame:{
        paddingLeft:20,
        paddingRight:20,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    areaFrame:{
        marginTop:10,
    },

    titleFrame:{
        marginTop:10,
    },
});
