import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird'
import PageResultAnalyzeProgressAreaRankPerson from "./pageResultAnalyzeProgressAreaRankPerson/PageResultAnalyzeProgressAreaRankPerson";
import PageResultAnalyzeProgressAreaRankRegion from "./pageResultAnalyzeProgressAreaRankRegion/PageResultAnalyzeProgressAreaRankRegion";
import PageResultAnalyzeProgressAreaRankProvin from "./pageResultAnalyzeProgressAreaRankProvin/PageResultAnalyzeProgressAreaRankProvin";

const TabRouteConfigs = {
    PageResultAnalyzeProgressAreaRankPersonal: {
        screen: PageResultAnalyzeProgressAreaRankPerson,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '个人排名',
        },
    },
    PageResultAnalyzeProgressAreaRankProvince: {
        screen: PageResultAnalyzeProgressAreaRankProvin,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '省区排名',
        },
    },
    PageResultAnalyzeProgressAreaRankRegion: {
        screen: PageResultAnalyzeProgressAreaRankRegion,
        navigationOptions: {
            title:'业绩进度',
            tabBarLabel : '大区排名',
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigsTop);

module.exports = pages;