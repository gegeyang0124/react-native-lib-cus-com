import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    ResultProgressBlock,
    Theme,
    TitleBlockTargetArea,
    FlatListView,
    ItemRowGoods,
    ScrollSelectOptions,
} from "com";
import { Service } from "./Service";

import ImageShareFile from 'images/shareFile.png';

import ViewShot from "react-native-view-shot";

type Props = {};
export default class PageResultAnalyzeProgressAreaRankProvin extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = 0;//0、全部排名；1、前10名；2、后10名

        this.dataObj = {
            dataList0:[],//全部排名
            dataList1:[],//前10名
            dataList2:[],//后10名
        };

        this.state = {
            dataList:[],//数据列表
            time:(new Date()).getTime(),
            rankScope: [
                {text:'全部',isChecked:true},
                {text:'前10'},
                {text:'后10'}
            ]
        };


        this.setParams({
            headerLeft: true,
            // headerRight:false,
            headerRight:ImageShareFile,
            headerRightHandle:this.onPressHeaderRight
        });
    }

    onPressHeaderRight = ()=>{
        let d20 = [];
        let dAll = [];
        this.state.dataList.forEach((v,i,a)=>{
            if(i < 20){
                d20.push(v);
            }

            dAll.push(v);
        });

        this.setState({
            dataList:d20
        });



        setTimeout(()=>{
            Tools.captureViewScreen(this.vShotRef).then(()=>{
                this.setState({
                    dataList:dAll
                });
            }).catch(()=>{
                this.setState({
                    dataList:dAll
                });
            });
        },0);
    };

    onPressItem(item,i){

    }

    getData = (time)=>{
        time = time == undefined ? new Date().getTime() : time;
        Service.getRank(Tools.timeFormatConvert(time,"YYYY-MM"))
            .then(retJson=>{
                this.dataObj = retJson;

                let curDate = new Date();
                if(curDate.getMonth() == (new Date(time).getMonth())){
                    time = curDate.getTime();
                }
                else {
                    time = Tools.getTimeByRank(time,1).time2;
                }

                this.setState({
                    dataList:this.dataObj["dataList" + this.selectedValue],
                    time:time
                });
            });
    }


    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
    }

    renderItem = (item,i)=>{
        let color = null;
        switch (i){
            case 0:{
                color = Theme.Colors.appRedColor;
                break;
            }
            case 1:{
                color = Theme.Colors.themeColor;
                break;
            }
            case 2:{
                color = Theme.Colors.barGreen;
                break;
            }
        }
        return(
            <ItemRowGoods icon={item.photo}
                          frameStyle={i&&styles.itemRowFrame}
                          text0={item.userName}
                          text1_1={"业绩累计达成:" + Number(item.countSum * 100).toFixed(1) + "%" }
                          text2_1={"大区:" + item.region}
                          //text3_1={"部门:" + item.department}
                          text4_1={"岗位:" + item.station}
                          text5={i < 9 ? "0" + (i + 1) : (i + 1)}
                          isIconCirle={true}
                          color={color}
                          onPress={()=>this.onPressItem(item,i)}
                          text1_1_Style={styles.text1_1_Style}/>
        );
    }

    onChange = (param1,param2,param3,param4,param5)=>{
// alert(param4)
        if(!param1){
            this.selectedValue = 0;
        }
        else {
            this.selectedValue = param4;
        }

        this.setState({
            dataList:this.dataObj["dataList" + this.selectedValue]
        });
    }

    render() {
        const {dataList,time,rankScope} = this.state;

        return (
            <ViewTitle isScroll={false}>

                <View style={styles.titleChkFrame}>
                    <ScrollSelectOptions isScroll={false}
                                         isReset={true}
                                         onChange={this.onChange}
                                         frameStyle={styles.chkFrame}
                                         dataList={rankScope}/>

                    <View style={styles.textFrame}>
                        <Text style={styles.titleChkText}>
                            统计时间：{Tools.timeFormatConvert(time,"YYYY-MM-DD")}
                        </Text>
                    </View>

                </View>

                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>

                <FlatListView ref={c=>this.vShotRef = c}
                              style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItem(item,index)}
                    // onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        marginTop:10,
    },

    itemRowFrame:{
        marginTop:10,
    },
    titleChkText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    textFrame:{
        flex:2,
    },
    chkFrame:{
        flex:3,
        // backgroundColor:'yellow',
    },
    titleChkFrame:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
        // marginTop:10,
        justifyContent:'center',
        alignItems:'center',
    },

    text1_1_Style:{
        color:Theme.Colors.themeColor,
    },

    flatListView:{
        marginTop:10,
        marginBottom:10,
    },
});
