import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import ImageUserLogo from 'images/userLogo.png';

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    /**
     * 获取大区业绩排名 数据
     * @param month string,//"YYYY-MM"
     * **/
    static getRank(month){

        return Http.get(HttpUrls.urlSets.urlResultProgressRank,{
            //目标参数
            month:month,//查询月份"YYYY-MM"

            //完成参数
            pageNumber: 1,//页码
            pageSize: 10000,//每页条数
            rankArea:3,//排名区域，1、个人排名；2、省区排名；3、大区排名；
            // 返回数据前10名和后10名数据分开在两个字段，
            // false:不获取前10名和后10名
        })
            .then(retJson=>{

                let retObj = {
                    dataList0:retJson.retData,//全部排名
                    dataList1:[],//前10名
                    dataList2:[],//后10名
                };

                retJson.retData.forEach((v,i,a)=>{
                    v.department = undefined;
                    v.photo = v.photo == '' || v.photo == null
                        ? ImageUserLogo
                        : v.photo;
                    if(i < 10){
                        retObj.dataList1.push(v);
                        retObj.dataList2.push(retJson.retData[retJson.retData.length - 1 - i]);
                    }

                })

                return retObj;

            });
    }


}
