import React, {Component} from 'react';
import moment from 'moment';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    ResultProgressBlock,
    Theme,
    TitleBlockTargetArea,
    FlatListView,
} from "com";
import { Service } from "./Service";

import ImageOrderRank from 'images/orderRank.png';

type Props = {};
export default class PageResultAnalyzeProgressAreaRegion extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.state = {
           dataList:[],//数据列表
           timeCircle:undefined,
            time:null,
        };

        this.setParams({
            headerLeft: true,
            headerRight:ImageOrderRank,
            headerRightHandle:this.onPressHeaderRight
        });
    }



    onPressHeaderRight = (item,i)=>{
        this.goPage("PageResultAnalyzeProgressAreaRank");
    }

    onPressItemRight = (item,i)=>{
        if(Tools.userConfig.userInfo.department_level == 1){
            // alert("去往区域详情");
            this.goPage("PageResultAnalyzeProgressAreaProvince",{id:item.id,name:item.name});
        }
        else {
            // alert("去往区域详情");
            this.goPage("PageResultAnalyzeProgressAreaProvince2",{id:item.id,name:item.name});
        }

    }

    getData = (time)=>{
        time = time == undefined ? new Date().getTime() : time;

        time = time == undefined ? new Date().getTime() : time;
        //如果传入的时间小于当前时间则设置时间进度为100%
        let now = moment(new Date()).startOf('month').format("YYYY-MM-DD");

        //减去8小时
        now = new Date(now).getTime()-28800000;

        if(time < now){
            this.state.timeCircle = 1.0;
        }else{
            this.state.timeCircle = undefined;
        }

        Service.getProgresRegion(Tools.timeFormatConvert(time,"YYYY-MM"))
            .then(retJson=>{

                this.setState({
                    dataList:retJson,
                    time:time,
                });
            });
    }


    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
    }

    renderItem = (item,i)=>{
        var preJd = item.progressCircle;
        var date = "";
        if(this.state.timeCircle != undefined){
            var res = moment(this.state.time).endOf('month').format("YYYY-MM-DD");
            date = new Date(res);
        }else{
            date = new Date();
        }

        var day = moment(date).format('DD');
        var monthDay = moment(date).daysInMonth();
        var jd = day/monthDay;
        item.status = 0;

        if(preJd < jd && preJd > (jd-0.1)){
            item.status = 2;
        }else if(preJd < jd){
            item.status = 1;
        }

        return(
            <TitleBlockTargetArea key={i}
                                  title={item.name}
                                  timeCircle={this.state.timeCircle}
                                  status={item.status}
                                  frameStyle={i&&styles.areaFrame}
                                  progressCircle={item.progressCircle}
                                  progressResultList={item.progressResultList}
                                  onPressTitleRight={()=>this.onPressItemRight(item,i)}
                                  progressTargetList={item.progressTargetList}/>
        );
    }

    render() {
        const {dataList} = this.state;

        return (
            <ViewTitle isScroll={false}>
                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>

                <FlatListView
                    style={styles.flatListView}
                    data={dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}
                    // onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    flatListView:{
        marginTop:10,
        marginBottom:10,
    },
    areaFrame:{
        marginTop:10,
    },

    titleFrame:{
        marginTop:10,
    },
});
