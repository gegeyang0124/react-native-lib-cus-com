import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    /**
     * 获取大区业绩进度 数据
     * @param month string,//"YYYY-MM"
     * **/
    static getProgresRegion(month){

        return Http.post(HttpUrls.urlSets.urlResultProgressProgress,{
            isNotUser:true,
            month:month, //月
            department_level :Tools.userConfig.userInfo.department_level + '',
            framework_id:Tools.userConfig.userInfo.department_id + '',
            queryType:'1',//查询级别，1、大区；2、省区；3、客户经理
        },false)
            .then(retJson=>{

                let showData = Tools.userConfig.userInfo.showAllData;

                let retObj = [];

                retJson.retListData.forEach(function (v,i,a) {
                    let progressCircle = v.month_achievement
                        / (!v.operations_target
                            ? v.month_achievement
                            : v.operations_target);
                    let oOT = v.old_month_achievement
                        / (!v.old_operations_target
                            ? v.old_month_achievement
                            : v.old_operations_target);
                    let oNT = v.new_month_achievement
                        / (!v.new_operations_target
                            ? v.new_month_achievement
                            : v.new_operations_target);

                    let cTT = v.month_achievement
                        / (!v.base_target
                            ? v.month_achievement
                            : v.base_target);
                    let cOT = v.old_month_achievement
                        / (!v.old_base_target
                            ? v.old_month_achievement
                            : v.old_base_target);
                    let cNT = v.new_month_achievement
                        / (!v.new_base_target
                            ? v.new_month_achievement
                            : v.new_base_target);

                    let item = {
                        id:v.companyid,//大区id
                        name:v.companyname,//大区的名字
                        progressCircle:progressCircle > 1 ? 1 : progressCircle,
                        progressResultList:[],
                        progressTargetList: []
                    };

                    let target1 = {
                        textLeft:'基础目标',
                        textRight:v.base_target.toFixed(2) + "/万元",
                        progress:cTT > 1 ? 1 : cTT,
                        colors1:Theme.Colors.appRedColor,
                    };

                    let target2 = {
                        textLeft:'运营目标',
                        textRight:v.operations_target.toFixed(2) + "/万元",
                        progress:progressCircle > 1 ? 1 : progressCircle,
                        colors1:Theme.Colors.themeColor,
                    };

                    let data1 = {
                        title:'基础目标',//头部header提示文本
                        progressList:[
                            {
                                textLeft:'达成占比',
                                textRight:(cTT * 100).toFixed(2) + "/%",
                                progress:cTT > 1 ? 1 : cTT,
                                colors1:Theme.Colors.appRedColor,
                            },
                            {
                                textLeft:'老  客  户',
                                textRight:(cOT * 100).toFixed(2) + "/%",
                                progress:cOT > 1 ? 1 : cOT,
                                colors1:Theme.Colors.themeColor,
                            },
                            {
                                textLeft:'新  客  户',
                                textRight:(cNT * 100).toFixed(2) + "/%",
                                progress:cNT > 1 ? 1 : cNT,
                                colors1:Theme.Colors.barGreen,
                            }
                        ],

                        titleBlockList:[
                            {
                                color:Theme.Colors.appRedColor,
                                textTop:'已达成业绩',
                                textRight:"万元",
                                textCenter:v.month_achievement.toFixed(2) ,
                                textDown:"目标:"
                                + v.base_target.toFixed(2)
                                + "万元"
                            },
                            {
                                color:Theme.Colors.themeColor,
                                textTop:'老客户',
                                textRight:"万元",
                                textCenter:v.old_month_achievement.toFixed(2) ,
                                textDown:"目标:"
                                + v.old_base_target.toFixed(2)
                                + "万元"
                            },
                            {
                                color:Theme.Colors.barGreen,
                                textTop:'新客户',
                                textRight:"万元",
                                textCenter:v.new_month_achievement.toFixed(2),
                                textDown:"目标:"
                                + v.new_base_target.toFixed(2)
                                + "万元"
                            }
                        ]
                    };
                    let data2 = {
                        title:'运营目标',//头部header提示文本
                        progressList:[
                            {
                                textLeft:'达成占比',
                                textRight:(progressCircle * 100).toFixed(2) + "/%",
                                progress:progressCircle > 1 ? 1 : progressCircle,
                                colors1:Theme.Colors.appRedColor,
                            },
                            {
                                textLeft:'老  客  户',
                                textRight:(oOT * 100).toFixed(2) + "/%",
                                progress:oOT > 1 ? 1 : oOT,
                                colors1:Theme.Colors.themeColor,
                            },
                            {
                                textLeft:'新  客  户',
                                textRight:(oNT * 100).toFixed(2) + "/%",
                                progress:oNT > 1 ? 1 : oNT,
                                colors1:Theme.Colors.barGreen,
                            }
                        ],

                        titleBlockList:[
                            {
                                color:Theme.Colors.appRedColor,
                                textTop:'已达成业绩',
                                textRight:"万元",
                                textCenter:v.month_achievement.toFixed(2) ,
                                textDown:"目标:"
                                + v.operations_target.toFixed(2)
                                + "万元"
                            },
                            {
                                color:Theme.Colors.themeColor,
                                textTop:'老客户',
                                textRight:"万元",
                                textCenter:v.old_month_achievement.toFixed(2) ,
                                textDown:"目标:"
                                + v.old_operations_target.toFixed(2)
                                + "万元"
                            },
                            {
                                color:Theme.Colors.barGreen,
                                textTop:'新客户',
                                textRight:"万元",
                                textCenter:v.new_month_achievement.toFixed(2),
                                textDown:"目标:"
                                + v.new_operations_target.toFixed(2)
                                + "万元"
                            }
                        ]
                    };

                    if(showData){
                        item.progressResultList.push(target1);
                        item.progressTargetList.push(data1);
                    }

                    item.progressResultList.push(target2);
                    item.progressTargetList.push(data2);

                    retObj.push(item);

                });

                return retObj

            });
    }


}
