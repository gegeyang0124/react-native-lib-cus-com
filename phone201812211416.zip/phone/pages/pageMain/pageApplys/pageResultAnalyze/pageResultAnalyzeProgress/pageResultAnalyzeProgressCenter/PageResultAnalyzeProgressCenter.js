import React, {Component} from 'react';
import moment from 'moment';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Tools,
    TitleRow,
    ResultProgressBlock,
    Theme,
    TitleBlockTarget,
} from "com";
import { Service } from "./Service";

import ImageOrderRank from 'images/orderRank.png';

type Props = {};
export default class PageResultAnalyzeProgressCenter extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.state = {
            targetSpurtTBL:[],//冲刺目标 新老目标
            targetSpurtProgress:[],//冲刺目标 进程对比

            targetOperateTBL:[],//运营目标 新老目标
            targetOperateProgress:[],//运营目标 进程对比

            operateProgress:[],//运营中心进度对比

            progressFinish:0,//完成进度
            custemrCount:0,//客户数量
            timeCircle:undefined,//时间进度
        };

        this.setParams({
            headerLeft: true,
            headerRight:ImageOrderRank,
            headerRightHandle:this.onPressHeaderRight
        });
    }
//Tools.userConfig.userInfo.showAllData,
    onPressHeaderRight = ()=>{
        // alert("去往区域详情");
        this.goPage("PageResultAnalyzeProgressAreaRank");
    }

    onPressItemRight = ()=>{
        // alert("去往区域详情");
        this.goPage("PageResultAnalyzeProgressAreaRegions");
    }

    getData = (time)=>{
        time = time == undefined ? new Date().getTime() : time;
        //如果传入的时间小于当前时间则设置时间进度为100%
        let now = moment(new Date()).startOf('month').format("YYYY-MM-DD");

        //减去8小时
        now = new Date(now).getTime()-28800000;

        if(time < now){
            this.state.timeCircle = 1.0;
        }else{
            this.state.timeCircle = undefined;
        }

        let parTime = Tools.timeFormatConvert(time,"YYYY-MM");
        Service.getTarget(parTime).then(retJson=>{
                var preJd = retJson.progressFinish;
                var date = "";
                if(this.state.timeCircle != undefined){
                    var res = moment(time).endOf('month').format("YYYY-MM-DD");
                    date = new Date(res);
                }else{
                    date = new Date();
                }

                var day = moment(date).format('DD');
                var monthDay = moment(date).daysInMonth();
                var jd = day/monthDay;
                retJson.status = 0;

                if(preJd < jd && preJd > (jd-0.1)){
                    retJson.status = 2;
                }else if(preJd < jd){
                    retJson.status = 1;
                }

                this.setState(retJson);
            });
    }

    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
    }

    render() {
        const {targetOperateTBL,targetSpurtTBL,operateProgress,
            targetSpurtProgress,targetOperateProgress,progressFinish,
            custemrCount,timeCircle} = this.state;
        return (
            <ViewTitle>
                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>

                <ResultProgressBlock progressCircle={progressFinish}
                                     timeCircle={timeCircle}
                                     frameStyle={styles.resultFrame}
                                     status={this.state.status}
                                     titleLeft={"门店运营中心"}
                                     options={{
                                         sectionList:[
                                             {
                                                 progressList:operateProgress
                                             }
                                         ]
                                     }}
                                     onPressTitleRight={this.onPressItemRight}/>

                <TitleBlockTarget frameStyle={styles.targetFrame}
                                  title={"基础目标"}
                                  titleBlockOptions={{
                                      textRight:"人",
                                      textCenter:custemrCount,
                                      textDown:"有效客户数"
                                  }}
                                  progressList={targetSpurtProgress}
                                  titleBlockList={targetSpurtTBL}/>

                <TitleBlockTarget frameStyle={styles.targetFrame}
                                  title={"运营目标"}
                                  titleBlockOptions={{
                                      textRight:"人",
                                      textCenter:custemrCount,
                                      textDown:"有效客户数"
                                  }}
                                  progressList={targetOperateProgress}
                                  titleBlockList={targetOperateTBL}/>


            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    targetFrame:{
        marginTop:10,
    },

    resultFrame:{
        marginTop:10,
    },

    titleFrame:{
        marginTop:10,
    },
});
