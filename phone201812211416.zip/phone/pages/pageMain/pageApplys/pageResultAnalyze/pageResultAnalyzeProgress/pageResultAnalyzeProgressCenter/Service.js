import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     * 获取运营中心业绩目标 数据
     * @param month string,//YYYY-MM
     * **/
    static getTarget(month){

        return new Promise(resolve => {
            Http.post(HttpUrls.urlSets.urlResultProgressCenter,{
                //目标参数
                month:month,//查询月份
                //完成参数
                pageNumber: 1,
                pageSize: 10000
            })
                .then(retJson=>{

                    let sTT = retJson.retData.month_achievement
                        / (!retJson.retData.base_target
                            ? retJson.retData.month_achievement
                            : retJson.retData.base_target);
                    let oldST = retJson.retData.old_month_achievement
                        / (!retJson.retData.old_base_target
                            ? retJson.retData.old_month_achievement
                            : retJson.retData.old_base_target);
                    let newST = retJson.retData.new_month_achievement
                        / (!retJson.retData.new_base_target
                            ? retJson.retData.new_month_achievement
                            : retJson.retData.new_base_target);

                    let oTT = retJson.retData.month_achievement
                        / (!retJson.retData.operations_target
                            ? retJson.retData.month_achievement
                            : retJson.retData.operations_target);

                    let oldOT = retJson.retData.old_month_achievement
                        / (!retJson.retData.old_operations_target
                            ? retJson.retData.old_month_achievement
                            : retJson.retData.old_operations_target);

                    let newOT = retJson.retData.new_month_achievement
                        / (!retJson.retData.new_operations_target
                            ? retJson.retData.new_month_achievement
                            : retJson.retData.new_operations_target);


                    let retObj = {
                        targetSpurtTBL:[
                            {
                                textRight:"万元",
                                textCenter:retJson.retData.month_achievement,
                                textDown:"基础目标:"
                                    + retJson.retData.base_target.toFixed(2)
                                    + "万元",
                                color:Theme.Colors.appRedColor,
                            },
                            {
                                textRight:"万元",
                                textCenter:retJson.retData.old_month_achievement,
                                textDown:"老客户目标:"
                                    + retJson.retData.old_base_target
                                    + "万元",
                                color:Theme.Colors.themeColor,
                            },
                            {
                                textRight:"万元",
                                textCenter:retJson.retData.new_month_achievement,
                                textDown:"新客户目标:"
                                    + retJson.retData.new_base_target
                                    + "万元",
                                color:Theme.Colors.barGreen,
                            }
                        ],
                        targetSpurtProgress:[
                            {
                                textLeft:"达成占比",
                                progress:parseFloat(sTT.toFixed(3)) > 1 ? 1 : parseFloat(sTT.toFixed(3)),
                                textRight:(sTT * 100).toFixed(2) + "%",
                                colors1:Theme.Colors.appRedColor,

                            },
                            {
                                textLeft:'老  客  户',
                                progress:parseFloat(oldST.toFixed(3)) > 1 ? 1 : parseFloat(oldST.toFixed(3)),
                                textRight:(oldST * 100).toFixed(2) + "%",
                                colors1:Theme.Colors.themeColor,
                            },
                            {
                                textLeft:'新  客  户',
                                progress:parseFloat(newST.toFixed(3)) > 1 ? 1 : parseFloat(newST.toFixed(3)),
                                textRight:(newST * 100).toFixed(2) + "%",
                                colors1:Theme.Colors.barGreen,
                            }
                        ],

                        targetOperateTBL:[
                            {
                                textRight:"万元",
                                textCenter:retJson.retData.month_achievement,
                                textDown:"运营目标:"
                                    + retJson.retData.operations_target.toFixed(2)
                                    + "万元",
                                color:Theme.Colors.appRedColor,
                            },
                            {
                                textRight:"万元",
                                textCenter:retJson.retData.old_month_achievement,
                                textDown:"老客户目标:"
                                    + retJson.retData.old_operations_target.toFixed(2)
                                    + "万元",
                                color:Theme.Colors.themeColor,
                            },
                            {
                                textRight:"万元",
                                textCenter:retJson.retData.new_month_achievement,
                                textDown:"新客户目标:"
                                    + retJson.retData.new_operations_target.toFixed(2)
                                    + "万元",
                                color:Theme.Colors.barGreen,
                            }
                        ],
                        targetOperateProgress:[
                            {
                                textLeft:"达成占比",
                                progress:parseFloat(oTT.toFixed(3)) > 1 ? 1 : parseFloat(oTT.toFixed(3)),
                                textRight:(oTT * 100).toFixed(2) + "%",
                                colors1:Theme.Colors.appRedColor,

                            },
                            {
                                textLeft:'老  客  户',
                                progress:parseFloat(oldOT.toFixed(3)) > 1 ? 1 : parseFloat(oldOT.toFixed(3)),
                                textRight:(oldOT * 100).toFixed(2) + "%",
                                colors1:Theme.Colors.themeColor,
                            },
                            {
                                textLeft:'新  客  户',
                                progress:parseFloat(newOT.toFixed(3)) > 1 ? 1 : parseFloat(newOT.toFixed(3)),
                                textRight:(newOT * 100).toFixed(2) + "%",
                                colors1:Theme.Colors.barGreen,
                            }
                        ],

                        operateProgress:[
                            {
                                textLeft:'基础目标',
                                textRight:retJson.retData.base_target.toFixed(2) + "/万元",
                                progress:parseFloat(sTT.toFixed(3)) > 1 ? 1 : parseFloat(sTT.toFixed(3)),
                                colors1:Theme.Colors.appRedColor,
                            },
                            {
                                textLeft:'运营目标',
                                textRight:retJson.retData.operations_target.toFixed(2) + "/万元",
                                progress:parseFloat(oTT.toFixed(3)) > 1 ? 1 : parseFloat(oTT.toFixed(3)),
                                colors1:Theme.Colors.themeColor,
                            }
                        ],

                        progressFinish:parseFloat(oTT.toFixed(3)),

                        custemrCount:retJson.retData.orderCustomerNum

                    };

                    resolve(retObj);
                });
        });

    }

}
