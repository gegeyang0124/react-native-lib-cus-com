import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird'
import PageProj1111 from "./pageProj1111/PageProj1111";
import PageFightPlan from "./pageFightPlan/PageFightPlan";
import PageGoodsKnowledge from "./pageGoodsKnowledge/PageGoodsKnowledge";
import PageShouldKnows from "./pageShouldKnow/PageShouldKnow";

const TabRouteConfigs = {
    PageProj1111: {
        screen: PageProj1111,
        navigationOptions: {
            title:'1111工程',
            tabBarLabel : '1111工程',
        },

    },
    PageFightPlan: {
        screen: PageFightPlan,
        navigationOptions: {
            title:'争锋计划',
            tabBarLabel : '争锋计划',
        },

    },
    PageGoodsKnowledge: {
        screen: PageGoodsKnowledge,
        navigationOptions: {
            title:'商品知识',
            tabBarLabel : '商品知识',
        },
    },
    PageShouldKnows: {
        screen: PageShouldKnows,
        navigationOptions: {
            title:'应知应会',
            tabBarLabel : '应知应会'
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;