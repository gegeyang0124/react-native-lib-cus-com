import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    Alert,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    ItemRowSwitch,
    Theme,
    ItemRowTitle,
    FlatListView,
    SearchDDDIpt,
    Tools,
} from "com";

import { Service } from "./Service";

type Props = {};
export default class PageGoodsKnowledge extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            title:'',//输入标题
            type1:'',//第一个下拉框选中值 //商品父级类别，用于请求子级类别
            type2:'',//第二个下拉框选中值
        }

        this.configData = {
            execFirst:true,
            executing:false
        }

        this.state = {
            total:0,//文件总数
            dataList:[],//文件项集合,
            dropList1:[{
                name:'一级分类',
                type_code:'0'
            }],//下拉框数据 第一个
            dropList2:[{
                name:'二级分类',
                type_code:null
            }],//下拉框数据 第二个
            clearDrop:true,//是否 清空数据
        }

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

    }

    getData(){
        if(!this.configData.execFirst)
        {
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        if(!this.configData.executing){
            // console.info("this.configData.executing:",this.configData.executing)
            this.configData.executing = true;

            Service.get(this.selectedValue,this.configData.execFirst)
                .then(retJson =>{
                    // console.info("retJson:",retJson)
                    this.configData.executing = false;
                    if(!this.configData.execFirst && !retJson.has)
                    {
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                    }
                    else
                    {
                        this.configData.execFirst = false;
                        this.setState({
                            total:retJson.total,
                            dataList:retJson.retListData
                        });

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }


                })
                .catch((status) =>{
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });

        }

    }

    /**
     * 获取商品类别
     * @param goodsParentType int,//商品父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    getDataGoodsTypes(type){
        Service.getGoodsTypes(this.selectedValue.type1 == ''
            ? 0
            : this.selectedValue.type1,
            type).then(retJson =>{
            if(type == 0){
                this.setState({
                    dropList1:retJson
                });
            }
            else  if(type == 1){
                this.setState({
                    clearDrop:false,
                    dropList2:retJson
                });
            }
            else  if(type == 2){
                // this.dropList.types3 = retJson;
            }

        });
    }

    onChangeText = (text)=>{
        this.selectedValue.title = text;
        // Tools.toast(this.configData.selectedValue)

    }

    onSearch = ()=>{
        // console.info("this.selectedValue:",this.selectedValue);
        this.setState({
            total:0,//文件总数
            dataList:[],//文件项集合,
        });
        this.configData.execFirst = true;
        this.getData();
    }

    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
        this.getDataGoodsTypes(0);
    }

    renderItem = (item,i)=>{
        return(
            <ItemRowSwitch key={i}
                           isShowHeader={false}
                           frameStyle={styles.contentRow}
                           isShowChildrenDefault={true}
                           isOpenFile={true}
                           dataList={item}/>
        );
    };

    onSelectDrop = (i,val,type)=>{
        if(type == 1){
            this.selectedValue.type1 = val.type_code;
            this.getDataGoodsTypes(1);

            this.setState({
                clearDrop:true
            });
        }
        else {
            this.selectedValue.type2 = val.type_code;
        }
    }

    render() {

        const {total,dataList,dropList1,dropList2,clearDrop} = this.state;

        return (
            <ViewTitle isScroll={false}>

                <SearchDDDIpt frameStyle={styles.dropdownFrameStyle}
                              isPickDropdown3={false}
                              options1={{
                                  style:styles.dropdownStyle,
                                  defaultValue:'一级分类',
                                  options:dropList1,
                                  onSelect:(i,val)=>this.onSelectDrop(i,val,1)
                              }}
                              options2={{
                                  style:styles.dropdownStyle,
                                  defaultValue:'二级分类',
                                  options:dropList2,
                                  clearDrop:clearDrop,
                                  onSelect:(i,val)=>this.onSelectDrop(i,val,2)
                              }}
                              placeholder={"--标题--"}
                              textChange={this.onChangeText}
                              onPressSearch={this.onSearch}/>

                <ItemRowTitle text1={"共有" + total + "个课件"}
                              textStyle={styles.titleText}
                              frameStyle={styles.titleTextFrame}/>

                <FlatListView
                    style={styles.contentFrame}
                    data={dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}
                    onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    searchFrameStyle:{
        marginTop:10,
        padding:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    titleTextFrame:{
        backgroundColor:Theme.Colors.themeColorLight0,
    },
    titleText:{
        color:Theme.Colors.themeColor,
    },
    contentFrame:{
        // marginTop:10,
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        paddingBottom:10,
    },
    contentRow:{
        marginBottom:10,
    },

    dropdownStyle:{
        width:180,
    },
    dropdownFrameStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
});
