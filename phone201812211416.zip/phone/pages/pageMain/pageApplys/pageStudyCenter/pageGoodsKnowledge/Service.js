import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import ImageDoc from 'images/doc.png';
import ImagePdf from 'images/pdf.png';
import ImagePpt from 'images/ppt.png';
import ImageXls from 'images/xls.png';

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级品类
            type2:'',//下拉选中值 二级品类
            type3:'',//下拉选中值 三级品类
            title:'',//商品名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取商品类别
     * @param goodsParentType int,//商品父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    static getGoodsTypes(goodsParentType,type){

        return Http.post(HttpUrls.urlSets.urlInfoProductTypeList,
            {parent_type_code:goodsParentType},false)
            .then((retJson) => {

                let types = [
                    {
                        name:(type == 0
                            ? "一"
                            : type == 1
                                ? '二'
                                : type == 2
                                    ? '三'
                                    : '')
                        + "级品类",
                        type_code:''
                    }
                ];

                if(retJson.retListData == undefined)
                {
                    retJson.retListData = [];
                }

                retJson.retListData.forEach((val,i,arr) =>{
                    val.name = val.type_name;
                    types.push(val);
                });



                return types;

            });
    }

    /**
     * 获取新品推荐商品列表
     * @param selectValue object,//搜索参数
     * selectValue = {
        type1:'',//下拉选中值 一级品类
        type2:'',//下拉选中值 二级品类
        type3:'',//下拉选中值 三级品类
        title:'',//标题
    }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(selectValue,init) {

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
            // this.base.paramsFetch.executing = true;
        }

        this.base.paramsFetch.selectValue = selectValue == undefined
            ? this.base.paramsFetch.selectValue
            : selectValue;

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retJson.retListData = [];
        }

        if(this.base.paramsFetch.executing){
            // this.base.paramsFetch.executing = false;
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        let reuestData = {
            sort:'create_time',
            order:'desc',
            pageNumber: this.base.paramsFetch.pageNumber,//页码
            pageSize: 20,//每页条数,
            filter:{
                type:"1",//1.商品知识 2.运营重点 3.销售技巧
                product_type_one : this.base.paramsFetch.selectValue.type1 + '', // 一级品类
                product_type_two : this.base.paramsFetch.selectValue.type2, // 二级品类
                title:this.base.paramsFetch.selectValue.title,//标题 搜索 输入条件值
                dept_id:Tools.userConfig.userInfo.department_id
            },//筛选条件
        };

        // alert(JSON.stringify(reuestData));

        return Http.post(HttpUrls.urlSets.urlInfoKnowledgeList, reuestData,init)
            .then((retJson) => {

                // alert(this.base.paramsFetch.pageNumber)
                this.base.retJson.total = retJson.retData.total;
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                // alert(JSON.stringify(retJson));
                retJson.retListData.forEach((val,i,arr) =>{
                    val.content = val.content.split(',');

                    let item = {
                        uri:val.content[0],//打开文件的地址 isOpenFile为true时调用
                        icon:'',//显示图片
                        title:val.title,//子元元素显示文本 isShowHeader为false可以不传
                        text:Tools.timeFormatConvert(val.create_time,'YYYY-MM-DD'),//第二行小字显示文本
                    };


                    item.icon = item.uri.indexOf(".do") > -1
                        ? ImageDoc
                        : item.uri.indexOf(".xl") > -1
                            ? ImageXls
                            : item.uri.indexOf(".ppt") > -1
                                ? ImagePpt
                                : ImagePdf;



                    this.base.retJson.retListData.push([item]);
                });

                // this.base.retJson.retListData.concat(retJson.retListData);
                // console.info("base:",this.base);
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }

}
