import React, {Component} from 'react';
import {
    View,
    Image,
    TouchableOpacity,
    Alert,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    SearchIpt,
    ItemRowSwitch,
    Theme,
    ItemRowTitle,
    FlatListView,
} from "com";

import { Service } from "./Service";

type Props = {};
export default class PageProj1111 extends BaseComponent<Props> {

    componentWillEnter(params){
        // console.info("componentWillEnter","componentWillEnter")
    }

    constructor(props) {
        super(props);

        this.configData = {
            selectedValue:'',
            data:null //数据源
        };

        this.state = {
            total:0,//文件总数
            filesList:[]//文件项集合
        }

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

    }

    getData(){
        Service.get().then(retJson=>{
            // console.info("retJson:",retJson);
            this.configData.data = retJson;
            this.setState(retJson);
        });
    };

    onChangeText = (text)=>{
        this.configData.selectedValue = text;
        // Tools.toast(this.configData.selectedValue)

    }

    onSearch = ()=>{
        let retObj = {
            total:0,//文件总数
            filesList:[],//文件项集合
        };

        this.configData.data.filesList
            .forEach((v,i,a)=>{
                let item = {
                    title:v.title,
                    filesList:[]//文件集合
                };

                v.filesList
                    .forEach((v1,i1,a1)=>{
                        if(v1.title.indexOf(this.configData.selectedValue) > -1){
                            retObj.total++;

                            item.filesList.push(v1);
                        }
                    });

               if(item.filesList.length > 0){
                   retObj.filesList.push(item);
               }

            });

        this.setState(retObj);

    }

    componentWillMount(){

    }

    componentDidMount(){
       this.getData();
    }

    renderItem = (item,i)=>{
        return(
            <ItemRowSwitch key={i}
                           textHeaderLeft={item.title}
                           frameStyle={styles.contentRow}
                           isShowChildrenDefault={!i&&true}
                           isOpenFile={true}
                           dataList={item.filesList}/>
        );
    };

    render() {

        const {total,filesList} = this.state;

        return (
            <ViewTitle isScroll={false}>
                <SearchIpt frameStyle={styles.searchFrameStyle}
                           onChangeText={this.onChangeText}
                           onPressSearch={this.onSearch}/>

                <ItemRowTitle text1={"共有" + total + "个课件"}
                              textStyle={styles.titleText}
                              frameStyle={styles.titleTextFrame}/>

                <FlatListView
                    style={styles.contentFrame}
                    data={filesList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}/>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    searchFrameStyle:{
        marginTop:10,
        padding:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    titleTextFrame:{
        backgroundColor:Theme.Colors.themeColorLight0,
    },
    titleText:{
        color:Theme.Colors.themeColor,
    },
    contentFrame:{
        // marginTop:10,
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        paddingBottom:10,
    },
    contentRow:{
        marginBottom:10,
    },
});
