import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import ImageDoc from 'images/doc.png';
import ImagePdf from 'images/pdf.png';
import ImagePpt from 'images/ppt.png';
import ImageXls from 'images/xls.png';

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {

        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取文件集合
     * **/
    static get(){
        return Http.post(HttpUrls.urlSets.urlInfoGet41ProjectList)
            .then(retJson=>{
                let retObj = {
                    total:0,//文件总数
                    filesList:[],//文件项集合
                };

                retJson.retListData
                    .forEach((v,i,a)=>{
                        let item = {
                            title:v.fileCategoryName,
                            filesList:[]//文件集合
                        };

                        v.filesList
                            .forEach((v1,i1,a1)=>{

                                retObj.total++;

                                let itm = {
                                    uri: v1.filePath[0],//打开文件的地址 isOpenFile为true时调用
                                    icon: null,//显示图片
                                    title: v1.fileName,//子元元素显示文本
                                    text: Tools.timeFormatConvert(v1.fileUpTime, 'YYYY-MM-DD HH:mm')//第二行小字显示文本
                                };

                                itm.icon = itm.uri.indexOf(".do") > -1
                                    ? ImageDoc
                                    : itm.uri.indexOf(".xl") > -1
                                        ? ImageXls
                                        : itm.uri.indexOf(".ppt") > -1
                                            ? ImagePpt
                                            : ImagePdf;

                                item.filesList.push(itm);
                            });

                        retObj.filesList.push(item);
                    });

                return retObj;
            });
    }

}
