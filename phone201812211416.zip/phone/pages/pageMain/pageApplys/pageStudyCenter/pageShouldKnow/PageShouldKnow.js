import {
    Theme,
    Tools,
} from 'com';
import {
    TabNavigator,
} from 'comThird';
import PageShouldKnowRecommendCourse from "./pageShouldKnowRecommendCourse/PageShouldKnowRecommendCourse";
import PageShouldKnowMyCourse from "./pageShouldKnowMyCourse/PageShouldKnowMyCourse";
import PageShouldKnowCourseDetail from "./pageShouldKnowCourseDetail/PageShouldKnowCourseDetail";
import PageShouldKnowCourseTest from "./pageShouldKnowCourseTest/PageShouldKnowCourseTest";

const TabRouteConfigsPageShouldKnows = {
    PageShouldKnowMyCourse: {
        screen: PageShouldKnowMyCourse,
        navigationOptions: {
            title:'我的课程',
            tabBarLabel : '我的课程',
        },

    },
    PageShouldKnowRecommendCourse: {
        screen: PageShouldKnowRecommendCourse,
        navigationOptions: {
            title:'推荐课程',
            tabBarLabel : '推荐课程',
        },

    },
};


const PageCourses = TabNavigator(TabRouteConfigsPageShouldKnows, Theme.TabNavigatorConfigsTop);

const TabRouteConfigs = {
    PageCourses: {
        screen: PageCourses,
        navigationOptions: {
            title:'应知应会',
            tabBarLabel : '应知应会',
        },

    },
    PageShouldKnowCourseDetail: {
        screen: PageShouldKnowCourseDetail,
        navigationOptions: {
            title:'应知应会',
            tabBarLabel : '应知应会',
        },

    },
    PageShouldKnowCourseTest: {
        screen: PageShouldKnowCourseTest,
        navigationOptions: {
            title:'知识小测',
            tabBarLabel : '知识小测',
        },

    },
};
const Pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);



module.exports = Pages;