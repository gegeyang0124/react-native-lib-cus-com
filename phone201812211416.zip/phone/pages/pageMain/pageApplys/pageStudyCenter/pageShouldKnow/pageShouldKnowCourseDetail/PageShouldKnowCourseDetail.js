import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    Alert,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    ItemRowSwitch,
    Theme,
    ItemRowTitle,
    FlatListView,
    Tools,
} from "com";

import { Service } from "./Service";

type Props = {};
export default class PageShouldKnowCourseDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            selectedValue:'',
            execFirst:true,
        };

        this.state = {
            id:null,//课程ID
            img_url:null,//string 头部显示图片
            title:null,//string 课程名
            content:null,//string 课程描述
            status:null,//string 中文 课程状态
            filesList:[]//文件集合
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

    }

    getData(id){
        Service.get(id).then(retJson=>{
            // console.info("retJson:",retJson);
            this.setState(retJson);
        });
    };


    componentWillMount(){

    }

    componentDidMount(){
        //this.getData();
    }

    componentWillEnter(params,action,page){
        this.getData(params.id);
    }

    onPressItem = (item,i)=>{

        // Tools.toast("测试：  " + JSON.stringify(item))
        this.goPage("ImageBgShouldKnowTest",{id:item.id});
    }

    renderItem = (item,i)=>{

        return(
            <ItemRowSwitch key={i}
                           onPress={this.onPressItem}
                           textHeaderLeft={item.title}
                           frameStyle={styles.contentRow}
                           isShowChildrenDefault={!i&&true}
                           isOpenFile={true}
                           dataList={item.filesList}/>
        );
    };

    /*[{
        title:'老子',
        filesList:[
            {
                icon:ImageDoc,
                uri:null,
                title:'老子弄死你',
                text:'视频教程',
                extraList:[
                    {
                        textLeft:'类型',
                        textRight:'教材'
                    },
                    {
                        textLeft:'状态',
                        textRight:'已完成'
                    },
                    {
                        textLeft:'完成时间',
                        textRight:'2013-05-09 15:30:30'
                    }
                ]
            },
            {
                icon:ImageDoc,
                uri:'http://static.lexin580.com/files/ProductPicture\\150438002101.jpg',
                title:'老子弄死你',
                text:'视频教程',
            },
            {
                icon:'http://static.lexin580.com/files/ProductPicture\\150438002101.jpg',
                title:'老子弄死你',
                text:'视频教程',
                extraList:[
                    {
                        textLeft:'类型',
                        textRight:'教材'
                    },
                    {
                        textLeft:'状态',
                        textRight:'已完成'
                    },
                    {
                        textLeft:'完成时间',
                        textRight:'2013-05-09 15:30:30'
                    }
                ]
            },
        ]
    }]*/

    render() {

        const {filesList,img_url,title,content,status} = this.state;

        return (
            <ViewTitle isScroll={false}>
                <Image source={img_url ? {uri:img_url}:img_url}
                       style={styles.image}/>

                <View style={styles.header}>
                    <View style={styles.header_1}>
                        <Text style={styles.headerTitleText}>
                            {title}
                        </Text>
                    </View>

                    <View style={styles.header_2}>
                        <Text style={styles.headerContentText}>
                            {content}
                        </Text>
                    </View>
                </View>

                <ItemRowTitle text1={"目录"}
                              text2={"状态"}
                              viewRight={
                                  <Text style={styles.titleBtnText}>
                                      {status}
                                  </Text>
                              }
                              textStyle={styles.titleText}
                              frameStyle={styles.titleTextFrame}/>

                <FlatListView style={styles.contentFrame}
                              data={filesList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItem(item,index)}/>

            </ViewTitle>
        );

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        console.info("this.state.id",this.state.id);
        console.info("param",param);
        console.info("param.id",param.id);

        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;

                // this.getData();
            }
            return (
                <ViewTitle isScroll={false}>
                    {/*<Image source={{uri:img_url}}*/}
                           {/*style={styles.image}/>*/}

                    <View style={styles.header}>
                        <View style={styles.header_1}>
                            <Text style={styles.headerTitleText}>
                                {title}
                            </Text>
                        </View>

                        <View style={styles.header_2}>
                            <Text style={styles.headerContentText}>
                                {content}
                            </Text>
                        </View>
                    </View>

                    <ItemRowTitle text1={"目录"}
                                  text2={"状态"}
                                  viewRight={
                                      <Text style={styles.titleBtnText}>
                                          {status}
                                      </Text>
                                  }
                                  textStyle={styles.titleText}
                                  frameStyle={styles.titleTextFrame}/>

                    <FlatListView style={styles.contentFrame}
                                  data={filesList}
                                  keyExtractor = {(item, index) => ("key" + index)}
                                  renderItem={({item,index}) => this.renderItem(item,index)}/>

                </ViewTitle>
            );
        }
        else {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }
    }
}

const styles = StyleSheetAdapt.create({
    image:{
        resizeMode:"stretch",
        height:250,
    },
    header:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    header_1:{
        margin:20,
        paddingBottom:10,
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth,
    },
    header_2:{
        marginLeft:20,
        marginRight:20,
        paddingBottom:20,
    },
    headerTitleText:{
        color:Theme.Colors.themeColor,
        fontSize:Theme.Font.fontSize,
    },
    headerContentText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },

    titleTextFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
    titleText:{
        color:Theme.Colors.themeColor,
    },
    titleBtnText:{
        color:Theme.Colors.minorColor,
        marginRight:10,
        fontSize:Theme.Font.fontSize_1,
    },


    contentFrame:{
        // marginTop:10,
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        paddingBottom:10,
    },
    contentRow:{
        marginBottom:10,
    },
});
