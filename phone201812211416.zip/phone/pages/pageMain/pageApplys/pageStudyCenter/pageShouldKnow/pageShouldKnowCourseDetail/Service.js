import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import ImageDoc from 'images/doc.png';
import ImagePdf from 'images/pdf.png';
import ImagePpt from 'images/ppt.png';
import ImageXls from 'images/xls.png';

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {

        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取文件集合
     * @param id string,//课程ID
     * **/
    static get(id){
        return Http.get(HttpUrls.urlSets.urlSchoolStudyCourseDetail,{
            id:id //课程ID
        })
            .then(retJson=>{

                /*let retData = {
                    img_url:null,//string 头部显示图片
                    title:null,//string 课程名
                    content:null,//string 课程描述
                    status:null,//string 中文 课程状态
                    filesList:[
                        {
                            title:'老子',//文件模块名
                            isTest:true,//是否测试 true测试 false不测试  没有就回传null或不传
                            filesList:[ //文件集合
                                {
                                    id:'',//文件或测试ID
                                    icon:null,//文件显示logo 没有就回传null或不传
                                    uri:null,//文件地址，没有就回传null或不传
                                    title:'老子弄死你',//文件名 没有就回传null或不传
                                    text:'视频教程',//教程类型 没有就回传null或不传
                                    extraList:[ //额外数据集合
                                        {
                                            textLeft:'类型',//左边显示文本 没有就回传null或不传
                                            textRight:'教材'//右边显示文本 没有就回传null或不传
                                        },
                                    ]
                                }

                            ]
                        }

                    ]//文件集合
                };*/

                retJson.retData.filesList.forEach((v,i,a)=>{
                    v.isOpenFile = v.isTest == true ? false : true;
                    v.filesList.forEach((v1,i1,a1)=>{
                        if(!v1.icon){
                            v1.icon = v1.uri.indexOf(".do") > -1
                                ? ImageDoc
                                : v1.uri.indexOf(".xl") > -1
                                    ? ImageXls
                                    : v1.uri.indexOf(".ppt") > -1
                                        ? ImagePpt
                                        : ImagePdf;
                        }
                    });
                });



                return retJson.retData;
            });
    }

}
