import React, {Component} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    ScrollView,
    DeviceEventEmitter,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    ItemRowSwitch,
    Theme,
    ItemRowTitle,
    FlatListView,
    Tools,
    Image,
    TextChange,
    ScrollSelectOptions,
} from "com";
import {
    CheckBox,
    Orientation,
    Swiper,//需要修改底层 添加scrollPre方法
} from 'comThird';

import { Service } from "./Service";

import ImageBgShouldKnowTest from 'images/bgShouldKnowTest.png';

type Props = {};
export default class PageShouldKnowCourseTest extends BaseComponent<Props> {

    constructor(props) {
        super(props);
        // console.info("this:",this);

        // PageShouldKnowCourseTest.self = this;

        this.configData = {
            execFirst:true,
            setTime:null,//设置时间函数
            curTime:null,//当前时间戳
            isTiming:false,//是否正在计时
            examTime:null,//考试用时 HH:mm:ss
        };

        // this.

        this.selectedValue = {

            examid:null,//试卷id
            examTime:null,//考试用时 HH:mm:ss
            /* answerList:[//提交时结构
                 /!*{
                     examCode:'',//题号
                     type:0,//int 类型 0、单选，1、多选，2、问答
                     examAnswer:'',//答案 单选/多选是数组  问答是字符串
                 }*!/
             ],*/

            answerList:{},//插入答案时答案
        };

        this.state = {
            id:null,//试卷ID
            total:0,//题目数量
            questionList:[],
            /*questionList:[//问题数组
                {
                    id:'',//题目ID
                    title:'TT娱乐城猜对四项都将获得',//题目 问题
                    type:'answer',//int 类型 0、单选，1、多选，2、问答
                    answerList:[
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },

                    ],//答案列表
                },
                {
                    id:'',//题目ID
                    title:'TT娱乐城猜对四项都将获得',//题目 问题
                    type:'selectMul',//int 类型 0、单选，1、多选，2、问答
                    answerList:[
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },

                    ],//答案列表
                },
                {
                    id:'',//题目ID
                    title:'TT娱乐城猜对四项都将获得',//题目 问题
                    type:'selectMul',//int 类型 0、单选，1、多选，2、问答
                    answerList:[
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },

                    ],//答案列表
                },
                {
                    id:'',//题目ID
                    title:'TT娱乐城猜对四项都将获得',//题目 问题
                    type:'select',//int 类型 0、单选，1、多选，2、问答
                    answerList:[
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },
                        {
                            indexParent:'',//题目下标自加
                            questionId:'',////题目ID 自家加入
                            id:'',//答案ID
                            text:'TT娱乐城猜对四项都将获得',//答案内容
                        },

                    ],//答案列表
                },

            ],*/

            refresh:false,//是否刷新，true:刷新，false：不刷新
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

    }

    init(){
        this.selectedValue = {

            examid:null,//试卷id
            examTime:null,//考试用时 HH:mm:ss
            /* answerList:[//提交时结构
                 /!*{
                     examCode:'',//题号
                     type:0,//int 类型 0、单选，1、多选，2、问答
                     examAnswer:'',//答案 单选/多选是数组  问答是字符串
                 }*!/
             ],*/

            answerList:{},//插入答案时答案
        };
        this.state = {
            id:null,//试卷ID
            total:0,//题目数量
            // questionList:[],
            questionList:[],

            refresh:false,//是否刷新，true:刷新，false：不刷新
        };
    }

    getData(){

        // this.selectedValue.examid = this.state.id;
        Service.get(this.state.id).then(retJson=>{
            // console.info("retJson:",retJson);
            this.selectedValue.examid = retJson.id;
            this.setState(retJson);
        });
    };

    componentWillEnter(context,param,action){
        // Tools.toast("gdsg")
       /* console.info("componentWillEnter this:",PageShouldKnowCourseTest.self);
        console.info("componentWillEnter:",context);*/
        context.setScreenOrientations(1);
        param = param == undefined ? {} : param;
        context.state.id = param.id;
        context.getData();

    }

    componentWillExit(context,param,action){
        context.setScreenOrientations(0);
        context.setTime();
    }

    componentWillMount(){
        /*const initial = Orientation.getInitialOrientation();
        if (initial === 'PORTRAIT') {
            // do something
        } else {
            // do something else
        }*/
    }

    componentDidMount(){
        /*  this.setTime();
          BaseComponent.execfunc = this.setTime;*/

        // console.info("this.context: ",this.props.context);

        // this.getData();
        // Orientation.addOrientationListener(this.orientationDidChange);

        /*DeviceEventEmitter.addListener('YY',(e)=>{
            alert(e)
        });
        let value = '监听'   //准备一个值
        DeviceEventEmitter.emit('YY',value); //发监听*/
    }

    componentWillUnmount() {
        // Orientation.lockToPortrait();
        /* Orientation.getOrientation((err, orientation) => {
             console.log(`Current Device Orientation: ${orientation}`);
         });*/


        // Remember to remove listener
        // Orientation.removeOrientationListener(this.orientationDidChange);
    }

    onPressBottom = (item,i)=>{
        switch (i){
            case 0:{
                this.swiper.scrollPre();
                break;
            }
            case 1:{
                this.swiper.scrollNext();
                break;
            }
            case 2:{


                let selectedValue = this.selectedValue;
                selectedValue.answerList = [];
                let quesIds = Object.keys(this.selectedValue.answerList);
                quesIds.forEach(id=>{
                    selectedValue.answerList.push(this.selectedValue.answerList[id]);
                });


                Service.putIn(selectedValue)
                    .then(retJson=>{
                        this.init();
                        this.goBack();
                    });

                break;
            }
        }

        // Tools.toast(JSON.stringify(item) + "  i：" + i);
    }

    onChange = (param1,param2,param3,param4,param5)=>{
        if(!this.configData.setTime){
            // this.configData.isTiming = true;
            this.setTime();
        }

        if(param2 == 'select'){
            this.selectedValue.answerList["" + param3.questionId] = {
                examCode:param3.questionId,//题号
                type:0,//int 类型 0、单选，1、多选，2、问答
                examAnswer:[param3.id],//答案 单选/多选是数组  问答是字符串
            };
            // item.answerList = param5;
            // console.info("param2:",param2)
            // alert(JSON.stringify(param5))
        }
        else if(param2 === "selectMul") {
            let lst = [];
            param1.forEach((v,i,a)=>{
                if(v.isChecked){
                    lst.push(v.id);
                }
            });
            this.selectedValue.answerList["" + param3.questionId] = {
                examCode:param3.questionId,//题号
                type:1,//int 类型 0、单选，1、多选，2、问答
                examAnswer:lst,//答案 单选/多选是数组  问答是字符串
            }
            // console.info("param1:",param1)
            // alert(JSON.stringify(param1))z
        }
        else {
            // console.info("param3:",param3);
            // alert(JSON.stringify(param3));
            this.selectedValue.answerList["" + param3.questionId] = {
                examCode:param3.questionId,//题号
                type:2,//int 类型 0、单选，1、多选，2、问答
                examAnswer:param1,//答案 单选/多选是数组  问答是字符串
            }
        }

        // console.info("this.dataList:",this.dataList)
        // this.dataList[i] = item;alert(JSON.stringify(this.dataList[i]))
    }

    renderItem = (item,i)=>{
        const {total} = this.state;

        return(
            <View key={i}
                  style={styles.frame}>
                <View style={styles.titleFrame}>
                    <View style={styles.titleFrame_1}>
                        <Text style={styles.title}>
                            第 {i+1}/{total} 题
                        </Text>
                    </View>

                    <View style={styles.titleFrame_2}>
                        <Text style={styles.title1}>
                            {item.title}
                        </Text>
                    </View>
                </View>

                <View style={styles.timeFrame}>
                    <TextChange text={""}
                                disabled={true}
                                textStyle={styles.timeText}/>
                </View>

                <View style={styles.contentFrame}>
                    <View style={styles.contentFrame_1}>
                        <ScrollSelectOptions dataList={item.answerList}
                                             onChange={this.onChange}
                                             text={item.answer}
                                             type={item.type}
                                             mode={'answer'}/>
                    </View>
                </View>
            </View>
        );
    }

    setTime = ()=>{
        if(this.configData.setTime == null){
            this.configData.curTime = this.configData.curTime||(new Date()).getTime();
            this.configData.examTime = this.configData.examTime||(new Date()).getTime();
            this.configData.setTime = setInterval(()=>{
                this.configData.examTime += 1000;
                // console.info("time",curTime);
                this.selectedValue.examTime = Tools.timeFormatConvert(
                    (this.configData.examTime - this.configData.curTime - 8 * 3600 * 1000),
                    "HH:mm:ss")
                this.timeText.setText("用时：" + this.selectedValue.examTime);
            },1000);
        }
        else {
            clearInterval(this.configData.setTime);
            this.configData.setTime = null;
        }

    }

    render() {

        const {questionList,refresh} = this.state;

        const viewList = questionList.map(this.renderItem);

        return (
            <Image source={ImageBgShouldKnowTest}
                   imageStyle={{resizeMode:"stretch"}}
                   refresh={refresh}
                   style={styles.bg}>
                <ViewTitle isScroll={false}
                           frameStyle={styles.frameStyle}
                           onPressBottom={this.onPressBottom}
                           viewBottomFrameStyle={styles.btnBottom}
                           viewBottom={["上一题","下一题","提交"]}>

                    <View style={styles.timeFrame1}>
                        <TextChange text={ "用时：00:00:00"}
                                    disabled={true}
                                    onExportThis={(com)=>this.timeText=com}
                                    textStyle={styles.timeText1}/>
                    </View>

                    <Swiper loop={false}
                            showsPagination={false}
                            ref={com=>this.swiper=com}>
                        {
                            viewList.map(value=>value)
                        }
                    </Swiper>

                </ViewTitle>
            </Image>

        );

        /*let param = this.getPageParams();
        param = param == undefined ? {} : param;
        if(true) {
            // if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                // this.getData();
            }
            return (
                <Image source={ImageBgShouldKnowTest}
                       imageStyle={{resizeMode:"stretch"}}
                       refresh={refresh}
                       style={styles.bg}>
                    <ViewTitle isScroll={false}
                               frameStyle={styles.frameStyle}
                               onPressBottom={this.onPressBottom}
                               viewBottomFrameStyle={styles.btnBottom}
                               viewBottom={["上一题","下一题","提交"]}>

                        <View style={styles.timeFrame1}>
                            <TextChange text={ "用时：00:00:00"}
                                        disabled={true}
                                        onExportThis={(com)=>this.timeText=com}
                                        textStyle={styles.timeText1}/>
                        </View>

                        <Swiper loop={false}
                                showsPagination={false}
                                ref={com=>this.swiper=com}>
                            {
                                viewList.map(value=>value)
                            }
                        </Swiper>

                    </ViewTitle>
                </Image>

            );
        }
        else {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({id:param.id})
            },0);
            return (
                <Image source={ImageBgShouldKnowTest}
                       imageStyle={{resizeMode:"stretch"}}
                       style={styles.bg}>
                </Image>
            );
        }*/
    }
}

const styles = StyleSheetAdapt.create({
    chkFrame:{
        margin:5,
    },
    rightTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        marginLeft:10,
    },
    chkImage:{
        width:30,
        height:30,
        tintColor:Theme.Colors.themeColor,
    },

    contentFrame_1:{
        // backgroundColor:'red',
        width:'0.6w',
        // height:358,
        alignItems:'center',
        justifyContent:'center',
    },
    contentContainerStyle:{
        // alignItems:'center',
        // justifyContent:'center',
        // backgroundColor:'red',
        // height:358,
    },
    contentFrame:{
        width:'w',
        alignItems:'center',
        justifyContent:'center',
        // backgroundColor:'red',
        marginTop:25,
        height:358
    },

    timeText:{
        fontSize:Theme.Font.fontSize2,
        color:'yellow',
        marginLeft:'0.5w',
        marginTop:100,
    },
    timeFrame:{
        width:'w',
        alignItems:'center',
        justifyContent:'center',
    },
    timeText1:{
        fontSize:Theme.Font.fontSize2,
        color:'yellow',
        marginLeft:'0.5w',
        // marginTop:100,
    },
    timeFrame1:{
        width:'w',
        alignItems:'center',
        justifyContent:'center',
        position:'absolute',
        zIndex:111,
        marginTop:StyleSheetAdapt.getHeight('0.5h') - StyleSheetAdapt.getHeight(170) + "n",
    },

    titleFrame_1:{
        width:'0.6w',
        // backgroundColor:'red',
        marginLeft:'0.3w',
        alignItems:'center',
        justifyContent:'center',
        marginTop:40,
    },
    titleFrame_2:{
        width:'0.5w',
        // backgroundColor:'red',
        marginLeft:'0.3w',
        alignItems:'center',
        justifyContent:'center',
        marginTop:10,
        height:150,
    },
    titleFrame:{
        alignItems:'center',
        justifyContent:'center',
        width:'w',
    },
    title:{
        fontSize:Theme.Font.fontSize2,
        color:Theme.Colors.themeColor,
    },
    title1:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor_1,
    },

    frame:{
        flex:1,
    },

    frameStyle:{
        backgroundColor:Theme.Colors.transparent,
    },
    bg:{
        /* width:'w',
         height:StyleSheetAdapt.getHeight() - StyleSheetAdapt.getHeight(160) + "n",*/
        flex:1,
        alignItems:'center',
    },
    btnBottom:{
        marginBottom:10,
    },
});
