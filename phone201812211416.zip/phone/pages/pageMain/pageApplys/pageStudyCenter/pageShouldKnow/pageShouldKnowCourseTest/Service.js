import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import ImageDoc from 'images/doc.png';
import ImagePdf from 'images/pdf.png';
import ImagePpt from 'images/ppt.png';
import ImageXls from 'images/xls.png';

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {

        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取考试题
     * @param id string,//课程ID
     * **/
    static get(id){
        return Http.get(HttpUrls.urlSets.urlSchoolStudyCourseExamGet,{
            id:id //课程ID
        })
            .then(retJson=>{

               /* let retData = {
                    id:'',//试卷ID
                    questionList:[//问题数组
                        {
                            id:'',//题目ID
                            title:'',//题目 问题
                            type:0,//int 类型 0、单选，1、多选，2、问答
                            answer:'',//问答题答案
                            answerList:[
                                {
                                    indexParent：''，//题目下标自加
                                    questionId:'',////题目ID 自家加入
                                    id:'',//答案ID
                                    text:'',//答案内容
                                }
                            ],//答案列表
                        }
                    ]
                };*/

                retJson.retData.questionList.forEach((v,i,a)=>{
                    if(v.type == 2){
                        v.answerList = [
                            {

                            }
                        ];
                    }
                    v.type = v.type == 0
                        ? 'select'
                        : v.type == 1
                            ? 'selectMul'
                            : 'answer';

                    v.answerList.forEach((v1,i1,a1)=>{
                        v1.type = v.type;
                        v1.questionId = v.id;
                        v1.indexParent = i;
                    });
                });

                retJson.retData.total =  retJson.retData.questionList.length;

                return retJson.retData;
            });
    }

    /**
     * 考试 提交
     * @param selectedValue Object //考试结果数据
     * **/
    static putIn(selectedValue){
        /*let request = {
            examid:'',//试卷id
            examTime:'',//考试用时 HH:mm:ss

            answerList:[
                {
                    examCode:'',//题号
                    type:0,//int 类型 0、单选，1、多选，2、问答
                    examAnswer:'',//答案 单选/多选是数组  问答是字符串
                }
            ],


        };*/
        return Http.post(HttpUrls.urlSets.urlSchoolStudyCourseExamPut,
            selectedValue)
            .then((retJson)=>retJson);
    }

}
