import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
    Alert,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    ItemRowTitle,
    FlatListView,
    SearchDDDIpt,
    Tools,
    SearchDropIpt,
    ItemRowBuyCar,
    TextIconBg,
} from "com";

import ImageFileProgress from 'images/fileProgress.png';

import { Service } from "./Service";

type Props = {};
export default class PageShouldKnowMyCourse extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            title:'',//输入标题
            type1:0,//第一个下拉框选中值 //商品父级类别，用于请求子级类别
            // type2:'',//第二个下拉框选中值
        }

        this.configData = {
            execFirst:true,
            executing:false,
            dropList:[
                {name:'全部',id:0},
                {name:'未参与',id:1},
                {name:'已参与',id:2},
                {name:'其他',id:3}
            ]
        }

        this.state = {
            total:0,//文件总数
            dataList:[],//文件项集合,
        }

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

    }

    getData(){
        if(!this.configData.execFirst)
        {
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        if(!this.configData.executing){
            // console.info("this.configData.executing:",this.configData.executing)
            this.configData.executing = true;

            Service.get(this.selectedValue.title,this.selectedValue.type1,this.configData.execFirst)
                .then(retJson =>{
                    // console.log(retJson)
                    this.configData.executing = false;
                    if(!this.configData.execFirst && !retJson.has){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                    }else{

                        this.configData.execFirst = false;
                        this.setState({
                            dataList:retJson.retListData
                        });
                        // console.log(retJson.retListData)

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }

                })
                .catch((status) =>{
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });

        }

    }

    /**
     * 获取商品类别
     * @param goodsParentType int,//商品父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    getDataGoodsTypes(type){
        Service.getGoodsTypes(this.selectedValue.type1 == ''
            ? 0
            : this.selectedValue.type1,
            type).then(retJson =>{
            if(type == 0){
                this.setState({
                    dropList1:retJson
                });
            }
            else  if(type == 1){
                this.setState({
                    clearDrop:false,
                    dropList2:retJson
                });
            }
            else  if(type == 2){
                // this.dropList.types3 = retJson;
            }

        });
    }

    onChangeText = (text)=>{
        this.selectedValue.title = text;
        // Tools.toast(this.configData.selectedValue)

    }

    onSearch = ()=>{
        // console.info("this.selectedValue:",this.selectedValue);
        this.setState({
            total:0,//文件总数
            dataList:[],//文件项集合,
        });
        this.configData.execFirst = true;
        this.getData();
    }

    componentWillMount(){

    }

    componentDidMount(){
        this.getData();
        // this.getDataGoodsTypes(0);
    }

    onPressItem(item,i){
        // Tools.toast("进入详情:" + JSON.stringify(item));
        this.goPage("PageShouldKnowCourseDetail",{id:item.id})
    }

    renderItem = (item,i)=>{
        let readSchedule =  (item.readedPercent&&(item.readedPercent * 100)|| '') ;
        if(readSchedule == ""){
            readSchedule = "您还未阅读";
        }else{
            readSchedule = "已阅读" + readSchedule + "%";
        }

        return(
            <TouchableOpacity key={i}
                              onPress={()=>this.onPressItem(item,i)}>

                <ItemRowBuyCar icon={item.imgUrl}
                               isShowCheckBox={false}
                               text2_1={item.title}
                               disabledPress={true}
                               text3_1={
                                   <View style={styles.dateFrame}>
                                       {
                                           <View style={styles.horizontalPillar}>

                                           </View>
                                       }

                                       <Text style={styles.dateText}>
                                           {
                                               "报名期限:" + Tools.timeFormatConvert(item.begin_time,"YYYY-MM-DD")
                                               + "至" + Tools.timeFormatConvert(item.end_time,"YYYY-MM-DD")
                                           }
                                       </Text>
                                   </View>
                               }
                               isShowRight={false}
                               isShowLeft={false}
                               text4_1={ <TextIconBg style={styles.iconView}
                                                     iconFrameStyle={styles.iconFrameStyle}
                                                     frameStyle={styles.textIconBgFrame}
                                                     size={StyleSheetAdapt.getWidth(35)}
                                                     icon={ImageFileProgress}
                                                     iconStyle={styles.iconViewIcon}
                                                     isInner={false}
                                                     textStyle={styles.perText}
                                                     text={readSchedule}
                                                     progress={item.readedPercent||0}/>}

                />

            </TouchableOpacity>
        );
    };

    onSelectDrop = (i,val,type)=> {
        this.selectedValue.type1 = val.id;
    }

    render() {

        const {dataList} = this.state;

        return (
            <ViewTitle isScroll={false}>

                <SearchDropIpt options={this.configData.dropList}
                               frameStyle={styles.searchFrame}
                               text2={"标题："}
                               placeholder={"请输入标题"}
                               onSelect={(i,val)=>this.onSelectDrop(i,val)}
                               defaultIndex={0}
                               defaultValue={this.configData.dropList[0].name}
                               textChange={(val) => this.onChangeText(val)}
                               onPressSearch={() => this.onSearch()}/>

                <FlatListView style={styles.contentFrame}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItem(item,index)}
                              onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    iconFrameStyle:{
        marginTop:10,
    },
    perText:{
        color:Theme.Colors.minorColor,
        marginLeft:10,
    },
    textIconBgFrame:{
        flexDirection:'row',
        height:30,
        // backgroundColor:'yellow'
    },
    iconView: {
        flex:1,
        // flexDirection: 'column',
        // backgroundColor: Theme.Colors.foregroundColor,
        // margin: 20,
        // marginBottom: 0,
        // marginTop: 0,
        alignItems: "center",
        justifyContent: "center",
    },
    iconViewIcon: {
        width: 15,
        height: "15dw",
        // tintColor:"#FF6B01",
    },

    searchFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },

    searchFrameStyle:{
        marginTop:10,
        padding:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    titleTextFrame:{
        backgroundColor:Theme.Colors.themeColorLight0,
    },
    titleText:{
        color:Theme.Colors.themeColor,
    },
    contentFrame:{
        // marginTop:10,
        flex:1,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingBottom:10,
        marginTop:10,
    },
    contentRow:{
        marginBottom:10,
    },

    dropdownStyle:{
        width:180,
    },
    dropdownFrameStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },

    dateFrame:{
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',
        paddingTop:5,
    },
    horizontalPillar:{
        width:30,
        height:5,
        backgroundColor:Theme.Colors.themeColor,
        marginRight:15,
    },
    dateText:{
        fontSize:Theme.Font.fontSize_2,
        color:Theme.Colors.themeColor,
    },
});
