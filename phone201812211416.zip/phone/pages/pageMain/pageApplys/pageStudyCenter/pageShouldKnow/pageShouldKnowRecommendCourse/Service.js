import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        title:'',
        status:'',
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取反馈列表
     * @param title string,//需要搜索的标题
     * @param status string,//需要搜索的状态
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(title,status,init) {


        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(this.base.paramsFetch.executing){
            return new Promise((resolve,reject)=>{
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        this.base.paramsFetch.title = title == undefined
            ? this.base.paramsFetch.title
            : title;
        this.base.paramsFetch.status = status == undefined
            ? this.base.paramsFetch.status
            : status;
        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retListData = [];
        }


        return Http.get(HttpUrls.urlSets.urlSchoolGetStudyRecommend, {
            title:this.base.paramsFetch.title,//标题
            pageindex:this.base.paramsFetch.pageNumber,
            pagesize:20,
            status:this.base.paramsFetch.status /** 状态 传入ID
        {name:'全部',id:0},
        {name:'未参与',id:1},
        {name:'已参与',id:2},
        {name:'其他',id:3}**/
        },init)
            .then((retJson) => {
                this.base.retJson.total = retJson.retData.total;
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                /**
                 * 图片：img_url
                 * begin_time:'报名开始时间戳'，
                 end_time：‘报名结束时间戳’
                 * **/
                retJson.retListData.forEach((val,i,arr) =>{
                    this.base.retJson.retListData.push(val);
                });

                // this.base.retListData.concat(retJson.retListData);
                // console.info("base:",this.base);
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }
}