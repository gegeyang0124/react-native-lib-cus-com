import React, {Component} from 'react';
import {
    ScrollView,
} from 'react-native';
import {
    StyleSheetAdapt,
    Theme,
}from "com";
import {
    Tools,
} from "com-api";
import {
    DrawerNavigator,
    DrawerItems,
    TabNavigator,
} from 'comThird';

import {
    PageCustomerDocList,
    PageCustomerDocDetails,
    PageCustomerDocListInvalid,
} from "./pageCustomerDoc/PageCustomerDoc";
import {
    PageApprovalList,
    PageApprovalDetails,
} from './pageCustomerApproval/PageCustomerApproval'
import PageCustomerAllocation from "./pageCustomerAllocation/PageCustomerAllocation";
import PageCustomerIndex from './pageCustomerDoc/pageCustomerIndex/PageCustomerIndex'

const DrawerRouteConfigs = {
    PageCustomerIndex: {
        screen: PageCustomerIndex,
        navigationOptions: ({navigation}) => ({
            title : '客户列表',
            drawerLabel : '客户主页',
            swipeEnabled:false,
        }),
    },
    PageCustomerDocList: {
        screen: PageCustomerDocList,
        navigationOptions: ({navigation}) => ({
            title : '有效客户',
            drawerLabel : '有效客户',
            swipeEnabled:false,
        }),
    },
    PageCustomerDocListInvalid: {
        screen: PageCustomerDocListInvalid,
        navigationOptions: ({navigation}) => ({
            title : '无效客户',
            drawerLabel : '无效客户',
            swipeEnabled:false,
        }),
    },
    PageApprovalList:{
        screen:PageApprovalList,
        navigationOptions:{
            title:'门店审核',
            drawerLabel:'门店审核',
        }
    },
    PageCustomerAllocation:{
        screen: PageCustomerAllocation,
        navigationOptions: {
            title : '客户分配',
            drawerLabel : '客户分配',
        },
    },
};

/**
 * 侧滑菜单返回按钮bug问题，修改底层底层
 * addNavigationHelpers.js
 * **/
const DrawerNavigatorConfigs = {
    // initialRouteName: 'PageTrip',
    // initialRouteName: 'none',
    // initialRoute: 'none',
    // contentComponent: DrawerItems,
    contentComponent:  props => <ScrollView><DrawerItems {...props}
                 onItemPress={({ route, focused })=>{
                     if(route.key == "PageCustomerAllocation"){
                         if(Tools.userConfig.userInfo.department_level != 1 && Tools.userConfig.userInfo.department_level != 2){
                             Tools.toast("权限不足，请联系对应的大区总监！");
                         }else{
                             props && props.onItemPress({ route, focused });
                         }
                     }else{
                         props && props.onItemPress({ route, focused });
                     }

                 }} /></ScrollView>,
    drawerPosition: 'left',
    lazy: true,
    swipeEnabled:true,
    animationEnabled:true,
    drawerWidth:StyleSheetAdapt.getWidth(170),
    // headerMode:'none',
    // backBehavior: 'none', // 按 back 键是否跳转到第一个Tab(首页)， none 为不跳转
    contentOptions: {
        activeTintColor:Theme.Colors.themeColor,
        style:{
            marginTop:StyleSheetAdapt.getHeight(20),
        },
        labelStyle:{
            fontSize:StyleSheetAdapt.getWidth(Theme.Font.fontSize),
            marginTop:StyleSheetAdapt.getHeight(20),
        }
        // backBehavior:'none',
    }
};

const PageCustomerDrawer = DrawerNavigator(DrawerRouteConfigs, DrawerNavigatorConfigs);


const TabRouteConfigs = {
    PageCustomerDrawer: {
        screen: PageCustomerDrawer,
        navigationOptions: {
            headerLeftDrawer:true,//true执行策划菜单打开或关闭，false或未设置执行默认返回 需要修改底层header的_navigateBack
            swipeEnabled:false,
        },
    },
    PageCustomerDocDetails:{
        screen:PageCustomerDocDetails,
        navigationOptions: {
        },
    },
    PageApprovalDetails:{
        screen:PageApprovalDetails,
        navigationOptions: {
        },
    }
}

const PagesCustomer = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = PagesCustomer;


