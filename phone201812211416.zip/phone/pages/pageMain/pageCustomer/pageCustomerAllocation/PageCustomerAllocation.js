import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    Slider,
    ImageBackground,
    TouchableOpacity,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    TextIcon,
    Tools,
    BaseComponent,
    ItemRowTripApply,
    SearchDDDIpt,
    FlatListView,
    Theme,
} from "com";

import {
    CheckBox
} from "comThird";

import {Service} from './Service';

/**
 * 门店运营中心 - 可分配所有客户
 * 大区总监 - 可分配大区下客户
 * 分配客户不支持跨大区
 * 搜索后才会刷新经理下拉框
 */
type Props = {};
export default class  PageCustomerAllocation extends BaseComponent<Props> {

    dropList = {
        types1: {
            name:[],
            code:{},
            clearDrop:false,
        },//一级品类 数据
        types2: {
            name:["选择省份"],
            code:{},
            clearDrop:false,
        },//二级品类 数据
        types3: {
            name:["选择城市"],
            code:{},
            clearDrop:false,
        },//三级品类 数据
    };

    managerList = {
        provomceManager:{
            name:["选择省区经理"],
            code:{},
            frameworkId:{},
            clearDrop:false,
        },
        customerManager:{
            name:["选择客户经理"],
            code:{},
            frameworkId:{},
            clearDrop:false,
        },
        assistant:{
            name:["选择运营助理"],
            code:{},
            frameworkId:{},
            clearDrop:false,
        }
    };

    //城市筛选选中
    selectValue = {
        regionId: '',//下拉选中值
        regionName:'',//下拉选中的大区
        provincialId: '',//下拉选中值
        cityId: '',//下拉选中值
        customerName: '',//名称输入值
        queryType:'',//额外条件单选
        execFirst: true,//是否是第一次执行
        type:'',
    };

    //底部下拉框经理筛选选中
    selectValue2 = {
        id:[],
        provomceManagerId: '',//下拉选中值
        provomceManager:'',
        customerManagerId: '',//下拉选中值
        customerManager:'',
        assistantId: '',//下拉选中值
        assistant:'',
        frameworkId:'',
        areaName:'',
        execFirst: true,//是否是第一次执行
    };

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            btn:null,
            isRenderItemFirst:true,
            execting:false,
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            workflowName:Tools.userConfig.userInfo.department_id == 52 ? '华南大区' :
                Tools.userConfig.userInfo.department_id == 53 ? "华北大区" :
                    Tools.userConfig.userInfo.department_id == 54 ? "华东大区" :
                        Tools.userConfig.userInfo.department_id == 55 ? "西南大区" :"华南大区",
            total: 0,//商品总数
            dataList: [],//数组列表SS
            refresh: false,//是否刷新
            clearDrop: false,
            clearDrop_2:true,
        }
    }

    initState(){
        let stateInit = {
            isChecked: true,//是否选中确认地址，默认选中
        };
        this.state = stateInit;
        this.setState(stateInit);
    }

    onChecked = (isChecked,item)=>{
        if(item.isChecked){
            this.selectValue2.id.push(item.id);
            item.isChecked = false;
        }else{
            item.isChecked = true;
            this.removeByValue(this.selectValue2.id,item.id);
        }

        this.setState({
            isChecked_par:isChecked
        });
        // console.log(this.selectValue2.id)
    };

    //删除数组指定数据
    removeByValue(arr, val) {
        for(var i=0; i<arr.length; i++) {
            if(arr[i] == val) {
                arr.splice(i, 1);
                break;
            }
        }
    }

    //全选
    onCheckedAll = (isChecked)=>{
        this.selectValue2.id = [];
        console.log(this.state.dataList)
        this.state.dataList.forEach((val,i,arr) =>{
            val.isChecked = !isChecked;
            if(isChecked){
                this.selectValue2.id.push(val.id);
            }
        });
        this.setState({
            isChecked:isChecked
        });
        console.log(this.selectValue2.id)
    };

    onTextChange(val) {
        this.selectValue.customerName = val;
    }

    /**
     * 搜索
     */
    onSearch() {
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);

        //清空经理数据
        this.managerList.provomceManager.name = [];
        this.managerList.provomceManager.clearDrop = true;
        this.selectValue2.provomceManagerId = '';

        this.managerList.customerManager.name = [];
        this.managerList.customerManager.clearDrop = true;
        this.selectValue2.customerManagerId = '';

        this.managerList.assistant.name = [];
        this.managerList.assistant.clearDrop = true;
        this.selectValue2.assistantId = '';

        this.setState({
            total: 0,
            dataList: []
        });
        this.getData(this.selectValue);
        this.initDepartment(this.selectValue.regionName);
    }

    componentWillMount(){
        this.initCity();
        this.initDepartment();

        this.getData();
    }

    initCity(){
        Service.getCity().then(retJson=>{
            this.dropList.types1 = retJson;

            this.setState({
                refresh:true,
                clearDrop:false,
            });

            //设置初始化省份
            if(this.state.workflowName != ''){
                let val = {
                    name:this.state.workflowName,
                }
                this.onSelectDrop(0,val,1);
            }
        });
    }

    initDepartment(regionName){
        Service.getDepartmentUserList(undefined,undefined,undefined,regionName,"省区总监")
            .then(retJson=>{
                this.managerList.provomceManager = retJson;
                this.setState({
                    refresh:true,
                    clearDrop_2:false
                });
            });
    }

    renderItem(item, index) {
        return (
            <View style={styles.list}>
                <View style={styles.checkBoxView}>
                    <CheckBox rightText={"客户名称："+item.name}
                              style={styles.bodyFrame3_chk}
                              rightTextStyle={styles.chkText}
                              isChecked={!item.isChecked}
                              onClick={()=>{this.onChecked(!item.isChecked,item)}}
                              imageStyle={styles.chkImage}
                              checkBoxColor={Theme.Colors.themeColor}/>
                </View>

                <View style={styles.segment}></View>

                <View style={styles.model}>
                    <View style={styles.model_view_1}>
                        <Text style={styles.model_text}>签约时间：{item.signTime}</Text>
                        <Text style={styles.model_text}>所 在 省：{item.province}</Text>
                        <Text style={styles.model_text_1}>省区经理：{item.provinceManager}</Text>
                    </View>

                    <View style={styles.model_view_1}>
                        <Text style={styles.model_text}>所 在 市：{item.city}</Text>
                        <Text style={styles.model_text_1}>客户经理：{item.customerManager}</Text>
                    </View>

                    <View style={styles.model_view_1}>
                        <Text style={styles.model_text_1}>运营助理：{item.assistant}</Text>
                    </View>
                </View>
            </View>
        );
    }

    onItemPress(item) {
        this.goPage("PageCustomerBase", {store_code: item});
    }

    //提交数据
    onPressBottom = ()=>{

        if(this.selectValue2.id.length>0){
            if(this.managerList.customerManager.name.length>1){
                let level = Tools.userConfig.userInfo.department_level;
                if(level == 1){
                    //获取大区信息
                    this.selectValue2.areaName = this.selectValue.regionId;
                }

                Service.putIn(this.selectValue2).then(retJson=>{
                    this.initState();
                    Tools.toast("分配成功，数据同步进行中，请稍后查看结果！");
                })
                    .catch((retJson)=>{
                        Tools.toast("内部服务器错误，请联系管理员");
                    });
            }else{
                Tools.toast('请选择省区经理')
            }
        }else{
            Tools.toast('请选择客户')
        }
    };

    /**
     * 设置下拉框选中
     * @param val
     * @param i
     * @param type
     */
    onSelectManager(val,i,type){
        this.selectValue.type = type;
        if(type == 1){
            this.managerList.customerManager.name = [];
            this.managerList.customerManager.clearDrop = true;
            this.selectValue2.customerManagerId = '';

            this.managerList.assistant.name = [];
            this.managerList.assistant.clearDrop = true;
            this.selectValue2.assistantId = '';

            this.selectValue2.provomceManagerId = this.managerList.provomceManager.code[val.name];
            this.selectValue2.provomceManager = val.name;
            this.selectValue2.frameworkId = this.managerList.provomceManager.frameworkId[val.name];

            if(this.selectValue2.provomceManagerId != '' && this.selectValue2.provomceManagerId != undefined) {
                this.getManagerTypes(this.selectValue2.frameworkId,
                    this.selectValue2.provomceManagerId,type,"客户经理");
            }

            this.setState({
                refresh:false,
                clearDrop_2:true
            });
        }
        if(type == 2){

            this.managerList.assistant.name = [];
            this.managerList.assistant.clearDrop = true;
            this.selectValue2.assistantId = '';

            this.selectValue2.customerManagerId = this.managerList.customerManager.code[val.name];
            this.selectValue2.customerManager = val.name;
            this.selectValue2.frameworkId = this.managerList.customerManager.frameworkId[val.name];

            if(this.selectValue2.customerManagerId != '' && this.selectValue2.customerManagerId != undefined){
                this.getManagerTypes(this.selectValue2.frameworkId,
                    this.selectValue2.customerManagerId,type,"运营助理");
            }

            this.setState({
                refresh:false,
                clearDrop_2:false
            });
        }
        if(type == 3){
            this.selectValue2.assistantId = this.managerList.assistant.code[val.name];
            this.selectValue2.assistant = val.name;
        }
    }

    /**
     * 获取城市列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {

        //如果是筛选大区区域后的搜索加入条件
        if(this.selectValue != undefined){
            selectValue = this.selectValue;
        }
        if(selectValue.departmentName == undefined){
            selectValue.departmentName = "";
        }


        if(!this.selectValue.execFirst){
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        if(!this.configData.execting){
            this.configData.execting = true;
            //查列表数据
            Service.get(selectValue,this.selectValue.execFirst)
                .then(retJson =>{

                    this.configData.execting = true;

                    if(!this.selectValue.execFirst && !retJson.has){
                        this.configData.execting = false;//控制是否去请求数据
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                    }else{
                        this.selectValue.execFirst = false;//控制清空数据
                        this.setState({
                            total:retJson.totalElements,
                            dataList:retJson.content
                        });

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);

                        this.configData.execting = false;//控制是否去请求数据
                    }

                })
                .catch((status) =>{
                    this.selectValue.execFirst = false;
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }
    }

    onSelectDrop(i,val,type){
        if(type == 1){
            this.selectValue.regionName = val.name;

            this.dropList.types2.name = [];
            this.dropList.types2.clearDrop = true;
            this.selectValue.provincialId = '';

            this.dropList.types3.name = [];
            this.dropList.types3.clearDrop = true;
            this.selectValue.cityId = '';

            this.selectValue.regionId = this.dropList.types1.code[val.name];
            this.selectValue2.areaName = val.name;

            if(this.selectValue.regionId != '') {
                this.getDataGoodsTypes(this.selectValue.regionId,type);
            }

            this.setState({
                refresh:false,
                clearDrop:true
            });
        }
        if(type == 2){

            this.dropList.types3.name = [];
            this.dropList.types3.clearDrop = true;
            this.selectValue.cityId = '';

            this.selectValue.provincialId = this.dropList.types2.code[val.name];
            if(this.selectValue.provincialId != ''){
                this.getDataGoodsTypes(this.selectValue.provincialId,type);
            }

            this.setState({
                refresh:false,
                clearDrop:false
            });
        }
        if(type == 3){
            this.selectValue.cityId = this.dropList.types3.code[val.name];
        }
    }

    /**
     * 获取城市分类
     * @param code int,//父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    getDataGoodsTypes(code,type){
        Service.getCity(code,type).then(retJson =>{
            if(type == 0){
                this.dropList.types1 = retJson;
            }else if(type == 1){
                this.dropList.types2 = retJson;
            }else  if(type == 2){
                this.dropList.types3 = retJson;
            }

            this.setState({
                refresh:true,
                clearDrop:false
            });
        });
    }

    /**
     * 获取下拉框数据-各级经理
     * @param userId int,//用户id
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * @parm framework_id int,//部门id
     * **/
    getManagerTypes(framework_id,userId,type,postName){
        Service.getDepartmentUserList(framework_id,userId,type,
            this.selectValue.regionName,postName).then(retJson =>{

            if(type == 0){
                this.managerList.provomceManager = retJson;
            }else if(type == 1){
                this.managerList.customerManager = retJson;
            }else if(type == 2){
                this.managerList.assistant = retJson;
            }

            this.setState({
                refresh:true,
                clearDrop_2:false
            });
        });
    }
    render() {
        const {isChecked,workflowId} = this.state;

        return (
            <ViewTitle frameStyle = {styles.submitButtonStyle} isScroll={false} viewBottom={"提交"}
                       onPressBottom={this.onPressBottom}  ref={c=>this.viewTitle=c}>
                <SearchDDDIpt refresh={this.state.refresh}
                              frameStyle={styles.searchStyle}
                              options1={{
                                  defaultValue: this.state.workflowName,
                                  options: this.dropList.types1.name,
                                  clearDrop: this.dropList.types1.clearDrop,
                                  onSelect: (i, val) => this.onSelectDrop(i, val, 1)
                              }}
                              options2={{
                                  defaultValue:this.dropList.types2.name[0] == undefined
                                      ? '选择省份'
                                      : this.dropList.types2.name[0],
                                  options: this.dropList.types2.name,
                                  clearDrop: this.state.clearDrop,
                                  onSelect: (i, val) => this.onSelectDrop(i, val, 2)
                              }}
                              options3={{
                                  defaultValue:this.dropList.types3.name[0] == undefined
                                      ? '选择城市'
                                      : this.dropList.types3.name[0],
                                  options: this.dropList.types3.name,
                                  clearDrop: this.dropList.types3.clearDrop,
                                  onSelect: (i, val) => this.onSelectDrop(i, val, 3)
                              }}
                              placeholder={"--客户姓名--"}
                              textChange={(val) => this.onTextChange(val)}
                              onPressSearch={() => this.onSearch()}/>

                <View style={styles.title}>
                    <View style={styles.titleIco}></View>
                    <CheckBox rightText={"全选"}
                              style={styles.bodyFrame3_chk}
                              rightTextStyle={styles.chkText}
                              isChecked={isChecked}
                              onClick={(isChecked)=>{this.onCheckedAll(isChecked)}}
                              imageStyle={styles.chkImage}
                              checkBoxColor={Theme.Colors.themeColor}/>
                </View>

                <FlatListView
                    data={this.state.dataList}
                    keyExtractor={(item, index) => ("key" + index)}
                    renderItem={({item, i}) => this.renderItem(item, i)}
                    onEndReached={() => this.getData()}
                />

                <View>
                    <View style={styles.titleFrame}>
                        <ItemRowTripApply text={"省区经理"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenterProps={{
                                              dropdownStyle:{
                                                  height:200,
                                              },
                                              clearDrop:this.managerList.provomceManager.clearDrop,
                                              defaultValue:this.managerList.provomceManager.name[0],
                                              options:this.managerList.provomceManager.name,
                                              onSelect:(i,val)=>this.onSelectManager(val,i,1)
                                          }}/>

                        <ItemRowTripApply text={"客户经理"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenterProps={{
                                              dropdownStyle:{
                                                  height:200,
                                              },
                                              defaultValue:this.managerList.customerManager.name[0] == undefined
                                                  ? '选择客户经理' : this.managerList.customerManager.name[0],
                                              options:this.managerList.customerManager.name,
                                              clearDrop:this.managerList.customerManager.clearDrop,
                                              onSelect:(i,val)=>this.onSelectManager(val,i,2)
                                          }}/>

                        <ItemRowTripApply text={"运营助理"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenterProps={{
                                              dropdownStyle:{
                                                  height:200,
                                                  marginTop:45,
                                              },
                                              defaultValue:this.managerList.assistant.name[0] == undefined
                                                  ? '选择运营助理' : this.managerList.assistant.name[0],
                                              options:this.managerList.assistant.name,
                                              clearDrop:this.managerList.assistant.clearDrop,
                                              onSelect:(i,val)=>this.onSelectManager(val,i,3)
                                          }}/>
                    </View>
                </View>
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    text1_1:{
        color:Theme.Colors.themeColor,
    },
    //顶部搜索
    searchStyle:{
        fontSize:Theme.Font.fontSize_1_1,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    pFrame: {
        borderColor: Theme.Colors.minorColor,
        borderTopWidth: Theme.Border.borderWidth,
        padding: 10,
    },
    promptFrame: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 10,
    },
    //高级选项字体
    text: {
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    btn: {
        width:160,
        borderColor: Theme.Colors.minorColor,
        borderWidth: Theme.Border.borderWidth,
        padding: 3,
        backgroundColor: Theme.Colors.backgroundColor,
    },
    interval: {
        marginLeft: 5,
        borderRadius: 30,
        width: 185,
    },
    interval2: {
        marginRight: 5,
    },
    btnActive:{
        borderWidth:0,
        backgroundColor:Theme.Colors.themeColor,
    },
    textBtnActive:{
        color:Theme.Colors.backgroundColor,
    },
    itemFram:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    segment:{
        left:10,
        height:15,
        width:750,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titleFrame:{
        height:200,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titleFrameTop:{
    },
    buttonHead_text:{
        fontSize:Theme.Font.fontSize_1,
    },
    titleFrame_btn:{
        height:Theme.Height.height2,
        padding:5,
        width:120,
    },
    itemrowBtton:{
        padding:10,
        alignItems: 'center',
        justifyContent: 'center',
    },
    bodyFrame3_chk:{
        paddingLeft:10,
        alignItems:'flex-start',
        justifyContent:'flex-start',
    },
    chkText:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.themeColor,
        marginLeft:3,
    },
    chkImage:{
        width:Theme.Font.fontSize1,
        height:Theme.Font.fontSize1 + "dw",
    },
    checkBoxView:{
        paddingLeft:10,
    },
    list:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    model:{
        flexDirection: 'row',
        paddingLeft:20,
        marginBottom:50,
    },
    model_text:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor_1,
    },
    model_view_1:{
        flex:1,
        alignItems:'flex-start',
        justifyContent:'flex-end',
        marginTop:10,
    },
    model_text_1:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    submitButtonStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
});

import {
    TabNavigator,
} from 'comThird';
import {ButtonChange} from "../../../../component/ui/ButtonChange";


const TabRouteConfigs = {
    PageCustomerAllocation: {
        screen: PageCustomerAllocation,
        navigationOptions: {
            title: '分配客户',
            tabBarLabel: '分配客户',
            // swipeEnabled: false,
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;
