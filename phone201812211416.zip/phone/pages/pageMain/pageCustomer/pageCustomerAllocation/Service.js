import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    retList = [];

    retJson = {
        retData: {
            has: false,//是否有数据，true:有，false:没有，默认是false
        },
        totalElements: 0,
    };//后台返回数据

    paramsFetch = {
        pageNumber:0,
        executing:false,//是否正在执行中
    };


    /**
     * 提交搜索数据
     * @param val 参数
     */
    static get(val,init) {

        init = init == undefined ? false : init;

        if(init || this.base == undefined){
            new Service();
        }

        if(init){
            this.base.paramsFetch.pageNumber = 0;
            this.base.retJson.retData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }else {
            this.base.paramsFetch.executing = true;
        }

        if(val != undefined && val != null && val != ""){
            val.regionName = (val.regionName == "") ? undefined : val.regionName;
        }

        //如果是门店运营中心默认选择华南大区
        if(Tools.userConfig.userInfo.showAllData && val.regionName == undefined){
            val = {
                regionId:"S010101",
                regionName:"华南大区",
                provincialId:"",
                cityId:"",
                customerName:"",
                queryType:"",
                execFirst:true,
            }
        }

        if(val == undefined){
            return Http.get(HttpUrls.urlSets.urlCustomerListGet,
                {jobGrade:Tools.userConfig.userInfo.job_grade,
                    userId :Tools.userConfig.userInfo.id,
                    number :this.base.paramsFetch.pageNumber,
                    size: 10},true)
                .then(retJson => {

                    if(retJson.retData == undefined || retJson.retData.content.length == 0) {
                        retJson.retData = [];
                        this.base.retJson.retData.has = false;
                    }else{
                        this.base.paramsFetch.pageNumber++;
                        this.base.retJson.retData.has = true;
                    }

                    retJson.retData.content.forEach((val,i,arr) =>{
                        var ret = {id:val.id,name:val.name,signTime:val.sign_time,province:val.storeAddressProvince,
                            provinceManager:val.provincialManagerName,city:val.storeAddressCity,
                            customerManager:val.customerManagerName,assistant:'无记录',
                            isChecked:true,code:val.storecode};

                        this.base.retList.push(ret);
                    });

                    this.base.retJson.retData.content = this.base.retList;

                    this.base.retJson.retData.totalElements = retJson.retData.totalElements;
                    this.base.paramsFetch.executing = false;

                    return this.base.retJson.retData;
                });
        }else{
            return Http.get(HttpUrls.urlSets.urlCustomerListGet,
                {regionId:val.regionId,
                    provincialId:val.provincialId,
                    userId :Tools.userConfig.userInfo.id,
                    number :this.base.paramsFetch.pageNumber,
                    size: 10,cityId:val.cityId,
                    jobGrade:Tools.userConfig.userInfo.job_grade,
                    customerName:val.customerName,
                    showAllData:Tools.userConfig.userInfo.showAllData,
                },true)
                .then(retJson => {

                    if(retJson.retData.content == "" || retJson.retData.content.length == 0) {
                        retJson.retData.content = [];
                        this.base.retJson.retData.has = false;
                    }else{
                        this.base.paramsFetch.pageNumber++;
                        this.base.retJson.retData.has = true;
                    }

                    retJson.retData.content.forEach((val,i,arr) =>{
                        var ret = {id:val.id,name:val.name,signTime:val.sign_time,province:val.storeAddressProvince,
                            provinceManager:val.provincialManagerName,city:val.storeAddressCity,
                            customerManager:val.customerManagerName,assistant:val.operationManagerName,
                            isChecked:true,code:val.storecode};

                        this.base.retList.push(ret);
                    });

                    this.base.retJson.retData.content = this.base.retList;

                    this.base.retJson.retData.totalElements = retJson.retData.totalElements;
                    this.base.paramsFetch.executing = false;

                    return this.base.retJson.retData;
                });
        }
    }

    /**
     * 读取城市列表
     * **/
    static getCity(code,type){

        var jobGrade = Tools.userConfig.userInfo.job_grade;
        if(Tools.userConfig.userInfo.showAllData){
            jobGrade = 1;
        }

        if(type == undefined){
            var queryType = 1;
            code = 'S0101';
        }else if(type == 1){
            var queryType = 2;
        }else if(type == 2){
            var queryType = 3;
        }
        return Http.get(HttpUrls.urlSets.urlCustomerGet,
            {jobGrade: jobGrade,queryType:queryType,parentCode:code},
            false)
            .then(retJson => {
                let types = {
                    name:[(type == undefined ? "选择大区": type == 1 ?
                        "选择省区" : type == 2 ? "选择城市" : '')],
                    code:{},
                    id:{},
                    clearDrop:false,
                };

                if(retJson.retData == undefined){
                    retJson.retData = [];
                }else{
                    types.name[types.name[0]] = '';
                }

                retJson.retData.forEach((val,i,arr) =>{
                    types.name.push(val.name);
                    types.code[val.name] = val.code;
                    types.id[val.name] = val.id;
                });

                return types;
            });
    }

    /**
     * 下拉选框-》获取部门员工
     * @param framework_id string,// 部门id
     * @param regionName//大区名称
     * **/
    static getDepartmentUserList(framework_id,userId,type,regionName,postName){

        userId = Tools.userConfig.userInfo.id;

        if(framework_id == undefined || framework_id == "" || framework_id == null){
            framework_id = Tools.userConfig.userInfo.department_id;
        }

        if(regionName == undefined){
            regionName = "";
        }

        let parFramework_id = parseInt(framework_id);
        let parUserId = parseInt(userId);
        let parLevel = parseInt(Tools.userConfig.userInfo.department_level);

        if(parLevel == 1){
            return Http.get(HttpUrls.urlSets.urlCustomerAllocation,{
                frameworkId:parFramework_id,
                level:parLevel,departmentName:regionName,postName:postName
            },false).then((retJson)=>{
                let types = {
                    name:[(type == undefined ? "选择省区经理": type == 1 ?
                        "选择客户经理" : type == 2 ? '请选择运营助理' : '选择省区经理')],
                    code:{},
                    frameworkId:{},
                    clearDrop:false,
                };
                if(retJson.retData == undefined){
                    retJson.retData = [];
                }else{
                    types.name[types.name[0]] = '';
                }
                retJson.retData.forEach((val,i,arr) =>{
                    types.name.push(val.fullName);
                    types.code[val.fullName] = val.employeeId;
                    types.frameworkId[val.fullName] = val.frameworkId;
                });
                return types;
            });
        }else{
            return this.getManagerList(parFramework_id,parUserId,type,postName)
        }
    }

    static getManagerList(framework_id,userId,type,postName){
        let parLevel = parseInt(Tools.userConfig.userInfo.department_level);

        return Http.get(HttpUrls.urlSets.urlCustomerAllocation,{
            frameworkId:framework_id,managerId : userId,
            level:parLevel,postName:postName
        },false).then((retJson)=>{
            let types = {
                name:[(type == undefined ? "选择省区经理": type == 1 ?
                    "选择客户经理" : type == 2 ? '请选择运营助理' : '选择省区经理')],
                code:{},
                frameworkId:{},
                clearDrop:false,
            };
            if(retJson.retData == undefined){
                retJson.retData = [];
            }else{
                types.name[types.name[0]] = '';
            }
            retJson.retData.forEach((val,i,arr) =>{
                types.name.push(val.fullName);
                types.code[val.fullName] = val.employeeId;
                types.frameworkId[val.fullName] = val.frameworkId;
            });
            return types;
        });
    }

    /**
     * 提交修改数据
     * @param provomceManagerId 省区经理
     * @param customerManagerId 客户经理
     * @param assistantId 运营助理
     * @param code 门店编码
     */
    static putIn(val){
        return Http.post(HttpUrls.urlSets.urlCustomerAllocationAdd,
            {id:val.id,region_manager_id:val.provomceManagerId,
                region_manager:val.provomceManager,
                operate_supervisor_id:val.customerManagerId,
                operate_supervisor:val.customerManager,
                operate_manager_id:val.assistantId,
                operate_manager:val.assistant,
                area_name:val.areaName},true)
            .then(retJson => {
                return retJson.retData;
            });
    }
}