import {
    Theme,
} from "com";
import {
    TabNavigator,
} from 'comThird';

import PageApprovalAdd from "./pageApprovalAdd/PageApprovalAdd";
import PageApprovalDetail from "./pageApprovalDetail/PageApprovalDetail";
import PageApprovalList from "./pageApprovalList/PageApprovalList";

const TabRouteConfigs = {
    PageApprovalDetail: {
        screen: PageApprovalDetail,
        navigationOptions: {
            title: '流程详情',
            tabBarLabel: '流程详情',
        },
    },

    PageApprovalAdd: {
        screen: PageApprovalAdd,
        navigationOptions: {
            title: '添加流程',
            tabBarLabel: '添加流程',
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = {
    get PageApprovalList(){
        return PageApprovalList;
    },
    get PageApprovalDetails(){
        return pages;
    },

};