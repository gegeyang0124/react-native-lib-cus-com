import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    Slider,
    ImageBackground,
    TouchableOpacity,
    TextInput,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    TextIcon,
    Tools,
    Media,
    BarcodeView,
    ProgressPer,
    WebViewCus,
    Theme,
    SwiperNotice,
    BaseComponent,
    PickDropdown,
    ImageList,
    ImageChange,
    TextInputLabel,
    MenuBottom,
    ButtonChange,
    Http,
    ItemRowTitle,
    VideoList
} from "com";

import {
    CheckBox
} from "comThird";

import {Service} from './Service';

import imageFrame from 'images/camera.png';

type Props = {};
export default class PageApprovalAdd extends BaseComponent<Props> {

    icon=require('images/imageFrame2.png');

    selectValue = {
        regionId: '',//下拉选中值
        execFirst: true,//是否是第一次执行
        isChecked1:false,//勾选
        isChecked2:false,//勾选
        /**
         * 1-5 店铺图片，10-15 退盟报告 20-21 退盟视频
         * 30-35 营业执照或注销证明或新营业执照 40-45 店铺分析文档 50-55 店内图片
         * 60-65 原门头照片 70-75 门头照片
         * 80-85 相关资料
         */
        imageId:'',//当前上传的图片id,
        itemType:2,//提交单据类型,默认为退盟申请
    };

    constructor(props) {
        super(props);

        this.state = {
            isQuit:'',
            imageSignInList:[],//附件列
            deCustomer:'请选择',//默认显示值
            deApproval:'客户退盟',
            customerList:[],//客户列表
            approvalList:[
                {name:'客户退盟',id:'2'},
                {name:'客户结业',id:'3'},
                {name:'客户维权',id:'6'}
            ],
            /*legalLegalStatus:[
                {name:'过期',id:'1'},
                {name:'盗版店',id:'2'},
            ],//维权原因*/
            isVisible_1: "flex",
            isVisible_2: "none",
            isVisible_3: "none",
            isVisible_title_1:'flex',
            isVisible_title_2:'none',
            isVisible_title_3:'none',
            region_manager:'',//省区经理
            operate_manager:'',//客户助理
            operate_supervisor:'',//客户经理
            store_address:'',//地址
            number1:'',
            number2:'',
            number3:'',
            number4:'',
            number5:'',
            number6:'',
            number7:'',
            number8:'',
            number9:'',
            number10:'',
            number11:'',
            number12:'',
            /**
             * 0-4 店铺图片，10-14 退盟报告 20-21 退盟视频
             * 30-35 营业执照或注销证明或新营业执照 40-45 店铺分析文档 50-55 店内图片
             * 60-65 原门头照片 70-75 门头照片
             * 80-85 店内图片 90-95 财务报告 100-105店铺图片 110-115 营业执照
             */
            storeImages:[{},{},{},{},{}],//店铺图片
            quitReport:[{},{},{},{},{}],//退盟报告
            quitViedo:[],//退盟视频
            newLicense:[{},{},{},{},{}],//新营业执照
            storeSrs:[{},{},{},{},{}],//店铺分析文档
            storeDetailImage:[{},{},{},{},{}],//店内图片
            oldShopSign:[{},{},{},{},{}],//原门头
            thisShopSign:[{},{},{},{},{}],//门头
            storeFile:[{},{},{},{},{}],//财务报告
            storeHead:[{},{},{},{},{}],//店铺图片
            storeLicence:[{},{},{},{},{}],//营业执照
            storeData:[{},{},{},{},{}],//店内图片
            clean:false,//是否可选择，true：不可以选择，false:可以选择
        };

        //退盟
        this.customerQuit={
            auditing_record_id:'',//档案id
            auditing_pic:[],//店铺图片
            auditing_file:[],//退盟报告
            auditing_video:[],//退盟视频
        };

        //结业
        this.customerWindingUp={
            auditing_record_id:'',
            auditing_pref:'',//应完成业绩金额
            auditing_first:'',//首批业绩金额
            auditing_after:'',//后期补货金额
            auditing_deposit:'',//可退保证金
            auditing_remark:'',//原因
            auditing_licence:[],//营业执照注销证明
            auditing_file:[],//店铺分析文档
            auditing_pic:[],//店内图片
            auditing_oldhead:[],//原门头照
            auditing_head:[],//门头照
        };

        //维权
        this.customerLegal ={
            auditing_record_id:'',
            auditing_account_amount:'',//账户金额
            auditing_remark:'',//原因
            auditing_pic:[],//店内图片
            storeFile:[],//财务报告
            storeHead:[],//店铺图片
            storeLicence:[],//营业执照
            storeData:[],//店内图片
            auditing_file:[],
            auditing_head:[],
            auditing_licence:[],
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.btnList = [
            {text:'拍摄',onPress:this.onGetPic},
            {text:'选取',onPress:this.onGetPic}
        ];
    }

    componentWillMount(){
        for(var i = 0; i <= 120; i++){
            this.state.imageSignInList.push("");
        }
        this.getCustomers();
        this.getData();
    }

    /**
     * 获取客户列表
     * **/
    getCustomers(){
        Service.getCustomers().then(retJson =>{
            this.setState({
                customerList:retJson,
            });
        })
    }

    getData() {

    };

    //选择客户
    onSelectCustomer(val){
        if(this.selectValue.itemType == 2){
            this.customerQuit.itemType = 2;
            this.customerQuit.auditing_record_id = val.id;
        }else if(this.selectValue.itemType == 3){
            this.customerWindingUp.itemType = 3;
            this.customerWindingUp.auditing_record_id = val.id;
        }else if(this.selectValue.itemType == 6){
            //加载客户信息
            Service.getDataDetailByid(val.id).then(retJson=>{
                this.setState({
                    region_manager : retJson.region_manager,
                    operate_manager : retJson.operate_manager,
                    store_address : retJson.store_address,
                    operate_supervisor : retJson.operate_supervisor,
                });
            });

            this.customerLegal.itemType = 6;
            this.customerLegal.auditing_record_id = val.id;
        }
    }

    //选择维权类型（暂时废弃，CRM3.0没有维权类型的选择）
    /* onSelectLegalStatus(val){
         this.customerLegal.status = val.id;
     }*/

    //选择提交类型
    onSelectApproval(val){
        console.log(val)
        this.selectValue.itemType = val.id;

        if(val.id == 2){
            this.setState({
                isVisible_1:'flex',
                isVisible_2:'none',
                isVisible_3:'none',
                isVisible_title_1:'flex',
                isVisible_title_2:'none',
                isVisible_title_3:'none',
            })
        }else if(val.id == 3){
            this.setState({
                isVisible_1:'none',
                isVisible_2:'flex',
                isVisible_3:'none',
                isVisible_title_1:'none',
                isVisible_title_2:'flex',
                isVisible_title_3:'none',
            })
        }else if(val.id == 6){
            this.setState({
                isVisible_1:'none',
                isVisible_2:'none',
                isVisible_3:'flex',
                isVisible_title_1:'none',
                isVisible_title_2:'none',
                isVisible_title_3:'flex',
            })
        }
    }

    //单选框
    onChecked = (item)=>{
        if(item == 1){
            if(this.selectValue.isChecked1){
                this.selectValue.isChecked1 = false;
                this.selectValue.isChecked2 = false;
            }else{
                this.selectValue.isChecked1 = true;
                this.selectValue.isChecked2 = false;
            }
        }else{
            if(this.selectValue.isChecked2){
                this.selectValue.isChecked2 = false;
                this.selectValue.isChecked1 = false;
            }else{
                this.selectValue.isChecked2 = true;
                this.selectValue.isChecked1 = false;
            }
        }

        this.customerQuit.isQuit = item;
        this.setState({
            isQuit:item,
        });
    };

    //输入框
    onChangeText(text,type){
        if(type ==0){
            this.customerQuit.auditing_first = text;
        }else if(type == 1){
            this.customerQuit.auditing_pref = text;
        }else if(type == 2){
            this.customerQuit.auditing_after = text;
        }else if(type == 3){
            this.customerQuit.auditing_deposit = text;
        }else if(type == 4){
            this.customerQuit.auditing_remark = text;
        }else if(type == 10){
            this.customerWindingUp.auditing_pref = text;
        }else if(type == 11){
            this.customerWindingUp.auditing_first=text;//首批业绩金额
        }else if(type == 12){
            this.customerWindingUp.auditing_after = text;//后期补货金额
        }else if(type == 13){
            this.customerWindingUp.auditing_deposit = text;//可退保证金
        }else if(type == 14){
            this.customerWindingUp.auditing_remark = text;
        }else if(type == 20) {
            this.customerLegal.status = text;
        }else if(type == 21){
            this.customerLegal.auditing_account_amount = text;//账上余额
        }else if(type == 22){
            this.customerLegal.auditing_remark = text;//原因
        }
    }

    //删除图片
    modelImageButton(id){
        let images = [{},{},{},{},{}];

        var thisImageId = id;
        if(id > 4){
            thisImageId = parseInt((id+"").substring(1,2));
        }

        /**
         * 0-4 店铺图片，10-14 退盟报告 20-21 退盟视频
         * 30-35 营业执照或注销证明或新营业执照 40-45 店铺分析文档 50-55 店内图片
         * 60-65 原门头照片 70-75 门头照片
         * 80-85 相关资料
         */
        if(id < 10){
            this.state.storeImages.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.storeImages[i];
                }
            });
            this.setState({storeImages:images});
        }else if(id >= 10 && id < 20){
            this.state.quitReport.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.quitReport[i];
                }
            });
            this.setState({quitReport:images});
        }else if(id >= 20 && id < 30){
            this.state.quitViedo.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.quitViedo[i];
                }
            });
            this.setState({quitViedo:images});
        }else if(id >= 30 && id < 40){
            this.state.newLicense.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.newLicense[i];
                }
            });
            this.setState({newLicense:images});
        }else if(id >= 40 && id < 50){
            this.state.storeSrs.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.storeSrs[i];
                }
            });
            this.setState({storeSrs:images});
        }else if(id >= 50 && id < 60){
            this.state.storeDetailImage.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.storeDetailImage[i];
                }
            });
            this.setState({storeDetailImage:images});
        }else if(id >= 60 && id < 70){
            this.state.oldShopSign.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.oldShopSign[i];
                }
            });
            this.setState({oldShopSign:images});
        }else if(id >= 70 && id < 80){
            this.state.thisShopSign.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.thisShopSign[i];
                }
            });
            this.setState({thisShopSign:images});
        }else if(id >= 80 && id < 90){
            this.state.storeData.forEach((val,i)=>{
                if(i != thisImageId){
                    images[i] = this.state.storeData[i];
                }
            });
            this.setState({storeData:images});
        }else if(id >= 90 && id < 100) {
            this.state.storeFile.forEach((val, i) => {
                if (i != thisImageId) {
                    images[i] = this.state.storeFile[i];
                }
            });
            this.setState({storeFile: images});
        }else if(id >= 100 && id < 110) {
            this.state.storeHead.forEach((val, i) => {
                if (i != thisImageId) {
                    images[i] = this.state.storeHead[i];
                }
            });
            this.setState({storeHead: images});
        }else if(id >= 110 && id < 120) {
            this.state.storeLicence.forEach((val, i) => {
                if (i != thisImageId) {
                    images[i] = this.state.storeLicence[i];
                }
            });
            this.setState({storeLicence: images});
        }
    }

    //获取图片
    onGetPic = (item,i)=>{
        if(this.selectValue.imageId>=20 && this.selectValue.imageId<=21){
            if(this.state.quitViedo.length==1){
                Tools.toast("视频数量已达到上线");
            }else{
                if(i==0){

                    Media.takeVideo(false,this.state.taskName).then(retJson=>{
                        MenuBottom.show(false);
                        // this.state.imageSignInList[this.selectValue.imageId] = retJson.path;
                        const video=[]
                        video.push({uri:retJson.path})
                        this.setState({quitViedo:video})

                    });
                }
                else{
                    Media.pickVideo()
                        .then(retJson=>{
                            MenuBottom.show(false);
                            // this.state.imageSignInList[this.selectValue.imageId] = retJson.path;

                            const video=[]
                            video.push({uri:retJson.path})
                            this.setState({quitViedo:video})
                        });
                }
            }
        }
        else{
            if(i == 0){
                Media.takeImage("",false).then(retJson=>{

                    MenuBottom.show(false);

                    this.state.imageSignInList[this.selectValue.imageId] = retJson.path;

                    this.setShowImagePath();
                })
            }else if(i == 1){
                Media.pickImage(false,"",false).then(retJson=>{

                    MenuBottom.show(false);

                    this.state.imageSignInList[this.selectValue.imageId] = retJson.path;

                    this.setShowImagePath();

                });
            }
        }
    };

    setShowImagePath(){
        //设置图片显示
        let images = [{},{},{},{},{}];

        var id = this.selectValue.imageId;
        // console.log(id)
        if(id > 4 && id < 100){
            id = parseInt((id+"").substring(1,2));
        }else if(id >= 100){
            id = parseInt((id + "").substring(2,3));
        }
        // console.log(id)
        if(id != null){
            if(id == 0){
                var image = {uri:this.state.imageSignInList[this.selectValue.imageId]};
                images[0] = image;
            }else if(id == 1){
                var image = {uri:this.state.imageSignInList[this.selectValue.imageId]};
                images[1] = image;
            }else if(id ==2){
                var image = {uri:this.state.imageSignInList[this.selectValue.imageId]};
                images[2] = image;
            }else if(id ==3){
                var image = {uri:this.state.imageSignInList[this.selectValue.imageId]};
                images[3] = image;
            }else if(id ==4){
                var image = {uri:this.state.imageSignInList[this.selectValue.imageId]};
                images[4] = image;
            }

            /**
             * 0-4 店铺图片，10-14 退盟报告 20-21 退盟视频
             * 30-35 营业执照或注销证明或新营业执照 40-45 店铺分析文档 50-55 店内图片
             * 60-65 原门头照片 70-75 门头照片
             * 80-85 相关资料
             */
            if(this.selectValue.imageId < 10){
                this.state.storeImages.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeImages[i];
                    }
                });
                this.setState({storeImages:images});
            }else if(this.selectValue.imageId >= 10 && this.selectValue.imageId < 20){
                this.state.quitReport.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.quitReport[i];
                    }
                });
                this.setState({quitReport:images});
            }else if(this.selectValue.imageId >= 20 && this.selectValue.imageId < 30){
                images=[]
                this.state.quitViedo.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.quitViedo[i];
                    }
                });
                this.setState({quitViedo:images});
            }else if(this.selectValue.imageId >= 30 && this.selectValue.imageId < 40){
                this.state.newLicense.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.newLicense[i];
                    }
                });
                this.setState({newLicense:images});
            }else if(this.selectValue.imageId >= 40 && this.selectValue.imageId < 50){
                this.state.storeSrs.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeSrs[i];
                    }
                });
                this.setState({storeSrs:images});
            }else if(this.selectValue.imageId >= 50 && this.selectValue.imageId < 60){
                this.state.storeDetailImage.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeDetailImage[i];
                    }
                });
                this.setState({storeDetailImage:images});
            }else if(this.selectValue.imageId >= 60 && this.selectValue.imageId < 70){
                this.state.oldShopSign.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.oldShopSign[i];
                    }
                });
                this.setState({oldShopSign:images});
            }else if(this.selectValue.imageId >= 70 && this.selectValue.imageId < 80){
                this.state.thisShopSign.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.thisShopSign[i];
                    }
                });
                this.setState({thisShopSign:images});
            }else if(this.selectValue.imageId >= 80 && this.selectValue.imageId < 90){
                this.state.storeData.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeData[i];
                    }
                });
                this.setState({storeData:images});
            }else if(this.selectValue.imageId >= 90 && this.selectValue.imageId < 100){
                this.state.storeFile.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeFile[i];
                    }
                });
                this.setState({storeFile:images});
            }else if(this.selectValue.imageId >= 100 && this.selectValue.imageId < 110){
                this.state.storeHead.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeHead[i];
                    }
                });
                this.setState({storeHead:images});

            }else if(this.selectValue.imageId >= 110 && this.selectValue.imageId < 120){
                this.state.storeLicence.forEach((item,i)=>{
                    if(id != i){
                        images[i] = this.state.storeLicence[i];
                    }
                });
                this.setState({storeLicence:images});
            }
        }
    }


    showMenu(id){
        MenuBottom.show(true);
        this.selectValue.imageId = id;
        if(this.state.imageSignInList[id] != ""){
            this.state.imageSignInList[id] = "";
        }
    }
    delVideo=()=>{
        const video=[]
        this.setState({quitViedo:video})

    }


    //提交数据
    submitData = ()=>{
        if(this.customerQuit.auditing_record_id == undefined){
            Tools.toast("请选择客户");
            return;
        }

        if(this.selectValue.isChecked1){
            this.selectValue.itemType = 7;
        }

        var type = this.selectValue.itemType;

        if(type == 2){

            //提交数据到接口
            this.state.storeImages.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerQuit.auditing_pic.push(temp.uri);
                }
            });

            this.state.quitReport.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerQuit.auditing_file.push(temp.uri);
                }
            });

            this.state.quitViedo.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerQuit.auditing_video.push(temp.uri);
                }
            });

            Service.saveData(this.customerQuit).then(retJson=>{

                if(retJson.code == 0){
                    Tools.toast("添加成功");
                    this.clientData();
                    BaseComponent.backRefresh = true;
                    this.goBack();
                }else{
                    Tools.toast("网络异常，请检查网络或联系管理员");
                }
            });

        }else if(type == 3){
            //上传文件，返回字符串集合
            this.state.newLicense.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerWindingUp.auditing_licence.push(temp.uri);
                }
            });
            this.state.storeSrs.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerWindingUp.auditing_file.push(temp.uri);
                }
            });

            this.state.storeDetailImage.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerWindingUp.auditing_pic.push(temp.uri);
                }
            });

            this.state.oldShopSign.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerWindingUp.auditing_oldhead.push(temp.uri);
                }
            });

            this.state.thisShopSign.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerWindingUp.auditing_head.push(temp.uri);
                }
            });

            Service.saveData(this.customerWindingUp).then(retJson=>{

                if(retJson.code == 0){
                    Tools.toast("添加成功");
                    this.clientData();
                    BaseComponent.backRefresh = true;
                    this.goBack();
                }else{
                    Tools.toast("网络异常，请检查网络或联系管理员");
                }
            });

            //提交数据到接口
        }else if(type == 6){

            this.state.storeData.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerLegal.auditing_pic.push(temp.uri);
                }
            });
            this.state.storeFile.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerLegal.auditing_file.push(temp.uri);
                }
            });

            this.state.storeHead.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerLegal.auditing_head.push(temp.uri);
                }
            });

            this.state.storeLicence.forEach(temp=>{
                if(JSON.stringify(temp) != "{}"){
                    this.customerLegal.auditing_licence.push(temp.uri);
                }
            });

            Service.saveData(this.customerLegal).then(retJson=> {

                if (retJson.code == 0) {
                    Tools.toast("添加成功");
                    this.clientData();
                    BaseComponent.backRefresh = true;
                    this.goBack();
                } else {
                    Tools.toast("网络异常，请检查网络或联系管理员");
                }
            });
        }
    };

    //清空页面数据
    clientData(){
        this.state.number1.setNativeProps({ text: '' });
        this.state.number2.setNativeProps({ text: '' });
        this.state.number3.setNativeProps({ text: '' });
        this.state.number4.setNativeProps({ text: '' });
        this.state.number5.setNativeProps({ text: '' });
        this.state.number6.setNativeProps({ text: '' });
        this.state.number7.setNativeProps({ text: '' });
        this.state.number8.setNativeProps({ text: '' });
        this.state.number9.setNativeProps({ text: '' });
        this.state.number10.setNativeProps({ text: '' });
        this.state.number11.setNativeProps({ text: '' });
        this.state.number12.setNativeProps({ text: '' });

        //清空提交数据
        for(var i = 0 ; i <= 22 ; i++){
            this.onChangeText('',i)
        }
        //清空图片
        this.setState({
            storeImages:[{},{},{},{},{}],//店铺图片
            quitReport:[{},{},{},{},{}],//退盟报告
            quitViedo:[{},{}],//退盟视频
            newLicense:[{},{},{},{},{}],//新营业执照
            storeSrs:[{},{},{},{},{}],//店铺分析文档
            storeDetailImage:[{},{},{},{},{}],//店内图片
            oldShopSign:[{},{},{},{},{}],//原门头
            thisShopSign:[{},{},{},{},{}],//门头
            storeFile:[{},{},{},{},{}],//财务报告
            storeHead:[{},{},{},{},{}],//店铺图片
            storeLicence:[{},{},{},{},{}],//营业执照
            storeData:[{},{},{},{},{}],//相关资料
        })
    }

    //遍历数据无法重置模块
    /*renderImage1=(item,i)=>{
     return(
     <View style={styles.modelImage}>
     <ImageChange icon={JSON.stringify(item[i]) == undefined ? this.icon : item[i]}
     iconStyle={styles.modelIconStyle}
     onPress={()=>this.showMenu(i)}
     style={styles.characterStyle}/>

     <ButtonChange text={"删除"}
     onPress={()=>this.modelImageButton(i)}
     textStyle={styles.viewTextBtn}
     style={styles.viewBottomBtn}/>
     </View>
     );
     }*/

    render() {
        const {customerList,approvalList,legalLegalStatus} = this.state;
        console.log(this.state.quitViedo)
        return (
            <ViewTitle>
                <View style={styles.modelTop}>
                    <View style={styles.headView}>
                        <View style={styles.headModel}>
                            <View style={styles.headModelView1}>
                                <Text style={styles.headText}>选择客户 </Text>
                            </View>
                            <View style={styles.titleFrame_1_1}>
                                <PickDropdown  defaultValue={this.state.deCustomer}
                                               options={customerList}
                                               onSelect={(i,val)=>this.onSelectCustomer(val)} />
                            </View>
                        </View>

                        <View style={styles.headModel}>
                            <View style={styles.headModelView2}>
                                <Text style={styles.headText}>类型 </Text>
                            </View>
                            <View style={styles.titleFrame_1_1}>
                                <PickDropdown  defaultValue={this.state.deApproval}
                                               options={approvalList}
                                               onSelect={(i,val)=>this.onSelectApproval(val)} />
                            </View>
                        </View>
                    </View>

                    <View style={styles.segment}></View>

                    <View style={{display:this.state["isVisible_title_1"]}}>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}> 是否5天内退盟</Text>
                                    <Text style={styles.modelLeftTextKey}>　首批进货金额</Text>
                                    <Text style={styles.modelLeftTextKey}>应完成业绩金额</Text>
                                </View>

                                <View style={styles.modelLeft1_2}>
                                    <View style={styles.modelCheckBox}>
                                        <CheckBox rightText={"是"}
                                                  style={styles.bodyFrame3_chk_1}
                                                  rightTextStyle={styles.chkText}
                                                  isChecked={this.selectValue.isChecked1}
                                                  onClick={()=>{this.onChecked(1)}}
                                                  imageStyle={styles.chkImage}
                                                  checkBoxColor={Theme.Colors.themeColor}/>

                                        <CheckBox rightText={"否"}
                                                  style={styles.bodyFrame3_chk_2}
                                                  rightTextStyle={styles.chkText}
                                                  isChecked={this.selectValue.isChecked2}
                                                  onClick={()=>{this.onChecked(2)}}
                                                  imageStyle={styles.chkImage}
                                                  checkBoxColor={Theme.Colors.themeColor}/>
                                    </View>

                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,0)}
                                                   keyboardType="numeric"
                                                   style={styles.titleFrame_textInput}
                                                   ref={element => {
                                                       this.state.number1 = element
                                                   }}
                                        />
                                        <Text style={styles.modelText}>元</Text>
                                    </View>

                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,1)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number2 = element
                                                   }}
                                        />
                                        <Text style={styles.modelText}>元</Text>
                                    </View>
                                </View>
                            </View>

                            <View style={styles.modelRight}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>后期补货金额</Text>
                                    <Text style={styles.modelLeftTextKey}>　可退保证金</Text>
                                </View>

                                <View style={styles.modelLeft1_2}>
                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,2)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number3 = element
                                                   }}
                                        />
                                        <Text style={styles.modelText}>元</Text>
                                    </View>

                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,3)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number4 = element
                                                   }}
                                        />
                                        <Text style={styles.modelText}>元</Text>
                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={styles.label}>

                            <View style={[styles.textFrame]}>
                                <Text style={[styles.labelText]}>
                                    退盟原因
                                </Text>
                            </View>

                            <View style={[styles.textFrame]}>
                                <TextInput onChangeText = {(text)=>this.onChangeText(text,4)}
                                           multiline = {true}
                                           style={styles.textInputStyle}
                                           ref={element => {
                                               this.state.number10 = element
                                           }}
                                           underlineColorAndroid='rgba(0,0,0,0)'>
                                </TextInput>
                            </View>

                        </View>
                    </View>

                    <View style={{display:this.state["isVisible_title_2"]}}>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View style={styles.modelLeft2_1}>
                                    <Text style={styles.modelLeftTextKey}>应完成业绩金额</Text>
                                    <Text style={styles.modelLeftTextKey}>　首批进货金额</Text>
                                </View>

                                <View style={styles.modelLeft1_2}>
                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,10)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number5 = element
                                                   }}/>

                                        <Text style={styles.modelText}>元</Text>
                                    </View>

                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,11)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number6 = element
                                                   }}/>

                                        <Text style={styles.modelText}>元</Text>
                                    </View>
                                </View>
                            </View>

                            <View style={styles.modelRight}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>后期补货金额</Text>
                                    <Text style={styles.modelLeftTextKey}>　可退保证金</Text>
                                </View>

                                <View style={styles.modelLeft1_2}>
                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,12)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number7 = element
                                                   }}
                                        />
                                        <Text style={styles.modelText}>元</Text>
                                    </View>

                                    <View style={styles.modelLeft2_2_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,13)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number8 = element
                                                   }}
                                        />
                                        <Text style={styles.modelText}>元</Text>
                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={styles.label}>
                            <View style={[styles.textFrame]}>
                                <Text style={[styles.labelText]}>
                                    结业原因
                                </Text>
                            </View>

                            <View style={[styles.textFrame]}>
                                <TextInput onChangeText = {(text)=>this.onChangeText(text,14)}
                                           multiline = {true}
                                           style={styles.textInputStyle}
                                           ref={element => {
                                               this.state.number11 = element
                                           }}
                                           underlineColorAndroid='rgba(0,0,0,0)'>
                                </TextInput>
                            </View>

                        </View>
                    </View>

                    <View style={{display:this.state["isVisible_title_3"]}}>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    {/* <Text style={styles.modelLeftTextKey}>维权原因</Text>*/}
                                    <Text style={styles.modelLeftTextKey}>省区经理</Text>
                                    <Text style={styles.modelLeftTextKey}>店铺地址</Text>
                                </View>

                                <View style={styles.modelLeft3_2}>
                                    {/*  <View style={styles.modelCheckBox}>
                                     <PickDropdown  defaultValue={this.state.deCustomer}
                                     options={legalLegalStatus}
                                     onSelect={(i,val)=>this.onSelectLegalStatus(val)} />
                                     </View>*/}

                                    <View style={styles.modelLeft1_2_input_wq}>
                                        <Text style={styles.titleFrame_textInput_wq}>{this.state.region_manager}</Text>
                                    </View>

                                    <View style={styles.modelLeft1_2_input_wq}>
                                        <Text style={styles.titleFrame_textInput_wq}>{this.state.store_address}</Text>
                                    </View>
                                </View>
                            </View>

                            <View style={styles.modelRight}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>账上余额</Text>
                                    <Text style={styles.modelLeftTextKey}>客户经理</Text>
                                    <Text style={styles.modelLeftTextKey}>运营助理</Text>
                                </View>

                                <View style={styles.modelLeft1_2}>
                                    <View style={styles.modelLeft1_2_input}>
                                        <TextInput onChangeText={(text)=>this.onChangeText(text,21)}
                                                   style={styles.titleFrame_textInput}
                                                   keyboardType="numeric"
                                                   ref={element => {
                                                       this.state.number9 = element
                                                   }}/>
                                    </View>

                                    <View style={styles.modelLeft1_2_input_wq}>
                                        <Text style={styles.titleFrame_textInput}>{this.state.operate_supervisor}</Text>
                                    </View>

                                    <View style={styles.modelLeft1_2_input_wq}>
                                        <Text style={styles.titleFrame_textInput}>{this.state.operate_manager}</Text>
                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={styles.label}>
                            <View style={[styles.textFrame]}>
                                <Text style={[styles.labelText]}>
                                    维权原因
                                </Text>
                            </View>

                            <View style={[styles.textFrame]}>
                                <TextInput onChangeText = {(text)=>this.onChangeText(text,22)}
                                           multiline = {true}
                                           style={styles.textInputStyle}
                                           ref={element => {
                                               this.state.number12 = element
                                           }}
                                           underlineColorAndroid='rgba(0,0,0,0)'>
                                </TextInput>
                            </View>
                        </View>
                    </View>

                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_1"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>店铺图片</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeImages[0].uri == undefined? this.icon : this.state.storeImages[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(0)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(0)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeImages[1].uri == undefined? this.icon : this.state.storeImages[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(1)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(1)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeImages[2].uri == undefined? this.icon : this.state.storeImages[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(2)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(2)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeImages[3].uri == undefined? this.icon : this.state.storeImages[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(3)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(3)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeImages[4].uri == undefined? this.icon : this.state.storeImages[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(4)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(4)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_1"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>退盟报告</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.quitReport[0].uri == undefined? this.icon : this.state.quitReport[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(10)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(10)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.quitReport[1].uri == undefined? this.icon : this.state.quitReport[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(11)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(11)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.quitReport[2].uri == undefined? this.icon : this.state.quitReport[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(12)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(12)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.quitReport[3].uri == undefined? this.icon : this.state.quitReport[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(13)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(13)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.quitReport[4].uri == undefined? this.icon : this.state.quitReport[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(14)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(14)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>



                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_1"]}]}>
                    {/*<View style={styles.title}>*/}
                    {/*<View style={styles.titleIco}></View>*/}
                    {/*<Text style={styles.titleText}>退盟视频</Text>*/}
                    {/*</View>*/}

                    {/*<View style={styles.addVisitView_right}>*/}

                    {/*<View style={styles.addVisitView_right_3}>*/}
                    {/*<View style={styles.modelImage}>*/}
                    {/*<ImageChange icon={this.state.quitViedo[0].uri == undefined? this.icon : this.state.quitViedo[0]}*/}
                    {/*iconStyle={styles.modelIconStyle}*/}
                    {/*onPress={()=>this.showMenu(20)}*/}
                    {/*style={styles.characterStyle}/>*/}

                    {/*<ButtonChange text={"删除"}*/}
                    {/*onPress={()=>this.modelImageButton(20)}*/}
                    {/*textStyle={styles.viewTextBtn}*/}
                    {/*style={styles.viewBottomBtn}/>*/}
                    {/*</View>*/}

                    {/*<View style={styles.modelImage}>*/}
                    {/*<ImageChange icon={this.state.quitViedo[1].uri == undefined? this.icon : this.state.quitViedo[1]}*/}
                    {/*iconStyle={styles.modelIconStyle}*/}
                    {/*onPress={()=>this.showMenu(21)}*/}
                    {/*style={styles.characterStyle}/>*/}
                    {/*<ButtonChange text={"删除"}*/}
                    {/*onPress={()=>this.modelImageButton(21)}*/}
                    {/*textStyle={styles.viewTextBtn}*/}
                    {/*style={styles.viewBottomBtn}/>*/}
                    {/*</View>*/}


                    {/*</View>*/}
                    {/*</View>*/}

                    <View
                        style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={'退盟视频'}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(20)}/>
                        <VideoList dataList={this.state.quitViedo}
                                   text={"删除"}
                                   onPressText={this.delVideo}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>


                    </View>
                </View>





                <View style={[styles.detailView,{display:this.state["isVisible_2"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>店铺分析文档</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeSrs[0].uri == undefined? this.icon : this.state.storeSrs[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(40)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(40)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeSrs[1].uri == undefined? this.icon : this.state.storeSrs[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(41)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(41)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeSrs[2].uri == undefined? this.icon : this.state.storeSrs[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(42)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(42)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeSrs[3].uri == undefined? this.icon : this.state.storeSrs[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(43)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(43)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeSrs[4].uri == undefined? this.icon : this.state.storeSrs[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(44)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(44)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_2"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>店内图片</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeDetailImage[0].uri == undefined? this.icon : this.state.storeDetailImage[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(50)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(50)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeDetailImage[1].uri == undefined? this.icon : this.state.storeDetailImage[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(51)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(51)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeDetailImage[2].uri == undefined? this.icon : this.state.storeDetailImage[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(52)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(52)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeDetailImage[3].uri == undefined? this.icon : this.state.storeDetailImage[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(53)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(53)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeDetailImage[4].uri == undefined? this.icon : this.state.storeDetailImage[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(54)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(54)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_2"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>原门头照片</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.oldShopSign[0].uri == undefined? this.icon : this.state.oldShopSign[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(60)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(60)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.oldShopSign[1].uri == undefined? this.icon : this.state.oldShopSign[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(61)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(61)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.oldShopSign[2].uri == undefined? this.icon : this.state.oldShopSign[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(62)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(62)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.oldShopSign[3].uri == undefined? this.icon : this.state.oldShopSign[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(63)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(63)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.oldShopSign[4].uri == undefined? this.icon : this.state.oldShopSign[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(64)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(64)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_2"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>门头照片</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.thisShopSign[0].uri == undefined? this.icon : this.state.thisShopSign[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(70)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(70)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.thisShopSign[1].uri == undefined? this.icon : this.state.thisShopSign[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(71)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(71)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.thisShopSign[2].uri == undefined? this.icon : this.state.thisShopSign[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(72)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(72)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.thisShopSign[3].uri == undefined? this.icon : this.state.thisShopSign[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(73)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(73)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.thisShopSign[4].uri == undefined? this.icon : this.state.thisShopSign[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(74)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(74)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_3"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>相关资料</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeData[0].uri == undefined? this.icon : this.state.storeData[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(80)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(80)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeData[1].uri == undefined? this.icon : this.state.storeData[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(81)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(81)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeData[2].uri == undefined? this.icon : this.state.storeData[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(82)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(82)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeData[3].uri == undefined? this.icon : this.state.storeData[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(83)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(83)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeData[4].uri == undefined? this.icon : this.state.storeData[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(84)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(84)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_3"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>财务报告</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeFile[0].uri == undefined? this.icon : this.state.storeFile[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(90)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(90)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeFile[1].uri == undefined? this.icon : this.state.storeFile[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(91)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(91)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeFile[2].uri == undefined? this.icon : this.state.storeFile[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(92)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(92)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeFile[3].uri == undefined? this.icon : this.state.storeFile[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(93)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(93)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeFile[4].uri == undefined? this.icon : this.state.storeFile[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(94)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(94)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_3"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>店铺图片</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>
                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeHead[0].uri == undefined? this.icon : this.state.storeHead[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(100)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(100)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeHead[1].uri == undefined? this.icon : this.state.storeHead[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(81)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(101)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeHead[2].uri == undefined? this.icon : this.state.storeHead[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(102)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(102)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeHead[3].uri == undefined? this.icon : this.state.storeHead[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(103)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(103)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeHead[4].uri == undefined? this.icon : this.state.storeHead[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(104)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(104)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={[styles.detailView,{display:this.state["isVisible_3"]}]}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>营业执照</Text>
                    </View>

                    <View style={styles.addVisitView_right}>

                        <View style={styles.addVisitView_right_3}>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeLicence[0].uri == undefined? this.icon : this.state.storeLicence[0]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(110)}
                                             style={styles.characterStyle}/>

                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(110)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeLicence[1].uri == undefined? this.icon : this.state.storeLicence[1]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(111)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(111)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeLicence[2].uri == undefined? this.icon : this.state.storeLicence[2]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(112)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(112)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeLicence[3].uri == undefined? this.icon : this.state.storeLicence[3]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(113)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(113)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                            <View style={styles.modelImage}>
                                <ImageChange icon={this.state.storeLicence[4].uri == undefined? this.icon : this.state.storeLicence[4]}
                                             iconStyle={styles.modelIconStyle}
                                             onPress={()=>this.showMenu(114)}
                                             style={styles.characterStyle}/>
                                <ButtonChange text={"删除"}
                                              onPress={()=>this.modelImageButton(114)}
                                              textStyle={styles.viewTextBtn}
                                              style={styles.viewBottomBtn}/>
                            </View>

                        </View>
                    </View>
                </View>

                <View style={styles.lastView}>
                    <ButtonChange text={"提交"} onPress={()=>this.submitData()}
                                  frameStyle={styles.submitButton}
                    />
                </View>

                <MenuBottom btnList={this.btnList}
                            isVisibleClose={false}/>
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    textInputStyle:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        width:'0.9w',
        height:200,
        borderRadius:Theme.Border.borderRadius,
        fontSize:Theme.Font.fontSize_1,
        padding:5,
    },
    textFrame:{
        margin:10,
    },
    lastView:{
        paddingTop:20,
        alignItems:'center',
        justifyContent:'center',
        height:100,
    },
    submitButton:{
        paddingBottom:20,
        width:100,
        height:Theme.Height.height1,
    },
    modelTop:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    headView:{
        flexDirection:'row',
        height:50,
        padding:20,
    },
    headModel:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'flex-start',
        width:300,
    },
    headText:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.fontcolor,
    },
    titleFrame_1_1:{
        alignItems:'center',
        justifyContent:'flex-start',
    },
    segment:{
        width:730,
        borderTopWidth:1,
        left:20,
        //alignItems: 'center',
        borderTopColor:Theme.Colors.minorColor,
    },
    modelLeftTextKey:{
        paddingTop:12,
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    model:{
        flexDirection: 'row',
        paddingLeft:20,
        paddingRight:20,
    },
    modelLeft:{
        flex:1,
        flexDirection: 'row',
        //width:450,
        //backgroundColor:Theme.Colors.backgroundColorBtn,
    },
    modelLeft2_1:{
        paddingTop:10,
    },
    modelRight:{
        flex:1,
        flexDirection: 'row',
        //width:280,
        alignItems:'center',
        justifyContent:'flex-end',
    },
    modelLeft1_2:{
        paddingTop:5,
        paddingLeft:25,
    },
    modelLeft3_2:{
        paddingBottom:5,
        paddingLeft:25,
    },
    titleFrame_textInput_wq:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize_1,
            width:220 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize_1,
            width:220 + Theme.Height.height1,
            height:33,
            padding:0,
            paddingLeft:8,
            paddingBottom:10,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize_1,
            width:100 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize_1,
            width:100 + Theme.Height.height1,
            height:33,
            padding:0,
            paddingLeft:8,
            paddingBottom:10,
            marginTop:12,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    modelCheckBox:{
        marginTop:10,
        flexDirection: 'row',
    },
    bodyFrame3_chk_1:{
        flex:1,
        alignItems:'flex-start',
        justifyContent:'center',
    },
    bodyFrame3_chk_2:{
        flex:1,
        alignItems:'flex-end',
        justifyContent:'center',
    },
    chkText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.themeColor,
    },
    chkImage:{
        width:Theme.Font.fontSize1,
        height:Theme.Font.fontSize1 + "dw",
    },
    modelText:{
        paddingTop:2,
        paddingLeft:5,
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.themeColor,
    },

    modelLeft1_2_input_wq:{
        flexDirection: 'row',
        paddingTop:8,
    },

    modelLeft1_2_input:{
        flexDirection: 'row',
    },
    modelLeft2_2_2_input:{
        flexDirection: 'row',
        paddingBottom:5,
    },
    label:{
        paddingLeft:20,
    },
    labelText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    addVisitView:{
        height:700,
        width:700,
    },
    characterStyle:{
        width:140,
        height:185,
    },
    modelIconStyle:{
        width:140,
        height:180,
        backgroundColor:"#FEF1EC",
    },
    addVisitView_right:{
        left:10,
        width:510,
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
    },
    addVisitView_right_3:{
        flexDirection:'row',
        zIndex:-99,
        height:250,
        width:750,
    },
    imageListStyle:{
        height:250,
        width:200,
        backgroundColor:Theme.Colors.themeColor,
    },
    imageFramStyle:{
        height:200,
        width:150,
        padding:10,
    },
    viewBottomBtn:{
        padding:2,
        width:80,
        height:30,
    },
    viewTextBtn:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    modelImage:{
        flex:1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    headModelView1:{
        width:100,
    },
    headModelView2:{
        width:50,
    },
    detailView:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{

        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
});