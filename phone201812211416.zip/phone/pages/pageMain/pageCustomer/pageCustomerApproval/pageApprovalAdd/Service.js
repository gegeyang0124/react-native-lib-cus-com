import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import {ServiceCommon} from "../../../pageTask/pageGuides/ServiceCommon";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    /**
     * 根据门店id获取资料
     */
    static getDataDetailByid(val){
        return Http.get(HttpUrls.urlSets.urlCustomerDetail,{id:val},false)
            .then(retJson => {
                return retJson.data;
            });
    }

    /**
     * 获取客户列表
     */
    static getCustomers() {
        var customerList = [{
            name: '请选择',
            id: ''
        }];

        return Http.get(HttpUrls.urlSets.urlCustomersGet)
            .then(retJson => {
                if (retJson.retData.length > 0) {
                    retJson.retData.forEach((item) => {
                        customerList.push({
                            name: item.storeName,
                            id: item.storeId,
                        });
                    });
                }
                return customerList;
            });
    }

    static saveData(data){

        let imageSignInList = [];

        if(data.auditing_pic != undefined && data.auditing_pic.length > 0){
            data.auditing_pic.forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:21,
                    id:"21"+i1,
                });
            });
            data.auditing_pic = [];
        }


        if(data.auditing_file != undefined && data.auditing_file.length > 0){
            data.auditing_file.forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:22,
                    id:"22"+i1,
                });
            });
            data.auditing_file = [];
        }


        if(data.auditing_video != undefined && data.auditing_video.length > 0){
            data.auditing_video.forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:23,
                    id:"23"+i1,
                });
            });
            data.auditing_video = [];
        }

        if(data.auditing_licence != undefined && data.auditing_licence.length > 0){
            data.auditing_licence.forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:31,
                    id:"31"+i1,
                });
            });
            data.auditing_licence = [];
        }

        if(data.auditing_oldhead != undefined && data.auditing_oldhead.length > 0){
            data.auditing_oldhead.forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:32,
                    id:"32"+i1,
                });
            });
            data.auditing_oldhead = [];
        }

        if(data.auditing_head != undefined && data.auditing_head.length > 0){
            data.auditing_head.forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:33,
                    id:"33"+i1,
                });
            });
            data.auditing_head = [];
        }


        //无法获取数据，重新赋值;
        var record_id = data.auditing_record_id;
        var remark = data.auditing_remark;
        var first = data.auditing_first;
        var after = data.auditing_after;
        var pref = data.auditing_pref;
        var deposit = data.auditing_deposit;
        var type = data.itemType;
        var account_amount = data.auditing_account_amount;

        return new Promise((resolve, reject) => {

            Http.upLoadFileToService(imageSignInList,0).then(retJson=>{

                    retJson.forEach((v,i,a)=>{
                       if(v.type == 21){
                           data.auditing_pic.push(v.servicePath);
                       }else if(v.type == 22){
                           data.auditing_file.push(v.servicePath);
                       }else if(v.type == 23) {
                           data.auditing_video.push(v.servicePath);
                       }else if(v.type == 31){
                           data.auditing_licence.push(v.servicePath);
                       }else if(v.type == 32){
                           data.auditing_oldhead.push(v.servicePath);
                       }else if(v.type == 33){
                           data.auditing_head.push(v.servicePath);
                       }
                    });

                    Http.post(HttpUrls.urlSets.urlCustomerDataSave + type, {
                        auditing_remark:remark,
                        auditing_record_id:record_id,
                        auditing_first:first,
                        auditing_after:after,
                        auditing_pref:pref,
                        auditing_deposit:deposit,
                        auditing_account_amount:account_amount,
                        auditing_pic:data.auditing_pic,
                        auditing_file:data.auditing_file,
                        auditing_video:data.auditing_video,
                        auditing_licence:data.auditing_licence,
                        auditing_oldhead:data.auditing_oldhead,
                        auditing_head:data.auditing_head,

                    }).then((retJson)=>{
                        console.log(retJson)
                        console.log("添加审核流程成功-》"+JSON.stringify(retJson));
                        resolve(retJson);
                    }).catch(err=>{

                            console.log(err)
                        resolve(err);


                    })

                });
        });

    }

}