import React, {Component} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    TextInput,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
    Image,
    ItemRowGuideTripApply,
    FlatListView,
    ImageList,
    VideoList,
    MenuBottom,
    ButtonChange,
    TextInputLabel,
} from "com";

import {
    CheckBox
} from "comThird";

import { Service} from "./Service";

/**
 * 流程详情
 * **/
type Props = {};
export default class PageApprovalDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.execFirst = true;

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            isVisible_1: "none",
            isVisible_2: "flex",
            isVisible_3: "flex",
            isVisible_4: "flex",
            type:'',
            videoList : [],
            dataList:{},
            approvalList:[],
            fileList:[],
            isQuit:false,
        };

        this.selectValue ={
            isChecked1:false,//勾选
            isChecked2:false,//勾选
            type:'',
            auditing_id:'',
            auditing_status:'',
            opinion:'',
        }
    }

    componentWillEnter(params,action,page){
        if(params != null){
            this.selectValue.auditing_id = params.auditing_id;
            this.selectValue.type = params.type;
            this.getData(params.auditing_id,params.type);
        }
    }

    getData(auditing_id,type){
        type == undefined ? this.selectValue.type : type;
        auditing_id == undefined ? this.selectValue.auditing_id : auditing_id;
        if(type != undefined && type != ''){
            this.state.type = type;
            if(type == 2){//退盟
                this.getExitDetail(auditing_id);
            }else if(type == 3){ //结业
                this.getOverDetail(auditing_id);
            }else if(type == 6){ //维权
                this.getRightsDetail(auditing_id);
            }
        }

        //审核回复
        Service.getApprovalDetail(auditing_id).then(retJson => {
            this.setState({
                approvalList:retJson,
            })
        });

        if(this.state.fileList.length > 0){
            this.state.fileList.forEach((v,i,a)=>{
                if(v.type == "video"){
                    if(v.file.length > 0){
                        v.file.forEach((item,i)=>{
                            this.state.videoList.push({
                                uri:item
                            });
                        })
                    }
                }
            });
        }
    }

    //退盟详情
    getExitDetail(auditing_id){
        Service.getDataDetail(auditing_id).then(retJson => {

            this.state.authStatus = retJson.auditing_auth_status;

            let auditingPicret = {name:'店铺图片',type:"image",file:retJson.auditing_pic};
            let auditingFile = {name:'相关文档',type:"image",file:retJson.auditing_file};
            let auditingVideo = {name:'退盟视频',type:"video",file:retJson.auditing_video}

            this.setState({
                dataList: {
                    authStatus:retJson.auditing_auth_status,
                    contract_sn:retJson.contract_sn,
                    customerName:retJson.name,
                    counselor:retJson.investment_manager,
                    storeArea:retJson.area+"m²",
                    firstOneStock:retJson.auditing_first,
                    lastOneStock:retJson.auditing_after,
                    signTime:retJson.sign_time,
                    quitJoin:retJson.auditing_remark,
                    level:retJson.shop_rank,
                    proposer:retJson.auditing_user_name == undefined ? "-　" : retJson.auditing_user_name,
                    isStore:retJson.has_store == 1 ? "是" : "无",
                    aimPerformance:retJson.auditing_pref,
                    margin:retJson.auditing_deposit,
                },
                fileList:[auditingPicret,auditingFile,auditingVideo]
            });
        });
    }

    //结业详情
    getOverDetail(auditing_id){
        Service.getDataDetail(auditing_id).then(retJson => {
            //console.log(JSON.stringify(retJson));
            this.state.authStatus = retJson.auditing_auth_status;

            //处理图片
            let auditingPicret = {name:'店铺图片',type:"image",file:retJson.auditing_pic != null ? retJson.auditing_pic : ""};
            let auditingFile = {name:'相关文档',type:"image",file:retJson.auditing_file != null ? retJson.auditing_file :""};
            let auditingLicence = {name:'营业执照注销证明（或新营业执照）',type:"image",file:retJson.auditing_licence != null ? retJson.auditing_licence :""};
            let auditingHead = {name :'门头照',type:'image',file:retJson.auditing_head != null ? retJson.auditing_head : ""};
            let auditingOldHead = {name :'原门头照',type:'image',file:retJson.auditing_oldhead != null ? retJson.auditing_oldhead : ""};

            this.setState({
                dataList: {
                    contract_sn:retJson.contract_sn,
                    customerName:retJson.name,
                    counselor:retJson.investment_manager,
                    storeArea:retJson.area+"m²",
                    firstOneStock:retJson.auditing_first +" /元",
                    lastOneStock:retJson.auditing_after +" /元",
                    signTime:retJson.sign_time,
                    quitJoin:retJson.auditing_remark,
                    level:retJson.shop_rank,
                    proposer:retJson.auditing_user_name == undefined ? "-　" : retJson.auditing_user_name,
                    isStore:retJson.has_store == 1 ? "是" : "无",
                    aimPerformance:retJson.auditing_pref +" /元",
                    margin:retJson.auditing_deposit +" /元",
                    regionManager:retJson.region_manager,
                    storeAddress:retJson.store_address,
                },
                fileList:[auditingLicence,auditingFile,auditingPicret,auditingHead,auditingOldHead]
            });
        });
    }

    //维权详情
    getRightsDetail(auditing_id){
        Service.getDataDetail(auditing_id).then(retJson => {

            this.state.authStatus = retJson.auditing_auth_status;

            let auditingPic = {name:'相关文档',type:"image",file:retJson.auditing_pic};
            let auditingFile = {name:'财务报告',type:"image",file:retJson.auditing_file};
            let auditingHead = {name:'店铺图片',type:"image",file:retJson.auditing_head};
            let auditingLicence = {name:'营业执照',type:"image",file:retJson.auditing_licence};

            this.setState({
                dataList: {
                    contract_sn:retJson.contract_sn,
                    customerName:retJson.name,
                    counselor:retJson.investment_manager,
                    storeArea:retJson.area+"m²",
                    firstOneStock:retJson.auditing_first,
                    lastOneStock:retJson.auditing_after,
                    signTime:retJson.sign_time,
                    quitJoin:retJson.auditing_remark,
                    level:retJson.shop_rank,
                    proposer:retJson.auditing_user_name == undefined ? "-　" : retJson.auditing_user_name,
                    isStore:retJson.has_store == 1 ? "是" : "无",
                    aimPerformance:retJson.auditing_pref,
                    margin:retJson.auditing_deposit,
                },
                fileList:[auditingPic,auditingFile,auditingHead,auditingLicence]
            });
        });
    }

    //单选框
    onChecked = (item)=>{
        let isVisible = '';
        if(item == 1){
            if(this.selectValue.isChecked1){
                this.selectValue.isChecked1 = false;
                this.selectValue.isChecked2 = false;
            }else{
                this.selectValue.isChecked1 = true;
                this.selectValue.isChecked2 = false;
            }
            isVisible = 'none';
        }else{
            if(this.selectValue.isChecked2){
                this.selectValue.isChecked2 = false;
                this.selectValue.isChecked1 = false;
            }else{
                this.selectValue.isChecked2 = true;
                this.selectValue.isChecked1 = false;
            }
            isVisible = 'flex';
        }

        this.selectValue.auditing_status = item;

        this.setState({
            isQuit:item,
            isVisible_3:isVisible,
        });
    };

    onChangeText = (item)=>{
        this.selectValue.opinion = item;
    }

    onSelect=(item)=>{
        if(item == 1){
            this.setState({
                isVisible_1:"none",
                isVisible_2:"flex",
                isVisible_4:"flex",
            });
        }else{
            this.setState({
                isVisible_1:"flex",
                isVisible_2:"none",
                isVisible_4:"none",
            });
        }
    };

    //保存数据
    onSave=()=>{
        if(this.selectValue.auditing_status == ''){
            Service.dataSave(this.selectValue).then(retJson => {
                if(retJson == 0){
                    Tools.toast("添加成功");
                    Service.getApprovalDetail(this.selectValue.auditing_id).then(retJson => {
                        this.setState({
                            approvalList:retJson,
                        })
                    });
                }else{
                    Tools.toast("网络异常");
                }
            });
        }else {
            Service.updateDataStatus(this.selectValue).then(retJson => {
                if (retJson == 0) {
                    Tools.toast("审核成功");
                    Service.getApprovalDetail(this.selectValue.auditing_id).then(retJson => {
                        this.setState({
                            approvalList:retJson,
                        })
                    });
                }else{
                    Tools.toast("网络异常");
                }
            });
        }
    };

    renderFile = (item,i)=>{
        console.log("3->"+item.file)
        // console.log(item.file)
        // console.log(JSON.stringify("item->"+JSON.stringify(item)));
        if(item != undefined && item != null && item != ""){
            return(
                <View style={[styles.model_2,{display:this.state.isVisible_1}]} key={i}>
                    <View style={styles.title_2}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>{item.name}</Text>
                    </View>
                    <View style={styles.versionTable}>
                        {item.type == "video" && item.file.length > 0 ?
                            <VideoList dataList={item.file}
                                       iconStyle={styles.imageStyle}/>
                            : item.file != "" ?
                            <ImageList dataList={item.file}
                                       rowCount={5}
                                       imageFrameStyle={{height:160}}
                                       isShowText={false}
                                       iconStyle={styles.imageStyle}/>
                                : null
                        }
                    </View>

                </View>
            )
        }
    };

    renderItem = (item,i)=>{

        if(item != null && item != undefined){
            return(
                <View style={[styles.renderModel,{display:this.state.isVisible_2}]}>
                    <View style={styles.model}>
                        <View style={styles.modelLeft}>
                            <Image source={{uri:item.replyUserPhoto}} style={{width:60,height:60}}/>
                            <View style={{paddingLeft:5}}>
                                <Text style={styles.modelLeftTextKey}>姓名：</Text>
                                <Text style={styles.modelLeftTextKey}>部门：</Text>
                                <Text style={styles.modelLeftTextKey}>审批意见：</Text>
                            </View>

                            <View >
                                <Text style={styles.modelLeftTextValue}>{item.replyUserName}</Text>
                                <Text style={styles.modelLeftTextValue}>{item.replyUserDep}</Text>
                                <Text style={styles.modelLeftTextValue}>{item.replyContent}</Text>
                            </View>
                        </View>

                        {
                            item.approveStatus != null ?
                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelTextKey}>审批结果：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelTextKey}>{item.approveStatus}</Text>
                                    </View>
                                </View>
                                :
                                null
                        }

                    </View>

                    <View style={styles.segment}></View>
                </View>
            );
        }
    };

    render() {

        return (
            <ViewTitle viewBottom={
                <View style={[styles.subView,{display:this.state.isVisible_4}]}>
                    <View style={{height:10}}></View>
                    <View style={[styles.submitView,{display:this.state.isVisible_3}]}>
                        <Text style={styles.chkText}>审核意见　</Text>
                        <View style={styles.inputView}>
                            <TextInput onChangeText={this.onChangeText}
                                       multiline={true}
                                       clearButtonMode={"always"}
                                       underlineColorAndroid={"#FDEFE3"}
                                       style={styles.modelLeftTextValue}/>
                        </View>
                    </View>

                    <View style={styles.modelCheckBox}>
                        <View style={[styles.modelCheckBox,{display:this.state.authStatus == 0 ? "none" : "flex"}]}>
                            <Text style={styles.chkText}>审核状态　</Text>
                            <CheckBox rightText={"通过"}
                                      style={styles.bodyFrame3_chk_1}
                                      rightTextStyle={styles.chkText}
                                      isChecked={this.selectValue.isChecked1}
                                      onClick={()=>{this.onChecked(1)}}
                                      imageStyle={styles.chkImage}
                                      checkBoxColor={Theme.Colors.themeColor}/>

                            <CheckBox rightText={"不通过"}
                                      style={styles.bodyFrame3_chk_2}
                                      rightTextStyle={styles.chkText}
                                      isChecked={this.selectValue.isChecked2}
                                      onClick={()=>{this.onChecked(2)}}
                                      imageStyle={styles.chkImage}
                                      checkBoxColor={Theme.Colors.themeColor}/>
                        </View>

                        <View style={this.state.authStatus == 0 ? styles.modelCheckBoxView2 : styles.modelCheckBoxView}>
                            <ButtonChange text={"提交"}
                                          onPress={this.onSave}
                                          textStyle={styles.buttonHead_text}
                                          style={styles.titleFrame_btn_detail}/>
                        </View>
                    </View>
                </View>
            }>
                <View style={styles.versionTable}>
                    <View style={styles.baseModel}>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    <Text style={styles.modelTextKey}>合同编号：</Text>
                                    <Text style={styles.modelLeftTextKey}>客户名称：</Text>
                                    <Text style={styles.modelLeftTextKey}>投资顾问：</Text>
                                    {
                                        this.state.type !=6 ?
                                            <View>
                                                <Text style={styles.modelLeftTextKey}>店铺面积：</Text>
                                                <Text style={styles.modelLeftTextKey}>首批进货：</Text>
                                                <Text style={styles.modelLeftTextKey}>后期补货：</Text>
                                                <Text style={styles.modelLeftTextKey}>签约时间：</Text>
                                            </View>
                                            :
                                            <View>
                                                <Text style={styles.modelLeftTextKey}>省区经理：</Text>
                                                <Text style={styles.modelLeftTextKey}>店铺地址：</Text>
                                            </View>
                                    }

                                    {
                                        this.state.type == 2 ?
                                            <Text style={styles.modelLeftTextKey}>退盟原因：</Text>
                                            : null
                                    }

                                </View>

                                <View>
                                    <Text style={styles.modelTextKey}>{this.state.dataList.contract_sn}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.dataList.customerName}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.dataList.counselor}</Text>
                                    {
                                        this.state.type != 6 ?
                                            <View>
                                                <Text style={styles.modelLeftTextValue}>{this.state.dataList.storeArea}</Text>
                                                <Text style={styles.modelLeftTextValue}>{this.state.dataList.firstOneStock}</Text>
                                                <Text style={styles.modelLeftTextValue}>{this.state.dataList.lastOneStock}</Text>
                                                <Text style={styles.modelLeftTextValue}>{this.state.dataList.signTime}</Text>
                                            </View>
                                            :
                                            <View>
                                                <Text style={styles.modelLeftTextValue}>{this.state.dataList.regionManager}</Text>
                                                <Text style={styles.modelLeftTextValue}>{this.state.dataList.storeAddress}</Text>
                                            </View>
                                    }
                                    {
                                        this.state.type == 2 ?
                                            <Text style={styles.modelLeftTextValue}>{this.state.dataList.quitJoin}</Text>
                                            : null
                                    }
                                </View>

                            </View>

                            <View style={styles.modelRight}>
                                <View >
                                    <Text style={styles.modelLeftTextKey}>　加盟级别：</Text>
                                    <Text style={styles.modelLeftTextKey}>流程申请人：</Text>
                                    <Text style={styles.modelLeftTextKey}>　是否有店：</Text>
                                    {
                                        this.state.type != 6 ?
                                            <View>
                                                <Text style={styles.modelLeftTextKey}>应完成业绩：</Text>
                                                <Text style={styles.modelLeftTextKey}>可退保证金：</Text>
                                            </View>
                                            :
                                            null
                                    }
                                </View>
                                <View >
                                    <Text style={styles.modelLeftTextValue}>{this.state.dataList.level}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.dataList.proposer}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.dataList.isStore}</Text>
                                    {
                                        this.state.type != 6 ?
                                            <View>
                                                <Text
                                                    style={styles.modelLeftTextValue}>{this.state.dataList.aimPerformance}</Text>
                                                <Text
                                                    style={styles.modelLeftTextValue}>{this.state.dataList.margin}</Text>
                                            </View>
                                            :
                                            null
                                    }
                                </View>

                            </View>
                        </View>

                    </View>
                </View>

                <View style={styles.division}>
                    <ButtonChange text={"审批进度"}
                                  onPress={()=>this.onSelect(1)}
                                  textStyle={[styles.divisionText,{color:this.state.isVisible_1 == "none" ? Theme.Colors.themeColor : Theme.Colors.minorColor}]}
                                  style={[styles.btn,{borderBottomWidth:2,
                                      borderBottomColor:this.state.isVisible_1 == "none" ? Theme.Colors.themeColor : Theme.Colors.foregroundColor}]}
                                  frameStyle = {styles.btn}/>

                    <ButtonChange text={"相关资料"}
                                  onPress={()=>this.onSelect(2)}
                                  textStyle={[styles.divisionText,{color:this.state.isVisible_2 == "none" ? Theme.Colors.themeColor : Theme.Colors.minorColor}]}
                                  style={[styles.btn,{borderBottomWidth:2,
                                      borderBottomColor:this.state.isVisible_2 == "none" ? Theme.Colors.themeColor : Theme.Colors.foregroundColor}]}
                                  frameStyle = {styles.btn}/>
                </View>

                {
                    this.state.approvalList.map(this.renderItem)
                }

                {
                    this.state.fileList.map(this.renderFile)
                }



            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    subView:{
        height:200,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    modelCheckBoxView:{
        width:450,
        alignItems:'flex-end',
        justifyContent:'center',
    },
    modelCheckBoxView2:{
        width:750,
        alignItems:'flex-end',
        justifyContent:'center',
    },
    /*titleFrame_btn_detail:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },*/
    buttonHead_text:{
        fontSize:Theme.Font.fontSize_1,
    },
    submitView:{
        height:100,
        paddingLeft:10,
        flexDirection: 'row',
    },
    inputView:{
        borderWidth:1,
        borderColor:Theme.Colors.fontcolor_1,
        width:640,
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:0,
    },
    labelStyle:{
        height:100,
    },
    labelText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    modelCheckBox:{
        paddingTop:5,
        width:280,
        margin:10,
        flexDirection: 'row',
    },
    chkImage:{
        width:Theme.Font.fontSize1,
        height:Theme.Font.fontSize1 + "dw",
    },
    chkText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    bodyFrame3_chk_1:{
        flex:1,
        alignItems:'flex-start',
        justifyContent:'center',
    },
    bodyFrame3_chk_2:{
        flex:1,
        alignItems:'flex-end',
        justifyContent:'center',
    },
    submitButtonStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    btn:{
        flex:1,
        backgroundColor:Theme.constructor.foregroundColor,
    },
    division:{
        flexDirection: 'row',
        marginTop:15,
        height:80,
        backgroundColor:Theme.Colors.foregroundColor,
        alignItems: 'center',
        justifyContent: 'center',
    },
    divisionText:{
        fontSize:Theme.Font.fontSize1,
        //color:Theme.Colors.minorColor,
    },
    segment:{
        //paddingTop:20,
        width:730,
        borderTopWidth:1,
        alignItems: 'flex-start',
        borderTopColor:Theme.Colors.minorColor,
    },
    modelTextKey:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.themeColor,
    },
    oneText:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    titleFrame_btn_detail:{
        width:90,
        height:30,
        padding:0,
    },
    versionRow:{
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        flexDirection: 'row',
        //alignItems: 'center',
        //justifyContent: 'center',
        //borderBottomColor:"#FEE0CA",
        backgroundColor:"#FEE0CA",
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
    },
    versionRowText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    versionRowIcon:{
        width:20,
        height:20,
        resizeMode:"contain",
    },
    baseModel:{
        padding:20,
    },
    renderModel:{
        backgroundColor:Theme.Colors.foregroundColor,
        padding:20,
    },
    model:{
        flexDirection: 'row',
        paddingBottom:20,
    },
    modelLeft:{
        flexDirection: 'row',
        width:450,
        //backgroundColor:Theme.Colors.backgroundColorBtn,
    },
    modelRight:{
        marginLeft:10,
        flexDirection: 'row',
        width:350,
        //backgroundColor:Theme.Colors.progressColor,
    },
    modelLeftTextKey:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
        paddingBottom:5,
    },
    modelLeftTextValue:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.fontcolor,
        paddingBottom:3,
    },
    model_2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    model2_view:{
        justifyContent:'center',
        alignItems: 'center',
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    title_2:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.fontcolor,
        marginLeft:20,
    },
    versionTable:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:0,
    },
    imageStyle:{
        backgroundColor:'#FDF0EB',
        width:140,
        height:'150dw',
    },
});

