import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    /**
     * 获取基本资料
     */
    static getDataDetail(auditing_id){
        return Http.get(HttpUrls.urlSets.urlCustomerApprovalDetail+auditing_id)
            .then(retJson => {
                return retJson.data;
            });
    }

    /**
     * 获取审核意见
     */
    static getApprovalDetail(auditing_id){
        return Http.get(HttpUrls.urlSets.urlCustomerApprovalOpinion+auditing_id)
            .then(retJson => {
                return retJson.data;
            });
    }

    /**
     * 提交审核数据
     */
    static dataSave(val){
        return Http.post(HttpUrls.urlSets.urlCustomerApprovalDataSave+val.auditing_id,
            {"message":val.opinion},true).then(retJson => {
            return retJson.code;
        });
    }

    /**
     * 更新审核状态
     */
    static updateDataStatus(val){
        return Http.post(HttpUrls.urlSets.urlCustomerApprovalDataUpdate+val.auditing_id,
            {"auditing_status":val.auditing_status,"message":val.opinion}).then(retJson => {
            return retJson.code;
        });
    }
}