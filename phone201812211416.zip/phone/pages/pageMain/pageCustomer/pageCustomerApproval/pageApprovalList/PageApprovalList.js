/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
    ScrollViewRowList,
    TextInputLabel,
    ButtonTime,
} from "com";
import {Service} from "./Service";

/**
 * 客户流程审批列表
 */
type Props = {};
export default class PageApprovalList extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.statusList = [{
            name:'状态',
        }];
        this.state = {
            dataList:[],//任务列表
            clearDrop:false,//是否清空下拉框
            approvalList:[
                {name:'选择类型',id:''},
                {name:'客户退盟',id:2},
                {name:'客户结业',id:3},
                {name:'客户维权',id:6}
            ],
            approvalDefault:'审批类型',
            departmentOneDisable:false,//是否可选择，true：不可以选择，false:可以选择
            approvalStatus:[
                {name:'选择状态',id:''},
                {name:'待审核',id:0},
                {name:'审批通过',id:1},
                {name:'审批退回',id:2},
               /* {name:'重新申请',id:3}*/
            ],
            departmentTowDefault:'审批状态',//默认显示值
            departmentTwoDisable:false,//二下拉框是否可选择，true：不可以选择，false:可以选择
            pickedDate:Tools.timeFormatConvert(Tools.timeFormatConvert(),"YYYY-MM"),
        };

        this.selectValue = {
            auditing_status:'',//状态
            auditing_type:'',//类型
            sign_time:'',//开始时间
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        };

        this.setParams({

            headerLeft: true,
            headerRight:require('images/add.png'),
            headerRightHandle:()=>{
                this.goPage("PageApprovalAdd");
            },
        });
    }

    onSelectDrop(val,i,type){
        if(type == 1){
            this.selectValue.auditing_type = val.id;
        }else if(type == 2){
            this.selectValue.auditing_status = val.id;
        }
    }

    onSearch = ()=>{
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });
        this.getData(this.selectValue);
    };

    onItemPress(item){
        this.goPage("PageApprovalDetail",{
            auditing_id:item.auditing_id,type:item.auditing_type,
        });
    }

    onItemPressBtn(item,statusObj){
        if(statusObj.code == 0){
            //alert("进入审核页面");
        }
        else{
            this.onItemPress(item);
        }
    }


    /**
     * 获取反馈列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {

        if(!this.selectValue.execFirst){
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        Service.getDataList(selectValue,this.selectValue.execFirst).then(retJson=>{
            if(!this.selectValue.execFirst && !retJson.has){
                Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
            }else{
                this.selectValue.execFirst = false;
                this.setState({
                    dataList:retJson.content
                });
                Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
            }
        })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });
    }

    componentDidMount() {
        this.getData();
    }

    renderItemView(item,i){
        /**
         * 21-24 21待审批 22 审批通过 23 审批退回 24 重新申请
         */
        item.status = item.auditing_status == 0 ? '21' :
            item.auditing_status == 1 ? '22' :
                item.auditing_status == 2 ? '23' : '';

        if(item.status == '21' && item.auditing_auth_status == 1){
            //待审核
            item.status == '21';
        }else if(item.status == '21'){
            //其他部门审核
            item.status = '26';
        }


        let statusObj = Tools.statusConvert(item.status);
        let btnList = [];
        statusObj.btnList.forEach((v,i,a)=>{
            btnList.push({
                onPress:()=>this.onItemPressBtn(item,v),
                text:v.text,
                backgroundColor:v.backgroundColor == undefined
                    ? Theme.Colors.backgroundColorBtn1
                    : v.backgroundColor
            });
        });

        return(
            <ItemRowTripTask  key={i}
                              disableRightSwipe={false}
                              isItemRowIconLeft={true}
                              btnList={btnList}
                              text1_1={item.name + item.auditing_type_name + "流程"}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={statusObj.text}
                              text2_1={"类型:" + item.auditing_type_name
                              + "       客户名称:" + item.name
                              + "       加盟级别:" + item.shop_rank
                              + "       投资顾问:" + item.investment_manager}
                              text2_1_Style={styles.text2_1_Style}
                              text3_1={"发起时间:" + item.auditing_create_time}
                              text4_1={"当前进度:" + item.auditing_current_branch_title}
                              onPress={() => this.onItemPress(item)}
                              text1_2_Style={{color:statusObj.color}}
                              itemRowIcon={false}
                              text1_2_Icon={statusObj.icon}/>
        );
    }

    /*onShowMonPicker(timestamp){
        this.setState(preState=>{
            preState.finishTime = Tools.timeFormatConvert(timestamp,"YYYY-MM-DD HH:mm:ss");
            return {
                nextWeekList:JSON.parse(JSON.stringify(preState.nextWeekList))
            }
        });
    }*/

    onChangeText = (text)=>{
        this.selectValue.name = text;
    }

    componentWillReceiveProps(){
        let param = this.getPageParams(true);
        if(param){
            this.onSearch();
        }
    }

    render() {
        const {dataList,approvalList,approvalStatus,approvalDefault,
            departmentTowDefault,departmentTwoDisable,departmentOneDisable,pickedDate
            ,clearDrop} = this.state;

        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c}>

                <View style={styles.titleFrame}>
                    <View style={styles.titleFrame_1}>

                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={approvalDefault}
                                           options={approvalList}
                                           disabled={departmentOneDisable}
                                           onSelect={(i,val)=>this.onSelectDrop(val,i,1)} />
                        </View>

                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={departmentTowDefault}
                                           clearDrop={clearDrop}
                                           options={approvalStatus}
                                           disabled={departmentTwoDisable}
                                           onSelect={(i,val)=>this.onSelectDrop(val,i,2)} />
                        </View>

                        <View style={styles.titleFrame_1_1}>
                            <TextInput placeholder={"--姓名--"}
                                       onChangeText={this.onChangeText}
                                       style={styles.titleFrame_textInput}/>
                        </View>

                        <View style={styles.titleFrame_1_1}>
                            <View style={styles.titleFrame_btnFrame}>
                                <ButtonChange text={"查询"}
                                              onPress={this.onSearch}
                                              style={styles.titleFrame_btn}/>
                            </View>
                        </View>

                    </View>

                </View>

                <FlatListView style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItemView(item,index)}
                              onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        height:200,
    },
    titleFrame:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
        paddingLeft:10,
        height:50,
    },
    titleFrame_1:{
        flexDirection:'row',
        flex:1,
        height:50,
    },
    titleFrame_2:{
        height:50,
        width:700,
    },
    titleFrame_1_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    titleFrame_2_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'flex-end',
    },
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            padding:0,
            paddingLeft:10,
            paddingBottom:10,
            marginTop:15,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    titleFrame_btnFrame:{
        width:Theme.Width.width1 + Theme.Height.height1,
    },
    titleFrame_btn:{
        width:100,
        height:Theme.Height.height1,
        padding:0,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginBottom:10,
    },
    itemTripBtn:{
        marginRight:"0.05w",
    },
});
