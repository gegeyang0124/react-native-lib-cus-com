import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {

    constructor() {
        Service.base = this;
    }

    retList = [];

    retJson = {
        data: {
            has: false,//是否有数据，true:有，false:没有，默认是false
        },
        totalElements: 0,
    };//后台返回数据

    paramsFetch = {
        pageNumber:0,
        executing:false,//是否正在执行中
    };


    /**
     * 获取数据列表
     * @param val object,//搜索参数
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static getDataList(val,init) {

        init = init == undefined ? false : init;

        if(init || this.base == undefined){
            new Service();
        }

        if(init){
            this.base.paramsFetch.pageNumber = 0;
            this.base.retJson.data = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }else {
            this.base.paramsFetch.executing = true;
        }

        if(val == undefined){
            return Http.get(HttpUrls.urlSets.urlCustomerApprovalList,
                {number :this.base.paramsFetch.pageNumber,device:"APP",
                    size: 30},init)
                .then(retJson => {

                    if(retJson.data != undefined && retJson.data.length  > 0) {

                        if (retJson.data.content == undefined || retJson.data.content.length == 0) {
                            retJson.data = [];
                            this.base.retJson.data.has = false;
                        } else {
                            this.base.paramsFetch.pageNumber++;
                            this.base.retJson.data.has = true;
                        }
                    }

                    retJson.data.content.forEach((val,i,arr) =>{
                        this.base.retList.push(val);
                    });

                    this.base.retJson.data.content = this.base.retList;
                    this.base.retJson.data.totalElements = retJson.data.totalElements;
                    this.base.paramsFetch.executing = false;

                    return this.base.retJson.data;
                });
        }else{
            return Http.get(HttpUrls.urlSets.urlCustomerApprovalList,
                {device:"APP",
                    number :this.base.paramsFetch.pageNumber+1,
                    size: 30,
                    auditing_type:val.auditing_type,
                    name:val.name,
                    auditing_status:val.auditing_status
                },init)
                .then(retJson => {

                    if(retJson.data != undefined && retJson.data.length  > 0) {

                        if(retJson.data.content == undefined || retJson.data.content.length == 0) {
                            retJson.data = [];
                            this.base.retJson.data.has = false;
                        }else{
                            this.base.paramsFetch.pageNumber++;
                            this.base.retJson.data.has = true;
                        }
                    }

                    retJson.data.content.forEach((val,i,arr) =>{
                        this.base.retList.push(val);
                    });

                    this.base.retJson.data.content = this.base.retList;
                    this.base.retJson.data.totalElements = retJson.data.totalElements;
                    this.base.paramsFetch.executing = false;

                    return this.base.retJson.data;
                });
        }
    }
}
