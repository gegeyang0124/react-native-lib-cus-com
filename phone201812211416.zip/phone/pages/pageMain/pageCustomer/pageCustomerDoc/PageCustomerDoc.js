import React, {Component} from 'react';
import {
    ScrollView,
} from 'react-native';
import {
    StyleSheetAdapt,
    Theme,
}from "com";
import {
    Tools,
} from "com-api";
import {
    DrawerNavigator,
    DrawerItems,
    TabNavigator,
} from 'comThird';
import PageCustomerDocList from "./pageCustomerDocList/PageCustomerDocList";
import PageCustomerDocListInvalid from "./pageCustomerDocList/PageCustomerDocListInvalid";
import PageCustomerDocDetail from "./pageCustomerDocDetail/PageCustomerDocDetail";
import PageCustomerDocInfo from "./pageCustomerDocInfo/PageCustomerDocInfo";
import PageVisitTaskList from "./pageVisitTaskList/PageVisitTaskList";


const TabRouteConfigs = {
    PageCustomerDocDetail: {
        screen: PageCustomerDocDetail,
    },
    PageCustomerDocInfo:{
        screen:PageCustomerDocInfo,
    },
    PageVisitTaskList:{
        screen:PageVisitTaskList,
    }
}

const PageCustomerDocDetails = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

const page = {
    get PageCustomerDocListInvalid(){
        return PageCustomerDocListInvalid;
    },
    get PageCustomerDocList() {
        return PageCustomerDocList;
    },
    get PageCustomerDocDetails(){
        return PageCustomerDocDetails;
    }
};

module.exports = page;



