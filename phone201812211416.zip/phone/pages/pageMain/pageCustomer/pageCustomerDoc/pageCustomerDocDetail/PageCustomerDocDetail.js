import React, {Component} from 'react';
import {
    View,
    TouchableOpacity,
    Text,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
    Image,
    ImageChange,
    TextChange,
    ButtonChange,
    ItemRowGuideTripApply,
    ItemRowSwitch,
    ChartCircleProgress,
} from "com";
const RN = require('react-native');
const Img = RN.Image;
import { Service, } from "./Service";

import CharacterBackground from "images/characterBackground.png"
import DetailVisitRecord from "../pageCustomerDocInfo/return/detailVisitRecord/DetailVisitRecord";

/**
 * 客户详情
 * **/
type Props = {};
export default class PageCustomerDocDetail extends BaseComponent<Props> {

    icon_1=require('images/moreIcon_1.png');
    icon_2=require('images/moreIcon_2.png');

    constructor(props) {
        super(props);

        this.execFirst = true;

        this.selectedValueId = null;
        this.storeId = null;

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            isVisible_1: "none",
            isVisible_2: "none",
            progressFinish:0,//完成进度
            store_code:'',//门店编码
            dataObj:{
                pictures:[],//图片列表
                imageList:[],//图片列表
                username:'',
                phone:'',
                site:'',
                startDate:'',
                endDate:'',
                runState:'',
                storeAcreage:'',
                displayAcreage:'',
                clientSort:'',
                clientValue:'',
                openDate:'',
                trialDate:'',
                character:'黄色',
                characterText:'和别人交往时，黄色性格的人表现冷漠，以产出和目标为导向，善于'+
                '控制他人和环境，果断行动和决策，他们最关心的时最后的结果。',
            },
            score_one:{
                balance:'',//账户余额
                turnover:'',//本月营业额
                newMember:'',//本月新增会员
                recharge:'',//本月充值金额
                inventory:'',//本月库存金额
                countMember:'',//会员总数
            },
            score_two:{
                returnCount:'',//返单次数
                returnSum:'',//返单金额
                visitingCount:'',//累计拜访次数
                visitingCallCount:'',//电话回访次数
            },
            relatedTaskList:[],
            awaitSendOrder:[],
            renderItem_awaiteceiveOrder:[]
        }
    }

    componentWillEnter(params,action,page){
        if(params != null){
            //设置进度条
            this.state.progressFinish = parseInt(params.progressFinish);
            this.selectedValueId = params.store_code;
            this.storeId = params.id;
            this.getData();
        }
    }

    /*componentWillExit(params,action,page){
        this.setState({
            store_code:'',
            dataObj:{},
            score_one:{},
            score_two:{},
            relatedTaskList:[],
            awaitSendOrder:[],
            renderItem_awaiteceiveOrder:[],
        });
    }*/


    getData(){

        Service.getCustomerDetail(this.selectedValueId)
            .then(retJson => {
                this.setState({
                    dataObj:{
                        imageList:retJson.pictures,
                        username:retJson.name,
                        openDate:retJson.openDate,
                        trialDate:retJson.trialDate,
                        phone:retJson.phone,
                        site:retJson.address,
                        startDate:retJson.signDate,
                        endDate:retJson.expireTime,
                        runState:retJson.operationMode,
                        storeAcreage:retJson.storeArea+'m²',
                        displayAcreage:retJson.displayArea+'m²',
                        clientSort:retJson.storeType == 1 ? "第一段" : retJson.storeType == 2?
                            "第二段" : retJson.storeType == 3 ? "第三段" : retJson.storeType == 4 ?
                                "第四段" : "第五段",
                        clientValue:retJson.storeTypeDesc,
                        character:'黄色',
                        characterText:'和别人交往时，黄色性格的人表现冷漠，以产出和目标为导向，善于'+
                        '控制他人和环境，果断行动和决策，他们最关心的时最后的结果。',
                    },
                    score_two:{
                        returnCount:retJson.returnOrderNum,//返单次数
                        returnSum:retJson.returnOrderMoney,//返单金额
                        visitingCount:retJson.totalVisitNum,//累计拜访次数
                        visitingCallCount:retJson.totalPhoneVisitNum,//电话回访次数
                    },
                    relatedTaskList:retJson.systemUseInfoList,
                    awaitSendOrder:retJson.waitSendOrders,
                    renderItem_awaiteceiveOrder:retJson.waitReceiveOrders,
                });
            });

        Service.getCustomerDetailSum(this.selectedValueId).then(retJson => {
            var thisRechargeMoney = parseInt(retJson.thisRechargeMoney);
            if(thisRechargeMoney >= 10000){
                thisRechargeMoney = (thisRechargeMoney / 10000 + '').replace(".",",");
            }

            var salesAmount = parseInt(retJson.this_sales_amount);
            if(salesAmount >= 10000){
                salesAmount = (salesAmount / 10000 + '').replace(".",",");
            }

            var account = parseInt(retJson.account);
            if(account >= 10000){
                account= (account / 10000 + '').replace(".",",");
            }

            var this_inventory_amount = parseInt(retJson.this_inventory_amount);
            if(this_inventory_amount >= 10000){
                this_inventory_amount= (this_inventory_amount / 10000 + '').replace(".",",");
            }

            this.setState({
                score_one: {
                    balance: thisRechargeMoney,//本月充值金额
                    turnover: salesAmount,//本月营业额
                    newMember: retJson.monthMemberCount,//本月新增会员
                    recharge: account,//账户余额
                    inventory: this_inventory_amount,//本月库存金额
                    countMember: retJson.thisMemberCount//会员总数
                }
            });
        });

     /*   BaseComponent.tmpData = {
            store_info:this.selectedValueId,//门店编码
            contract_sn:'',//合同编码
        };*/

        Service.getCustomerDetailAll(this.selectedValueId).then(retJson => {

            BaseComponent.tmpData = {
                store_info:this.selectedValueId,//门店编码
                contract_sn:retJson.contract_sn,//合同编码
                store_name:retJson.name,//客户名称
                customer_id:retJson.member_id,//客户id
                store_code: this.selectedValueId,
                clientSort:this.state.dataObj.clientSort,
                storeId:this.storeId,
            };
        });
    }

    renderItem = (item,i)=>{
        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.systemName}
                                   text2={item.opened}
                                   text3={item.lastUseDate == null ? '-' : item.lastUseDate}
                                   text4={item.useCount == null ? '-' : item.useCount}
                                   text5={false}
                                   text6={false}
                                   text7={false}
                                   textStyle={styles.systemText}
                                   frameStyle={styles.systemFram}/>
        );
    }

    renderItem_awaitSendOrder = (item,i)=>{
        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.orderNo}
                                   text2={'待发货'}
                                   text3={item.createTime}
                                   text4={item.paymentMoney}
                                   text5={false}
                                   text6={false}
                                   text7={false}
                                   textStyle={styles.systemText}
                                   frameStyle={styles.systemFram}/>

        );
    }

    renderItem_awaiteceiveOrder = (item,i)=>{
        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.orderNo}
                                   text2={'待收货'}
                                   text3={item.createTime}
                                   text4={item.paymentMoney}
                                   text5={false}
                                   text6={false}
                                   text7={false}
                                   textStyle={styles.systemText}
                                   frameStyle={styles.systemFram}/>

        );
    }

    onSend(){
        if(this.storeId != undefined){
            Service.getCustomerMessage(this.storeId);
        }
    }

    //店铺诊断
    onPressSearch(){
        //alert(111);
    }

    onDetail=()=>{
        //跳转档案
        this.goPage("CustomerDetail",
            {store_code: this.selectedValueId,
            clientSort:this.state.dataObj.clientSort,
            storeId:this.storeId});
    };

    //跳转明细
    onSelect(val){
        if(val == 1){
            this.goPage("PageVisitTaskList");
        }else if(val ==2){
            this.goPage("DetailVisitRecord",{store_code: this.selectedValueId,
                clientSort:this.state.dataObj.clientSort,
                storeId:this.storeId});
        }
    };

    render() {

        const {relatedTaskList,awaitSendOrder,renderItem_awaiteceiveOrder} = this.state;

        return (
            <ViewTitle>
                <View style={styles.head}>
                    <SwiperImage isCheckImage={true}
                                 imageList={this.state.dataObj.imageList}
                                 frameStyle={styles.frameSize}
                                 imageStyle={styles.imageStyle}/>

                    <View style={styles.baseStyle}>
                        <Text style={styles.fontStyle}>姓　  名：
                            <Text style={styles.oneText}>{this.state.dataObj.username}</Text>
                        </Text>
                        <Text style={styles.fontStyle}>手 机 号：
                            <Text style={[styles.paramsStyle,styles.oneText]}>{this.state.dataObj.phone}</Text>
                        </Text>
                        <Text style={styles.fontStyle}>经营方式：
                            <Text style={[styles.paramsStyle,styles.oneText]}>{this.state.dataObj.runState}</Text>
                        </Text>
                        <Text style={styles.fontStyle}>店铺地址：
                            <Text style={[styles.paramsStyle,styles.oneText]}>{this.state.dataObj.site}</Text>
                        </Text>
                    </View>

                    <View style={styles.buttonHead}>
                        <ButtonChange text={"获取信息"}
                                      onPress={() =>this.onSend()}
                                      textStyle={styles.buttonHead_text}
                                      style={styles.titleFrame_btn}/>

                        <ButtonChange text={"档案详情"}
                                      onPress={this.onDetail}
                                      textStyle={styles.buttonHead_text}
                                      style={styles.titleFrame_btn_detail}/>
                    </View>

                </View>

                <View style={styles.detail}>
                    <View style={styles.detail_1}>
                        <Text style={styles.detail_text}>签约时间：{this.state.dataObj.startDate}</Text>
                        <Text style={styles.detail_text}>试营业时间：{this.state.dataObj.trialDate}</Text>
                    </View>
                    <View style={styles.detail_1}>
                        <Text style={styles.detail_text}>到期时间：{this.state.dataObj.endDate}</Text>
                        <Text style={styles.detail_text}>门店面积：{
                            this.state.dataObj.storeAcreage == null ? 0 :this.state.dataObj.storeAcreage}</Text>
                    </View>
                    <View style={styles.detail_1}>
                        <Text style={styles.detail_text}>开业时间：{this.state.dataObj.openDate}</Text>
                        <Text style={styles.detail_text}>陈列面积：{this.state.dataObj.displayAcreage}</Text>
                    </View>
                </View>

                <View>
                    <TouchableOpacity style={styles.versionRow}
                                      onPress={() => this.setState({isVisible_1:this.state.isVisible_1 == "none" ? "flex" : "none"})}>
                        <View style={styles.versionRowView}>
                            <Text style={styles.versionRowText}>客户分类：{this.state.dataObj.clientSort}</Text>
                        </View>
                        <Image source={this.state.isVisible_1 == "none" ? this.icon_2 : this.icon_1}
                               style={[styles.versionRowIcon]}></Image>
                    </TouchableOpacity>
                    <View style={[styles.analyze_detail,{display:this.state.isVisible_1}]}>
                        <Text style={styles.analyze_detail_text}>{this.state.dataObj.clientValue}</Text>
                    </View>
                </View>

                <View>
                    <TouchableOpacity style={styles.versionRow}
                                      onPress={() => this.setState({isVisible_2:this.state.isVisible_2 == "none" ? "flex" : "none"})}>
                        <View style={styles.versionRowView}>
                            <Text style={styles.versionRowText}>性格分析：{this.state.dataObj.character}</Text>
                        </View>
                        <Image source={this.state.isVisible_2 == "none" ? this.icon_2 : this.icon_1}
                               style={[styles.versionRowIcon]}></Image>
                    </TouchableOpacity>

                    <Image source={CharacterBackground}
                           imageStyle={styles.characterImageStyle}
                           style={[styles.characterStyle,{display:this.state.isVisible_2}]}>
                        <Text style={styles.character_text}>
                            {this.state.dataObj.characterText}
                        </Text>
                    </Image>
                </View>

                <View>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>店铺体检</Text>
                    </View>

                    <View style={styles.fix}>
                        <View style={styles.score}>

                            <Image source={this.state.progressFinish >= 100 ? require('images/examination-100.png'):
                                this.state.progressFinish >= 90 ? require('images/examination-90.png'):
                                    this.state.progressFinish >= 80 ? require('images/examination-80.png'):
                                        this.state.progressFinish >= 70 ? require('images/examination-70.png'):
                                            this.state.progressFinish >= 60 ? require('images/examination-60.png'):
                                                this.state.progressFinish >= 50 ? require('images/examination-50.png'):
                                                    this.state.progressFinish >= 40 ? require('images/examination-40.png'):
                                                        this.state.progressFinish >= 30 ? require('images/examination-30.png'):
                                                            this.state.progressFinish >= 20 ? require('images/examination-20.png'):
                                                                this.state.progressFinish >= 10 ? require('images/examination-10.png'):
                                                                    require('images/examination-0.png')}
                                   style={[styles.resultFrame]}>
                                <TextChange textStyle={styles.imageTextNumber}
                                            onPress={()=>this.onPressSearch()}
                                            text={this.state.progressFinish} />
                            </Image>


                        </View>
                        <View style={styles.score_params_1}>
                            <View style={styles.score_params_1_view}>
                                <View style={styles.score_params_1_1}>
                                    <View style={styles.score_params_1_1_titleIco}></View>
                                    <View style={styles.scpre_params_1_1_view}>
                                        <Text style={styles.scpre_params_1_1_text}>
                                            <Text style={styles.scpre_params_1_1_text_number}>{this.state.score_one.recharge}</Text>
                                            元
                                        </Text>
                                        <Text style={styles.scpre_params_1_1_text}>账户余额</Text>
                                    </View>
                                </View>

                                <View style={styles.score_params_1_2}>
                                    <View style={styles.score_params_1_2_titleIco}></View>
                                    <View style={styles.scpre_params_1_1_view}>
                                        <Text style={styles.scpre_params_1_1_text}>
                                            <Text style={styles.scpre_params_1_2_text_number}>{this.state.score_one.turnover}</Text>
                                            元
                                        </Text>
                                        <Text style={styles.scpre_params_1_1_text}>本月营业额</Text>
                                    </View>
                                </View>

                                <View style={styles.score_params_1_3}>
                                    <View style={styles.score_params_1_3_titleIco}></View>

                                    <View style={styles.scpre_params_1_1_view}>
                                        <Text>
                                            <Text style={styles.scpre_params_1_3_text_number}>{this.state.score_one.newMember}</Text>
                                            个
                                        </Text>
                                        <Text style={styles.scpre_params_1_1_text}>本月新增会员</Text>
                                    </View>
                                </View>
                            </View>
                        </View>

                        <View style={styles.score_params_2}>
                            <View style={styles.score_params_1_view}>
                                <View style={styles.score_params_1_1}>
                                    <View style={styles.score_params_1_1_titleIco}></View>
                                    <View style={styles.scpre_params_1_1_view}>
                                        <Text style={styles.scpre_params_1_1_text}>
                                            <Text style={styles.scpre_params_1_1_text_number}>{this.state.score_one.balance}</Text>
                                            元
                                        </Text>
                                        <Text style={styles.scpre_params_1_1_text}>本月充值金额</Text>
                                    </View>
                                </View>
                                <View style={styles.score_params_1_2}>
                                    <View style={styles.score_params_1_2_titleIco}></View>
                                    <View style={styles.scpre_params_1_1_view}>
                                        <Text style={styles.scpre_params_1_1_text}>
                                            <Text style={styles.scpre_params_1_2_text_number}>{this.state.score_one.inventory}</Text>
                                            元
                                        </Text>
                                        <Text style={styles.scpre_params_1_1_text}>本月库存额</Text>
                                    </View>
                                </View>
                                <View style={styles.score_params_1_3}>
                                    <View style={styles.score_params_1_3_titleIco}></View>
                                    <View style={styles.scpre_params_1_1_view}>
                                        <Text>
                                            <Text style={styles.scpre_params_1_3_text_number}>{this.state.score_one.countMember}</Text>
                                            个
                                        </Text>
                                        <Text style={styles.scpre_params_1_1_text}>会员总数</Text>
                                    </View>
                                </View>
                            </View>
                        </View>
                    </View>

                    <View style={styles.returnVisit}>

                        <View style={styles.returnVisit_1_view}>
                            <View style={styles.returnVisit_key}>
                                <Text style={styles.returnVisit_text}>返单次数：</Text>
                                <Text style={styles.returnVisit_text}>返单总金额：</Text>
                            </View>
                            <View style={styles.returnVisit_value}>
                                <Text style={styles.returnVisit_text}>
                                    {this.state.score_two.returnCount == undefined ? 0 :this.state.score_two.returnCount}</Text>
                                <Text style={styles.returnVisit_text}>
                                    {this.state.score_two.returnSum == undefined ? 0 : this.state.score_two.returnSum}</Text>
                            </View>
                        </View>

                        <View style={styles.returnVisit_2_view}>
                            <View style={styles.returnVisit_titleIco}></View>
                        </View>

                        <View style={styles.returnVisit_3_view}>
                            <View style={styles.returnVisit_key}>
                                <Text style={styles.returnVisit_text}>累计拜访次数：</Text>
                                <Text style={styles.returnVisit_text}>售后回访次数：</Text>
                            </View>

                            <View style={styles.returnVisit_value}>
                                <Text style={styles.returnVisit_text}>
                                    {this.state.score_two.visitingCount}
                                </Text>
                                <Text style={styles.returnVisit_text}>
                                    {this.state.score_two.visitingCallCount}
                                </Text>
                            </View>

                        </View>

                        <View style={styles.returnVisit_4_view}>
                            <ButtonChange text={"拜访明细"}
                                          onPress={() =>this.onSelect(1)}
                                          textStyle={styles.buttonHead_text}
                                          style={styles.returnVisit_btn_1}/>
                            <ButtonChange text={"回访明细"}
                                          onPress={() =>this.onSelect(2)}
                                          textStyle={styles.buttonHead_text}
                                          style={styles.returnVisit_btn_2}/>
                        </View>
                    </View>
                </View>

                <View>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>系统使用情况</Text>
                    </View>

                    <View style={styles.titleFrame1}>
                        <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                               frameStyle={styles.itemRowFrameTop}
                                               text1={"系统名称"}
                                               text2={"是否开通"}
                                               text3={"最近一次使用"}
                                               text4={"累计使用次数"}
                                               text5={false}
                                               text6={false}
                                               text7={false}
                        />

                        {relatedTaskList.map(this.renderItem)}

                    </View>

                    <View>
                        <View style={styles.title}>
                            <View style={styles.titleIco}></View>
                            <Text style={styles.titleText}>待发货订单</Text>
                        </View>

                        <View style={styles.titleFrame1}>
                            <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                                   frameStyle={styles.itemRowFrameTop}
                                                   text1={"订单编号"}
                                                   text2={"订单状态"}
                                                   text3={"订单日期"}
                                                   text4={"订单总金额(元)"}
                                                   text5={false}
                                                   text6={false}
                                                   text7={false}
                            />

                            {awaitSendOrder.map(this.renderItem_awaitSendOrder)}

                        </View>

                    </View>

                    <View>
                        <View style={styles.title}>
                            <View style={styles.titleIco}></View>
                            <Text style={styles.titleText}>待收货订单</Text>
                        </View>

                        <View style={styles.titleFrame1}>
                            <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                                   frameStyle={styles.itemRowFrameTop}
                                                   text1={"订单编号"}
                                                   text2={"订单状态"}
                                                   text3={"订单日期"}
                                                   text4={"订单总金额(元)"}
                                                   text5={false}
                                                   text6={false}
                                                   text7={false}
                            />

                            {renderItem_awaiteceiveOrder.map(this.renderItem_awaiteceiveOrder)}

                        </View>

                    </View>

                </View>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    //字号大
    oneText:{
        fontSize:Theme.Font.fontSize,
    },
    buttonHead_text:{
        fontSize:Theme.Font.fontSize_1,
    },
    character_text:{
        marginTop:30,
        marginLeft:125,
        width:480,
        color:Theme.Colors.foregroundColor,
        fontSize:Theme.Font.fontSize_1_1,
    },
    characterStyle:{
        height: 150,
        backgroundColor:'#FDEFE6',
    },
    characterImageStyle:{
        width:730,
        marginLeft:20,
    },
    resultFrame:{
        marginTop:10,
        height:350,
        width:250,
        alignItems:'center',
        justifyContent:'center',
        //backgroundColor:Theme.Colors.progressColor,
    },
    frameSize:{
        width:170,
        height:'200dw',
    },
    imageStyle:{
        width:170,
        height:'200dw',
    },
    //客户分类1
    analyze:{
        paddingLeft:10,
        paddingTop:1,
        flexDirection:'row',
        backgroundColor:'#FEE2CC',
    },
    analyze_text:{
        width:200,
        fontSize:Theme.Font.fontSize,
    },
    analyze_detail:{
        paddingLeft:20,
        height:80,
        backgroundColor:'#FDEFE6',
        //justifyContent: 'center',
    },
    analyze_detail_text:{
        top:5,
        fontSize:Theme.Font.fontSize_1,
    },
    below_statusBtnFrameImage:{
        width: 550,
        height: 25,
        padding:5,
        alignItems:'flex-end',
    },
    head:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
    },
    detail:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
        padding:10
    },
    detail_1:{
        flex:1,
    },
    detail_text:{
        fontSize:Theme.Font.fontSize_1,
    },
    //客户头部基本档案
    baseStyle:{
        width:460,
        justifyContent:'flex-end',
        //backgroundColor:Theme.Colors.borderColor,
        //alignItems:'flex-end',
        //marginTop:25,
        padding:10,
    },
    fontStyle:{
        fontSize:Theme.Font.fontSize,
        marginTop:10,
        justifyContent:'flex-end',
    },
    buttonHead:{
        alignItems:'flex-end',
        justifyContent:'flex-end',
        width:130,
    },
    paramsStyle:{
        color:Theme.Colors.themeColor,
    },
    titleFrame_btn:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },
    titleFrame_btn_detail:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },
    //通用分类标签
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    //店铺体检
    fix:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
    },
    score:{
        height:400,
        width:310,
        alignItems:'center',
        justifyContent:'center',
        borderColor: Theme.Colors.minorColor,
        borderRightWidth:Theme.Border.borderWidth,
    },
    score_params_1:{
        width:230,
        borderColor: Theme.Colors.minorColor,
        borderRightWidth:Theme.Border.borderWidth,
    },
    score_params_2:{
        width:220,
    },
    score_params_1_view:{
        flexDirection:'column',
        height:400,
    },
    score_params_1_1:{
        width:230,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        flex:1,
        borderColor: Theme.Colors.minorColor,
        borderBottomWidth:Theme.Border.borderWidth,
    },
    score_params_1_2:{
        width:230,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        flex:1,
        borderColor: Theme.Colors.minorColor,
        borderBottomWidth:Theme.Border.borderWidth,
    },
    score_params_1_3:{
        width:230,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        flex:1,
    },
    score_params_1_1_titleIco:{
        marginLeft:30,
        width:3,
        height:70,
        backgroundColor:"#F42020",
    },
    scpre_params_1_1_view:{
        marginLeft:15,
    },
    scpre_params_1_1_text:{
        color:Theme.Colors.minorColor,
        fontSize:Theme.Font.fontSize_1,
    },
    scpre_params_1_1_text_number:{
        color:"#F42020",
        fontSize:35,
    },
    score_params_1_2_titleIco:{
        marginLeft:30,
        width:3,
        height:70,
        backgroundColor:"#17C8FE",
    },
    scpre_params_1_2_text_number:{
        color:"#17C8FE",
        fontSize:35,
    },
    score_params_1_3_titleIco:{
        marginLeft:30,
        width:3,
        height:70,
        backgroundColor:"#17D26D",
    },
    scpre_params_1_3_text_number:{
        color:"#17D26D",
        fontSize:35,
    },
    imageTextNumber:{
        fontSize:60,
        fontWeight: 'bold',
        color:Theme.Colors.themeColor,
    },
    returnVisit:{
        backgroundColor:Theme.Colors.foregroundColor,
        padding:10,
        flexDirection:'row',
        height:120,
        borderColor: Theme.Colors.minorColor,
        borderTopWidth:Theme.Border.borderWidth,
    },
    returnVisit_titleIco:{
        width:3,
        height:100,
        backgroundColor:Theme.Colors.themeColor,
    },
    returnVisit_1_view:{
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'center',
        width:300,
    },
    returnVisit_key:{
        alignItems: 'flex-end',
        justifyContent: 'center',
    },
    returnVisit_value:{
        alignItems: 'flex-start',
        justifyContent: 'center',
    },
    returnVisit_2_view:{
        width:20,
    },
    returnVisit_3_view:{
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'center',
        width:210,
    },
    returnVisit_4_view:{
        justifyContent:'flex-end',
        alignItems: 'flex-end',
        width:220,
    },
    returnVisit_btn_1:{
        padding:5,
        width:120,
        height:Theme.Height.height1,
        marginBottom:5,
    },
    returnVisit_btn_2:{
        padding:5,
        width:120,
        height:Theme.Height.height1,
        marginBottom:20,
    },
    returnVisit_text:{
        fontSize:Theme.Font.fontSize_1,
        borderColor: Theme.Colors.minorColor,
    },
    systemText:{
        fontSize:Theme.Font.fontSize_1,
        borderColor: Theme.Colors.minorColor,
    },
    titleFrame1:{
        padding:10,
        flex:1,
        //marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        //paddingTop:10,
        //paddingBottom:10,
    },
    itemRowText:{
        color:Theme.Colors.fontcolor,
        fontSize:Theme.Font.fontSize_1,
    },
    itemRowFrameTop:{
        borderColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth1,
        borderTopWidth:Theme.Border.borderWidth,
    },
    systemFram:{
        borderColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth1,
    },
    versionRow:{
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        flexDirection: 'row',
        //borderBottomColor:"#FEE0CA",
        backgroundColor:"#FEE0CA",
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,

    },
    versionRowText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    versionRowIcon:{
        width:20,
        height:20,
        resizeMode:"contain",
    },
    versionRowView:{
        width:730,
    },
});