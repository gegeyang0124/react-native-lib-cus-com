import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retData: [],
        total: 0,
        has: false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    paramsFetch = {
        pageNumber:1,
        executing:false,//是否正在执行中
    };

    /**
     * 获取客户详情
     */
    static getCustomerDetail(code){
        return Http.get(HttpUrls.urlSets.urlCustomerDetailBase,
            {storeCode:code},true)
            .then(retJson => {
                return retJson.retData;
            });
    }


    /**
     * 获取客户基本资料
     */
    static getCustomerDetailAll(code){
        return Http.get(HttpUrls.urlSets.urlCustomerDetail,{storecode:code},false)
            .then(retJson => {
                return retJson.data;
            });
    }

    static getCustomerDetailSum(code){
        return Http.get(HttpUrls.urlSets.urlCustomerDetailSum,{storeCode:code},false).then(retJson => {
            return retJson.retData;
        });
    }

    /**
     * 发送客户信息
     */
    static getCustomerMessage(id){
        return Http.post(HttpUrls.urlSets.urlCustomerPhoneNote+id,{
            user_id:Tools.userConfig.userInfo.id,type:5,agent_id:11}).then(retJson => {
            if(retJson.code == 0){
                Tools.toast("获取成功，请在企业微信查看");
            }else{
                Tools.toast("获取失败，请联系管理员");
            }
            return retJson.retData;
        });
    }
}