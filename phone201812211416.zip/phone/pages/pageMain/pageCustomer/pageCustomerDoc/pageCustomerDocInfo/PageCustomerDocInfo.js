import {
    Theme,
} from 'com';
import {
    TabNavigator,
} from 'comThird';
import CustomerDetail from './baseDetail/CustomerDetail';
import CustomerCompact from './compact/CustomerCompact';
import BusinessDetail from './business/BusinessDetail';
import StoreDetail from './store/StoreDetail';
import VisitRecord from './return/VisitRecord';
//import ReturnVisitToRecord from './return/returnVisitToRecord/ReturnVisitToRecord';

/**
 * 客户详情
 **/
const TabRouteConfigs = {
    CustomerDetail: {
        screen: CustomerDetail,
        navigationOptions: {
            title:'基本资料',
            tabBarLabel : '基本资料',
        },
    },
    CustomerCompact: {
        screen: CustomerCompact,
        navigationOptions: {
            title:'签约合同',
            tabBarLabel : '签约合同',
        },
    },
    BusinessDetail: {
        screen: StoreDetail,
        navigationOptions: {
            title:'店铺营业',
            tabBarLabel : '店铺营业',
        },
    },
    StoreDetail: {
        screen: BusinessDetail,
        navigationOptions: {
            title:'店铺资料',
            tabBarLabel : '店铺资料',
        },
    },
    VisitRecord: {
        screen: VisitRecord,
        navigationOptions: {
            title:'回访记录',
            tabBarLabel : '回访记录',
        },
    },
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigsTop);

module.exports = pages;