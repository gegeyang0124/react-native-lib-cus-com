import React, {Component} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
    Image,
    ButtonChange,
    ItemRowGuideTripApply,
} from "com";
import { Service} from "./Service";

/**
 * 基本资料
 * **/
type Props = {};
export default class CustomerDetail extends BaseComponent<Props> {

    icon_1=require('images/moreIcon_1.png');
    icon_2=require('images/moreIcon_2.png');

    constructor(props) {
        super(props);

        this.execFirst = true;

        this.level = "-";
        this.storeId = null;

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            isVisible_1: "flex",
            isVisible_2: "none",
            isVisible_3: "none",
            isVisible_4: "none",
            isVisible_5: "none",
            baseList:{},
            storeList:{},
            relatedTaskList:[],
            agreement:'',
            other:'',
        };
    }

    componentWillEnter(params,action,page) {
        if (params != null) {
            this.selectedValueId = params.store_code;
            this.storeId = params.storeId;
            this.level = params.clientSort;
            this.getData();
        } else if (BaseComponent.tmpData != null) {
            this.selectedValueId = BaseComponent.tmpData.store_code;
            this.storeId = BaseComponent.tmpData.storeId;
            this.level = BaseComponent.tmpData.clientSort;
            this.getData();
        }

    }

    getData(){
        this.execFirst = true;
        Service.getCustomerDetail(this.selectedValueId).then(retJson => {

            /*BaseComponent.tmpData = {
                store_info:this.selectedValueId,//门店编码
                contract_sn:retJson.contract_sn,//合同编码
                store_name:retJson.name,//客户名称
                customer_id:retJson.member_id,//客户id
            };*/

            this.setState({
                baseList: {
                    userName:retJson.name,
                    phone:retJson.tel,
                    job:retJson.profession,
                    character:retJson.client_character,
                    createdTime:(retJson.sign_time == null) ? "-" : retJson.sign_time,
                    status:retJson.operation_mode,
                    trait:retJson.client_feature,
                    userCode:retJson.idcard,
                    userSite:retJson.domicile,
                    codeOfValidity:retJson.idcard_time
                },
                storeList:{
                    level:retJson.shop_rank,
                    createdTime:(retJson.practice_time == null) ? "-" : retJson.practice_time,
                    status:retJson.progress,
                    displayArea:retJson.display_area+'m²',
                    storeArea:retJson.area+'m²',
                    startTime:retJson.practice_day+'天',
                    decorationTime:retJson.decorate_day+'天',
                    customerManagerName:retJson.operate_supervisor,
                    provincialManagerName:retJson.region_manager,
                    assistantManagerName:retJson.operate_manager,
                    isStore:retJson.has_store,
                    investmentAdviserMain:retJson.investment_manager,
                    investmentAdviserMinor:retJson.investment_manager2,
                    storeSite:retJson.store_address,
                    consignee:retJson.consignee,
                    consigneePhone:retJson.consignee_tel,
                    storeSiteDetail:retJson.receiving_address,
                    code:retJson.zip_code,
                    province:retJson.consignee_province,
                    city:retJson.consignee_city,
                },
                agreement:retJson.agreement,
                other:retJson.remark,
            });
        });
    }

    renderItem = (item,i)=>{
        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.name}
                                   text2={item.isOpenUp == 0 ?'是':'否'}
                                   text3={item.lastTime == '' ? '-' : item.lastTime}
                                   text4={item.useCount == '' ? '-' : item.useCount}
                                   text5={false}
                                   text6={false}
                                   text7={false}
                                   textStyle={styles.systemText}
                                   frameStyle={styles.systemFram}/>

        );
    }

    onSend(){
        if(this.storeId != undefined){
            Service.getCustomerMessage(this.storeId);
        }
    }

    render() {

        const {relatedTaskList} = this.state;

        return (
            <ViewTitle>
                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_1:this.state.isVisible_1 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>基本信息</Text>
                    <Image source={this.state.isVisible_1 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>
                <View style={[styles.versionTable,{display:this.state.isVisible_1}]}>
                    <View style={styles.baseModel}>
                        <ButtonChange text={"获取信息"}
                                      onPress={() => this.onSend()}
                                      textStyle={styles.oneText}
                                      style={styles.titleFrame_btn_detail}/>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>姓名：</Text>
                                    <Text style={styles.modelLeftTextKey}>手机：</Text>
                                    <Text style={styles.modelLeftTextKey}>职业：</Text>
                                    <Text style={styles.modelLeftTextKey}>性格：</Text>
                                </View>

                                <View>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.userName}</Text>
                                    <Text style={styles.modelTextKey}>{this.state.baseList.phone}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.job}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.character}</Text>
                                </View>

                            </View>

                            <View style={styles.modelRight}>
                                <View >
                                    <Text style={styles.modelLeftTextKey}>签约日期：</Text>
                                    <Text style={styles.modelLeftTextKey}>经营方式：</Text>
                                    <Text style={styles.modelLeftTextKey}>客户等级：</Text>
                                    <Text style={styles.modelLeftTextKey}>客户特征：</Text>
                                </View>
                                <View >
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.createdTime}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.status}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.level}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.trait}</Text>
                                </View>

                            </View>
                        </View>

                        <View>
                            <View style={styles.segment}></View>

                            <View style={styles.model}>
                                <View style={styles.modelLeft}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>身份证号码：</Text>
                                        <Text style={styles.modelLeftTextKey}>身份证地址：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.userCode}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.userSite}</Text>
                                    </View>
                                </View>

                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>身份证有效期限：</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.codeOfValidity}</Text>
                                    </View>
                                </View>

                            </View>
                        </View>
                    </View>
                </View>

                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_2:this.state.isVisible_2 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>店铺信息</Text>
                    <Image source={this.state.isVisible_2 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>
                <View style={[styles.versionTable,{display:this.state.isVisible_2}]}>
                    <View style={styles.baseModel}>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>加盟级别：</Text>
                                    <Text style={[styles.modelLeftTextKey,{marginBottom:3}]}>开业时间：</Text>
                                    <Text style={[styles.modelLeftTextKey,{marginBottom:3}]}>客户状态：</Text>
                                    <Text style={[styles.modelLeftTextKey,{marginBottom:3}]}>陈列面积：</Text>
                                    <Text style={[styles.modelLeftTextKey,{marginBottom:3}]}>店铺面积：</Text>
                                    <Text style={[styles.modelLeftTextKey,{marginBottom:2}]}>开店周期：</Text>
                                    <Text style={styles.modelLeftTextKey}>装修天数：</Text>
                                </View>

                                <View>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.level}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.createdTime}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.status}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.displayArea}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.storeArea}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.startTime}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.decorationTime}</Text>
                                </View>

                            </View>

                            <View style={styles.modelRight}>
                                <View >
                                    <Text style={styles.modelLeftTextKey}>　客户经理：</Text>
                                    <Text style={styles.modelLeftTextKey}>　省区经理：</Text>
                                    <Text style={styles.modelLeftTextKey}>　运营助理：</Text>
                                    <Text style={styles.modelLeftTextKey}>有无实体店：</Text>
                                    <Text style={styles.modelLeftTextKey}>主投资顾问：</Text>
                                    <Text style={styles.modelLeftTextKey}>副投资顾问：</Text>
                                </View>
                                <View >
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.customerManagerName}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.provincialManagerName}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.assistantManagerName}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.isStore == "1" ? "有" : "无"}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.investmentAdviserMain}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.storeList.investmentAdviserMinor}</Text>
                                </View>

                            </View>
                        </View>

                        <View>
                            <View style={styles.segment}></View>

                            <View style={styles.model}>
                                <View style={styles.modelLeft}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>店铺地址：</Text>
                                        <Text style={styles.modelLeftTextKey}>　</Text>
                                        <Text style={styles.modelLeftTextKey}>　收货人：</Text>
                                        <Text style={styles.modelLeftTextKey}>收货电话：</Text>
                                        <Text style={styles.modelLeftTextKey}>收货地址：</Text>
                                        <Text style={styles.modelLeftTextKey}>邮　　编：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelTextKey}>{this.state.storeList.storeSite}</Text>
                                        <Text style={styles.modelLeftTextValue}>　</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.storeList.consignee}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.storeList.consigneePhone}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.storeList.storeSiteDetail}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.storeList.code}</Text>
                                    </View>
                                </View>

                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>收货省份：</Text>
                                        <Text style={styles.modelLeftTextKey}>收货城市：</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.storeList.province}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.storeList.city}</Text>
                                    </View>
                                </View>

                            </View>
                        </View>
                    </View>
                </View>

                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_3:this.state.isVisible_3 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>系统信息</Text>
                    <Image source={this.state.isVisible_3 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>
                <View style={[styles.titleFrame1,styles.versionTable,{display:this.state.isVisible_3}]}>
                    <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                           frameStyle={styles.itemRowFrameTop}
                                           text1={"系统名称"}
                                           text2={"是否开通"}
                                           text3={"最近一次使用"}
                                           text4={"累计使用次数"}
                                           text5={false}
                                           text6={false}
                                           text7={false}
                    />
                    {relatedTaskList.map(this.renderItem)}
                </View>

                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_4:this.state.isVisible_4 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>协议信息</Text>
                    <Image source={this.state.isVisible_4 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>
                <View style={[styles.markModel,styles.versionTable,styles.agreement,{display:this.state.isVisible_4}]}>
                    <View style={styles.markModelView}>
                        <Text style={styles.modelLeftTextValue}>{this.state.agreement}</Text>
                    </View>
                </View>

                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_5:this.state.isVisible_5 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>其　　它</Text>
                    <Image source={this.state.isVisible_5 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>
                <View style={[styles.markModel,styles.versionTable,{display:this.state.isVisible_5}]}>
                    <View>
                        <View>
                            <Text style={styles.markModelText}>备注</Text>
                        </View>
                        <View style={styles.markModelView}>
                            <Text style={styles.modelLeftTextValue}>{this.state.other}</Text>
                        </View>
                    </View>
                </View>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    modelTextKey:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.themeColor,
    },
    oneText:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    titleFrame_btn_detail:{
        width:90,
        height:30,
        padding:0,
    },
    versionTable:{
        //margin:30,
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:0,
    },
    versionRow:{
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        flexDirection: 'row',
        //alignItems: 'center',
        //justifyContent: 'center',
        //borderBottomColor:"#FEE0CA",
        backgroundColor:"#FEE0CA",
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
    },
    versionRowText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    versionRowIcon:{
        width:20,
        height:20,
        resizeMode:"contain",
    },
    baseModel:{
        padding:20,
    },
    model:{
        flexDirection: 'row',
        paddingBottom:20,
        marginTop:5,
    },
    modelLeft:{
        flexDirection: 'row',
        width:450,
        //backgroundColor:Theme.Colors.backgroundColorBtn,
    },
    modelRight:{
        marginLeft:10,
        flexDirection: 'row',
        width:350,
        //backgroundColor:Theme.Colors.progressColor,
    },
    modelLeftTextKey:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    modelLeftTextValue:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.fontcolor,
    },
    segment:{
        paddingTop:20,
        width:730,
        borderTopWidth:1,
        alignItems: 'flex-start',
        borderTopColor:Theme.Colors.themeColor,
    },
    markModel:{
        alignItems: 'center',
        justifyContent: 'center',
    },
    markModelText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.themeColor,
    },
    markModelView:{
        backgroundColor:"#FDEFE3",
        width:700,
        height:280,
        borderWidth:1,
        borderColor:Theme.Colors.themeColor,
        padding:5,
    },
    agreement:{
        paddingTop:15,
        paddingBottom:15,
    },
});