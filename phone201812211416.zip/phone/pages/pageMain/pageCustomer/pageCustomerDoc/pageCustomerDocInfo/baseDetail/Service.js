import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    /**
     * 获取客户基本资料
     */
    static getCustomerDetail(code){
        return Http.get(HttpUrls.urlSets.urlCustomerDetail,{storecode:code},false)
            .then(retJson => {
                return retJson.data;
            });
    }

    /**
     * 发送客户信息
     */
    static getCustomerMessage(id){
        return Http.post(HttpUrls.urlSets.urlCustomerPhoneNote+id,{
            user_id:Tools.userConfig.userInfo.id,type:5,agent_id:11}).then(retJson => {
            if(retJson.code == 0){
                Tools.toast("获取成功，请在企业微信查看");
            }else{
                Tools.toast("获取失败，请联系管理员");
            }
            return retJson.retData;
        });
    }
}