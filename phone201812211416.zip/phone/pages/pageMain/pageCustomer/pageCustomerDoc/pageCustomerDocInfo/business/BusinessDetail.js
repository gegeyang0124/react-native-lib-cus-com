import React, {Component} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
    Image,
    ButtonChange,
    ItemRowGuideTripApply,
    ImageList,
    VideoList,
} from "com";
import { Service} from "./Service";

/**
 * 店铺资料
 * **/
type Props = {};
export default class BusinessDetail extends BaseComponent<Props> {

    icon_1=require('images/moreIcon_1.png');
    icon_2=require('images/moreIcon_2.png');

    constructor(props) {
        super(props);

        this.execFirst = true;

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            isVisible_1: "none",
            isVisible_2: "none",
            isVisible_3: "none",
            isVisible_4: "none",
            isVisible_5: "none",
            isVisible_6: "none",
            isVisible_7: "none",
            isVisible_8: "none",
            isVisible_9: "none",
            isVisible_10: "none",
            isVisible_11: "none",
            dataList:[],
        };
    }

    componentWillEnter(params,action,page){
        if(BaseComponent.tmpData.store_info != null){
            this.getData(BaseComponent.tmpData.store_info);
        }
    }

    getData(code){
        Service.getStoreImages(code).then(retJson => {
            this.setState({
                dataList:retJson,
            })
        });
    }

    renderImages = (item,i)=>{
        let isPic = true;
         if(item.list && item.list.length > 0){
             let src = item.list[0];
             if(src.indexOf(".mp4") > -1){
                 isPic = false;
             }
         }
        return(
            <View>
                <View style={styles.title}>
                    <View style={styles.titleIco}></View>
                    <Text style={styles.titleText}>{item.date}</Text>
                </View>

                {
                    isPic ? <ImageList dataList={item.list}
                                       rowCount={2}
                                       isScroll={true}
                                       isShowText={false}
                                       iconStyle={styles.imageStyle}
                                       frameRowStyle={styles.imageFrameRowStyle}
                                       frameStyle={styles.imageFramStyle}/>
                        : <VideoList dataList={item.list}
                                     rowCount={2}
                                     isScroll={true}
                                     isShowText={false}
                                     iconStyle={styles.imageStyle}
                                     frameRowStyle={styles.imageFrameRowStyle}
                                     frameStyle={styles.imageFramStyle}/>
                }


            </View>
        )
    }

    renderItem = (item,i)=>{
        return(
           <View>
            <TouchableOpacity style={styles.versionRow}
                              onPress={() => this.setState({["isVisible_"+i]:this.state["isVisible_" + i] == "none" ? "flex" : "none"})}>
                <View style={styles.versionRowView}>
                    <Text style={styles.versionRowText}>{item.name}</Text>
                </View>

                <Image source={this.state["isVisible_" + i] == "none" ? this.icon_2 : this.icon_1}
                       style={[styles.versionRowIcon]}></Image>
            </TouchableOpacity>
               <View style={[styles.versionTable,{display:this.state["isVisible_" + i]}]}>
                    {item.list.map(this.renderImages)}
               </View>
            </View>
        );
    };


    render() {
        return (
            <ViewTitle>
                {this.state.dataList.map(this.renderItem)}
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    versionRow:{
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        flexDirection: 'row',
        //alignItems: 'center',
        //justifyContent: 'center',
        borderBottomColor:"#FEE0CA",
        backgroundColor:"#FEE0CA",
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
    },
    versionRowText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    versionRowIcon:{
        width:20,
        height:20,
        resizeMode:"contain",
    },
    versionRowView:{
        width:730,
    },
    versionTable:{
        //margin:30,
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:0,
    },
    titleFrame_btn:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },
    titleFrame_btn_detail:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },
    //通用分类标签
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    imageStyle:{
        backgroundColor:'#FDF0EB',
        width:350,
        height:'250dw',
    },
    imageFrameRowStyle:{
        flex:1,
    },
    imageFramStyle:{
        flexDirection: 'row',
        // backgroundColor:'red'
    }
});