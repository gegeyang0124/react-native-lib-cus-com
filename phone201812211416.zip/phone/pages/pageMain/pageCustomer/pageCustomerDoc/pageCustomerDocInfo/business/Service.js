import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retData: [],
        total: 0,
        has: false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    paramsFetch = {
        pageNumber:1,
        executing:false,//是否正在执行中
    };


    /**
     * 获取客户详情
     */
    static getStoreImages(code){
        return Http.get(HttpUrls.urlSets.urlCustomerTaskPicture,
            {storeCode:code})
            .then(retJson => {
                return retJson.retData;
            });
    }
}