import React, {Component} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
    Image,
    ButtonChange,
    ItemRowGuideTripApply,
    ImageList,
} from "com";
import { Service} from "./Service";

/**
 * 签约合同
 * **/
type Props = {};
export default class CustomerCompact extends BaseComponent<Props> {

    icon_1=require('images/moreIcon_1.png');
    icon_2=require('images/moreIcon_2.png');

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft:true
        });

        this.state = {
            isVisible_1: "flex",
            isVisible_2: "none",
            isVisible_3: "none",
            imageList:[],
            baseList:{},
        }
    }

    componentWillEnter(params,action,page){
        this.getData();
    }

    getData(){
        Service.getCustomerCompact(BaseComponent.tmpData.contract_sn).then(retJson => {

            let retImageList = [retJson.accessory,retJson.accessory2,retJson.accessory3,
                                retJson.accessory4,retJson.accessory5];

            let phone = retJson.tel;

            this.setState({
                imageList:retImageList,
                baseList:{
                    contractCode:retJson.contract_sn,
                    userName:retJson.name,
                    phone:phone,
                    createdTime:(retJson.sign_time ==null) ? "-" : retJson.sign_time,
                    endTime:retJson.effective_time ==null ? "-" : retJson.effective_time,
                    brand:retJson.brand == 1 ? "可爱可亲" : "小狮贝恩",
                    level:retJson.shop_rank ==null ? "-" : retJson.shop_rank,
                    investmentAdviserMain:retJson.investment_manager == null ? "-" : retJson.investment_manager,
                    investmentAdviserMinor:retJson.investment_manager2 ==null ? "-" : retJson.investment_manager2,
                    investmentAdviserMainAmount:retJson.second_money ==null ? "-" : retJson.second_money,
                    investmentAdviserMinorAmount:retJson.second_money2 ==null ? "-" : retJson.second_money2,
                    contractAmount:retJson.total_amount ==null ? "-" : retJson.total_amount,
                    contractEndTime:retJson.expire_time ==null ? "-" : retJson.expire_time,
                    apparatusMainAmount:retJson.instrument_amount1 ==null ? "-" : retJson.instrument_amount1,
                    apparatusMinorAmount:retJson.instrument_amount2 ==null ? "-" : retJson.instrument_amount2,
                    apparatusAmount:retJson.instrument_amount ==null ? "-" : retJson.instrument_amount,
                    apparatusEndTime:retJson.instrument_time ==null ? "-" : retJson.instrument_time,
                    showcaseMainAmount:retJson.cabinet_amount1 ==null ? "-" : retJson.cabinet_amount1,
                    showcaseMinorAmount:retJson.cabinet_amount2 ==null ? "-" : retJson.cabinet_amount2,
                    showcaseAmount:retJson.cabinet_amount ==null ? "-" : retJson.cabinet_amount,
                    showcaseEndTime:retJson.cabinet_time ==null ? "-" : retJson.cabinet_time,
                    cashDeposit:retJson.deposit_amount ==null ? "-" : retJson.deposit_amount,
                    reimbursementAmount:retJson.traffic_amount ==null ? "-" : retJson.traffic_amount,
                    contractAmountSum:retJson.amount ==null ? "-" : retJson.amount,
                    licensingAmount:retJson.license_amount ==null ? "-" : retJson.license_amount,
                    activityAmount:retJson.discount_amount ==null ? "-" : retJson.discount_amount,
                    paymentTime:retJson.pay_time ==null ? "-" : retJson.pay_time,
                    discountAmount:retJson.discount_amount ==null ? "-" : retJson.discount_amount,
                    showcaseAmountSum:retJson.shelf_amount ==null ? "-" : retJson.shelf_amount,
                    fullAmount:retJson.amount ==null ? "-" : retJson.amount,
                    isDiscounts:retJson.privilege == 0 ? "无" : "有",
                    exchangeAmount:retJson.chang_amount ==null ? "-" : retJson.chang_amount,
                    reimbursementAmountSum:retJson.reimbursement_amount ==null ? "-" : retJson.reimbursement_amount,
                    apparatus:retJson.instrument,
                    customerDetail:retJson.client_desc,
                    supplementary:retJson.agreement,
                }
            });
        })
    }

/*    //获取信息
    onDetail=()=>{

    }*/

    render() {
        return (
            <ViewTitle>
                <TouchableOpacity style={styles.versionRow}
                                         onPress={() => this.setState({isVisible_1:this.state.isVisible_1 == "none" ? "flex" : "none"})}>
                <Text style={styles.versionRowText}>基本信息</Text>
                <Image source={this.state.isVisible_1 == "none" ? this.icon_2 : this.icon_1}
                       style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
            </TouchableOpacity>
                <View style={[styles.versionTable,{display:this.state.isVisible_1}]}>
                    <View style={styles.baseModel}>
                       {/* <ButtonChange text={"获取信息"}
                                      onPress={this.onDetail}
                                      textStyle={styles.oneText}
                                      style={styles.titleFrame_btn_detail}/>*/}
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>合同编号：</Text>
                                    <Text style={styles.modelLeftTextKey}>　签约方：</Text>
                                    <Text style={styles.modelLeftTextKey}>手　　机：</Text>
                                    <Text style={styles.modelLeftTextKey}>签约日期：</Text>
                                    <Text style={styles.modelLeftTextKey}>到期日期：</Text>
                                </View>

                                <View>
                                    <Text style={styles.modelTextKey}>{this.state.baseList.contractCode}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.userName}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.phone}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.createdTime}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.endTime}</Text>
                                </View>

                            </View>

                            <View style={styles.modelRight}>
                                <View >
                                    <Text style={styles.modelLeftTextKey}>加盟品牌：</Text>
                                    <Text style={styles.modelLeftTextKey}>加盟级别：</Text>
                                    <Text style={styles.modelLeftTextKey}>主投资顾问：</Text>
                                    <Text style={styles.modelLeftTextKey}>副投资顾问：</Text>
                                </View>
                                <View >
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.brand}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.level}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.investmentAdviserMain}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.investmentAdviserMinor}</Text>
                                </View>

                            </View>
                        </View>

                        <View>
                            <View style={styles.segment}></View>

                            <View style={styles.model}>
                                <View style={styles.modelLeft}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>主顾问金额(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>副顾问金额(元)：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.investmentAdviserMainAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.investmentAdviserMinorAmount}</Text>
                                    </View>
                                </View>

                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>合同总金额(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>　　　到期日期：</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.contractAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.contractEndTime}</Text>
                                    </View>
                                </View>

                            </View>
                        </View>

                        <View>
                            <View style={styles.segment}></View>

                            <View style={styles.model}>
                                <View style={styles.modelLeft}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>主仪器款(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>副仪器款(元)：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.apparatusMainAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.apparatusMinorAmount}</Text>
                                    </View>
                                </View>

                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>总仪器款(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>仪器款到款时间：</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.apparatusAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.apparatusEndTime}</Text>
                                    </View>
                                </View>

                            </View>
                        </View>

                        <View>
                            <View style={styles.segment}></View>

                            <View style={styles.model}>
                                <View style={styles.modelLeft}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>主展柜款(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>副展柜款(元)：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.showcaseMainAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.showcaseMinorAmount}</Text>
                                    </View>
                                </View>

                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>总展柜款(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>展柜款到款时间：</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.showcaseAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.showcaseEndTime}</Text>
                                    </View>
                                </View>

                            </View>
                        </View>

                        <View>
                            <View style={styles.segment}></View>

                            <View style={styles.model}>
                                <View style={styles.modelLeft}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>保证金(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>报销路费(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>合同金额(元)：</Text>
                                    </View>

                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.cashDeposit}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.reimbursementAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.contractAmountSum}</Text>
                                    </View>
                                </View>

                                <View style={styles.modelRight}>
                                    <View>
                                        <Text style={styles.modelLeftTextKey}>品牌授权费(元)：</Text>
                                        <Text style={styles.modelLeftTextKey}>参加活动金额(元)：</Text>
                                    </View>
                                    <View>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.licensingAmount}</Text>
                                        <Text style={styles.modelLeftTextValue}>{this.state.baseList.activityAmount}</Text>
                                    </View>
                                </View>

                            </View>
                        </View>

                    </View>
                </View>

                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_2:this.state.isVisible_2 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>协议信息</Text>
                    <Image source={this.state.isVisible_2 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>
                <View style={[styles.versionTable,{display:this.state.isVisible_2}]}>
                    <View style={styles.baseModel}>
                        <View style={styles.model}>
                            <View style={styles.modelLeft}>
                                <View>
                                    <Text style={styles.modelLeftTextKey}>缴费时间：</Text>
                                    <Text style={styles.modelLeftTextKey}>优惠金额(元)：</Text>
                                    <Text style={styles.modelLeftTextKey}>货柜款(元)：</Text>
                                    <Text style={styles.modelLeftTextKey}>全款金额(元)</Text>
                                </View>

                                <View>
                                    <Text style={styles.modelTextKey}>{this.state.baseList.paymentTime}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.discountAmount}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.showcaseAmountSum}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.fullAmount}</Text>
                                </View>

                            </View>

                            <View style={styles.modelRight}>
                                <View >
                                    <Text style={styles.modelLeftTextKey}>有无优惠政策：</Text>
                                    <Text style={styles.modelLeftTextKey}>仪器款(元)：</Text>
                                    <Text style={styles.modelLeftTextKey}>调换金额(元)：</Text>
                                    <Text style={styles.modelLeftTextKey}>报销金额(元)：</Text>
                                </View>
                                <View >
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.isDiscounts}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.apparatusAmount}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.exchangeAmount}</Text>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.reimbursementAmountSum}</Text>
                                </View>
                            </View>

                        </View>

                        <View style={styles.segment}></View>

                        <View style={[styles.markModel,styles.versionTable]}>
                            <View>
                                <View>
                                    <Text style={styles.markModelText}>项目仪器</Text>
                                </View>
                                <View style={styles.markModelView}>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.apparatus}</Text>
                                </View>
                            </View>
                        </View>

                        <View style={[styles.markModel,styles.versionTable,styles.markModel_son]}>
                            <View>
                                <View>
                                    <Text style={styles.markModelText}>客户情况</Text>
                                </View>
                                <View style={styles.markModelView}>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.customerDetail}</Text>
                                </View>
                            </View>
                        </View>

                        <View style={[styles.markModel,styles.versionTable,styles.markModel_son]}>
                            <View>
                                <View>
                                    <Text style={styles.markModelText}>补充条款</Text>
                                </View>
                                <View style={styles.markModelView}>
                                    <Text style={styles.modelLeftTextValue}>{this.state.baseList.supplementary}</Text>
                                </View>
                            </View>
                        </View>

                    </View>
                </View>

                <TouchableOpacity style={styles.versionRow}
                                  onPress={() => this.setState({isVisible_3:this.state.isVisible_3 == "none" ? "flex" : "none"})}>
                    <Text style={styles.versionRowText}>合同附件</Text>
                    <Image source={this.state.isVisible_3 == "none" ? this.icon_2 : this.icon_1}
                           style={[styles.versionRowIcon,{left:(Tools.screen.width * 0.95 - StyleSheetAdapt.getWidth(80))}]}></Image>
                </TouchableOpacity>

                <View style={[styles.versionTable,{display:this.state.isVisible_3}]}>
                    <ImageList dataList={this.state.imageList}
                               rowCount={3}
                               isShowImage={true}
                               isScroll={false}
                               text={"加盟合同书"}
                               textStyle={styles.imageTextStyle}
                               iconStyle={styles.imageStyle}/>
                </View>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    modelTextKey:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.themeColor,
    },
    oneText:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    titleFrame_btn_detail:{
        width:90,
        height:30,
        padding:0,
    },
    versionTable:{
        //margin:30,
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:0,
    },
    versionRow:{
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        flexDirection: 'row',
        //alignItems: 'center',
        //justifyContent: 'center',
        borderBottomColor:"#FEE0CA",
        backgroundColor:"#FEE0CA",
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
    },
    versionRowText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    versionRowIcon:{
        width:20,
        height:20,
        resizeMode:"contain",
    },
    baseModel:{
        padding:20,
    },
    model:{
        paddingTop:10,
        flexDirection: 'row',
        paddingBottom:20,
    },
    modelLeft:{
        flexDirection: 'row',
        width:450,
        //backgroundColor:Theme.Colors.backgroundColorBtn,
    },
    modelRight:{
        flexDirection: 'row',
        width:350,
        //backgroundColor:Theme.Colors.progressColor,
    },
    modelLeftTextKey:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    modelLeftTextValue:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.fontcolor,
    },
    segment:{
        paddingTop:20,
        width:730,
        borderTopWidth:1,
        alignItems: 'flex-start',
        borderTopColor:Theme.Colors.themeColor,
    },
    markModel:{
        alignItems: 'center',
        justifyContent: 'center',
    },
    markModelText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.themeColor,
    },
    markModelView:{
        backgroundColor:"#FDEFE3",
        width:700,
        height:250,
        borderWidth:1,
        borderColor:Theme.Colors.themeColor,
        padding:5,
    },
    markModel_son:{
        paddingTop:15,
    },
    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor_1,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        backgroundColor:'#FDF0EB',
        width:150,
        height:'150dw',
    },
});