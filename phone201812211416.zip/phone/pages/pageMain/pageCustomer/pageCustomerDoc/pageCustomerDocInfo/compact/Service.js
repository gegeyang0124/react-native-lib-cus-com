import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    /**
     * 获取客户基本资料
     */
    static getCustomerCompact(contract_sn){
        if(contract_sn != ''){
            return Http.get(HttpUrls.urlSets.urlCustomerCompact,{
                contract_sn :contract_sn})
                .then(retJson => {
                    return retJson.data;
                });
        }
    }
}