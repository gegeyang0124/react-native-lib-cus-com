/**
 * Created by Administrator on 2018/5/5.
 */

import {
    Theme,
} from "com";
import {
    TabNavigator,
} from 'comThird'
import DetailVisitRecord from "./detailVisitRecord/DetailVisitRecord";
import SaveVisitRecord from "./saveVisitRecord/SaveVisitRecord";
import ReturnVisitToRecord from "./returnVisitToRecord/ReturnVisitToRecord";

const TabRouteConfigs = {
    ReturnVisitToRecord: {
        screen: DetailVisitRecord,
        navigationOptions: ({navigation}) => ({
            title : '回访列表',
            tabBarLabel : '回访列表',
        }),
    },
    DetailVisitRecord: {
        screen: DetailVisitRecord,
        navigationOptions: ({navigation}) => ({
            title : '回访详情',
            tabBarLabel : '回访详情',
        }),
    },
    SaveVisitRecord: {
        screen: SaveVisitRecord,
        navigationOptions: ({navigation}) => ({
            title : '添加回访',
            tabBarLabel : '添加回访',
        }),
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;