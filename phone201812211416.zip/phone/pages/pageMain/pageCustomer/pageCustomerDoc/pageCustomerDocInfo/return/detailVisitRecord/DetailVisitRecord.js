import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TextInput,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    TextIcon,
    Charts,
    Tools,
    Theme,
    PickDropdownMonth,
    ButtonChange,
    SearchDDDIpt,
    ImageList,
    ImageChange,
    Media,
    MenuBottom,
} from "com";

import { Service } from "./Service";


type Props = {};
export default class DetailVisitRecord extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerRight:require('images/add.png'),
            headerRightHandle:()=>{
                // console.log(this.selectedValue)
                this.goPage("SaveVisitRecord", {
                    record_id:this.selectedValue.record_id,
                    resource_id:this.selectedValue.resource_id
                })
            },
        });

        this.params = {
            detail_id: '',//回访id
            member_id:'',//客户id
        };

        this.selectedValue = {
            name:'',
            status:'',
            revisit_name:'',
            storeInfo:'',
            customer_id:'',
            record_id:null,
            resource_id:null,
        }

        this.state = {
            handle_person_user_name:'',
            direction:'left',
            customer: [],
            handle_data:[],
            yesData:[],
            refresh: false,//是否刷新
            clearDrop: false,
            imageSignInList:[],//附件列
        };
    }

    componentWillEnter(params,action,page){

        if(BaseComponent.tmpData){
            this.selectedValue.storeInfo = BaseComponent.tmpData.store_code;
            this.selectedValue.storeId = BaseComponent.tmpData.storeId;
            this.selectedValue.level = BaseComponent.tmpData.clientSort;

            this.getData();
        }

    }

    getData(){
        Service.getDataList(this.selectedValue).then(retJson => {
            // console.log(retJson.length)

                this.selectedValue.record_id = retJson[0].record_id;
                this.selectedValue.resource_id = retJson[0].resource_id;
                this.params = {
                    member_id : retJson[0].resource_id
                };

                // console.log(this.selectedValue)
                Service.getDetail(this.params).then(retJson=>{
                    this.setState({
                        customer:retJson.customer,
                        handle_data:retJson.wechat,
                        yesData:retJson.yesData,
                    });
                });



        });

    }

    //遍历回答
    renderView = (item,index) =>{
        if(this.state.handle_person_user_name == ""){
            this.state.handle_person_user_name = item.handle_person_user_name;
        }else{
            if(this.state.handle_person_user_name != item.handle_person_user_name){
                this.state.handle_person_user_name = item.handle_person_user_name;
                this.state.direction = this.state.direction == 'left' ? 'right': 'left';
            }
        }

        return(
            <View>
               {/* 头像预留
               <Image style={styles.headPortrait}
                       source={{uri:item.portrait}}/>*/}
                <View style={this.state.direction == 'left' ? styles.replyLeft : styles.replyRight}>
                    <View>
                        <Text style={styles.reply_title}>{item.handle_person_position}-{item.handle_person_user_name}</Text>
                    </View>

                    <View style={styles.reply_detail}>
                        <Text style={styles.reply_data}>{item.handle_person_title}</Text>
                    </View>
                </View>
            </View>
        )
    };


    //遍历回答
    renderHandleView = (item,index) =>{
        var images = [];
        if(item.detail_file && item.detail_file != null && item.detail_file[0] != "" ){
            images = item.detail_file;
        }

        return(
            <View key={index}>
                <View style={styles.model2}>
                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>
                        <Text style={styles.titleText}>
                            主题：
                            {item.detail_title[0]}
                            {(item.detail_title2 == "" || item.detail_title2 == null) ? '' :('/'+item.detail_title2)}
                            {(item.detail_title3 == "" || item.detail_title3 == null) ? '' :('/'+item.detail_title3)}
                            {(item.detail_title4 == "" || item.detail_title4 == null) ? '' :('/'+item.detail_title4)}
                            {(item.detail_title5 == "" || item.detail_title5 == null) ? '' :('/'+item.detail_title5)}
                            {(item.detail_title6 == "" || item.detail_title6 == null) ? '' :('/'+item.detail_title6)}
                        </Text>
                    </View>

                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>

                        <Text style={styles.titleText}>
                            回访部门：{item.department}
                        </Text>

                        <Text style={styles.titleText}>
                            回访人员：{item.revisit_name}
                        </Text>
                    </View>

                    <View style={styles.title}>
                        <View style={styles.titleIco}></View>

                        <Text style={styles.titleText}>
                            回访时间：{item.create_time}
                        </Text>
                    </View>


                    <View style={styles.markModelView}>
                        <Text style={styles.modelLeftTextValue}>{item.detail_content}</Text>
                    </View>
                </View>

                {
                    item.detail_file != null ?
                    <View style={styles.model2}>
                        <View style={styles.title}>
                            <View style={styles.titleIco}></View>
                            <Text style={styles.titleText}>
                                附件
                            </Text>
                        </View>

                        <View>
                            <ImageList dataList={images}
                                       isScroll={true}
                                       isShowText={false}
                                       iconStyle={styles.imageStyle}
                                       frameRowStyle={styles.imageFrameRowStyle}
                                       frameStyle={styles.imageFramStyle}/>
                        </View>
                    </View>
                    :
                    null
                }

                { this.state.yesData ?
                    <View style={styles.model2}>
                        <View style={styles.title}>
                            <View style={styles.titleIco}></View>
                            <Text style={styles.titleText}>
                                处理回复
                            </Text>
                        </View>
                        {this.state.yesData.map(this.renderView)}
                    </View>
                    :
                    null
                }
            </View>
        )
    };


    render() {

        return (
            <ViewTitle>
                <View style={styles.model}>
                    <View style={styles.modelLeft}>
                        <View>
                            <Text style={styles.modelLeftTextKey}>客户姓名：</Text>
                            <Text style={styles.modelLeftTextKey}>省区经理：</Text>
                        </View>

                        <View>
                            <Text style={styles.modelLeftTextValue}>{this.state.customer.name}</Text>
                            <Text style={styles.modelLeftTextValue}>{this.state.customer.region_manager}</Text>
                        </View>

                    </View>

                    <View style={styles.modelRight}>
                        <View >
                            <Text style={styles.modelLeftTextKey}>手机号码：</Text>
                            <Text style={styles.modelLeftTextKey}>省　　市：</Text>
                            <Text style={styles.modelLeftTextKey}>招商经理：</Text>
                        </View>
                        <View >
                            <Text style={styles.modelLeftTextValue}>{this.state.customer.tel}</Text>
                            <Text style={styles.modelLeftTextValue}>{this.state.customer.province} {this.state.customer.city}</Text>
                            <Text style={styles.modelLeftTextValue}>{this.state.customer.investment_manager}</Text>
                        </View>

                    </View>
                </View>

                <View style={styles.interval}></View>

                { this.state.handle_data.length > 0 ?

                    this.state.handle_data.map(this.renderHandleView)
                    :
                    null
                }
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    model:{
        flexDirection: 'row',
        padding:20,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    model2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    modelLeft:{
        flexDirection: 'row',
        width:450,
        //backgroundColor:Theme.Colors.backgroundColorBtn,
    },
    modelRight:{
        marginLeft:10,
        flexDirection: 'row',
        width:350,
        //backgroundColor:Theme.Colors.progressColor,
    },
    modelLeftTextKey:{
        paddingBottom:3,
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    modelLeftTextValue:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    segment:{
        paddingTop:20,
        width:730,
        borderTopWidth:1,
        alignItems: 'flex-start',
        borderTopColor:Theme.Colors.themeColor,
    },
    markModel:{
        alignItems: 'center',
        justifyContent: 'center',
    },
    markModelText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.themeColor,
    },
    interval:{
        height:10,
    },
    titleFrame_btn:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },
    titleFrame_btn_detail:{
        height:Theme.Height.height1,
        padding:5,
        marginBottom:20,
        width:120,
    },
    //通用分类标签
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:5,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize_1,
        marginLeft:20,
    },
    markModelView:{
        //alignItems: 'center',
        //justifyContent: 'center',
        left:20,
        backgroundColor:"#FDEFE3",
        width:700,
        height:200,
        padding:5,
    },
    agreement:{
        paddingTop:15,
        paddingBottom:15,
    },
    imageStyle:{
        width:150,
        height:'150dw',
    },
    imageFrameRowStyle:{
        flex:1,
    },
    imageFramStyle:{
        flexDirection: 'row',
    },
    headPortrait:{
        width:100,
        height:200,
    },
    reply_title:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    reply_data:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    reply_detail:{
        backgroundColor:'#FDF0EB',
    },
    replyLeft:{
        alignItems: 'center',
        justifyContent: 'flex-start',
    },
    replyRight:{
        alignItems: 'center',
        justifyContent: 'flex-end',
    },
});