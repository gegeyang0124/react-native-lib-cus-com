import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }
    /**
     * 获取搜索数据
     * @param val
     * @param init
     */
    static getDetail(val,init){
        return Http.get(HttpUrls.urlSets.urlCustomerReturnDetail,
            {member_id:val.member_id})
            .then(retJson => {
                return retJson.data;
            });
    }

    /**
     * 获取回访列表数据
     * @param val
     * @param init
     */
    static getDataList(val,init){

        return Http.get(HttpUrls.urlSets.urlCustomerReturn,
            {storecode: val.storeInfo,
            })
            .then(retJson => {
                return retJson.data.content;
            });
    }
}