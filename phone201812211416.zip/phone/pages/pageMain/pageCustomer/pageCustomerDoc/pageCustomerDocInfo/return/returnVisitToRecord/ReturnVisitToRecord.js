import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    TextIcon,
    Charts,
    Tools,
    Theme,
    PickDropdownMonth,
    ButtonChange,
    PickDropdown,
    SearchDDDIpt,
    ButtonTime,
} from "com";

import { Service } from "./Service";
import SaveVisitRecord from "../saveVisitRecord/SaveVisitRecord";


type Props = {};
export default class ReturnVisitToRecord extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerRight:require('images/info.png'),
            headerRightHandle:()=>{

                this.goPage("SaveVisitRecord", {
                        record_id:this.selectedValue.record_id,
                        resource_id:this.selectedValue.resource_id
                })
            },
        });

        this.selectedValue = {
            name:'',
            status:'',
            revisit_name:'',
            storeInfo:'',
            customer_id:'',
            record_id:null,
            resource_id:null,
        }

        this.state = {
            clearDrop:false,
            id: null,  //任务id
            statusList:['待处理','未处理','已处理'],
            data: [],
        }

        this.setParams({
            headerLeft: true,
            headerRight:true,
            // headerRightHandle:()=>{
            //     this.goPage("SaveVisitRecord");
            // },
        });
    }


    componentWillEnter(params){
        if(BaseComponent.tmpData){
            this.selectedValue.storeInfo = BaseComponent.tmpData.store_code;
            this.selectedValue.storeId = BaseComponent.tmpData.storeId;
            this.selectedValue.level = BaseComponent.tmpData.clientSort;

            this.getData();
        }
    }

    //查看详情
    onSearch(item){
        this.goPage("DetailVisitRecord", {
            record_id:this.selectedValue.record_id,
            resource_id:this.selectedValue.resource_id});
    }

    renderItem = (item,i)=>{
        return(
            <View style={styles.modelList}>
                <View style={styles.title}>
                    <View style={styles.titleIco}></View>
                    <Text style={styles.titleText}>主题：{item.detail_title}</Text>
                    <Text style={styles.titleRightText}>{item.detail_handle_status == 0 ? "待处理" : "已处理"}</Text>
                </View>
                <View style={styles.segment}></View>

                <View style={styles.title_mark}>
                    <View style={styles.title_mark_view}>
                        <Text style={styles.mainView}>客户姓名：{item.name}</Text>
                        <Text style={styles.mainView}>回访专员：{item.revisit_name}</Text>
                    </View>
                    <View style={styles.title_mark_view2}>
                        <Text style={styles.mainView}>签约时间：{item.sign_time}</Text>
                        <Text style={styles.mainView}>加盟级别：{item.shop_rank}</Text>
                    </View>
                    <View>
                        <ButtonChange text={"查看详情"}
                                      onPress={() => this.onSearch(item)}
                                      textStyle={styles.viewText}
                                      style={styles.buttonStyle}/>
                    </View>
                </View>
                <View style={styles.lastView}>
                    <Text style={styles.lastTime}>回访时间：{item.create_time}</Text>
                </View>
            </View>
        );
    };

    onSelectState = (val)=>{
        if(val.name == '待处理'){
            this.selectedValue.status = 0;
        }else if(val.name == '未处理'){
            this.selectedValue.status = 1;
        }else if(val.name == '已处理'){
            this.selectedValue.status = 2;
        }
    }

    onChangeText = (text)=>{
        this.selectedValue.revisit_name = text;
    };

    //搜索
    onSelect =()=>{
        this.getData();
    };

    getData(){
        Service.getDataList(this.selectedValue).then(retJson => {
            this.selectedValue.record_id = retJson[0].record_id;
            this.selectedValue.resource_id = retJson[0].resource_id;

            this.setState({
                data: retJson,
            });

        })
    }

    render() {
        return (
            <ViewTitle>
                <View style={styles.titleFrame}>
                    <View style={styles.titleModel}>

                        <SearchDDDIpt refresh={this.state.refresh}
                                      frameStyle={styles.searchStyle}
                                      options1={{
                                          defaultValue: '选择状态',
                                          options: this.state.statusList,
                                          clearDrop: this.state.clearDrop,
                                          onSelect: (i, val) => this.onSelectState(val,i)
                                      }}
                                      isPickDropdown2={false}
                                      isPickDropdown3={false}
                                      placeholder={"--回访专员--"}
                                      textChange={(val) => this.onChangeText(val)}
                                      onPressSearch={() => this.onSelect()}/>
                    </View>
                </View>

                <View style={styles.interval}></View>

                {this.state.data.map(this.renderItem)}
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        //height:100,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingLeft:15,
        paddingRight:15,
    },
    titleFrame_1:{
        flexDirection:'row',
        alignItems: 'center',
        justifyContent:'flex-start',
    },
    titleFrame_2:{
        paddingLeft:20,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent:'flex-start',
    },
    titleFrame_Text0:{
        fontSize:Theme.Font.fontSize_1,
        marginRight:5,
    },
    buttonHead_text:{
        fontSize:Theme.Font.fontSize_1,
    },
    titleFrame_btn:{
        height:Theme.Height.height2,
        padding:5,
        width:120,
    },
    button_submit:{
        width:150,
        justifyContent:'center',
        alignItems: 'flex-end',
        height:80,
    },
    button_add:{
        justifyContent:'center',
        alignItems: 'flex-start',
        height:80,
        paddingLeft:10,
        width:150,
    },
    modelList:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    //通用分类标签
    title:{
        margin:10,
        flexDirection:'row',
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        color:Theme.Colors.themeColor,
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
        width:650,
    },
    titleRightText:{
        color:Theme.Colors.themeColor,
        fontSize:Theme.Font.fontSize,
        justifyContent:'flex-end',
        alignItems: 'flex-end',
    },
    title_mark:{
        paddingTop:10,
        paddingLeft:20,
        flexDirection:'row',
    },
    titleModel:{
        paddingTop:20,
        flexDirection:'row',
    },
    titleModel2:{
        justifyContent:'flex-end',
        alignItems: 'flex-end',
        flexDirection:'row',
    },
    segment:{
        left:10,
        width:750,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    interval:{
        height:10,
    },
    title_mark_view2:{
        width:455,
    },
    mainView:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor,
    },
    lastView:{
        paddingTop:10,
        paddingLeft:20,
        paddingBottom:10,
    },
    lastTime:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    title_mark_view:{
        width:200,
    },
    viewText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.colorFontBtn,
    },
    buttonStyle:{
        padding:5,
    },
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize: Theme.Font.fontSize,
            width: Theme.Width.width1 + Theme.Height.height1,
            height: Theme.Height.height1,
            padding: 0,
            paddingLeft: 10,
            paddingBottom: 10,
            marginTop: 15,
            marginLeft: -20,
        },
});