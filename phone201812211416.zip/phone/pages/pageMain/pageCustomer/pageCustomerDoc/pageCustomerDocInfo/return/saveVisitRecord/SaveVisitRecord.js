import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TextInput,
} from 'react-native';
import {
    Http,
    HttpUrls,
} from "com-api";
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    TextIcon,
    Charts,
    Tools,
    Theme,
    PickDropdown,
    ButtonChange,
    SearchDDDIpt,
    ImageList,
    ImageChange,
    Media,
    MenuBottom,
    ItemRowTripApply
} from "com";

import { Service } from "./Service";
import camera from 'images/camera.png'


type Props = {};
export default class SaveVisitRecord extends BaseComponent<Props> {

    dropList = {
        types1: {
            name:["请选择","常规回访","异常回访"],
            code:{"常规回访":1,"异常回访":2},
            value:'',
            clearDrop:false,
        },//一级品类 数据
        types2: {
            name:["请选择"],
            code:{},
            clearDrop:false,
        },//二级品类 数据
        types3: {
            name:["请选择"],
            code:{},
            clearDrop:false,
        },//三级品类 数据
        types4: {
            name:["请选择"],
            code:{},
            clearDrop:false,
        },//四级品类 数据
    };

    selectValue = {
        type1_theme:'',
        type2_theme:'',
        type3_theme:'',
        type4_theme:'',
        images:[],
        type:'',
        from_name:'',
        handle_person_title:'',
        theme_id:'',
        member_id:null,
        record_id:null,
        content:[],
    }

    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true
        });

        this.state = {
            id: null,//任务id
            dataList: [],//数组列表SS
            dataList2:[],
            refresh: false,//是否刷新
            clearDrop: false,
            isVisible:'none',//是否显示提交图标
            imageSignInList:[],
            textMark:'',
            source:[
                {name:'去电',id:'1'},
                {name:'来电',id:'2'},
                {name:'上访',id:'3'}
            ],
            type:[
                {name:'新客户回访',id:'1'},
                {name:'常规回访',id:'2'}
            ],
            text:'',
            resize:false
        };

        this.btnList = [
            {text:'拍摄',onPress:this.onGetPic},
            {text:'选取',onPress:this.onGetPic}
        ];
    }

    /* getData(val){
         Service.getVisitRecordSelect(val).then(retJson=>{
             this.dropList.types1 = retJson;
         });
     }*/

    //获取图片
    onGetPic = (item,i)=>{
        let imageSignInList = [];

        if(this.state.imageSignInList.length > 0){
            this.state.imageSignInList.forEach((val,i,arr) =>{
                imageSignInList.push(val);
            });
        }

        if(i == 0){
            Media.takeImage("",false).then(retJson=>{

                MenuBottom.show(false);
                imageSignInList.push(retJson.path);

                this.setState({
                    imageSignInList:imageSignInList
                });
            })
        }else if(i == 1){

            Media.pickImage(false,"",false).then(retJson=>{

                MenuBottom.show(false);

                imageSignInList.push(retJson.path);

                this.setState({
                    imageSignInList:imageSignInList
                });

            });
        }
        this.selectValue.images = imageSignInList;
    }

    /**
     * 获取回访主题
     * @param code int,//父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    getDataGoodsTypes(code,type){
        Service.getVisitRecordSelect(code).then(retJson =>{
            if(type == 0){
                this.dropList.types1 = retJson;
            }else if(type == 1){
                this.dropList.types2 = retJson;
            }else  if(type == 2){
                this.dropList.types3 = retJson;
            }else  if(type == 3){
                this.dropList.types4 = retJson;
            }

            this.setState({
                refresh:true,
                clearDrop:false
            });

        });
    }

    onSelectDrop(i,val,type){
        if(type == 1){
            this.dropList.types2.name = [];
            this.dropList.types2.clearDrop = true;

            this.dropList.types3.name = [];
            this.dropList.types3.clearDrop = true;

            this.dropList.types4.name = [];
            this.dropList.types4.clearDrop = true;

            this.selectValue.theme_id = this.dropList.types1.code[val.name];

            this.selectValue.type1_theme = val.name;

            if(this.selectValue.theme_id != '') {
                this.getDataGoodsTypes(this.selectValue.theme_id,type);
            }

            this.setState({
                refresh:false,
                clearDrop:true
            });
        }

        if(type == 2){

            this.dropList.types3.name = [];
            this.dropList.types3.clearDrop = true;

            this.dropList.types4.name = [];
            this.dropList.types4.clearDrop = true;

            this.selectValue.theme_id = this.dropList.types2.code[val.name];

            this.selectValue.type2_theme = val.name;

            if(this.selectValue.theme_id != ''){
                this.getDataGoodsTypes(this.selectValue.theme_id,type);
            }

            //alert(JSON.stringify(this.dropList.types3));

            this.setState({
                refresh:false,
                clearDrop:true
            });

        }
        if(type == 3){

            // this.dropList.types4.name = [];
            // this.dropList.types4.clearDrop = true;

            // this.selectValue.theme_id = this.dropList.types3.code[val.name];

            this.selectValue.type3_theme = val.name;

            // if(this.selectValue.theme_id != ''){
            //     this.getDataGoodsTypes(this.selectValue.theme_id,type);
            // }
            //
            // this.setState({
            //     refresh:false,
            //     clearDrop:false
            // });
        }
        if(type == 4){
            this.selectValue.type4_theme = val.name;
            // this.selectValue.theme_id = this.dropList.types4.code[val.name];
        }
    }

    //选择来源
    onSelectSource(val){
        this.selectValue.from_name = val.name;
    }

    //选择类型
    onSelectType(val){
        this.selectValue.type = val.name;
    }

    //说明
    onChangeText = (item)=>{
        this.selectValue.handle_person_title = item;
    };

    onSelect =()=>{
        Service.getDataList(this.selectedValue)
    };

    onAdd =()=>{
        let foo = [];

        let detail_title = [];



        if(this.selectValue.type3_theme){
            detail_title.push(this.selectValue.type3_theme);
            if(this.selectValue.type4_theme){
                detail_title.push(this.selectValue.type4_theme);
                if(this.selectValue.type1_theme){
                    detail_title.push(this.selectValue.type1_theme);
                    if(this.selectValue.type2_theme){
                        detail_title.push(this.selectValue.type2_theme);
                        if(!this.state.text){
                            Tools.toast('请输入文字')
                        }
                    }else{
                        Tools.toast('请输入主题')
                    }
                }else{
                    Tools.toast('请输入主题')
                }
            }else{
                Tools.toast('请输入服务类型')
            }
        }else{
            Tools.toast('请输入来源')
        }

        if(this.selectValue.type1_theme&&this.selectValue.type2_theme&&this.selectValue.type3_theme&&this.selectValue.type4_theme&&this.state.text){
            this.selectValue.handle_person_title= this.state.text;
            let title = this.state.text;

            //if(this.selectValue.images.length > 0){

            this.state.dataList2.push(this.selectValue);

            //去除已填写数据
            this.state.imageSignInList = [];
            //this.selectValue.handle_person_title = "";

            if(this.state.dataList2.length > 0){
                this.state.dataList2.forEach((val,i,arr) =>{
                    console.info("val"+JSON.stringify(val));
                    foo.push(val);
                });
            }

            this.state.isVisible = 'flex';

            let temp = {
                detail_content: title,
                detail_title: detail_title,
                handle_status: 0,
            };

            this.selectValue.content.push(temp);

            this.setState({
                textMark:'',
                dataList:foo,

            })
        }

        //上传图片
        /* Http.upLoadFileToService(this.selectValue.images).then(resJson => {
             let temp = {
                 detail_file: resJson[0].servicePath,
                 detail_content: title,
                 detail_title: detail_title,
                 handle_status: 0,
             };
             this.selectValue.content.push(temp);

             foo.images = temp.detail_file;
             console.log(JSON.stringify(foo));
             this.setState({
                 textMark:'',
                 dataList:foo
             })
         });*/

        //}
    };

    //删除
    onRemove =(item,i)=>{

        let a =[];
        this.state.dataList2.splice(i,1);

        if(this.state.dataList2.length > 0){
            this.state.dataList2.forEach((val,i,arr) =>{
                a.push(val);
            });
        }

        if(a.length <= 0){
            this.state.isVisible = 'none';
        }

        this.setState({dataList:a});

    };

    //保存数据
    onSave =()=>{

        let params = {
            record_id:this.selectValue.record_id,
            member_id:this.selectValue.member_id,
            type:1,
            from_name:this.selectValue.from_name,
            effective:1,
            content:this.selectValue.content,
            level:"低",
        };

        Service.saveData(params).then(respose => {
            //清空提交的数据
            this.selectValue = {
                type1_theme:'',
                type2_theme:'',
                type3_theme:'',
                type4_theme:'',
                images:[],
                type:'',
                from_name:'',
                handle_person_title:'',
                theme_id:'',
                member_id:null,
                record_id:null,
                content:[],
            }
            //清空以选数据
            this.setState({
                    textMark:'',
                    dataList:[],
                    dataList2:[],
                    text:'',
                    resize:true
                }
            )
            Tools.toast("添加成功");
            this.goBack();
        }).catch(retJson=> {
            Tools.toast("添加失败，请联系管理员");
        });
    };

    componentWillEnter(param){
        this.setState({resize:false})
        if(param && param.record_id != null && param.resource_id != null){
            this.selectValue.member_id = param.resource_id;
            this.selectValue.record_id = param.record_id;
        }
    }

    renderItem = (item,i)=>{
        if(item.type1_theme != undefined){
            return(
                <View key={i}>
                    <View style={styles.modelList}>
                        <View style={styles.model_title}>
                            <View style={styles.title}>
                                <View style={styles.titleIco}></View>
                                <Text style={styles.titleText}>主题{i+1}</Text>
                                <Text style={styles.titleText_2}>
                                    {item.type1_theme} {item.type2_theme} {item.type3_theme} {item.type4_theme}
                                </Text>
                            </View>
                            <View style={styles.title}>
                                <View style={styles.titleIco}></View>
                                <Text style={styles.titleText}>说明</Text>
                                <Text style={styles.titleText_2}>{item.handle_person_title}</Text>
                            </View>
                            {/*<View style={styles.title}>
                                <View style={styles.titleIco}></View>
                                <Text style={styles.titleText}>附件</Text>
                                <ImageList dataList={item.images} iconStyle={styles.imagesStyle}/>
                            </View>*/}
                        </View>
                        <View style={styles.model_remove_button}>
                            <ButtonChange text={"删除"}
                                          onPress={()=>this.onRemove(item,i)}
                                          textStyle={styles.buttonHead_text}
                                          style={styles.titleFrame_btn}
                                          iconStyle={styles.imageStyle}/>
                        </View>
                    </View>
                    <View style={styles.segment}></View>
                </View>
            );
        }
    };


    render() {
        return (
            <ViewTitle>
                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"来源"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenterProps={{
                                          defaultValue:"请选择",
                                          clearDrop: this.state.resize,
                                          options:this.state.source,
                                          onSelect:(i,val)=>this.onSelectDrop(i,val,3)

                                      }}/>

                    <ItemRowTripApply text={"服务类型"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenterProps={{
                                          defaultValue:"请选择",
                                          options:this.state.type,
                                          clearDrop: this.state.resize,
                                          onSelect:(i,val)=>this.onSelectDrop(i,val,4)
                                      }}/>

                </View>

                <View style={styles.visitColor}>
                    <Text style={styles.versionRowText}>添加回访主题</Text>
                </View>

                <View style={styles.addVisit}>
                    <View style={styles.addVisitView_left}>
                        <View style={styles.addVisitView_left_1}>
                            <Text style={styles.titleFrame_2_text}>选择主题</Text>
                        </View>
                        <View style={styles.addVisitView_left_2}>
                            <Text style={styles.titleFrame_2_text}>说明</Text>
                        </View>
                        {/* <View style={styles.addVisitView_left_3}>
                            <Text style={styles.titleFrame_2_text}>附件</Text>
                        </View>*/}
                    </View>

                    <View style={styles.addVisitView_right}>
                        <View style={styles.addVisitView_right_1}>
                            <SearchDDDIpt refresh={this.state.refresh}
                                          options1={{
                                              defaultValue: '请选择',
                                              options: this.dropList.types1.name,
                                              clearDrop: this.state.resize,
                                              onSelect: (i, val) => this.onSelectDrop(i, val, 1)
                                          }}
                                          options2={{
                                              defaultValue:'请选择',
                                              options: this.dropList.types2.name,
                                              clearDrop: this.state.resize,
                                              onSelect: (i, val) => this.onSelectDrop(i, val, 2)
                                          }}
                                /*options3={{
                                    defaultValue:this.dropList.types3.name[0] == undefined
                                        ? '请选择'
                                        : this.dropList.types3.name[0],
                                    options: this.dropList.types3.name,
                                    clearDrop: this.dropList.types3.clearDrop,
                                    onSelect: (i, val) => this.onSelectDrop(i, val, 3)
                                }}
                                options4={{
                                    defaultValue:this.dropList.types4.name[0] == undefined
                                        ? '请选择'
                                        : this.dropList.types4.name[0],
                                    options: this.dropList.types4.name,
                                    clearDrop: this.dropList.types4.clearDrop,
                                    onSelect: (i, val) => this.onSelectDrop(i, val, 4)
                                }}*/
                                          isTextInput={false}
                                          isSearch={false}
                                          isPickDropdown3={false}
                                          isPickDropdown4={false}/>
                        </View>

                        {/*<View style={styles.addVisitView_right_2}>
                            <View style={styles.versionTable}>
                                <View style={styles.markModelView}>
                                    <TextInput onChangeText={text=>this.setState({text})}
                                               multiline={true}
                                               defaultValue={this.state.text}
                                               clearButtonMode={"always"}
                                               underlineColorAndroid={"#FDEFE3"}
                                               style={styles.modelLeftTextValue}/>
                                </View>
                            </View>
                        </View>*/}

                        <TextInput onChangeText={text=>this.setState({text})}
                                   multiline={true}
                                   defaultValue={this.state.text}
                                   clearButtonMode={"always"}
                                   underlineColorAndroid={"#FDEFE3"}
                                   style={styles.markModelView}/>

                        {/* <View style={styles.addVisitView_right_3}>
                            <ImageList dataList={this.state.imageSignInList}
                                       iconStyle={styles.imagesStyle}/>

                            <ImageChange icon={camera}
                                         onPress={()=>MenuBottom.show(true)}
                                         style={styles.characterStyle}>

                            </ImageChange>
                        </View>*/}

                        <View style={styles.button_add}>
                            <ButtonChange text={"添加"}
                                          onPress={this.onAdd}
                                          textStyle={styles.buttonHead_text}
                                          style={styles.titleFrame_btn}/>
                        </View>
                    </View>
                </View>
                <View style={styles.segment}></View>

                {
                    this.state.dataList.map(this.renderItem)
                }

                <View style={[styles.model_2,{display:this.state.isVisible}]}>
                    <ButtonChange text={"提交"}
                                  onPress={this.onSave}
                                  textStyle={styles.buttonHead_text}
                                  style={styles.titleFrame_btn}/>
                </View>

                <MenuBottom btnList={this.btnList}
                            isVisibleClose={false}/>
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({

    versionRowText:{
        fontSize:Theme.Font.fontSize1,
        color:Theme.Colors.fontcolor,
    },
    visitColor:{
        paddingLeft: 10,
        paddingRight: 10,
        paddingTop: 5,
        paddingBottom: 5,
        borderBottomColor:"#FEE0CA",
        backgroundColor:"#FEE0CA",
    },
    titleFrame:{
        //height:80,
        backgroundColor:Theme.Colors.foregroundColor,
        //flexDirection:'row',
        paddingLeft:15,
        paddingRight:15,
        paddingBottom:20,
    },
    titleFrame_1:{
        flex:1,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent:'center',
    },
    titleFrame_2:{
        flex:1,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent:'center',
    },
    titleFrame_2_text:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.fontcolor,
    },
    titleFrame_Text0:{
        fontSize:Theme.Font.fontSize,
        marginRight:5,
    },
    buttonHead_text:{
        fontSize:Theme.Font.fontSize,
    },
    titleFrame_btn:{
        height:Theme.Height.height2,
        padding:5,
        width:120,
    },
    button_submit:{
        width:335,
        justifyContent:'center',
        alignItems: 'flex-end',
        height:80,
    },
    button_add:{
        justifyContent:'flex-end',
        alignItems: 'flex-end',
        width:500,
        paddingTop:10,
    },
    modelList:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
    },
    //通用分类标签
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize_1,
        marginLeft:10,
        color:Theme.Colors.themeColor,
    },
    titleText_2:{
        fontSize:Theme.Font.fontSize_1,
        marginLeft:10,
        color:Theme.Colors.minorColor,
    },
    title_mark:{
        paddingLeft:20,
        paddingRight:20,
        justifyContent:'center',
        alignItems: 'center',
    },
    title_mark_text:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.minorColor,
    },
    segment:{
        left:10,
        height:15,
        width:750,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    interval:{
        height:10,
    },
    markModelView:{
        backgroundColor:"#FDEFE3",
        width:500,
        height:100,
        borderWidth:1,
        borderColor:Theme.Colors.themeColor,
        padding:5,
    },
    versionTable:{
        width:510,
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:0,
    },
    addVisit:{
        height:350,
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
    },
    addVisitView_left:{
        width:140,
        alignItems: 'flex-end',
        justifyContent: 'flex-start',
    },
    addVisitView_right:{
        left:10,
        width:510,
        alignItems: 'flex-start',
        justifyContent: 'flex-start',
    },
    addVisitView_left_1:{
        justifyContent: 'center',
        height:60,
    },
    addVisitView_left_2:{
        justifyContent: 'flex-start',
        height:120,
    },
    addVisitView_left_3:{
        justifyContent: 'flex-start',
        height:30,
    },
    addVisitView_right_1:{
        height:60,
        justifyContent: 'center',
    },
    addVisitView_right_2:{
        height:110,
        justifyContent: 'center',
    },
    addVisitView_right_3:{
        flexDirection:'row',
        height:130,
        width:500,
        justifyContent: 'center',
    },
    model_2:{
        paddingTop:10,
        alignItems: 'center',
        justifyContent: 'center',
    },
    titleFrame_btn:{
        padding:5,
        width:90,
        height:Theme.Height.height1,
        marginBottom:5,
    },
    characterStyle:{
        width:50,
        height:40,
    },
    model_title:{
        width:650,
    },
    model_remove_button:{
        alignItems: 'flex-end',
        padding:10,
    },
    btn:{
        marginBottom:20,
    },
    imagesStyle:{
        width:160,
        height:'160dw',
        padding:10,
    },
    //下拉框样式
    titleFrameTop:{
        paddingTop:20,
        //left:50,
        //width:150,
    }
});