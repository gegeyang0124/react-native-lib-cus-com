import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {

    static base;

    constructor() {
        Service.base = this;
    }

    /**
     * 获取搜索数据
     * @param val
     * @param init
     */
    static getVisitRecordSelect(val){
        let themeList = {
                name:["请选择"],
                code:{},
                clearDrop:false,
        };

        return Http.get(HttpUrls.urlSets.urlCustomerTheme)
            .then(retJson => {
                if(val == 1){
                    retJson.data[0].child.forEach((val,i,a)=>{
                        themeList.name.push(val.category_name);
                        themeList.code[val.category_name] = val.category_id;
                    });
                    console.log("1->"+JSON.stringify(themeList))
                    return themeList;
                }else if(val == 2){
                    retJson.data[1].child.forEach((val,i,a)=>{
                        themeList.name.push(val.category_name);
                        themeList.code[val.category_name] = val.category_id;
                    });
                    return themeList;

                }else if(val >= 3 && val <=5){
                    //第三层
                    let number = val - 3;
                    retJson.data[0].child[number].child.forEach((val,i,a)=>{
                        themeList.name.push(val.category_name);
                        themeList.code[val.category_name] = val.category_id;
                    });
                    return themeList;
                }else if(val >= 23 && val <= 28){
                    //第三层
                    let number = val - 23;
                    retJson.data[1].child[number].child.forEach((val,i,a)=>{
                        themeList.name.push(val.category_name);
                        themeList.code[val.category_name] = val.category_id;
                    });
                    return themeList;
                }
            });
    }

    static saveData(val){
        return Http.post(HttpUrls.urlSets.urlCustomerReturnAdd,val)
            .then(retJson => {
                console.log(retJson);
                return retJson;
            });
    }
}