import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retData: [],
        total: 0,
        has: false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    paramsFetch = {
        pageNumber:1,
        executing:false,//是否正在执行中
    };

    /**
     * 提交搜索数据
     * @param val 参数
     */
    static get(val,init) {

        init = init == undefined ? false : init;

        if(init || this.base == undefined){
            new Service();
        }

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retJson.retData = [];
        }


        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }else {
            this.base.paramsFetch.executing = true;
        }


        if(val == undefined){
            return Http.get(HttpUrls.urlSets.urlCustomerListGet,
                {jobGrade:Tools.userConfig.userInfo.job_grade,
                    userId :Tools.userConfig.userInfo.id,
                    number :this.base.paramsFetch.pageNumber,
                    size: 10},init)
                .then(retJson => {
                    return retJson.retData;
                });
        }else{
            return Http.get(HttpUrls.urlSets.urlCustomerListGet,
                {regionId:val.regionId,provincialId:val.provincialId,
                    userId :Tools.userConfig.userInfo.id,
                    number :this.base.paramsFetch.pageNumber,
                    size: 10,cityId:val.cityId,
                    jobGrade:Tools.userConfig.userInfo.job_grade,
                    customerName:val.customerName,
                    queryType:val.queryType
                },init)
                .then(retJson => {
                    return retJson.retData;
                });
        }
    }


    /**
     * 获取客户详情
     */
    static getStoreAmount(code,time){
        return Http.get(HttpUrls.urlSets.urlCustomerDetailSum,
            {storeCode:code,month:time})
            .then(retJson => {
                return retJson.retData;
            });
    }
}