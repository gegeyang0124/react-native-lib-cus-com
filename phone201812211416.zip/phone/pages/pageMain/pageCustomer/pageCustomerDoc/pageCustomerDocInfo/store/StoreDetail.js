import React, {Component} from 'react';
import {
    View,
    Text,
    TouchableOpacity,
} from 'react-native';
import {
    ViewTitle,
    BaseComponent,
    Tools,
    WebViewCus,
    Theme,
    SwiperImage,
    StyleSheetAdapt,
    TextDoubleIcon,
    ImageView,
    Image,
    ButtonChange,
    ItemRowGuideTripApply,
    ImageList,
    TitleRow,
} from "com";
import { Service, } from "./Service";

/**
 * 店铺营业
 * **/
type Props = {};
export default class StoreDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.execFirst = true;

        this.setParams({
            headerLeft:true
        });

        this.state = {
            baseList:{},
        }
    }

    componentWillEnter(params,action,page){
        if(BaseComponent.tmpData.store_info != null){
            this.getData();
        }
    }

    getData = (time)=>{
        time = time == undefined ? new Date().getTime() : time;

        Service.getStoreAmount(BaseComponent.tmpData.store_info,Tools.timeFormatConvert(time,"YYYY-MM"))
            .then(retJson=>{
                var growthRate_01 = (retJson.qoq_month_sale_amount * 100).toFixed(2);
                var growthRate_02 = (retJson.qoq_order_count * 100).toFixed(2);
                var growthRate_03 = (retJson.qoq_single_price * 100).toFixed(2);

                this.setState({
                    baseList:{
                        currentMonthAmount:retJson.this_sales_amount,
                        lastMonthAmount:retJson.prev_sales_amount,
                        growthRate_01:growthRate_01,
                        currentMonthOrderSum:retJson.this_order_count,
                        lastMonthOrderSum:retJson.pre_order_count,
                        growthRate_02:growthRate_02,
                        currentMonthCustomerPrice:retJson.this_single_price,
                        lastMonthCustomerPrice:retJson.prev_single_price,
                        growthRate_03:growthRate_03,
                        currentMonthPureProfit:retJson.this_gross_profit,
                        currentMonthNewMember:retJson.monthMemberCount,
                        memberSum:retJson.thisMemberCount,
                        balance:retJson.account,
                    }
                });
            });
    }

    render() {
        return (
            <ViewTitle>
                <TitleRow frameStyle={styles.titleFrame}
                          onPressLeft={this.getData}
                          onPressRight={this.getData}
                          onPressCenter={this.getData}
                          textLeft={"上一月"}
                          textRight={"下一月"}/>

                <View style={styles.store}>
                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_1_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_1_text_number}>{this.state.baseList.currentMonthAmount}</Text>
                                元
                            </Text>
                            <Text style={styles.scpre_params_text}>本月营业额</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_2_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_2_text_number}>{this.state.baseList.lastMonthAmount}</Text>
                                元
                            </Text>
                            <Text style={styles.scpre_params_text}>上月营业额</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_3_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_3_text_number}>{this.state.baseList.growthRate_01}</Text>
                                %
                            </Text>
                            <Text style={styles.scpre_params_text}>环比增长率</Text>
                        </View>
                    </View>

                </View>
                <View style={styles.interval}></View>
                <View style={styles.store}>
                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_1_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_1_text_number}>{this.state.baseList.currentMonthOrderSum}</Text>
                                人
                            </Text>
                            <Text style={styles.scpre_params_text}>本月客单量</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_2_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_2_text_number}>{this.state.baseList.lastMonthOrderSum}</Text>
                                人
                            </Text>
                            <Text style={styles.scpre_params_text}>上月客单量</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_3_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_3_text_number}>{this.state.baseList.growthRate_02}</Text>
                                %
                            </Text>
                            <Text style={styles.scpre_params_text}>环比增长率</Text>
                        </View>
                    </View>

                </View>
                <View style={styles.interval}></View>
                <View style={styles.store}>
                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_1_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_1_text_number}>{this.state.baseList.currentMonthCustomerPrice}</Text>
                                元
                            </Text>
                            <Text style={styles.scpre_params_text}>本月客单价</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_2_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_2_text_number}>{this.state.baseList.lastMonthCustomerPrice}</Text>
                                元
                            </Text>
                            <Text style={styles.scpre_params_text}>上月客单价</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_3_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_3_text_number}>{this.state.baseList.growthRate_03}</Text>
                                %
                            </Text>
                            <Text style={styles.scpre_params_text}>环比增长率</Text>
                        </View>
                    </View>

                </View>
                <View style={styles.interval}></View>
                <View style={styles.store}>
                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_1_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_1_text_number}>{this.state.baseList.currentMonthPureProfit}</Text>
                                元
                            </Text>
                            <Text style={styles.scpre_params_text}>本月毛利额</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_2_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_2_text_number}>{this.state.baseList.currentMonthNewMember}</Text>
                                人
                            </Text>
                            <Text style={styles.scpre_params_text}>本月新增会员</Text>
                        </View>
                    </View>

                    <View style={styles.score_params}>
                        <View style={[styles.score_params_1_3_titleIco,styles.score_params_titleIco]}></View>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_1_3_text_number}>{this.state.baseList.memberSum}</Text>
                                人
                            </Text>
                            <Text style={styles.scpre_params_text}>会员总数</Text>
                        </View>
                    </View>

                </View>
                <View style={styles.interval}></View>

                <View style={styles.balance}>
                    <View style={styles.balance_icon}>
                        <View style={[styles.score_params_1_1_titleIco,styles.score_params_balance]}></View>
                    </View>
                    <View style={styles.balance_data}>
                        <View style={styles.scpre_params_view}>
                            <Text style={styles.scpre_params_text}>账户余额</Text>
                            <Text style={styles.scpre_params_text}>
                                <Text style={styles.scpre_params_balance_text_number}>{this.state.baseList.balance}</Text>
                                元
                            </Text>
                        </View>
                    </View>
                </View>
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    balance:{
        height:100,
        backgroundColor:"#FEF0E4",
        flexDirection:'row',
    },
    balance_icon:{
      width:20,
    },
    balance_data:{
        height:100,
        width:200,
        justifyContent: 'center',
    },
    scpre_params_balance_text_number:{
        color:Theme.Colors.themeColor,
        fontSize:37,
    },
    interval:{
      height:10,
    },
    store:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:15,
        paddingBottom:15,
        height:120,
    },
    score_params:{
        width:230,
        flexDirection:'row',
        alignItems: 'center',
        justifyContent: 'flex-start',
        flex:1,
    },
    score_params_titleIco:{
        marginLeft:30,
        width:3,
        height:70,
    },
    scpre_params_view:{
        marginLeft:15,
    },
    scpre_params_text:{
        color:Theme.Colors.minorColor,
        fontSize:Theme.Font.fontSize_1,
    },
    scpre_params_1_1_text_number:{
        color:Theme.Colors.themeColor,
        fontSize:35,
    },
    score_params_1_1_titleIco:{
        backgroundColor:Theme.Colors.themeColor,
    },
    scpre_params_1_2_text_number:{
        color:"#17D26D",
        fontSize:35,
    },
    score_params_1_2_titleIco:{
        backgroundColor:"#17D26D",
    },
    scpre_params_1_3_text_number:{
        color:"#17C8FE",
        fontSize:35,
    },
    score_params_1_3_titleIco:{
        backgroundColor:"#17C8FE",
    },
    score_params_balance:{
        width:7,
        height:100,
    },
    titleFrame:{
        marginTop:10,
    },
});