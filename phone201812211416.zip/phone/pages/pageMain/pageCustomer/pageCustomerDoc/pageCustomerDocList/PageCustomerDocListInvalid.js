import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    Slider,
    ImageBackground,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    TextIcon,
    Tools,
    BaseComponent,
    ImageView,
    VideoView,
    Media,
    BarcodeView,
    ProgressPer,
    Http,
    WebViewCus,
    Theme,
    SwiperNotice,
    TextDoubleIcon,
    Charts,
    ItemRowTripTask,
    ImageChange,
    TextChange,
    SearchDDDIpt,
    FlatListView,
    ButtonChange,
    ItemRowFeedback,
    PickDropdown,
} from "com";

import {Service} from './Service';

type Props = {};
export default class PageCustomerDocList extends BaseComponent<Props> {

    dropList = {
        types1: {
            name:["选择大区"],
            code:{},
            clearDrop:false,
        },//一级品类 数据
        types2: {
            name:["选择省份"],
            code:{},
            clearDrop:false,
        },//二级品类 数据
        types3: {
            name:["选择城市"],
            code:{},
            clearDrop:false,
        },//三级品类 数据
    };

    selectValue = {
        regionId: '',//下拉选中值
        provincialId: '',//下拉选中值
        cityId: '',//下拉选中值
        customerName: '',//名称输入值
        queryType:'',//额外条件单选
        execFirst: true,//是否是第一次执行
        customerStatus:2,//无效客户
    };


    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            btn:null,
            isRenderItemFirst:true,
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });

        this.state = {
            total: 0,//商品总数
            dataList: [],//数组列表SS
            refresh: false,//是否刷新
            clearDrop: false,
            totalType:'',//查询类型
            d:[
                {row:[
                    {text:"30天无返单",selected:false,queryType:1},
                    {text:"60天无返单",selected:false,queryType:2},
                    {text:"门店面积>100m²",selected:false,queryType:3},
                    {text:"门店面积<100m²",selected:false,queryType:4}]
                },
                {row:[
                    {text:"30天未电话回访",selected:false,queryType:5},
                    {text:"60天未拜访",selected:false,queryType:6},
                    {text:"首单>20W",selected:false,queryType:7},
                    {text:"首单<20W",selected:false,queryType:8}]
                }
            ]
        }
    }

    onTextChange(val) {
        this.selectValue.customerName = val;
    }

    /**
     * 搜索
     */
    onSearch() {
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            total: 0,
            dataList: []
        });

        this.getData(this.selectValue);
    }

    componentWillEnter(params,action,page){
        if(params != null){
            Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
            this.selectValue.queryType = params.queryType;
            this.selectValue.execFirst = true;

            this.state.totalType = this.selectValue.queryType == 9 ? "24小时未电话回访" :
                this.selectValue.queryType == 5 ? "30天未电话回访" :
                    this.selectValue.queryType == 10 ? "60天未电话回访" :
                        this.selectValue.queryType == 11 ? "合同到期" : "";
            this.setState({
                total: 0,
                dataList: []
            });
        }

        this.getData(this.selectValue);
        Service.getCity().then(retJson=>{
            this.dropList.types1 = retJson;
            this.setState({
                refresh:true,
                clearDrop:false
            });
        });
    }

    componentWillMount(){
        this.getData();
        Service.getCity().then(retJson=>{
            this.dropList.types1 = retJson;
            this.setState({
                refresh:true,
                clearDrop:false
            });
        });
    }

    renderItem(item, index) {
        return (
            <ItemRowFeedback
                isShowIcon={false}
                frameStyle={styles.itemFram}
                onPress={() => this.onItemPress(item)}
                text1_1={"客户姓名:" + item.name}
                text1_2={
                    {
                        text_1:item.customer_status == null ? undefined : item.customer_status,
                        text_2:item.contract_status == null ? "合同到期" : item.contract_status,
                        text_3:item.store_zf == null ? undefined : item.store_zf,
                        text_4:item.diagnosticScore == null ? undefined : item.diagnosticScore,

                        text_5:item.bgStore ? "标杆" : null,
                        text_6:item.demoStore ? "样板" : null
                    }
                }
                text2_1={"签约时间:" + (item.sign_time == null ? "无记录" : item.sign_time)}
                text2_2={"门店面积:" + (item.storeArea == null ? "无记录" : item.storeArea+"m²")}
                text3_1={"最近返单:" + (item.lastOrderTime == null ? "无记录" : item.lastOrderTime)}
                text3_2={"开业时间:" + (item.openDate == null ? "" : item.openDate)}
                text4_1={"最近电话回访:" + (item.lastPhoneVisitDate == null ? "无记录" : item.lastPhoneVisitDate)}
                text4_2={"最近拜访:" + (item.lastVisitDate == null ? "无记录" : item.lastVisitDate)}
                text5_1={"店铺地址:" + (item.store_address == null ? "无记录" : item.store_address)}/>
        );
    }

    onItemPress(item) {
        this.goPage("PageCustomerDocDetail",
            {store_code: item.storecode,id:item.id,progressFinish:item.diagnosticScore});
    }

    /**
     * 获取城市列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {

        if(this.selectValue != undefined){
            selectValue = this.selectValue;
        }
        //不需要诊断分
        selectValue.needScore = 2;

        if(!this.selectValue.execFirst){
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        Service.get(selectValue,this.selectValue.execFirst,this.selectValue.customerStatus)
            .then(retJson =>{

                if(!this.selectValue.execFirst && !retJson.has){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                }else{
                    this.selectValue.execFirst = false;
                    this.setState({
                        total:retJson.totalElements,
                        dataList:retJson.content
                    });

                    Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                }

            })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });

        if(this.state.totalType != undefined){
            this.selectValue.queryType = '';
            this.state.totalType = '';
        }
    }


    onSelectDrop(i,val,type){
        if(type == 1){
            this.dropList.types2.name = [];
            this.dropList.types2.clearDrop = true;
            this.selectValue.provincialId = '';

            this.dropList.types3.name = [];
            this.dropList.types3.clearDrop = true;
            this.selectValue.cityId = '';

            this.selectValue.regionId = this.dropList.types1.code[val.name];

            if(this.selectValue.regionId != '') {
                this.getDataGoodsTypes(this.selectValue.regionId,type);
            }

            this.setState({
                refresh:false,
                clearDrop:true
            });
        }
        if(type == 2){

            this.dropList.types3.name = [];
            this.dropList.types3.clearDrop = true;
            this.selectValue.cityId = '';

            this.selectValue.provincialId = this.dropList.types2.code[val.name];
            if(this.selectValue.provincialId != ''){
                this.getDataGoodsTypes(this.selectValue.provincialId,type);
            }

            this.setState({
                refresh:false,
                clearDrop:false
            });
        }
        if(type == 3){
            this.selectValue.cityId = this.dropList.types3.code[val.name];
        }
    }

    /**
     * 获取城市分类
     * @param code int,//父级类别，用于请求子级类别
     * @param type int,//获取几级品类，0：1级；1：二级；2：三级；
     * **/
    getDataGoodsTypes(code,type){
        Service.getCity(code,type).then(retJson =>{
            if(type == 0){
                this.dropList.types1 = retJson;
            }else if(type == 1){
                this.dropList.types2 = retJson;
            }else  if(type == 2){
                this.dropList.types3 = retJson;
            }

            this.setState({
                refresh:true,
                clearDrop:false
            });
        });
    }

    onButtonPress = (item,index) => {
        let d1 = [];
        this.state.d.forEach((v,i,a)=>{
            let it = {row:[]};
            v.row.forEach((v1,i1,a1)=>{

                if(i1 == index && v1==item) {
                    if (v1.selected) {
                        v1.selected = false;
                        this.selectValue.queryType = '';
                    } else {
                        v1.selected = true;
                    }
                }else{
                    v1.selected = false;
                }
                it.row.push(v1);
            });

            d1.push(it);
        });

        d1.forEach((value,item)=>{
            value.row.forEach((value2,item2)=>{
                if(value2.selected == true){
                    this.selectValue.queryType = value2.queryType;
                }
            })
        })

        this.setState({
            d:d1
        });
    };

    rederItem = (item,i)=>{
        return(
            <ButtonChange key={"i" + i}
                          text={item.text}
                          onPress={() => this.onButtonPress(item,i)}
                          style={[styles.btn,item.selected?styles.btnActive:{}]}
                          textStyle={[styles.text,item.selected?styles.textBtnActive:{}]}
                          frameStyle={styles.interval}/>
        );
    }

    rederItemParent = (item,i)=>{
        return(
            <View key={"p" + i}
                  style={styles.promptFrame} >
                {
                    item.row.map(this.rederItem)
                }
            </View>
        );
    }

    render() {
        return (
            <ViewTitle isScroll={false}>
                <SearchDDDIpt refresh={this.state.refresh}
                              frameStyle={styles.searchStyle}
                              options1={{
                                  defaultValue: this.dropList.types1.name[0],
                                  options: this.dropList.types1.name,
                                  clearDrop: this.dropList.types1.clearDrop,
                                  onSelect: (i, val) => this.onSelectDrop(i, val, 1)
                              }}
                              options2={{
                                  defaultValue:this.dropList.types2.name[0] == undefined
                                      ? '选择省份'
                                      : this.dropList.types2.name[0],
                                  options: this.dropList.types2.name,
                                  clearDrop: this.state.clearDrop,
                                  onSelect: (i, val) => this.onSelectDrop(i, val, 2)
                              }}
                              options3={{
                                  defaultValue:this.dropList.types3.name[0] == undefined
                                      ? '选择城市'
                                      : this.dropList.types3.name[0],
                                  options: this.dropList.types3.name,
                                  clearDrop: this.dropList.types3.clearDrop,
                                  onSelect: (i, val) => this.onSelectDrop(i, val, 3)
                              }}
                              placeholder={"--客户姓名--"}
                              textChange={(val) => this.onTextChange(val)}
                              onPressSearch={() => this.onSearch()}/>

                <View style={styles.pFrame}>
                    {
                        this.state.d.map(this.rederItemParent)
                    }
                </View>

                <View style={[styles.title,styles.titleStyle]}>
                    <View style={styles.titleIco}></View>
                    <Text style={styles.titleText}>共有{this.state.total}家客户{this.state.totalType}</Text>
                </View>


                <FlatListView
                    data={this.state.dataList}
                    keyExtractor={(item, index) => ("key" + index)}
                    renderItem={({item, i}) => this.renderItem(item, i)}
                    onEndReached={() => this.getData()}
                />
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    text1_1:{
        color:Theme.Colors.themeColor,
    },
    //顶部搜索
    searchStyle:{
        fontSize:Theme.Font.fontSize_1_1,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titleStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    pFrame: {
        borderColor: Theme.Colors.minorColor,
        borderTopWidth: Theme.Border.borderWidth,
        padding: 10,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    promptFrame: {
        backgroundColor:Theme.Colors.foregroundColor,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 10,
    },
    //高级选项字体
    text: {
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    btn: {
        width:160,
        borderColor: Theme.Colors.minorColor,
        borderWidth: Theme.Border.borderWidth,
        padding: 3,
        backgroundColor: Theme.Colors.backgroundColor,
    },
    interval: {
        marginLeft: 5,
        borderRadius: 30,
        width: 185,
    },
    interval2: {
        marginRight: 5,
    },
    btnActive:{
        borderWidth:0,
        backgroundColor:Theme.Colors.themeColor,
    },
    textBtnActive:{
        color:Theme.Colors.backgroundColor,
    },
    itemFram:{
        backgroundColor:Theme.Colors.foregroundColor,
    }
});