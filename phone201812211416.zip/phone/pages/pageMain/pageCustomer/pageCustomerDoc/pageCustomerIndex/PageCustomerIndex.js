import React,{Component} from 'react'
import { Image,Text,View,ImageBackground,TouchableOpacity}from 'react-native'

import {
    BaseComponent,
    StyleSheetAdapt,
    Theme,
    Tools,
    Http,
    HttpUrls,


} from 'com'
import {PageCustomerDocList, PageCustomerDocListInvalid} from "../PageCustomerDoc";
import {PageApprovalList} from "../../pageCustomerApproval/PageCustomerApproval";
import PageCustomerAllocation from "../../pageCustomerAllocation/PageCustomerAllocation";
import {ViewTitle} from "../../../../../component/ui/ViewTitle";




export default class PageCustomerIndex extends BaseComponent<Props>{

    constructor(prop){
        super(prop)

        this.state={
            dataList:[]
        }
        this.data=[]
        this.mount=false
        this.renderItem=true
    }
    getData(){
        Http.post(HttpUrls.urlSets.urlCustomerIndex,{jobGrade:Tools.userConfig.userInfo.job_grade},false).then(retJson=>{
                this.data=retJson.retData
                console.log(this.data)
                if(!this.mount){
                    this.setState({dataList:retJson})
                }
            }
        )
    }
    componentWillUnmount(){
        this.mount=true
    }
    componentWillEnter(){
        this.getData()
    }
    //点击跳转
    onPress(screen){
        if(Tools.userConfig.userInfo.department_level != 1 && Tools.userConfig.userInfo.department_level != 2)
        {
            Tools.toast("权限不足，请联系对应的大区总监！");
        }
        else{
            this.goPage(screen)
        }
        }
    render(){
        if(this.renderItem){
            this.getData();
            this.renderItem=false
        }
        let dataList=this.data;
        if(this.data == null){
            dataList = {
                validStore1:0,
                validStore2:0,
                validStore3:0,
                validStore4:0,
                validStore5:0,
                invalidStore2:0,
                invalidStore3:0,
                invalidStore4:0,
                invalidStore5:0,
            }
        }
        // console.log(this.data)
        return(
            <ViewTitle>
                <View style={styles.model}>
                    <View style={styles.parent} >

                        <Image source={require("../../../../../res/images/top.png")}
                               style={styles.topPicture}>
                        </Image>


                    </View>

                    <View style={styles.parent}>
                        <ImageBackground source={require("../../../../../res/images/effective.png")}
                                         style={styles.firstRow}>
                            <View style={styles.container}>
                                <Text style={styles.welcome}>
                                    <Image source={require('../../../../../res/images/effectiveInner.png')} style={styles.imageInTextStyle}/>
                                    &nbsp;&nbsp;有效客户
                                </Text>
                                {/*<Text style={styles.topRight}>*/}
                                {/*01*/}
                                {/*</Text>*/}
                            </View>
                            <TouchableOpacity onPress={()=>{this.goPage('PageCustomerDocList')}}>
                                <Text style={styles.content1}>
                                    今日新增客户:{dataList.validStore1}/个
                                </Text >
                                <Text style={styles.content}>
                                    华南大区客户:{dataList.validStore2}/个
                                </Text>
                                <Text style={styles.content}>
                                    华东大区客户:{dataList.validStore3}/个
                                </Text>
                                <Text style={styles.content}>
                                    华北大区客户:{dataList.validStore4}/个
                                </Text>
                                <Text style={styles.content}>
                                    西南大区客户:{dataList.validStore5}/个
                                </Text>
                            </TouchableOpacity>

                        </ImageBackground>
                        <ImageBackground source={require("../../../../../res/images/uneffective.png")}
                                         style={styles.firstRow}>
                            <View style={styles.container}>
                                <Text style={styles.welcome}>
                                    <Image source={require('../../../../../res/images/uneffectiveInner.png')} style={styles.imageInTextStyle}/>
                                    &nbsp;&nbsp;无效客户
                                </Text>
                                <Text style={styles.topRight}>
                                    01
                                </Text>
                            </View>
                            <TouchableOpacity onPress={()=>{this.goPage('PageCustomerDocListInvalid')}}>
                                {/*<Text style={styles.content1}>*/}
                                    {/*新增无效客户:{dataList.invalidStore2}/个*/}
                                {/*</Text >*/}
                                <Text style={styles.content5}>
                                    华南大区客户:{dataList.invalidStore2}/个
                                </Text>
                                <Text style={styles.content5}>
                                    华东大区客户:{dataList.invalidStore3}/个
                                </Text>
                                <Text style={styles.content5}>
                                    华北大区客户:{dataList.invalidStore4}/个
                                </Text>
                                <Text style={styles.content5}>
                                    西南大区客户:{dataList.invalidStore5}/个
                                </Text>
                                {/*<Text style={styles.content}>*/}
                                {/*西南大区客户:{dataList.invalidStore5}/个*/}
                                {/*</Text>*/}
                            </TouchableOpacity>
                        </ImageBackground>

                    </View>
                    <View style={styles.parent}>
                        <ImageBackground source={require("../../../../../res/images/approval.png")}
                                         style={styles.firstRow}>
                            <View style={styles.container}>
                                <Text style={styles.welcome}>
                                    <Image source={require('../../../../../res/images/approvalInner.png')} style={styles.imageInTextStyle}/>
                                    &nbsp;&nbsp;客户审批
                                </Text>
                                <Text style={styles.topRight}>
                                    01
                                </Text>
                            </View>
                            <TouchableOpacity onPress={()=>{this.goPage('PageApprovalList')}}>
                                <Text style={styles.content3}>
                                    收到新消息:0/个

                                </Text >
                                <Text style={styles.content4}>
                                    待&nbsp;&nbsp;审&nbsp;&nbsp;批:0/个
                                </Text>
                                <Text style={styles.content4}>
                                    审核&nbsp;&nbsp;通&nbsp;&nbsp;过:0/个
                                </Text>
                                <Text style={styles.content4}>
                                    审核不通过:0/个
                                </Text>
                            </TouchableOpacity>
                        </ImageBackground>
                        <ImageBackground source={require("../../../../../res/images/allocation.png")}
                                         style={styles.firstRow}>
                            <View style={styles.container}>
                                <Text style={styles.welcome}>
                                    <Image source={require('../../../../../res/images/allocationInner.png')} style={styles.imageInTextStyle}/>
                                    &nbsp;&nbsp;客户分配
                                </Text>
                                <Text style={styles.topRight}>
                                    01
                                </Text>
                            </View>
                            <TouchableOpacity onPress={()=>{this.onPress('PageCustomerAllocation')
                            }}>
                                <Text style={styles.content3}>
                                    收到新消息:0/个

                                </Text >
                                <Text style={styles.content4}>
                                    待&nbsp;&nbsp;分&nbsp;&nbsp;配:0/个
                                </Text>
                                <Text style={styles.content4}>
                                    分配完成:0/个
                                </Text>
                                <Text style={styles.content4}>
                                    已完成任务:0/个
                                </Text>
                            </TouchableOpacity>
                        </ImageBackground>

                    </View>

                    <View style={styles.explainView}>
                        <Text style={styles.explainText}>五段客户说明：</Text>
                        <Text style={styles.explainText}>第一段：已签约尚未确认店址的客户</Text>
                        <Text style={styles.explainText}>第二段：新店选址确认审核，开业后三个月内</Text>
                        <Text style={styles.explainText}>第三段：高价值客户(过去12个月有返单（订货），无次数限制）</Text>
                        <Text style={styles.explainText}>第四段：高潜力客户(过去12个月无返单（订货），卖场面积60M²以上，月销售额＞5W)</Text>
                        <Text style={styles.explainText}>第五段：双低客户(过去12个月无返单（订货），卖场面积小，月销售额低)</Text>
                    </View>

                </View>
            </ViewTitle>
        )
    }
}
const styles = StyleSheetAdapt.create({
    explainView:{
        paddingLeft:20,
        paddingTop:10,
    },
    explainText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
        paddingTop: 5,
    },
    model:{
        marginTop:-10,
    },
    topPicture:{
        flex:1,
        height:200,
        marginTop:5
    },
    parent:{
        flexDirection:'row',
        // justifyContent:'center',
        // alignItems:'center'
    },
    firstRow:{
        marginTop:10,
        marginLeft:5,
        marginRight:5,
        flex:0.5,
        height:200
    },
    leftIcon:{
        width:20,
        height:20,

        marginLeft:20,
        marginTop:20
    },
    container: {
        flex:1,

    },

    imageInTextStyle:{

        width:20,
        height:20,
        resizeMode:'cover'
    },
    welcome:{
        marginTop:20,
        marginLeft:20,
        fontSize:20
    },
    content:{
        marginLeft:50,
        marginBottom:10,
        fontSize:17,
        color:Theme.Colors.minorColor

    },
    content5:{
        marginLeft:50,
        marginBottom:14,
        fontSize:17,
        color:Theme.Colors.minorColor

    },
    content1:{
        marginLeft:50,
        marginBottom:10,
        fontSize:17,
        color:Theme.Colors.themeColor

    },
    content3:{
        marginLeft:50,
        marginBottom:15,
        fontSize:17,
        color:Theme.Colors.themeColor

    },
    content4:{
        marginLeft:50,
        marginBottom:13,
        fontSize:17,
        color:Theme.Colors.minorColor

    },
    content2:{
        marginTop:20,
        marginLeft:50,
        marginBottom:10,
        fontSize:17,
        color:Theme.Colors.themeColor
    },
    topRight:{
        marginLeft:345,
        fontSize:25,
        color:'white',
        marginTop:-40
    }





})




