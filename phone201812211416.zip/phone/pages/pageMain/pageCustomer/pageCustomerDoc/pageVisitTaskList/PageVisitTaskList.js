/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageVisitTaskList extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.statusList = [{
            name:'状态',
        }];
        this.state = {
            dataList:[],//任务列表
            total:0,
        };

        this.selectValue = {
            execFirst:true,//是否是第一次执行
            object_id:'',
        };

        this.setParams({
            headerLeft: true,
            headerRight:true,
            headerRightHandle:()=>{
                this.goPage("PageTripApply");
            },
        });
    }

    componentWillEnter(params,action,page){
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });

        this.getStatusList();
        this.getData();
    }

   /* onSearch = ()=>{
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });
        this.getData(this.selectValue);
    };*/

   /* onItemPress(item){
        this.goPage("PageTripDetail",{id:item.id});
    }*/

    /*onItemPressBtn(item,statusObj){
        if(statusObj.code == 0){
            this.goPage("PageGuideList",{id:item.id});
        }
        else{
            this.onItemPress(item);
        }
    }*/

    /**
     * 获取反馈列表
     * @param selectValue object;//搜索参数
     * **/
    getData() {

        let object_id = '';
        if(BaseComponent.tmpData != null){
            object_id = BaseComponent.tmpData.store_info;
        }

        if(!this.selectValue.execFirst) {
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        let task_type = 1; //1巡店 2出差
        Service.getTripList(this.selectValue.execFirst,object_id,task_type).then(retJson=>{
            if(!this.selectValue.execFirst && !retJson.has)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);

            }
            else
            {
                this.selectValue.execFirst = false;
                this.setState({
                    dataList:retJson.retListData,
                    total:retJson.total
                });

                Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
            }
        })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });

    }


    renderItemView(item,i){

        let statusObj = Tools.statusConvert(item.status,item.executor_id);

        //let btnList = [];
        /*statusObj.btnList.forEach((v,i,a)=>{
            btnList.push({
                onPress:()=>this.onItemPressBtn(item,v),
                text:v.text,
                backgroundColor:v.backgroundColor == undefined
                    ? Theme.Colors.backgroundColorBtn1
                    : v.backgroundColor
            });
        });*/

        return(
            <ItemRowTripTask  key={i}
                              disableRightSwipe={false}
                              isItemRowIconLeft={true}
                              //btnList={btnList}
                              text1_1={item.name}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={statusObj.text}
                              text2_1={"申请人:" + item.executor}

                              text2_1_Style={styles.text2_1_Style}
                              text3_1={"出差编码:" + item.number}
                              text4_1={"出差开始/结束时间:" + item.begin_time
                              + " ~ " + item.end_time}
                              //onPress={() => this.onItemPress(item)}
                              text1_2_Style={{color:statusObj.color}}
                              itemRowIcon={false}
                              text1_2_Icon={statusObj.icon}/>
        );
    }

    getStatusList(){
        Tools.statusConvert().forEach((v,i,a)=>{
            v.name = v.text;
            this.statusList.push(v);
        });
    };

    /*componentWillReceiveProps(){
        let param = this.getPageParams(true);
        if(param)
        {
            // alert(JSON.stringify(param.paramData));
            this.onSearch();
        }
    }*/

    render() {
        const {dataList} = this.state;

        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c} >

                <View style={[styles.title,styles.titleStyle]}>
                    <View style={styles.titleIco}></View>
                    <Text style={styles.titleText}>共有{this.state.total}条拜访记录</Text>
                </View>

                <FlatListView style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItemView(item,index)}
                              onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titleStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    titleFrame:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
        height:100,
    },
    titleFrame_1:{
        flexDirection:'row',
        flex:1,
        height:50,
    },
    titleFrame_1_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            padding:0,
            paddingLeft:10,
            paddingBottom:10,
            marginTop:15,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    titleFrame_btnFrame:{
        width:Theme.Width.width1 + Theme.Height.height1,
    },
    titleFrame_btn:{
        width:100,
        height:Theme.Height.height1,
        padding:0,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginBottom:10,
    },
    itemTripBtn:{
        marginRight:"0.05w",
    },
});
