/**
 * Created by Administrator on 2018/4/30.
 */
import{
    Theme
} from "com";
import {
    TabNavigator,
} from "comThird";

import PageHome from "./pageHome/PageHome";
import PageInforms from './pageInform/PageInform';
import PagePictureDetail from './pagePictureDetail/PagePictureDetail'

const TabRouteConfigs = {
    PageHome: {
        screen: PageHome,
        // screen: PageMine,
        navigationOptions: {
            title: '首页',
            // tabBarLabel : '我的',
        },
    },
    PageInforms: {
        screen: PageInforms,
    },
    PagePictureDetail: {
    screen: PagePictureDetail
    }


}


const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);


module.exports = pages;