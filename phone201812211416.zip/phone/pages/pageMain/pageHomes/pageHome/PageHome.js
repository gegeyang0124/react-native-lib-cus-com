import React, {Component} from 'react';
import moment from 'moment';
import {
    View,
    Text,
    Image,
    Slider,
    ImageBackground,
    TouchableOpacity,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    TextIcon,
    Tools,
    BaseComponent,
    ImageView,
    VideoView,
    Media,
    BarcodeView,
    ProgressPer,
    Http,
    WebViewCus,
    Theme,
    SwiperNotice,
    TextDoubleIcon,
    Charts,
    ItemRowTripTask,
    ImageChange,
    ResultProgressBlock,
    TalkingData,
    FlatListView,
    ScrollViewRowList,
    ViewCtrl,
    ItemRowSwitch
} from "com";
import {Service} from './Service';
import {HttpUrls} from "../../../../component/api/HttpUrls";
import DeviceInfo from 'react-native-device-info';
import Loading from 'react-native-kactivityindicator';

type Props = {};
export default class PageHome extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.itemTripFirst = null;// 第一个出差任务成员
        this.state = {

            viewBottom:{
                vBFrame2_IconRotate:null,
                text:'查看更多',
            },//查看更多
            upDownStyle:null,//升降样式
            dataSize:0,
            customerObj:{
                customerNewNum:null,//新客户数量
                customer1DayNum:null,//1天未回访数据
                customer30DayNum:null,//30天未回访数据
                customer60DayNum:null,//60天未回访数据
            },//客户对象
            tripListData:[],//出差任务数据
            noticesData:[],//公告数据
            resultEstimateData:[],//业绩预估数据
            resultFinishProgress:0,//业绩完成进度
            resultFinishCustomerData:{
                old_operations_target:0,
                new_operations_target:0,
                newStoreNum:0,
                oldStoreNum:0,
                perNewOldTarget:0,
                perNewOldFinish:0,
            },//业绩新老客户数据
            status:0,//业绩进度表情
            pictures:[],
            picture:[],
            path:{uri:'images/product1.png'},
            stimulate:[],
        }
        this.weather={
            day_air_temperature:null,
            day_weather_code:null,
            day_weather:null,
            quality:null
        }

        this.stimulateList = [
            "📢：每一个成功者都有一个开始。勇于开始，才能找到成功的路!💪💪💪",
            "📢：世界会向那些有目标和远见的人让路!加油！💪💪💪",
            "📢：若不给自己设限，则人生中就没有限制你发挥的藩篱！加油！💪💪💪",
            "📢：即使爬到最高的山上，一次也只能脚踏实地地迈一步！加油！💪💪💪",
            "📢：别想一下造出大海，必须先由小河川开始！加油！💪💪💪",
            "📢：世上并没有用来鼓励工作努力的赏赐，所有的赏赐都只是被用来奖励工作成果的！加油！💪💪💪",
            "📢：即使是不成熟的尝试，也胜于胎死腹中的策略！别想一下造出大海，必须先由小河川开始!加油！💪💪💪",
            "📢：旁观者的姓名永远爬不到比赛的计分板上！加油！💪💪💪",
            "📢：伟人之所以伟大，是因为他与别人共处逆境时，别人失去了信心，他却下决心实现自己的目标！加油！💪💪💪",
            "📢：当你感到悲哀痛苦时，最好是去学些什么东西。学习会使你永远立于不败之地！加油！💪💪💪",
            "📢：成功者所达到并保持着的高处，并不是一飞就到的，而是他们在同伴们都睡着的时候，一步步艰辛地向上攀爬的！加油！💪💪💪",
            "📢：天上不会掉钱，要赚钱找顾客拿。买和不买永远不是价格的问题，而是价值的问题。要不断的向顾客塑造产品的价值！加油！💪💪💪",
            "📢：坚韧是成功的一大要素，只要在门上敲得够久、够大声，终会把人唤醒的！加油！💪💪💪",
            "📢：只有找到了与顾客的共同点，才可能与他建立关系。销售就是建立关系，建立人脉！加油！💪💪💪",
            "📢：小事情就是一切，煮熟的鸭子为什么会飞掉？是你的细节失败了！加油！💪💪💪",
            "📢：多听少讲，必备多问少说；服务的最高境界——发自内心，而不是流于形式！加油！💪💪💪",
            "📢：因为熟练，所以专业；因为专业，所以极致。只有专业才能成为专家，只有专家才能成为赢家！加油！💪💪💪",
            "📢：任何顾客都不会和业余选手玩，因为他们深知业余没有好结果。顾客永远只相信专家，专家代表权威和被信任！加油！💪💪💪",
        ];

        this.setParams({
            headerLeft: false,
            headerRight:require('images/info.png'),
            headerRightHandle:()=>{
                // this.goPage("PageInform");//首页通知

                this.goPage("PageTaskInform")
            },
        });
        this.pictures=[];
        this.num=0
        this.path= [require('images/product1.png'),require('images/product2.png'),require('images/product3.png'),require('images/product4.png')]
        this.infoList=null//通知未读数
        this.weatherPicture={"00":require('images/weather/00.png'),"01":require('images/weather/01.png'),"02":require('images/weather/02.png'),"03":require('images/weather/03.png'),
            "03":require('images/weather/03.png'),"06":require('images/weather/06.png'),"07":require('images/weather/07.png'),
            "09":require('images/weather/09.png'),"10":require('images/weather/10.png'),"15":require('images/weather/15.png'),"18":require('images/weather/18.png'),"29":require('images/weather/29.png')
            ,"30":require('images/weather/30.png')}

    }

    onItemPress = (item,i)=>{
        WebViewCus.show(true,item.html);
    };

    onPressResult = ()=>{
        if(Tools.userConfig.userInfo.department_level == 1 || Tools.userConfig.userInfo.showAll){
            this.goPage("PageResultAnalyzeProgressCenter",null,null,"PageApply");
            // this.goPage("PageResultAnalyzeProgressAreaProvince");
        }
        else if(Tools.userConfig.userInfo.department_level == 2){
            this.goPage("PageResultAnalyzeProgressAreaRegions",null,null,"PageApply");
        }
        else {
            this.goPage("PageResultAnalyzeProgressAreaProvince2", {
                    id:Tools.userConfig.userInfo.department_id,
                    name:Tools.userConfig.userInfo.department_name
                }
                ,null,"PageApply");
        }
    };

    onPressTrip = ()=>{
        this.goPage("PageIndex");
    };

    onItemPressTrip(item){
        // BaseComponent.tabIndex = 0;
        this.goPage("PageTripDetail",{id:item.id},true,["PageIndex","PageTripList"]);
    }

    onGoPages(type){
        switch (type)
        {
            case 1 : {

                // Tools.toast("sd");
                this.goPage("PageInformList",{queryType:12}); //新客户

                // alert("新客户");
                break;
            }
            case 2 : {
                this.goPage("PageInformList",{queryType:9});//24小时

                // alert("24未");
                break;
            }
            case 3 : {
                this.goPage("PageInformList",{queryType:5});//30天未回访

                // alert("超30天");
                break;
            }
            case 4 : {
                this.goPage("PageInformList",{queryType:6});//60天
                // alert("超60天");
                break;
            }
        }
    }

    onViewBottom = ()=>{
        if(this.state.viewBottom.vBFrame2_IconRotate == null) {
            this.viewTitle.scrollTo(0,StyleSheetAdapt.getHeight('0.6h'));
        }
        else {
            this.viewTitle.scrollTo(0,0);
        }

        this.setState({
            viewBottom:{
                vBFrame2_IconRotate:this.state.viewBottom.vBFrame2_IconRotate == null
                    ? styles.vBFrame2_IconRotate
                    : null,
                text:this.state.viewBottom.vBFrame2_IconRotate == null
                    ? '收起'
                    : '查看更多',
            }
        });
    };

    onUpDown = () =>{
        let tripListData = [];
        this.state.tripListData.forEach((v,i,a)=>{
            tripListData.push(a[(a.length - 1 - i)]);
        });

        this.setState({
            upDownStyle:this.state.upDownStyle == null
                ? styles.vBFrame2_IconRotate
                : null,
            tripListData:tripListData
        });
    };

    renderViewTrip = (item,index) =>{
        let statusObj = Tools.statusConvert(item.status,item.executor_id)
        return(
            <ItemRowTripTask  key={index}
                              ref={(com)=>{
                                  this.itemTripFirst = this.itemTripFirst == null
                                      ? com
                                      : this.itemTripFirst;
                              }}
                              text1_1={item.name}
                              text1_2={statusObj.text}
                              text2_1={"巡店数量：" + item.relationTaskNum + "个"}
                              text3_1={"出差开始/结束时间：" + item.begin_time
                              + " ~ " + item.end_time}
                              text4_1={"任务完成后获得奖励：鲜花 +5"}
                              onPress={()=>this.onItemPressTrip(item)}
                              text1_2_Style={{color:statusObj.color}}
                              text4_1_Style={{color:Theme.Colors.themeColor}}
                              text1_2_Icon={statusObj.icon}/>
        );
    }

    goRight() {
        //alert("123");
    }

    /**
     * 图片转格式
     */
    transfer(v){
        //图片总数量
        this.state.pictures.forEach((i,val)=> {
            this.pictures.push({icon: HttpUrls.urlIPHome + i.photo_url, id: i.id,content:i.content})
        });

        //将图片总数量切成若干个子数组
        var arr=[];
        for(var j=0;j<this.pictures.length;j=j+4){
            arr.push(this.pictures.slice(j,j+4));
        }
        //轮播渲染的图片数组
        this.picture=arr[v];

        this.setState({picture:arr[v]})

    }

    pressLeft=()=>{

        if(this.num<=0){
            this.num=0;
            return
        }
        else{
            this.num--;
            this.transfer(this.num);
        }

    };

    pressRight=()=>{

        if(this.num>=this.state.pictures.length/4-1){
            this.num=this.pictures.length;
            this.num=this.state.pictures.length/4-1;
            // console.log(this.num)
            return
        }
        else{
            ++this.num
            // console.log('aaa')
            console.log(this.num);
            this.transfer(this.num);
        }
    };

    getData() {
        //设置业绩进度
        Service.getResultEstimate().then(retJson =>{

            if(retJson != null){
                let dataList = [
                    retJson.day15 == null ? 0 : retJson.day15,
                    retJson.day20 == null ? 0 : retJson.day20,
                    retJson.day25 == null ? 0 : retJson.day25,
                ];

                let b = true;
                dataList.forEach((v,i,a)=>{
                    if(v != 0){
                        b = false;
                    }
                });

                if(b){
                    dataList = [];
                }

                this.setState({
                    resultEstimateData:dataList
                });
            }
        });

        Service.getResultProgressCustomer().then(retJson=>{
            var preJd = retJson.resultFinishProgress;
            var date = new Date();
            var day = moment(date).format('DD');
            var monthDay = moment(date).daysInMonth();
            var jd = day/monthDay;
            var status = 0;


            if(preJd < jd && preJd > (jd-0.1)){
                status = 2;
            }else if(preJd < jd){
                status = 1;
            }

            this.setState({
                resultFinishProgress:retJson.resultFinishProgress,
                resultFinishCustomerData:retJson,
                status:status,
            });
        });

        Service.getInfo().then(retJson=>{
            this.infoList=retJson[0].unread_num
        })

        Service.getTtipList().then(retJson=>{
            this.setState({
                dataSize:retJson.length,
                tripListData:retJson
            });
        });

        Service.getPushNum().then(retJson=>{
            this.setParams({
                headerLeft: false,
                headerRight:
                    <TouchableOpacity onPress={()=>this.goPage("PageTaskInform")}>

                        <Text style={{color:'white',fontSize:23,marginRight:30,}}>通知</Text>
                        {
                            this.infoList != 0 ?
                                <View style={{height:21,width:21,borderRadius:15,backgroundColor:'red',position:'absolute',right:5,top:-9}}>
                                    {
                                        this.infoList>=10 ?
                                            <Text style={{color:'white',fontSize:13,marginTop:3,paddingLeft:2}}>
                                                {this.infoList=this.infoList>=100 ? 99 : this.infoList}
                                            </Text>
                                            :
                                            <Text style={{color:'white',fontSize:13,marginTop:3,paddingLeft:6}}>
                                                {this.infoList}
                                            </Text>
                                    }
                                </View>
                                :
                                null}
                    </TouchableOpacity>,
            });
        });


        Service.getCustomerNum().then(retJson=>{
            this.setState({
                customerObj:{
                    customerNewNum:retJson.newStoreNum,//新客户数量
                    customer1DayNum:retJson.unPhoneVisit24hour,//1天未回访数据
                    customer30DayNum:retJson.unPhoneVisit30day,//30天未回访数据
                    customer60DayNum:retJson.unTaskVisit60day,//60天未回访数据
                }//客户对象
            });
        });

        Service.getNotices().then(retJson=>{
            retJson.forEach((v,i,a)=>{
                v.onPress = this.onItemPress;
            });

            this.setState({
                noticesData:retJson
            });
        });

        Service.getPicture().then(retJson=>{
            // console.log(retJson)
            this.setState({pictures:retJson})

            this.transfer(this.num)
            // console.log(this.pictures)
        });

        Tools.getLocation().then((res)=>{
            const city=res.city.slice(0,res.city.length-1)
            Service.getWeather(city).then(retJson=>{
                //类型：String  必有字段
                // 备注：白天的天气编码"00"=晴 "01"=多云 "02"=阴 "03"=阵雨 "04"=雷阵雨 "05"=雷阵雨伴有冰雹 "06"=雨夹雪 "07"=小雨 "08"=中雨
                // "09"=大雨 "10"=暴雨 "11"=大暴雨 "12"=特大暴雨 "13"=阵雪 "14"=小雪 "15"=中雪 "16"=大雪 "17"=暴雪 "18"=雾 "19"=冻雨 "20"=沙尘暴
                // "21"=小到中雨 "22"=中到大雨 "23"=大到暴雨 "24"=暴雨到大暴雨 "25"=大暴雨到特大暴雨 "26"=小到中雪 "27"=中到大雪
                // "28"=大到暴雪 "29"=浮尘 "30"=扬沙 "31"=强沙尘暴 "53"=霾 "99"=无 "301"=雨 "302"=雪
                this.weather.day_air_temperature=retJson.retData.weather.day_air_temperature
                this.weather.day_weather_code=retJson.retData.weather.day_weather_code
                this.weather.quality=retJson.retData.weather.quality
                this.weather.day_weather=retJson.retData.weather.day_weather

            })
        });


        let i = 0;
        setInterval(()=>{
            if(i >= this.stimulateList.length){
                i = 0;
            }
            this.setState({
                stimulate:this.stimulateList[i],
            });
            i++;
        },8000);
    }

    componentWillMount(){

    }

    componentDidMount() {
        TalkingData.setLocation();

        this.getData();

        /*HotUpdate.checkUpdate(()=>{
            // console.info("Tools.app_config.serviceConfig.closeVersion",Tools.app_config.serviceConfig.closeVersion)
            if(!__DEV__&&Tools.app_config.serviceConfig.closeVersion === DeviceInfo.getVersion()){
                // Loading.show(false,"抱歉运营通2.0暂不提供服务");
                Loading.show(false,Tools.app_config.serviceConfig.closeVersionReason);
            }
            else
            {
                this.getData();
            }

        });*/
        /*this.props.navigation. = { swipeEnabled:false};*/

    }

    onMomentumScrollEnd = ()=>{
        if(this.itemTripFirst){
            this.itemTripFirst.measure().then((pos) => {

                if(pos.py < StyleSheetAdapt.getHeight(Theme.Height.heightGuideTop))
                {
                    // alert("小于： " + JSON.stringify(pos) + " h：" + StyleSheetAdapt.getHeight(Theme.Height.heightGuideTop))
                    this.setState({
                        viewBottom:{
                            vBFrame2_IconRotate:styles.vBFrame2_IconRotate,
                            text:'收起',
                        }
                    });
                }
                else
                {
                    // alert("大于： " + JSON.stringify(pos) + "  h:" + StyleSheetAdapt.getHeight(Theme.Height.heightGuideTop))
                    this.setState({
                        viewBottom:{
                            vBFrame2_IconRotate: null,
                            text:'查看更多',
                        }
                    });
                }

                // callback && callback();
            });
        }

    }

    getResultProgressRate(){
        let {resultFinishCustomerData} = this.state;
        // console.info("resultFinishCustomerData: ",resultFinishCustomerData)
        return {
            titleList:[
                {
                    title:'目标',
                    color:Theme.Colors.minorColor
                },
                {
                    title:'达成',
                    color:Theme.Colors.themeColor
                },
                {
                    title:'完成率',
                    color:Theme.Colors.barGreen
                },
            ],
            sectionList:[
                {
                    title:'新客户',
                    progressList:[
                        {
                            progress:1,
                            textRight:(resultFinishCustomerData.new_operations_target * 1).toFixed(2) + "/万元"

                        },
                        {
                            textRight:(resultFinishCustomerData.newStoreNum * 1).toFixed(2) + "/万元",
                            progress:resultFinishCustomerData.newStoreNum/resultFinishCustomerData.new_operations_target,
                            colors1:Theme.Colors.themeColor,
                        },
                        {
                            textRight:(((resultFinishCustomerData.perNewFinish * 100).toFixed(1))/10000).toFixed(2) + "%",
                            progress:resultFinishCustomerData.newStoreNum/resultFinishCustomerData.new_operations_target,
                            colors1:Theme.Colors.barGreen,
                        }
                    ]
                },
                {
                    title:'老客户',
                    progressList:[
                        {
                            progress:1,
                            textRight:(resultFinishCustomerData.old_operations_target * 1).toFixed(2) + "/万元"

                        },
                        {
                            textRight:(resultFinishCustomerData.oldStoreNum * 1).toFixed(2) + "/万元",
                            progress:resultFinishCustomerData.oldStoreNum/resultFinishCustomerData.old_operations_target,
                            colors1:Theme.Colors.themeColor,
                        },
                        {
                            textRight:(((resultFinishCustomerData.perOldFinish * 100).toFixed(1))/10000).toFixed(2) + "%",
                            progress:resultFinishCustomerData.oldStoreNum/resultFinishCustomerData.old_operations_target,
                            colors1:Theme.Colors.barGreen,
                        }
                    ]
                }
            ]
        }

    }

    onSwipeRight = ()=>{
        // console.log(this.num)
        // Tools.toast("R")
    }

    onSwipeLeft = ()=>{
        // Tools.toast("L")

        setInterval(()=>{
            this.setState({
                yy:'rr'
            });
        },5000)
    }

    openFile(item,i){

        if(item.content.toLowerCase().indexOf(".jpg") > -1
            || item.content.toLowerCase().indexOf(".png") > -1){
            this.goPage('PagePictureDetail',{id:item.id})
        }
        else{
            Tools.openDoc(item.content);
        }

    }

    render() {

        const {resultEstimateData,noticesData,resultFinishProgress,
            tripListData,customerObj,isNews,pictures,path,dataSize,picture} = this.state;

        return (
            <ViewTitle viewBottom={
                <TouchableOpacity style={styles.vBFrame}
                                  onPress={this.onViewBottom}>
                    <View style={styles.vBFrame1}>
                        <Text style={styles.vBFrame1_text}>
                            {this.state.viewBottom.text}
                        </Text>
                    </View>

                    <View style={styles.vBFrame2}>
                        <Image source={require('images/toDownMore.png')}
                               style={[
                                   styles.vBFrame2_Icon,
                                   this.state.viewBottom.vBFrame2_IconRotate]}/>
                    </View>
                </TouchableOpacity>
            }
                       ref={(viewTitle) => { this.viewTitle = viewTitle; }}
                       scrollPropsObject={{
                           onMomentumScrollEnd:this.onMomentumScrollEnd
                       }}>

                <WebViewCus />

                <View style={styles.titleTop}>
                    <View style={styles.titleTopFrame1}>
                        <Text style={styles.stimulateText}>
                            {this.state.stimulate}
                        </Text>
                    </View>

                    <View style={styles.titleTopFrame2}>
                        <View style={styles.titleTopFrame2_1}>
                            <Image source={this.weatherPicture[this.weather.day_weather_code] ?
                                this.weatherPicture[this.weather.day_weather_code] :
                                require('images/weather/02.png')}
                                   style={styles.titleTopImg}/>

                            <Text style={styles.titleTopText}>
                                气温{this.weather.day_air_temperature}
                            </Text>
                        </View>
                        <View style={styles.titleTopFrame2_1}>
                            <Text style={styles.titleTopText1}>
                                {this.weather.day_weather}
                            </Text>

                            <Text style={styles.titleTopText}>
                                空气质量&nbsp;{this.weather.quality}
                            </Text>
                        </View>
                    </View>
                </View>

                <View style={styles.titlesInfoFrame}>
                    {/*<View style={styles.titlesInfoFrame0}>
                        <ImageBackground source={require('images/notice.png')}
                                         resizeMode='contain'
                                         style={styles.titlesInfoNoticeIcon}>
                            <View style={[styles.titlesInfoNoticeIcon,styles.titlesInfoFrame_1]}>
                                <Text style={styles.titlesInfoNoticeText}>公告通知</Text>
                            </View>
                        </ImageBackground>
                    </View>

                    <SwiperNotice dataList={noticesData}/>

                    <View style={styles.titlesInfoFrame0_1}>
                        <Image source={require('images/noticeBottom.png')}
                               style={styles.titlesInfoNoticeIcon2}/>
                    </View>*/}

                    <SwiperNotice dataList={noticesData}/>
                </View>

                <ViewCtrl style={[styles.titleImgFrame]}
                          onSwipeRight={this.onSwipeRight}
                          onSwipeLeft={this.onSwipeLeft}>

                    <ImageChange icon={require('images/rightBlack.png')}
                                 iconStyle={[styles.imageRight,styles.imageRight2]}
                                 frameStyle={styles.imageRightFrame}
                                 onPress={this.pressLeft}/>

                    <ImageChange icon={this.path[0]}
                                 iconStyle={styles.imageLeft}
                                 frameStyle={styles.imageLeftFrame}/>

                    <ScrollViewRowList frameStyle={styles.frameStyle}
                                       imageFrameStyle={styles.imageFrameStyle}
                                       iconStyle={[styles.imageFrameStyles,styles.imgIcon,]}
                                       isScroll={false}
                                       dataList={this.picture}
                                       onPress={(item,index)=>{this.openFile(item,index)}}/>


                    <ImageChange icon={require('images/rightBlack.png')}
                                 iconStyle={styles.imageRight}
                                 frameStyle={styles.imageRightFrame}
                                 onPress={this.pressRight}/>

                </ViewCtrl>

                <View style={styles.titlesInfoFrame1}>
                    {
                        (resultEstimateData != null && resultEstimateData.length > 0)
                            ? <View style={styles.titlesInfoFrame1_1}>

                                <View style={styles.titlesInfoFrame1_1_1}>
                                    <View style={styles.titlesInfoFrame1_1_1_1}></View>
                                    <Text style={styles.titlesInfoFrame1_1_1_1_Text}>
                                        业绩预估
                                    </Text>
                                </View>

                                <View style={styles.titlesInfoFrame1_1_2}>
                                    <Charts.Chart type={Charts.Chart.type.barHome}
                                                  height={StyleSheetAdapt.getHeight((Tools.platformType ? 200 : 180))}
                                                  width={StyleSheetAdapt.getWidth((Tools.platformType ? '0.25w' : 400))}
                                                  option={{
                                                      data:resultEstimateData,
                                                      unit:'元',
                                                  }}
                                    />
                                </View>

                            </View>
                            : null
                    }

                    <ResultProgressBlock progressCircle={resultFinishProgress}
                                         frameStyle={styles.frameRPB}
                                         status={this.state.status}
                                         options={this.getResultProgressRate()}
                                         onPressTitleRight={this.onPressResult}/>

                </View>

                <View style={styles.titlesInfoFrame2}>

                    <TouchableOpacity style={styles.titlesInfoFrame2_1}
                                      onPress={()=>this.onGoPages(1)}>
                        <ImageBackground source={require('images/customerNewCount.png')}
                                         resizeMode='contain'
                                         style={styles.titlesInfoFrame2_1_img}>
                            <View style={[
                                styles.titlesInfoNoticeIcon,
                                styles.titlesInfoFrame2_1_1]}>
                                <Text style={styles.titlesInfoNoticeText}>
                                    {customerObj.customerNewNum}
                                    <Text style={[
                                        styles.titlesInfoNoticeText,
                                        styles.titlesInfoFrame2_1_1_text
                                    ]}>
                                        个
                                    </Text>
                                </Text>

                                <Text style={[styles.titlesInfoFrame2_1_1_text,styles.titlesInfoFrame2_1_1_text_new]}>
                                    新增
                                    <Text style={styles.titlesInfoFrame2_1_1_text}>客户</Text>
                                </Text>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.titlesInfoFrame2_1}
                                      onPress={()=>this.onGoPages(2)}>
                        <ImageBackground source={require('images/customerNoVisitCount.png')}
                                         resizeMode='contain'
                                         style={styles.titlesInfoFrame2_1_img}>
                            <View style={[
                                styles.titlesInfoNoticeIcon,
                                styles.titlesInfoFrame2_1_1]}>
                                <Text style={styles.titlesInfoNoticeText}>
                                    {customerObj.customer1DayNum}
                                    <Text style={[
                                        styles.titlesInfoNoticeText,
                                        styles.titlesInfoFrame2_1_1_text
                                    ]}>
                                        个
                                    </Text>
                                </Text>

                                <Text style={[
                                    styles.titlesInfoFrame2_1_1_text,styles.titlesInfoFrame2_1_1_text_24]}>
                                    超24小时
                                    <Text style={styles.titlesInfoFrame2_1_1_text}>{'\n'}未电话回访</Text>
                                </Text>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.titlesInfoFrame2_1}
                                      onPress={()=>this.onGoPages(3)}>
                        <ImageBackground source={require('images/customerNoVisitMonCount.png')}
                                         resizeMode='contain'
                                         style={styles.titlesInfoFrame2_1_img}>
                            <View style={[
                                styles.titlesInfoNoticeIcon,
                                styles.titlesInfoFrame2_1_1]}>
                                <Text style={styles.titlesInfoNoticeText}>
                                    {customerObj.customer30DayNum}
                                    <Text style={[
                                        styles.titlesInfoNoticeText,
                                        styles.titlesInfoFrame2_1_1_text
                                    ]}>
                                        个
                                    </Text>
                                </Text>

                                <Text style={[
                                    styles.titlesInfoFrame2_1_1_text, styles.titlesInfoFrame2_1_1_text_24]}>
                                    超30天
                                    <Text style={styles.titlesInfoFrame2_1_1_text}>{'\n'}未电话回访</Text>
                                </Text>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                    <TouchableOpacity style={[
                        styles.titlesInfoFrame2_1,
                        styles.titlesInfoFrame2_2
                    ]}
                                      onPress={()=>this.onGoPages(4)}>
                        <ImageBackground source={require('images/customerNoVisit2MonCount.png')}
                                         resizeMode='contain'
                                         style={styles.titlesInfoFrame2_1_img}>
                            <View style={[
                                styles.titlesInfoNoticeIcon,
                                styles.titlesInfoFrame2_1_1]}>
                                <Text style={styles.titlesInfoNoticeText}>
                                    {customerObj.customer60DayNum}
                                    <Text style={[
                                        styles.titlesInfoNoticeText,
                                        styles.titlesInfoFrame2_1_1_text
                                    ]}>
                                        个
                                    </Text>
                                </Text>

                                <Text style={[
                                    styles.titlesInfoFrame2_1_1_text,styles.titlesInfoFrame2_1_1_text_new]}>
                                    超60天
                                    <Text style={styles.titlesInfoFrame2_1_1_text}>{'\n'}未上门拜访</Text>
                                </Text>
                            </View>
                        </ImageBackground>
                    </TouchableOpacity>

                </View>

                <View style={styles.titlesInfoFrame3}>

                    <View style={styles.titlesInfoFrame1_1_1}>
                        <View style={styles.titlesInfoFrame1_1_1_1}></View>
                        <Text style={styles.titlesInfoFrame1_1_1_1_Text}>待办事项 ({dataSize})</Text>
                        <ImageChange icon={require('images/upDown.png')}
                                     style={styles.titlesInfoFrame1_1_1_1_icon}
                                     iconStyle={this.state.upDownStyle}
                                     onPress={this.onUpDown}/>
                        <TextDoubleIcon onPress={this.onPressTrip}
                                        style={styles.TextDoubleIcon1}
                                        frameStyleRight={styles.TextDoubleIcon2}
                                        textStyleRight={styles.TextDoubleIcon3}
                                        icon={true}/>
                    </View>

                    <View style={styles.titlesInfoFrame3_2}>
                        {
                            tripListData.map(this.renderViewTrip)
                        }
                        {/*<FlatListView*/}
                        {/*data={tripListData}*/}
                        {/*keyExtractor={(item,index)=>("key"+index)}*/}
                        {/*renderItem={({item,index})=>this.renderViewTrip(item,index)}*/}
                        {/*onEndReached={()=>this.getMoreData()}/>*/}
                        {/*<FlatListView style={styles.flatListView}*/}
                        {/*data={dataList}*/}
                        {/*keyExtractor = {(item, index) => ("key" + index)}*/}
                        {/*renderItem={({item,index}) => this.renderItemView(item,index)}*/}
                        {/*onEndReached={() =>this.getData()}*/}
                        {/*/>*/}

                    </View>

                </View>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    imageLeftFrame:{
        width:90,
        height:"130dw",
        alignItems:'center',
        justifyContent:'center',
        marginLeft:5,
        borderRadius:Theme.Border.borderRadius,
    },
    imageLeft:{
        width:90,
        height:"130dw",
        resizeMode:Image.resizeMode.stretch,
        borderRadius:Theme.Border.borderRadius,
    },
    imgIcon:{
        resizeMode:Image.resizeMode.stretch,
        borderRadius:Theme.Border.borderRadius,
    },
    imageRight2:{
        transform:[
            {rotateY:'180deg'}
        ],
    },
    imageRight:{
        width:15,
        height:'15dw',
        tintColor:Theme.Colors.themeColor,
    },
    imageRightFrame:{
        width:30,
        height:"75dw",
        backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        borderRadius:Theme.Border.borderRadius,
    },
    frameStyle:{
        flex:1,
        marginRight:5,
        marginLeft:5,
    },
    imageFrameStyles:{
        height:"125dw",
        width:150,
    },
    imageFrameStyle:{
        height:"125dw",
        // width:10,
    },
    titleImgFrame:{
        alignItems:'center',
        justifyContent:'center',
        flex:1,
        flexDirection:'row',
        marginTop:10,
    },

    titleTopText1:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    titleTopText:{
        fontSize:Theme.Font.fontSize_2,
    },
    titleTopImg:{
        width:30,
        height:'30dw',
        resizeMode:'contain',
    },
    titleTopFrame2_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',

    },
    titleTopFrame2:{
        flex:3,
        flexDirection:'row',
    },
    titleTopFrame1:{
        flex:7,
    },
    titleTop:{
        backgroundColor:Theme.Colors.foregroundColor,
        flex:1,
        flexDirection:'row',
        marginTop:10,
        padding:10,
    },

    stimulate:{
        height:Theme.Height.height1,
        //alignItems:'center',
        justifyContent:'center',
    },
    stimulateText:{
        paddingLeft:10,
        color:Theme.Colors.themeColor,
        fontSize:Theme.Font.fontSize_1_1,
    },
    frameRPB:{
        marginLeft:10,
        marginRight:10,
    },

    titlesInfoFrame:{
        // alignItems:'center',
        // justifyContent:'center',
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
    titlesInfoFrame0:{
        alignItems:'center',
        justifyContent:'center',
    },
    titlesInfoFrame0_1:{
        // backgroundColor:'red',
        marginTop:-25,
    },
    titlesInfoFrame_1:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'flex-end',
        marginTop:0,
    },
    titlesInfoNoticeIcon:{
        alignItems:'center',
        justifyContent:'center',
        width:200,
        height:60,
        marginTop:10,
    },
    titlesInfoNoticeIcon2:Tools.platformType
        ? {
            resizeMode:"contain",
            // marginTop:-25,
            width:'w',
        }
        : {
            resizeMode:"contain",
            width:'w',
            // backgroundColor:'yellow',
            // top:-25,
            height:45,
        },
    titlesInfoNoticeText: {
        fontSize: Theme.Font.fontSize1,
        color:Theme.Colors.colorFontBtn,
        marginRight:30,
        fontWeight:'bold',
    },

    titlesInfoFrame1:{
        flexDirection:'row',
        height:220,
        marginTop:10,
        paddingBottom: 10,
        /*alignItems:'center',
         justifyContent:'flex-end',*/
    },
    titlesInfoFrame1_1:{
        flex:1,
        backgroundColor:Theme.Colors.foregroundColor,
        marginLeft:10,
    },
    titlesInfoFrame1_1_1:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titlesInfoFrame1_1_2:Tools.platformType
        ? {
            flex:1,
            bottom:20,
            /*alignItems:'center',
            justifyContent:'center',*/
        }
        : {
            flex:1,
            marginTop:15,
        },
    titlesInfoFrame1_1_1_1:{
        width:5,
        // height:30,
        backgroundColor:Theme.Colors.themeColor,
    },
    titlesInfoFrame1_1_1_1_Text:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    titlesInfoFrame1_1_1_1_icon:{
        width:Theme.Font.fontSize,
        height:Theme.Font.fontSize,
        marginLeft:20,
    },

    TextDoubleIcon1:{
        alignItems: 'flex-start',
        // justifyContent:'center',
        borderBottomWidth:0,
        flex:1,
        padding:0,
    },
    TextDoubleIcon2:{
        paddingRight:0
    },
    TextDoubleIcon3:{
        padding:0,
        color:Theme.Colors.themeColor,
    },

    titlesInfoFrame2:{
        flex:1,
        flexDirection:'row',
        height:Tools.platformType ? 95 : 85,
        paddingBottom:10,
        // top:5,
        /* alignItems:'center',
         justifyContent:'center',*/
    },
    titlesInfoFrame2_1:{
        flex:1,
        marginLeft:10,
        alignItems:'center',
        justifyContent:'center',
        // backgroundColor:Theme.Colors.themeColor,
    },
    titlesInfoFrame2_1_img:{
        flex:1,
        margin:0,
        padding:0,
        // height:80,
        width:StyleSheetAdapt.getWidth('0.25w') - StyleSheetAdapt.getWidth(10) + 'n',
        // borderRadius:10,
    },
    titlesInfoFrame2_1_1:{
        flexDirection:'column',
        alignItems: 'flex-start',
        justifyContent:'flex-start',
        marginLeft:50,
    },
    titlesInfoFrame2_1_1_text:{
        fontSize:Theme.Font.fontSize_2,
        color:Theme.Colors.foregroundColor,
    },
    titlesInfoFrame2_1_1_text_new:{
        color:"#ffff33"
    },
    titlesInfoFrame2_1_1_text_24:{
        color:"#ff3333"
    },
    titlesInfoFrame2_1_1_text_1:{
        // marginTop:-5,
    },
    titlesInfoFrame2_2:{
        marginRight:10,
    },

    titlesInfoFrame3:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titlesInfoFrame3_2:{
        marginLeft:10,
        marginRight:10,
    },

    vBFrame:{
        alignItems:'center',
        justifyContent:'center',
        backgroundColor:Theme.Colors.foregroundColor,
    },
    vBFrame1:{
        marginTop:5,
        marginBottom:5,
    },
    vBFrame1_text:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.themeColor,
    },
    vBFrame2:{
        marginBottom:5,
    },
    vBFrame2_Icon:{
        width:20,
        height:10,
        resizeMode:'contain',
    },
    vBFrame2_IconRotate:{
        transform:[
            {rotateX:'180deg'}
        ],
    },
    contentRow:{
        marginBottom:10,
    },
});