import {
    Http,
    HttpUrls,
    Tools,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    constructor(){
        pageNumber:1
    }

    /**
     * 天气情况和推送数据量
     * @param cityCode int,//城市代码
     * @param city string,//城市名
     * **/
    static getPushNum(cityCode,city) {

        cityCode = cityCode == undefined ? null : cityCode;
        city = city == undefined ? null : city;
        return Http.post(HttpUrls.urlSets.urlWeather, {
            cityCode:cityCode,
            city:city
        },false)
            .then((retJson) => retJson.retData)
            .catch((status) => status);
    }

    /**
     * 获取业绩预估
     * **/
    static getResultEstimate(){
        return Http.post(HttpUrls.urlSets.urlProgressResultEstimateGet, {})
            .then((retJson) => retJson.retData)
            .catch((status) => status);
    }

    /**
     * 获取公告
     * **/
    static getNotices(){

        return new Promise(resolve => {

            Http.post(HttpUrls.urlSets.urlHomeNoticesGet, {},false)
                .then((retJson) => {
                    // console.log(JSON.stringify(retJson))
                    let dataList = [];
                    retJson.retListData.forEach((v,i,a) =>{
                        dataList.push({
                            // icon:'http://static.lexin580.com/files/ProductPicture\\ca3c816d-3988-446e-9595-9fc781ee5c10_20180503142224.jpg',//图片地址或require图片
                            icon:v.cover,//图片地址或require图片
                            onPress:null,//回调事件
                            title:v.title,//标题
                            content:v.theme,//内容
                            author:'发布人：' + v.releaseBy,//发布人
                            time:Tools.timeFormatConvert(v.crleaseDate,"YYYY-MM-DD HH:mm"),//时间
                            html:v.content,
                        })
                    });

                    resolve(dataList);
                    // return dataList;
                })
                .catch((status) => status);
        });
    }

    /*
    **
    * 获取数据
    * @param val 参数
    */
    static getInfo() {
        return Http.post(HttpUrls.urlSets.urlInform,
            {userId :Tools.userConfig.userInfo.id},false).then(retJson => {

            if(retJson.retListData == undefined || retJson.retListData.length == 0) {
                retJson.retListData = [];
            }
            return retJson.retListData;
        });
    }

    /**
     * 获取出差数据列表
     * **/
    static getTtipList(){
        return Http.post(HttpUrls.urlSets.urlTaskLst, {
            userId:Tools.userConfig.userInfo.id,
            sort: 'create_time',
            order: 'desc',
            pageNumber: 1,
            pageSize: 20,
            type:'1',//请求运营中心一下的分公司
            filter: {
                parent_id:'0',
                task_type: '2',
                begin_time:'',//开始时间,格式：YYYY-MM-DD HH:mm:ss
                end_time:'',//结束时间,格式：YYYY-MM-DD HH:mm:ss
                department_id:'',//分公司id
                dept_id:Tools.userConfig.userInfo.department_level == 1 ? '' : Tools.userConfig.userInfo.department_id,//分公司id或区域
                dep_id:'',//区域id
                queryType:'5',//'1' 查询巡店向导，任务管理，‘2’查询任务管理‘未关闭’，‘’查询所有任务数据，‘4’查询‘出差’、‘巡店’、‘临时’三种任务；5：查询状态1，3，4，6
                startTime:'',//任务预计开始时间
                endTime:'',//任务预计结束时间
                number:'',//搜索任务编号
            },//查询条件
        },false)
            .then((retJson) => {
                retJson.retListData.forEach((v,i,a)=>{
                    v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY年MM月DD日 HH:mm");
                    v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY年MM月DD日 HH:mm");
                });
                return retJson.retListData;
            })
    }

    /**
     * 获取业绩 完成进度 数据
     * **/
    static getResultProgress(){
        return Http.post(HttpUrls.urlSets.urlResultAnalysisInfo, {
            user_id:Tools.userConfig.userInfo.id,//用户id
            department_level:Tools.userConfig.userInfo.department_level,
            //目标参数
            month:Tools.timeFormatConvert((new Date()).getTime(),"YYYY-MM"),//查询月份
            framework_id:Tools.userConfig.userInfo.department_id,//部门id

            //完成参数
            pageNumber: 1,
            pageSize: 10000,

        })
            .then((retJson) => retJson.retData)
            .catch((status) => status);
    }

    /**
     * 获取业绩 新老客户完成进度情况 数据
     * **/
    static getResultProgressCustomer(){

        let param = {
            user_id:Tools.userConfig.userInfo.id,//用户id
            department_level:Tools.userConfig.userInfo.department_level,
            //目标参数
            month:Tools.timeFormatConvert((new Date()).getTime(),"YYYY-MM"),//查询月份
            framework_id:Tools.userConfig.userInfo.department_id,//部门id

            //完成参数
            pageNumber: 1,
            pageSize: 10000,
        };

        return new Promise(function (resolve, reject) {
            Http.post(HttpUrls.urlSets.urlResultProgressCenter, param)
                .then((retJson1) => {

                    let dataObj = {
                        old_operations_target:(retJson1.retData.old_operations_target).toFixed(2),
                        new_operations_target:(retJson1.retData.new_operations_target).toFixed(2),
                        newStoreNum:retJson1.retData.new_month_achievement,
                        oldStoreNum:retJson1.retData.old_month_achievement,
                        perNewFinish:(retJson1.retData.new_month_achievement / retJson1.retData.new_operations_target)*10000,
                        perOldFinish:(retJson1.retData.old_month_achievement / retJson1.retData.old_operations_target)*10000,

                        resultFinishProgress:(retJson1.retData.new_month_achievement+retJson1.retData.old_month_achievement) /
                                                (retJson1.retData.old_operations_target+retJson1.retData.new_operations_target)
                    };

                    resolve(dataObj);

                })
                .catch((status) => {
                    reject(status);
                });
        });


    }

    /**
     * 获取客户数量
     * **/
    static getCustomerNum(){
        /**
         * newStoreNum			新客户数量
         unPhoneVisit24hour	24小时未电话回访客户数量
         unPhoneVisit30day	30天未电话回访客户数量
         unTaskVisit60day	60天未巡店客户数量
         * **/
        return Http.post(HttpUrls.urlSets.urlHomeVisitNum, {
            user_id:Tools.userConfig.userInfo.id,//用户id
            department_level:Tools.userConfig.userInfo.department_level,//部门级别
            //目标参数
            month:Tools.timeFormatConvert((new Date()).getTime(),"YYYY-MM"),//查询月份
            framework_id:Tools.userConfig.userInfo.department_id,//部门id
        })
            .then((retJson) => retJson.retData)
            .catch((status) => status);
    }


    /**
     * 获取图片
     */
    // static getPicture(){
    //     return Http.post(HttpUrls.urlSets.urlGetPicture).then(retJson=>{
    //             var arr=[];
    //             for(var i in retJson.retData){
    //                 arr.push(retJson.retData[i])
    //             }
    //             console.log(JSON.stringify(arr));
    //             return arr
    //         }
    // )}
    static getPicture(){
        return Http.post(HttpUrls.urlSets.urlGetPicture,{
            filter:{
                type:"2",
                dept_id:Tools.userConfig.userInfo.department_id
                },sort:"sticky DESC,fcreate_time",order:"desc",pageSize:20}).then(retJson=>{

                return retJson.retListData
            }
        )}
    static getWeather(city){
        return Http.post(HttpUrls.urlSets.urlWeather,{city:city}).then(retJson=>{
                console.log(retJson)
                return retJson
            }
        )}


    static getEvent(){
        return Http.post(HttpUrls.urlSets.urlInfoKnowledgeList, reuestData,init)
            .then((retJson) => {

                // alert(this.base.paramsFetch.pageNumber)
                this.base.retJson.total = retJson.retData.total;
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                // alert(JSON.stringify(retJson));
                retJson.retListData.forEach((val,i,arr) =>{
                    val.content = val.content.split(',');

                    let item = {
                        uri:val.content[0],//打开文件的地址 isOpenFile为true时调用
                        icon:'',//显示图片
                        title:val.title,//子元元素显示文本 isShowHeader为false可以不传
                        text:Tools.timeFormatConvert(val.create_time,'YYYY-MM-DD'),//第二行小字显示文本
                    };


                    item.icon = item.uri.indexOf(".do") > -1
                        ? ImageDoc
                        : item.uri.indexOf(".xl") > -1
                            ? ImageXls
                            : item.uri.indexOf(".ppt") > -1
                                ? ImagePpt
                                : ImagePdf;



                    this.base.retJson.retListData.push([item]);
                });

                // this.base.retJson.retListData.concat(retJson.retListData);
                // console.info("base:",this.base);
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });
    }
}