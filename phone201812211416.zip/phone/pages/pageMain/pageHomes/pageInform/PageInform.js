/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
    TextIconBg,
} from "com";
import {Service} from "./Service";

/**
 * 通知列表
 */
type Props = {};
class PageInform extends BaseComponent<Props> {
    constructor(props) {
        super(props);

        this.state = {
            test:{
                row: [
                    {icon: require("images/examination.png"),
                        progress:0.9,onPress:() => {
                        this.goPage("PageFightPlan");
                    }},
                ]
            },
            systemInformSum:0,
            taskInformSum:0,
            childrens:[],//系统通知统计
            clearDrop:false,//是否清空下拉框
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });
    }

    componentDidMount() {
        this.getData();
    }

    getData() {
        Service.get().then(retJson =>{
            let syssum = 0;
            let tasksum = 0;
            retJson.forEach((val)=>{
                if(val.code == 1){
                    tasksum = parseInt(val.unread_num);
                    tasksum = tasksum >= 100 ? 99 : tasksum;
                }else if(val.code == 2){
                    syssum = parseInt(val.unread_num);
                    syssum = syssum >= 100 ? 99 : syssum;
                    this.state.childrens = val.childrens;
                }
            });

            this.setState({
                systemInformSum:syssum,
                taskInformSum:tasksum
            });
        });
    }

    onSearch(val){
        if(val == 0){
            this.goPage("PageTaskInform");
        }else{
            this.goPage("PageSystemInform",{childrens:this.state.childrens});
        }
    }

    render() {
        return (
            <ViewTitle>
                {/* <TextIconBg frameStyle={styles.frameStyle}
                 isScroll={false}
                 size={150}
                 progress={0.5} />*/}

                <View style={styles.model}>
                    {
                        this.state.taskInformSum > 0 ?

                            <View style={styles.view}>
                                <ButtonChange text={"任务通知"}
                                              onPress={() => this.onSearch(0)}
                                              textStyle={styles.viewText}
                                              style={styles.buttonStyle}/>
                                <View style={styles.circle}>
                                    <Text style={styles.circleText}>{this.state.taskInformSum}</Text>
                                </View>
                            </View>
                            : null
                    }

                    {
                        this.state.systemInformSum > 0 ?

                            <View style={styles.view}>
                                <ButtonChange text={"系统通知"}
                                              onPress={() => this.onSearch(1)}
                                              textStyle={styles.viewText}
                                              style={styles.buttonStyle}/>
                                <View style={styles.circle}>
                                    <Text style={styles.circleText}>{this.state.systemInformSum}</Text>
                                </View>
                            </View>
                            : null
                    }

                </View>
            </ViewTitle>
        )
    }
}

const styles = StyleSheetAdapt.create({
    model:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    view:{
        height:60,
        flexDirection:'row',
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
        alignItems:'center',
        justifyContent:'center',
    },
    viewText:{
        fontSize:Theme.Font.fontSize1,
        color:Theme.Colors.minorColor,
        width:680,
    },
    circle:{
        borderRadius: 50,
        width: 30,
        height: 30,
        backgroundColor:"#FF3B30",
        alignItems:'center',
        justifyContent:'center',
    },
    circleText:{
        color:Theme.Colors.foregroundColor,
        fontSize:Theme.Font.fontSize_1,
    },
    buttonStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    }
});

import {
    TabNavigator,
} from 'comThird';

import PageSystemInform from "./pageSystemInform/PageSystemInform";
import PageInformList from "./pageInformList/PageInformList";
import PageTaskInform from "./pageTaskInform/PageTaskInform";

const TabRouteConfigs = {
    PageInform: {
        screen: PageInform,
        navigationOptions: {
            title: '通知',
            tabBarLabel: '通知',
        },
    },

    PageSystemInform: {
        screen: PageSystemInform,
        navigationOptions: {
            title: '系统通知',
            tabBarLabel: '系统通知',
        },
    },

    PageInformList: {
        screen: PageInformList,
        navigationOptions: {
            title: '系统通知',
            tabBarLabel: '系统通知',
        },
    },

    PageTaskInform:{
        screen: PageTaskInform,
        navigationOptions: {
            title: '任务通知',
            tabBarLabel: '任务通知',
        },
    }
};

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;
