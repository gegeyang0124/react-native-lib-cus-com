import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    /**
     * 获取数据
     * @param val 参数
     */
    static get() {
        return Http.post(HttpUrls.urlSets.urlInform,
            {userId :Tools.userConfig.userInfo.id},false).then(retJson => {

                if(retJson.retListData == undefined || retJson.retListData.length == 0) {
                    retJson.retListData = [];
                }
                return retJson.retListData;
            });
    }
}