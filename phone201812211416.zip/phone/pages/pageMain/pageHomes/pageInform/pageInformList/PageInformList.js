import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    Slider,
    ImageBackground,
    TouchableOpacity,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    Tools,
    BaseComponent,
    ImageView,
    VideoView,
    Media,
    BarcodeView,
    ProgressPer,
    Http,
    WebViewCus,
    Theme,
    SwiperNotice,
    TextDoubleIcon,
    Charts,
    ItemRowTripTask,
    ImageChange,
    TextChange,
    SearchDDDIpt,
    FlatListView,
    ButtonChange,
    ItemRowFeedback,
    PickDropdown,
} from "com";

import {Service} from './Service';

type Props = {};
export default class PageSystemInform extends BaseComponent<Props> {

    selectValue = {
        regionId: '',//下拉选中值
        provincialId: '',//下拉选中值
        cityId: '',//下拉选中值
        customerName: '',//名称输入值
        queryType:'',//额外条件单选
        execFirst: true,//是否是第一次执行
    };

    constructor(props) {
        super(props);

        this.state = {
            total: 0,//商品总数
            dataList: [],//数组列表SS
            refresh: false,//是否刷新
            clearDrop: false,
            totalType:'',//查询类型
        }

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            btn:null,
            isRenderItemFirst:true,
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });
    }

    componentWillEnter(params,action,page){
        if(params != null){
            Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
            this.selectValue.queryType = params.queryType;
            this.selectValue.execFirst = true;
            this.state.totalType =
                this.selectValue.queryType == 9 ? "24小时未电话回访" :
                    this.selectValue.queryType == 5 ? "30天未电话回访" :
                        this.selectValue.queryType == 6 ? "60天未拜访" :
                            this.selectValue.queryType == 12 ? "" : "";
            this.setState({
                total: 0,
                dataList: []
            });
        }
        this.getData(this.selectValue);
    }

    /**
     * 获取城市列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {

        if(this.selectValue != undefined){
            selectValue = this.selectValue;
        }

        if(!this.selectValue.execFirst){
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        Service.get(selectValue,this.selectValue.execFirst)
            .then(retJson =>{

                if(!this.selectValue.execFirst && !retJson.has){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                }else{
                    this.selectValue.execFirst = false;
                    this.setState({
                        total:retJson.totalElements,
                        dataList:retJson.content
                    });

                    Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                }

            })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });
    }


    renderItem(item, index) {
        return (
            <ItemRowFeedback
                isShowIcon={false}
                frameStyle={styles.itemFram}
                onPress={() => this.onItemPress(item)}
                text1_1={"客户姓名:" + item.name}
                text1_2={
                    {
                        text_1:item.customer_status == null ? undefined : item.customer_status,
                        text_2:item.contract_status == null ? "合同到期" : item.contract_status,
                        text_3:item.store_zf == null ? undefined : item.store_zf,
                        text_4:item.diagnosticScore == null ? undefined : item.diagnosticScore,
                    }
                }
                text2_1={"签约时间:" + (item.sign_time == null ? "无记录" : item.sign_time)}
                text2_2={"门店面积:" + (item.storeArea == null ? "无记录" : item.storeArea+"m²")}
                text3_1={"最近返单:" + (item.lastOrderTime == null ? "无记录" : item.lastOrderTime)}
                text3_2={"开业时间:" + (item.openDate == null ? "" : item.openDate)}
                text4_1={"最近电话回访:" + (item.lastPhoneVisitDate == null ? "无记录" : item.lastPhoneVisitDate)}
                text4_2={"最近拜访:" + (item.lastVisitDate == null ? "无记录" : item.lastVisitDate)}
                text5_1={"店铺地址:" + (item.store_address == null ? "无记录" : item.store_address)}/>
        );
    }

    onItemPress(item) {
        this.goPage("PageCustomerDocDetail", {
            store_code: item.storecode,id:item.id,progressFinish:item.diagnosticScore});
    }

    render() {
        return (
            <ViewTitle isScroll={false}>
                <View style={[styles.title,styles.titleStyle]}>
                    <View style={styles.titleIco}></View>
                    <Text style={styles.titleText}>共有{this.state.total}家客户{this.state.totalType}</Text>
                </View>

                <FlatListView
                    data={this.state.dataList}
                    keyExtractor={(item, index) => ("key" + index)}
                    renderItem={({item, i}) => this.renderItem(item, i)}
                    onEndReached={() => this.getData()}
                />
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    text1_1:{
        color:Theme.Colors.themeColor,
    },
    //顶部搜索
    searchStyle:{
        fontSize:Theme.Font.fontSize_1_1,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titleStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    title:{
        margin:10,
        flexDirection:'row',
        paddingBottom:10,
        borderBottomWidth:1,
        borderBottomColor:Theme.Colors.themeColor,
    },
    titleIco:{
        width:5,
        backgroundColor:Theme.Colors.themeColor,
    },
    titleText:{
        fontSize:Theme.Font.fontSize,
        marginLeft:20,
    },
    pFrame: {
        borderColor: Theme.Colors.minorColor,
        borderTopWidth: Theme.Border.borderWidth,
        padding: 10,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    promptFrame: {
        backgroundColor:Theme.Colors.foregroundColor,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 10,
    },
    //高级选项字体
    text: {
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.minorColor,
    },
    btn: {
        width:160,
        borderColor: Theme.Colors.minorColor,
        borderWidth: Theme.Border.borderWidth,
        padding: 3,
        backgroundColor: Theme.Colors.backgroundColor,
    },
    interval: {
        marginLeft: 5,
        borderRadius: 30,
        width: 185,
    },
    interval2: {
        marginRight: 5,
    },
    btnActive:{
        borderWidth:0,
        backgroundColor:Theme.Colors.themeColor,
    },
    textBtnActive:{
        color:Theme.Colors.backgroundColor,
    },
    itemFram:{
        backgroundColor:Theme.Colors.foregroundColor,
    }
});