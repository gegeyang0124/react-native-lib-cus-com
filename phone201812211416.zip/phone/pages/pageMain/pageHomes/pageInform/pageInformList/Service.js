import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    constructor() {
        Service.base = this;
    }

    retList = [];

    retJson = {
        retData: {
            has: false,//是否有数据，true:有，false:没有，默认是false
        },
        totalElements: 0,
    };//后台返回数据

    paramsFetch = {
        pageNumber:0,
        executing:false,//是否正在执行中
    };

    /**
     * 提交搜索数据
     * @param val 参数
     */
    static get(val,init) {

        init = init == undefined ? false : init;

        if(init || this.base == undefined){
            new Service();
        }

        if(init){
            this.base.paramsFetch.pageNumber = 0;
            this.base.retJson.retData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }else {
            this.base.paramsFetch.executing = true;
        }

        if(val == undefined){
            return Http.get(HttpUrls.urlSets.urlCustomerListGet,
                {jobGrade:Tools.userConfig.userInfo.job_grade,
                    userId :Tools.userConfig.userInfo.id,
                    number :this.base.paramsFetch.pageNumber,
                    size: 10},init)
                .then(retJson => {

                    if(retJson.retData != undefined){
                        if(retJson.retData.content == undefined || retJson.retData.content.length == 0) {
                            retJson.retData.content = [];
                            this.base.retJson.retData.has = false;
                        }else{
                            this.base.paramsFetch.pageNumber++;
                            this.base.retJson.retData.has = true;
                        }
                    }else{
                        retJson.retData.content = [];
                        this.base.retJson.retData.has = false;
                    }

                    retJson.retData.content.forEach((val,i,arr) =>{
                        this.base.retList.push(val);
                    });

                    this.base.retJson.retData.content = this.base.retList;
                    this.base.retJson.retData.totalElements = retJson.retData.totalElements;
                    this.base.paramsFetch.executing = false;

                    return this.base.retJson.retData;
                });
        }else{
            return Http.get(HttpUrls.urlSets.urlCustomerListGet,
                {regionId:val.regionId,provincialId:val.provincialId,
                    userId :Tools.userConfig.userInfo.id,
                    number :this.base.paramsFetch.pageNumber,
                    size: 10,cityId:val.cityId,
                    jobGrade:Tools.userConfig.userInfo.job_grade,
                    customerName:val.customerName,
                    queryType:val.queryType
                },init)
                .then(retJson => {

                    if(retJson.retData != undefined){

                        if(retJson.retData.content == undefined || retJson.retData.content.length == 0) {
                            retJson.retData.content = [];
                            this.base.retJson.retData.has = false;
                        }else{
                            this.base.paramsFetch.pageNumber++;
                            this.base.retJson.retData.has = true;
                        }
                    }else{
                        retJson.retData.content = [];
                        this.base.retJson.retData.has = false;
                    }

                    retJson.retData.content.forEach((val,i,arr) =>{
                        this.base.retList.push(val);
                    });

                    this.base.retJson.retData.content = this.base.retList;
                    this.base.retJson.retData.totalElements = retJson.retData.totalElements;
                    this.base.paramsFetch.executing = false;

                    return this.base.retJson.retData;
                });
        }
    }
}