/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
} from "com";
import {Service} from "./Service";

/**
 * 通知列表
 */
type Props = {};
export default class PageSystemInform extends BaseComponent<Props> {
    constructor(props) {
        super(props);

        this.state = {
            oneDaySum:2,
            oneMonthDaySum:3,
            twoMonthDaySum:1,
            expire:2,
            loading:false,//是否清空下拉框
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });
    }

    componentWillEnter(params,action,page){
        if(params != null){
            params.childrens.forEach((val)=>{
                if(val.code == 203){
                    this.state.oneDaySum = val.unread_num
                }else if(val.code == 204){
                    this.state.oneMonthDaySum = val.unread_num
                }else if(val.code == 205){
                    this.state.twoMonthDaySum = val.unread_num
                }
            });
            this.setState({
                loading:true,
            });
        }
        this.getData();
    }

    getData() {

    }

    onSearch(val){
        if(val == 0){
            this.goPage("PageInformList",{queryType:9});
        }else if(val == 1){
            this.goPage("PageInformList",{queryType:5});
        }else if(val == 2){
            this.goPage("PageInformList",{queryType:10});
        }else{
            this.goPage("PageInformList",{queryType:11});
        }
    }

    render() {
        return (
            <ViewTitle>
                <View style={styles.model}>
                    {
                        this.state.oneDaySum > 0 ?
                            <View style={styles.view}>
                                <ButtonChange text={"24小时未回访"}
                                    onPress={()=>this.onSearch(0)}
                                    textStyle={styles.viewText}
                                    style={styles.buttonStyle}  />
                                <View style={styles.circle}>
                                    <Text style={styles.circleText}>{this.state.oneDaySum}</Text>
                                </View>
                            </View>
                            : null
                        }

                    {
                        this.state.oneMonthDaySum > 0 ?
                            <View style={styles.view}>
                                <ButtonChange text={"30天未回访"}
                                              onPress={()=>this.onSearch(1)}
                                              textStyle={styles.viewText}
                                              style={styles.buttonStyle}  />
                                <View style={styles.circle}>
                                    <Text style={styles.circleText}>{this.state.oneMonthDaySum}</Text>
                                </View>
                            </View>
                            : null
                    }

                    {
                        this.state.twoMonthDaySum > 0 ?
                            <View style={styles.view}>
                                <ButtonChange text={"60天未回访"}
                                              onPress={()=>this.onSearch(2)}
                                              textStyle={styles.viewText}
                                              style={styles.buttonStyle}  />
                                <View style={styles.circle}>
                                    <Text style={styles.circleText}>{this.state.twoMonthDaySum}</Text>
                                </View>
                            </View>
                        : null
                    }

                    {
                        this.state.expire > 0 ?
                            <View style={styles.view}>
                                <ButtonChange text={"合同到期"}
                                              onPress={()=>this.onSearch(3)}
                                              textStyle={styles.viewText}
                                              style={styles.buttonStyle}  />
                                <View style={styles.circle}>
                                    <Text style={styles.circleText}>{this.state.expire}</Text>
                                </View>
                            </View>
                        : null
                    }
                </View>
            </ViewTitle>
        )
    }
}

const styles = StyleSheetAdapt.create({
    model:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    view:{
        height:60,
        flexDirection:'row',
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
        alignItems:'center',
        justifyContent:'center',
    },
    viewText:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.minorColor,
        width:680,
    },
    circle:{
        borderRadius: 50,
        width: 30,
        height: 30,
        backgroundColor:"#FF3B30",
        alignItems:'center',
        justifyContent:'center',
    },
    circleText:{
        color:Theme.Colors.foregroundColor,
        fontSize:Theme.Font.fontSize_1,
    },
    buttonStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    }
});