/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
    Image,
} from "com";
import {Service} from "./Service";

/**
 * 任务通知
 */
type Props = {};
export default class PageTaskInform extends BaseComponent<Props> {
    icon_1=require('images/moreIcon_2.png');

    constructor(props) {
        super(props);

        this.state = {
            dataList:[],
        };

        this.setParams({
            headerLeft: true,
            headerRight:false,
        });
    }

    componentWillEnter(params){
        this.getData();
    }


    getData() {
        let dataList = [];
        Service.get().then(retJson =>{
            retJson.forEach((val)=>{
                dataList.push({
                    begin_time:val.begin_time,
                    title:val.title,
                    object_id:val.object_id,
                    id:val.id,
                })
            });

            this.setState({
                dataList:dataList,
            });
            // Tools.flatListView.showFooter(FlatListView.showFootConfig.success)
        });
    }

    onSelect(object_id,id){
        Service.readMessage(id);
        BaseComponent.isSkip = true;
        this.goPage("PageTripDetail",{id:object_id});
    }

    rederItemParent = (item,i)=>{
        return(
            <View style={styles.view} key={i}>
                <ButtonChange text={item.begin_time +" "+ item.title}
                              onPress={()=>this.onSelect(item.object_id,item.id)}
                              textStyle={styles.viewText}
                              style={styles.buttonStyle}  />
                <View style={styles.circle}>
                    <Image source={this.icon_1}
                           style={styles.versionRowIcon}></Image>
                </View>
            </View>
        );
    };

    render() {
        return (
            <ViewTitle>
                <View style={styles.model}>
                    {
                        this.state.dataList.map(this.rederItemParent)
                    }
                </View>
            </ViewTitle>
        )
    }
}

const styles = StyleSheetAdapt.create({
    model:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    view:{
        height:80,
        flexDirection:'row',
        borderBottomWidth:0.5,
        borderBottomColor:Theme.Colors.minorColor,
        alignItems:'center',
        justifyContent:'center',
    },
    viewText:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
        width:680,
    },
    circle:{
        alignItems:'center',
        justifyContent:'center',
    },
    versionRowIcon:{
        width:20,
        height:20,
        // resizeMode:"contain",
    },
    buttonStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    }
});