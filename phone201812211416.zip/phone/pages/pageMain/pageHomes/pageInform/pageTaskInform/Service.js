import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    static base;

    /**
     * 获取数据
     * @param val 参数
     */
    static get() {
        return Http.post(HttpUrls.urlSets.urlInTaskform,
            {sort:'is_read asc,fcreate_time',order:"desc",pageNumber:0,
                pageSize:1000,
                filter:{receive_user_id :Tools.userConfig.userInfo.id,
                        category:1,is_read:1}}).then(retJson => {

            if(retJson.retListData == undefined || retJson.retListData.length == 0) {
                retJson.retListData = [];
            }

            return retJson.retListData;
        });
    }

    static readMessage(id){
        let ids = [];
        ids.push(id);
        return Http.post(HttpUrls.urlSets.urlNoticeRecord,
            {notifyIds:ids,type:1}).then(retJson => {
            return retJson;
        })
    }
}