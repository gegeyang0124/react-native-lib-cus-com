import React, {Component} from 'react';
import {
    StyleSheetAdapt,
    BaseComponent,
    ImageList,
    ViewTitle,
    Theme,
} from "com";
import {Service} from './Service';


type Props = {};
export default class PagePictureDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);
        this.state={
            icon:null,//图表
            id:null,
            content:[]
        }

        this.setParams({
            headerLeft: true,
            headerRight:false
        });

    }

    getData(){
        Service.getPicture(this.state.id)
            .then(retJson=>{

                this.setState({
                    content:retJson.content
                })

            })
    }


    renderItem(item,index){
        let imageList = [];

        imageList.push(item);

        return(
            <ImageList key={index}
                       dataList={imageList}
                       isShowText={false}
                       iconStyle={styles.iconStyle}
                       imageFrameStyle={styles.imageStyle}/>
        )
    }

    componentWillEnter(params){
        if(params){
            params.content = [];
            this.setState(params,()=>{
                this.getData();
            });
        }
    }

    render() {
        const {content} = this.state;

        return (
            <ViewTitle isScroll={false}>
                <ImageList dataList={content}
                           rowCount={1}
                           isShowText={false}
                           iconStyle={styles.iconStyle}
                           imageFrameStyle={styles.imageStyle}/>
            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    imageStyle:{
        width:'w',
        height:'h',
        justifyContent: 'center',
        alignItems: 'center',
    },
    iconStyle:{
        width:'w',
        height:StyleSheetAdapt.getHeight()
        - StyleSheetAdapt.getHeight(
            Theme.Height.heightGuideTop
            + Theme.Height.heightGuideBottom
        ) + "n",
    }
})