import {
    Http,
    HttpUrls,
    Tools,
} from "com-api";

/**
 * 接口
 * **/
export class Service {
    constructor(){
        pageNumber:1
    }




    /**
     * 获取图片
     */

    static getPicture(id){
        return Http.post(HttpUrls.urlSets.urlPictureDetail,
            {id:id})
            .then(retJson=>{
                retJson.retData.content = retJson.retData.content.split(",");
                return retJson.retData;
            })
    }


}