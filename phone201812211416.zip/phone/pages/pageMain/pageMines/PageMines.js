/**
 * Created by Administrator on 2018/4/30.
 */
import {
    Theme
} from "com";
import {
    TabNavigator,
} from "comThird";

import PageMine from "./pageMine/PageMine";
import PageMinePassword from "./pageMinePassword/PageMinePassword";
import PageWorkReport from "./pageWorkReport/PageWorkReport";
import PageVersion from "./pageVersion/PageVersion"
import PageIntegral from "./pageIntegral/PageIntegral";

/**
 * 工具页面页面 引入集合
 **/
const TabRouteConfigs = {
    PageMine: {
        screen: PageMine,
        navigationOptions: {
            title:'我的',
            tabBarLabel : '我的',
        },
    },
    PageVersion:{
        screen:PageVersion,
        navigationOptions:{
            title:'版本说明',
            tabBarLabel:'版本说明'
        }
    },
    PageMinePassword: {
        screen: PageMinePassword,
        navigationOptions: {
            title:'修改密码',
            tabBarLabel : '修改密码',
        },
    },
    PageWorkReport: {
        screen: PageWorkReport,
    },
    PageIntegral:{
        screen:PageIntegral,
        navigationOptions:{
            title:'积分累计',
            tabBarLabel:'积分累计'
        }
    },
}


const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);


module.exports = pages;