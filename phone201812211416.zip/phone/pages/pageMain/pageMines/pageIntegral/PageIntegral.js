import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    ScrollViewRowList,
    Theme,
    Tools,
    ItemRowTripApply,
    ItemRowGuideTripApply,
    TextIcon,
    ImageChange,
} from "com";
import {
    Http,
    HttpUrls
} from "com-api"
import {Service} from "./Service";


type Props = {};
//个人中心进入我的背包=>积分奖励
export default class PageIntegral extends BaseComponent<Props>{
    constructor(props){
        super(props)

        this.setParams({
            headerLeft:true,
            headerRight:false
        })

        this.state={
            dataList:[]
        }
    }
    //返回奖励图表
    icon(value,item){
        // console.log(item)
        // console.log(item.desert_type)
        if(value==1){
            const icon=item.forList.map((item,index)=>
            <TextIcon iconStyle={styles.icon}
                      key={index}
                      icon={require('images/rose.png')}/>)
            return icon
        }else{
            const icon=item.forList.map((item,index)=>
                <TextIcon iconStyle={styles.icon}
                          key={index}
                          icon={require('images/feces.png')}/>)
            return icon
        }


    }


    getData(){
        Service.getIntegral().then(retjson=>{
            this.setState({dataList:retjson})


            console.log(this.state.dataList)
        })
    }

    componentWillMount(){
        this.getData();
        //console.log(this.icon())

    }

    //渲染
    render(){

        //console.log(this.state.dataList.desert)
        const {dataList}=this.state
        //const list=[]
        return(

            <ViewTitle>

                <View style={styles.content}>
                    <ItemRowGuideTripApply
                        frameStyleChild={styles.frame}
                        text1="日期"
                        text2="项目"
                        text3="奖励">

                    </ItemRowGuideTripApply>
                    {dataList.map((item,index)=><ItemRowGuideTripApply key={index}
                                                                       frameStyleChild={styles.frame}
                                                                       text1={Tools.timeFormatConvert(item.fcreate_time,'YYYY/MM/DD')}
                                                                       text2={item.module_type}
                                                                       text3={<View style={styles.cont}>
                                                                           {this.icon(item.desert_type,item)}
                                                                       </View>
                                                                       }/>)}
                </View>
            </ViewTitle>
        )
    }


}
const styles=StyleSheetAdapt.create({
    cont:{
        flexDirection:'row',
        flex:1.3,
        alignItems:'center',
        justifyContent:'center',
        borderColor:Theme.Colors.minorColor,
        borderBottomWidth:Theme.Border.borderWidth,
        borderRightWidth:Theme.Border.borderWidth,
        padding:10,
    },

    content:{
        margin:10,
        marginTop:20,
        borderTopWidth:Theme.Border.borderWidth,
        borderLeftWidth:Theme.Border.borderWidth,
        borderColor:Theme.Colors.borderColor,
        borderTopColor:Theme.Colors.themeColor

    },
    frame:{
        flex:1.3,
    },
    icon:{
        width:Theme.Font.fontSize_1,
        height:Theme.Font.fontSize_1 + "dw",
        marginRight:5,
    }
})
