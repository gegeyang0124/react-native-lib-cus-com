import {
    Http,
    HttpUrls
} from "com-api";

export  class Service{
    static getIntegral(){
        return Http.post(HttpUrls.urlSets.urlIntegral).then(
            retJson=>{
                retJson.retListData.forEach(v=>{
                    v.forList = [];
                    console.log(v)
                    for (let i = 0;i < v.desert ; i++) {
                        v.forList[i] = i
                    }

                    if(v.desert_type==1){
                        v.icon='images/rose.png'
                    }
                    else
                    {
                        v.icon='images/feces.png'
                    }
                });
                return retJson.retListData;
            }
        )
    }
}