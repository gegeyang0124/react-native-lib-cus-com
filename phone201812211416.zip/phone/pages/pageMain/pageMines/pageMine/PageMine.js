import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TouchableOpacity,
} from 'react-native';
import {
    Http,
    HttpUrls,
} from "com-api";
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    TextDoubleIcon,
    Tools,
    LocalStorage,
    ImageList,
    TextIcon,
    Theme,
    ButtonChange,
    ItemRowTitle,
    TitleRow,
    TitleBlockList,
    TextIconBg,
    ItemRowTripApply,
    JPush,
    MenuBottom,
    ImageChange,
    Alert,
    Media,
} from "com";
import { Service } from "./Service";
import PageSearchRole from "./pageSearchRole/PageSearchRole";

type Props = {};
export default class PageMine extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.selectedValue = {
            day15:'',
            day20:'',
            day25:''
        };
        this.btnList = [
            {
                text:'拍照',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];
        this.state = {
            isVisible: "none",

            address:null,
            create_time:null,
            phot:null,
            photos:null,
            taskName:null,

            address1:null,
            create_time1:null,
            opacity:1,
            opacity1:1,
            dataList :[
                {
                    title:"任职部门:",
                    value:Tools.userConfig.userInfo == null ? '' : Tools.userConfig.userInfo .department_name,
                },
                {
                    title:"任职岗位:",
                    value:Tools.userConfig.userInfo == null ? '' : Tools.userConfig.userInfo .position_name,
                },
                {
                    title:"手机号码:",
                    value:Tools.userConfig.userInfo == null ? '' : Tools.userConfig.userInfo .phone,
                },

                /* {
                     title:"用户名",
                     value:Tools.userConfig.userInfo == null ? '' : Tools.userConfig.userInfo .full_name,
                 },*/

                /*{
                    title:"现金出库额",
                    value:Tools.userConfig.userInfo == null ? '' : Tools.userConfig.userInfo .amountEx + "元",
                    icon:this.icon,
                    onPress:()=>{
                        alert("现金出库额")
                    },
                },
                {
                    title:"出库毛利额",
                    value:Tools.userConfig.userInfo == null ? '' : Tools.userConfig.userInfo .profitEx + "元",
                    icon:this.icon,
                    onPress:()=>{
                        alert("出库毛利额")
                    }
                }*/
            ],
            modelBtnList : [
                {
                    text:'周报',
                },
                /* {
                     text:'月报',
                 },*/
            ],

            challenge_target: null,
            new_challenge_target: null,
            old_challenge_target: null,
            last_month_achievement:null,
            month_achievement:null,
            new_month_achievement:null,
            new_last_month_achievement:null,
            old_month_achievement:null,
            old_last_month_achievement:null,

            amountEx:null,
            profitEx:null,

            estimate15:'',
            estimate20:'',
            estimate25:'',
            estimateInput:'input',

            cosPoint:null,//用户积分
            avg:null,//评价分
            progressScoreStudy:1,

            ranking:null, //个人排名
            depRanking:null, //部门排名

            flower: null,//花 积分
            shit: null,//负积分

            unlearnedNumber:0,//类型：Number  必有字段  备注：未学习数量
            learnedNumber:0,//类型：Number  必有字段  备注：学习数量
            totalNumber:0,//类型：Number  必有字段  备注：总数量

            pushMoneyTotal:null,//总提成
        };
        this.show=null
        this.icon=[require('images/up.png'),require('images/up.png'),require('images/up.png')]
        let param = Tools.userConfig.userCutAccount && Tools.userConfig.userCutAccount.length > 0
            ? {
                headerLeft:<ImageChange icon={require("images/role.png")}
                                        onPressIn={()=>PageSearchRole.show(this)}
                                        style={styles.hLeft}/>
            }
            : {
                headerLeft:false
            };

        this.setParams(param);
    }

    onPressRight = ()=>{

        var reg = /^[1-9][0-9]*$/;
        if(!reg.test(this.state.estimate15) ||
            !reg.test(this.state.estimate20) ||
            !reg.test(this.state.estimate25)){
            Tools.toast("非法输入，请填写正确的数字！");
            return;
        }


        if(this.state.estimateInput == 'input'){
            Service.setResultEstimate(this.state.estimate15,
                this.state.estimate20,
                this.state.estimate25)
                .then(retJson=>{
                    Tools.toast("提交成功");
                });
        }
    }

    onGetPic = (item,i)=>{
        if(this.show==1) {
            if (this.state.phot) {
                // Tools.toast("您已经签到过了");
            } else {
                if (i == 0) {

                    Media.takeImage(this.state.taskName, true, () => {
                        MenuBottom.show(false);
                    }).then(retJson => {


                        this.setState({
                            phot: retJson.path
                        });
                        Tools.getLocation().then(res => {
                            console.log(this.state.phot)
                            Http.upLoadFileToService([this.state.phot]).then(resJson => {
                                Service.addSign(res.address, res.lat, res.lng, res.timestamp, resJson[0].servicePath, 1).then(respose => {

                                    this.setState({
                                        address: res.address,
                                        create_time: Tools.timeFormatConvert(res.timestamp, "YYYY-MM-DD HH:mm", true),
                                        phot: resJson[0].servicePath,
                                        opacity:0.5
                                    })
                                })

                            })

                        })
                    });
                } else if (i == 1) {

                    Media.pickImage(false, this.state.taskName, false)
                        .then(retJson => {
                            MenuBottom.show(false);

                            // console.info(retJson,retJson);
                            this.setState({
                                phot: retJson.path
                            });

                            Tools.getLocation().then(res => {
                                console.log(this.state.phot)
                                Http.upLoadFileToService([this.state.phot]).then(resJson => {
                                    Service.addSign(res.address, res.lat, res.lng, res.timestamp, resJson[0].servicePath, 1).then(respose => {

                                        this.setState({
                                            address: res.address,
                                            create_time: Tools.timeFormatConvert(res.timestamp, "YYYY-MM-DD HH:mm", true),
                                            phot: resJson[0].servicePath,
                                            opacity:0.5
                                        })
                                    })

                                })

                            })
                        })

                }
            }
        }else if(this.show==2){
            if (this.state.photos) {
                // Tools.toast("您已经签到过了");
            } else {
                if (i == 0) {

                    Media.takeImage(this.state.taskName, true, () => {
                        MenuBottom.show(false);
                    }).then(retJson => {


                        this.setState({
                            photos: retJson.path
                        });
                        Tools.getLocation().then(res => {
                            console.log(this.state.photos)
                            Http.upLoadFileToService([this.state.photos]).then(resJson => {
                                Service.addSign(res.address, res.lat, res.lng, res.timestamp, resJson[0].servicePath, 2).then(respose => {

                                    this.setState({
                                        address1: res.address,
                                        create_time1: Tools.timeFormatConvert(res.timestamp, "YYYY-MM-DD HH:mm", true),
                                        photos: resJson[0].servicePath,
                                        opacity1:0.5
                                    })
                                })

                            })

                        })
                    });
                } else if (i == 1) {

                    Media.pickImage(false, this.state.taskName, false)
                        .then(retJson => {
                            MenuBottom.show(false);

                            // console.info(retJson,retJson);
                            this.setState({
                                photos: retJson.path
                            });
                            Tools.getLocation().then(res => {

                                Http.upLoadFileToService([this.state.photos]).then(resJson => {
                                    Service.addSign(res.address, res.lat, res.lng, res.timestamp, resJson[0].servicePath, 2).then(respose => {

                                        this.setState({
                                            address1: res.address,
                                            create_time1: Tools.timeFormatConvert(res.timestamp, "YYYY-MM-DD HH:mm", true),
                                            photos: resJson[0].servicePath,
                                            opacity1:0.5
                                        })
                                    })

                                })

                            })

                        })

                }
            }
        }


    }

    keyExtractor = (item, index) => item.title;

    renderItem = ({item,index}) =>(
        <TextDoubleIcon id={index}
                        onPress={() =>this.onPressItem(item.title)}
                        textLeft={item.title}
                        textRight={item.value}
                        icon={item.icon}/>
    );

    renderView = (item,index) =>{

        //{this.menuList.map(this.renderView)}
        // textRight={item.value}
        return (
            <TextDoubleIcon key={index}
                            onLongPress={()=>{index == 1
                                ? Tools.toast(Tools.userConfig.userInfo.full_name)
                                : null}}
                            onPress={item.onPress}
                            frameStyle={styles.itemRowFrame}
                            textLeft={item.title + " " + item.value}
                            isShowRight={false}
                            icon={item.icon}/>
        );
    }

    renderViewVersion(item,index) {

        //{this.menuList.map(this.renderView)}
        return (
            <TextDoubleIcon key={index}
                            style={styles.versionItem}
                            frameStyleLeft={styles.frameStyleLeft}
                            frameStyleRight={styles.frameStyleRight}
                            textLeft={index == 0 ? "当前版本：" + item.version : item.version}
                            textRight={item.description}/>
        );
    }

    exitLogin(){
        JPush.stopJPush();
        LocalStorage.save(Tools.userConfig.namekey,Tools.userConfig.userInfo);
        // LocalStorage.save(Tools.userConfig.namekey,null);
        Tools.cutLogin = true;
        this.goPage("PageLogin");
    }

    logout(){
        /* Tools.userConfig.userInfo.id = '';
         LocalStorage.save(Tools.userConfig.namekey,Tools.userConfig.userInfo);
         BaseComponent.goPage("PageLogin");*/
        // Tools.cutLogin = true;

        // this.props.navigation.pop();
        // this.props.navigation.push("PageLogin");
        // this.props.navigation.push("PageMain");
        // this.goPage("PageLogin");
        // this.goPage("PageHome");
        // return;
        // iOS和Android上都可用
        Alert.alert(
            '退出登录',
            '是否清空密码',
            [
                {text: '取消', onPress: () => {
                        //Tools.toast("ox")
                    }},
                {text: '否', onPress: () => {
                        Tools.userConfig.userInfo.id = '';
                        this.exitLogin();
                        /*LocalStorage.save(Tools.userConfig.namekey,Tools.userConfig.userInfo);
                        BaseComponent.goPage("PageLogin");*/
                    }},
                {text: '是', onPress: () => {
                        Tools.userConfig.userInfo.id = '';
                        Tools.userConfig.userInfo.password = '';
                        Tools.userConfig.userInfo.countListHistory
                            .forEach((v,i,a)=>{
                                if(Tools.userConfig.userInfo.count == v.count){
                                     v.password = "";
                                }
                            });
                        this.exitLogin();
                        /* LocalStorage.save(Tools.userConfig.namekey,Tools.userConfig.userInfo);
                         BaseComponent.goPage("PageLogin");*/
                    }},
            ],
            { cancelable: true }
        );

    }

    getData(){
        if(Tools.userConfig.userInfo .position_name == "运营助理"){
            return;
        }
        if(Tools.userConfig.userInfo.department_level == 3){
            // Service.getPushMoney().then(retJson=>{
            //     console.info("retJson",retJson);
            //     this.setState({pushMoneyTotal:retJson.pushMoneyTotal});
            // });
        }

        Service.getTarget(Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM"))
            .then(retJson=>{
                // console.log(retJson)
                this.setState(retJson);
            });

        this.getResultEstimate();

        // console.log(Tools.userConfig.userInfo.department_level);
        if(Tools.userConfig.userInfo.department_level == 3){
            Service.getPersonRanking(
                Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM")
            )
                .then(retJson=>{
                    this.setState(retJson);
                });
        }

        Service.getStudyIntegral(Tools.userConfig.userInfo.phone)
            .then(retJson=>{
                this.setState(retJson);
            });

        Service.getIntegral(Tools.userConfig.userInfo.phone)
            .then(retJson=>{
                this.setState(retJson);
            });

        Service.get().then((retJson) =>{

            Tools.userConfig.userInfo.amountEx = retJson.amountEx;
            Tools.userConfig.userInfo.profitEx = retJson.profitEx;
            this.setState(retJson);
            // this.forceUpdate();//强制刷新
        });

        Service.getMyCourse(Tools.userConfig.userInfo.phone)
            .then(retJson=>{
                // console.info("retJson",retJson)
                this.setState(retJson);
            });
        // Service.getSign().then(retJson=>{
        //     this.setState(retJson)
        //
        // })

        Service.getSign().then(res=>{
                if(res.length>0){
                    if(res.length==1&&res[0].type==1){
                        this.setState({address:res[0].address,create_time:Tools.timeFormatConvert(res[0].create_time,"YYYY-MM-DD HH:mm",true),phot:res[0].photo,opacity:0.5})
                    }
                    else if(res.length==1&&res[0].type==2){
                        this.setState({address1:res[0].address,create_time1:Tools.timeFormatConvert(res[0].create_time,"YYYY-MM-DD HH:mm",true),photos:res[0].photo,opacity1:0.5})
                    }
                    else if(res.length==2)
                    {
                        this.setState({
                            address:res[0].address,create_time:Tools.timeFormatConvert(res[0].create_time,"YYYY-MM-DD HH:mm",true),phot:res[0].photo,opacity:0.5,opacity1:0.5,
                            address1:res[1].address,create_time1:Tools.timeFormatConvert(res[1].create_time,"YYYY-MM-DD HH:mm",true),photos:res[1].photo})
                    }
                }
            });
    }

    showPicture(type){
        this.show=type
        MenuBottom.show(true);

    }

    getResultEstimate = (time)=>{
        time = time == undefined ? new Date().getTime() : time;

        if(Tools.timeFormatConvert(time,"YYYY-MM")
            == Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM")
        ){
            this.setState({
                estimateInput:'input'
            });
        }
        else {
            this.setState({
                estimateInput:'text'
            });
        }

        Service.getResultEstimate(Tools.timeFormatConvert(time,"YYYY-MM"))
            .then(retJson =>{
                if(retJson != null){
                    this.selectedValue.day15 = retJson.day15 ? retJson.day15 : '';
                    this.selectedValue.day20 = retJson.day20 ? retJson.day20 : '';
                    this.selectedValue.day25 = retJson.day25 ? retJson.day25 : '';
                    this.setState({
                        estimate15:this.selectedValue.day15,
                        estimate20:this.selectedValue.day20,
                        estimate25:this.selectedValue.day25
                    });
                }
            });
    }

    componentWillMount(){
    }

    componentDidMount(){
        Service.getLevel().then(resJson=>{
            // console.log(resJson)
            if(resJson==5)
            {
                this.setParams({headerRight:<ButtonChange text={"提交"}
                                                          onPress={this.onPressRight}/>})
            }else{

            }

        });

        this.getData();
    }

    onPressModel(type){

        if(type == 0){
            Service.getLevel().then(resJson=>{
                // console.log(resJson)
                if(resJson==5)
                {
                    this.goPage("PageWorkReportWeekP")
                }else{
                    this.goPage("PageWorkReportWeek");
                }

            })

        }
        else {
            this.goPage("PageWorkReportMonth");
        }
    }

    renderModelBtn = (item,index)=>{
        return(
            <ButtonChange key={index}
                          text={item.text}
                          frameStyle={styles.modelBtn}
                          textStyle={styles.textBtn}
                          onPress={()=>{this.onPressModel(index)}}
                          style={[styles.titleFrame_btn]} />
        );
    }

    renderInnerUI(c,t,size){

        return(
            <View style={styles.circleInnerFrame}>

                <Text style={[
                    styles.circleInnerTextTop,
                    {fontSize:StyleSheetAdapt.getWidth(size / 150 * Theme.Font.fontSize5)}
                ]}>
                    {c}
                </Text>

                <Text style={[
                    styles.circleInnerTextDown,
                    {fontSize:StyleSheetAdapt.getWidth(size / 150 * Theme.Font.fontSize_1)}
                ]}>
                    {t}
                </Text>

            </View>
        );
    }

    onChangeText(text,type){
        let isNumber = true;

        switch (type){
            case 0:{
                if(isNumber){
                    this.selectedValue.day15 = text;
                }
                else {
                    this.selectedValue.day15 = this.state.estimate15;
                }

                this.setState({
                    estimate15:this.selectedValue.day15
                });
                break;
            }
            case 1:{
                if(isNumber){
                    this.selectedValue.day20 = text;
                }
                else {
                    this.selectedValue.day20 = this.state.estimate20;
                }
                this.setState({
                    estimate20:this.selectedValue.day20
                });
                break;
            }
            case 2:{
                if(isNumber){
                    this.selectedValue.day25 = text;
                }
                else {
                    this.selectedValue.day25 = this.state.estimate25;
                }

                this.setState({
                    estimate25:this.selectedValue.day25
                });
                break;
            }
        }
    }

    onPressPassword = ()=>{
        this.goPage("PageMinePassword");
    }

    onPressVersion=()=>{
        this.goPage("PageVersion")
    }

    onPressIntegral=()=>{
        // this.goPage("PageIntegral")
        // console.log('aaa')
    }

    render() {

        const {dataList,modelBtnList,challenge_target,new_challenge_target,
            old_challenge_target,month_achievement,new_month_achievement,
            last_month_achievement,
            new_last_month_achievement,
            old_last_month_achievement,
            old_month_achievement,estimate15,estimate20,estimate25,cosPoint,
            ranking,depRanking,flower,shit,progressScoreStudy,estimateInput,
            unlearnedNumber,learnedNumber,totalNumber,pushMoneyTotal,create_time,address,phot,photos,create_time1,address1,opacity,opacity1} = this.state;
        const monthAchievement =month_achievement-last_month_achievement>0?true:false
        const newMonthAchievement =new_month_achievement-new_last_month_achievement>0?true:false
        const oldMonthAchievement =old_month_achievement-old_last_month_achievement>0?true:false
        if(monthAchievement){
            this.icon[0]=require('images/up.png')
        }
        else{
            this.icon[0]=require('images/down.png')
        }

        if(newMonthAchievement){
            this.icon[1]=require('images/up.png')
        }
        else{
            this.icon[1]=require('images/down.png')
        }

        if(oldMonthAchievement){
            this.icon[2]=require('images/up.png')
        }
        else{
            this.icon[2]=require('images/down.png')
        }

        return (
            <ViewTitle viewBottom={"退出登录"}
                       onPressBottom={()=>this.logout()}>

                <View style={styles.mineFrame}>
                    <ImageList dataList={[
                        {
                            icon:Tools.userConfig.userInfo.picture
                        }
                    ]}
                               isScroll={false}
                               frameStyle={styles.image}
                               imageFrameStyle={styles.iconFrame}
                               isShowText={false}
                               iconStyle={styles.iconStyle}/>

                    <View style={styles.userFrame}>
                        {
                            dataList.map(this.renderView)
                        }

                        {/*<TouchableOpacity style={styles.backpack}
                                          onPress={this.onPressIntegral}>
                            <Text style={styles.backpackText}>我的收获: </Text>
                            <TextIcon icon={require('images/rose.png')}
                                      iconStyle={styles.backpackImage}
                                      textStyle={styles.textStyle1}
                                      frameStyle={styles.textIcon}
                                      textFrameStyle={styles.textFrameStyle}
                                      text={flower}/>
                            <TextIcon icon={require('images/feces.png')}
                                      iconStyle={styles.backpackImage}
                                      frameStyle={styles.textIcon}
                                      textStyle={styles.textStyle1}
                                      textFrameStyle={styles.textFrameStyle}
                                      text={shit}/>
                        </TouchableOpacity>*/}

                        <View style={styles.backpack}>
                            <Text style={styles.backpackText}>我的报告: </Text>
                            <View style={styles.modelBtnFrame}>

                                {
                                    modelBtnList.map(this.renderModelBtn)
                                }

                            </View>
                        </View>
                    </View>

                    <View style={styles.userRight}>


                        <Image source={require('images/myHarvest.png')}
                               style={styles.myHarvest}/>

                        <TouchableOpacity style={styles.backpack}
                        >
                            <TextIconBg icon={require('images/rose.png')}
                                        iconStyle={styles.backpackImage}
                                        frameStyle={styles.textIcon}
                                        onPress={()=>{this.goPage('PageIntegral')}}>
                                <Text style={[styles.backpackText,styles.backpackText1]}>
                                    {flower}
                                </Text>
                            </TextIconBg>
                            <TextIconBg icon={require('images/feces.png')}
                                        iconStyle={styles.backpackImage}
                                        frameStyle={styles.textIcon}
                                        onPress={()=>{this.goPage('PageIntegral')}}>
                                <Text style={styles.backpackText}>
                                    {Math.abs(shit)}
                                </Text>
                            </TextIconBg>

                        </TouchableOpacity>

                    </View>

                </View>
                <View style={styles.sign}>
                    <ImageChange icon={phot?{uri:phot}:require('images/moren.png')} style={styles.ImageChange} iconStyle={styles.Icon}/>
                    <View style={styles.View}>
                        <Text style={styles.Text}>签到时间：{create_time}</Text>
                        <Text style={styles.Text}>签到地址：{address}</Text>

                    </View>
                    <TouchableOpacity style={[styles.TouchableOpacity,{opacity:opacity1}]} onPress={()=>!phot&&this.showPicture(1)}>
                        <Image source={require('images/qiandao.png')} style={styles.Image}/>
                        <Text style={styles.Text1}>签到</Text>
                    </TouchableOpacity>
                </View>
                <Image source={require('images/homeline.png')} style={styles.Image1}/>
                <View style={styles.sign1}>
                    <ImageChange icon={photos?{uri:photos}:require('images/moren.png')} style={styles.ImageChange} iconStyle={styles.Icon}/>
                    <View style={styles.View}>
                        <Text style={styles.Text}>签退时间：{create_time1}</Text>
                        <Text style={styles.Text}>签退地址：{address1}</Text>

                    </View>
                    <TouchableOpacity style={[styles.TouchableOpacity,{opacity:opacity1}]} onPress={()=>!photos&&this.showPicture(2)}>
                        <Image source={require('images/qiandao.png')} style={styles.Image}/>
                        <Text style={styles.Text1}>签退</Text>
                    </TouchableOpacity>
                </View>
                <View style={styles.resultFrame}>
                    <ItemRowTitle text1={"个人业绩"}
                                  frameStyle={styles.titleResultFrame}/>

                    <View style={styles.resultFrame_1}>
                        <View style={[styles.resultFrame_1_1_1,styles.resultFrame_1_1_1_0]}>
                            <TitleRow frameStyle={styles.resultFrame_1_1}
                                      icon={require('images/leftCircleRed.png')}
                                      iconStyle={styles.iconResultStyle}
                                      textCenterTop={
                                          <Text style={styles.textCenterTop}>
                                              业绩预估
                                          </Text>
                                      }
                                      isShowIconCenter={false}
                                      textCenterStyle={styles.textCenterStyle}
                                      onPressLeft={this.getResultEstimate}
                                      onPressRight={this.getResultEstimate}
                                      onPressCenter={this.getResultEstimate}/>

                            <View style={styles.resultFrame_1_2}>
                                <ItemRowTripApply text={"1号预估:"}
                                                  frameLabelStyle={styles.resultFrame_1_2_1}
                                                  viewCenterProps={{
                                                      style:styles.text2,
                                                      value:estimate15 + "",
                                                      onChangeText:(text)=>this.onChangeText(text,0)
                                                  }}
                                                  isStar={false}
                                                  text3={"/元"}
                                                  text3Style={styles.text3}
                                                  text2={estimate15}
                                                  viewCenter={estimateInput}/>
                                <ItemRowTripApply text={"10号预估:"}
                                                  frameStyle={styles.resultFrame_1_2_1_0}
                                                  frameLabelStyle={styles.resultFrame_1_2_1}
                                                  text2={estimate20}
                                                  viewCenterProps={{
                                                      style:styles.text2,
                                                      value:estimate20 + "",
                                                      onChangeText:(text)=>this.onChangeText(text,1)
                                                  }}
                                                  isStar={false}
                                                  text3={"/元"}
                                                  text3Style={styles.text3}
                                                  viewCenter={estimateInput}/>
                                <ItemRowTripApply text={"20号预估:"}
                                                  frameStyle={styles.resultFrame_1_2_1_0}
                                                  frameLabelStyle={styles.resultFrame_1_2_1}
                                                  text2={estimate25}
                                                  viewCenterProps={{
                                                      style:styles.text2,
                                                      value:estimate25 + "",
                                                      onChangeText:(text)=>this.onChangeText(text,2)
                                                  }}
                                                  isStar={false}
                                                  text3={"/元"}
                                                  text3Style={styles.text3}
                                                  viewCenter={estimateInput}/>
                            </View>

                        </View>

                        {
                            Tools.userConfig.userInfo.showAllData ?
                                <TitleBlockList isScroll={false}
                                                frameStyle={styles.resultFrame_1_1_1}
                                                dataList={[
                                                    {
                                                        textDown:'基础目标',
                                                        textCenter:(this.state.base_target * 1).toFixed(2),
                                                        textRight:'万元',
                                                        color:Theme.Colors.themeColor
                                                    },
                                                    {
                                                        textDown:'新客户目标',
                                                        textCenter:(this.state.new_base_target * 1).toFixed(2),
                                                        textRight:'万元',
                                                        color:Theme.Colors.barGreen
                                                    },
                                                    {
                                                        textDown:'老客户目标',
                                                        textCenter:(this.state.old_base_target * 1).toFixed(2),
                                                        textRight:'万元',
                                                        color:Theme.Colors.appRedColor
                                                    }
                                                ]}/>
                                :

                                <TitleBlockList isScroll={false}
                                                frameStyle={styles.resultFrame_1_1_1}
                                                dataList={[
                                                    {
                                                        textDown:'运营目标',
                                                        textCenter:(this.state.operations_target * 1).toFixed(2),
                                                        textRight:'万元',
                                                        color:Theme.Colors.themeColor,

                                                    },
                                                    {
                                                        textDown:'新客户目标',
                                                        textCenter:(this.state.new_operations_target * 1).toFixed(2),
                                                        textRight:'万元',
                                                        color:Theme.Colors.barGreen
                                                    },
                                                    {
                                                        textDown:'老客户目标',
                                                        textCenter:(this.state.old_operations_target * 1).toFixed(2),
                                                        textRight:'万元',
                                                        color:Theme.Colors.appRedColor
                                                    }
                                                ]}/>
                        }

                        <TitleBlockList isScroll={false}
                                        frameStyle={styles.resultFrame_1_1_1}
                                        dataList={[
                                            {
                                                textDown:'业绩完成',
                                                textCenter:(month_achievement * 1).toFixed(2),
                                                textRight:'万元',
                                                color:Theme.Colors.themeColor,
                                                icon:this.icon[0]

                                            },
                                            {
                                                textDown:'新客户',
                                                textCenter:(new_month_achievement * 1).toFixed(2),
                                                textRight:'万元',
                                                color:Theme.Colors.barGreen,
                                                icon:this.icon[1]
                                            },
                                            {
                                                textDown:'老客户',
                                                textCenter:(old_month_achievement * 1).toFixed(2),
                                                textRight:'万元',
                                                color:Theme.Colors.appRedColor,
                                                icon:this.icon[2]
                                            }
                                        ]}/>

                        {
                            Tools.userConfig.userInfo .position_name == "客户经理" ?

                                <View style={styles.rankFrame}>
                                    <View style={[styles.rankFrame,styles.rankTextLeftFrame]}>
                                        <Text style={styles.rankLeft}>
                                            个人排名：
                                        </Text>
                                        <Text style={styles.rankRight}>
                                            {ranking}
                                        </Text>
                                    </View>

                                    <View style={styles.rankFrame}>
                                        <Text style={styles.rankLeft}>
                                            部门排名：
                                        </Text>
                                        <Text style={styles.rankRight}>
                                            {depRanking}
                                        </Text>
                                    </View>

                                </View>
                                :
                                Tools.userConfig.userInfo .position_name == "省区总监" ?
                                    <View style={styles.rankFrame}>
                                        <View style={styles.rankFrame}>
                                            <Text style={styles.rankLeft}>
                                                部门排名：
                                            </Text>
                                            <Text style={styles.rankRight}>
                                                {depRanking}
                                            </Text>
                                        </View>
                                    </View>
                                    :
                                    Tools.userConfig.userInfo .position_name == "大区经理" ?
                                        <View style={styles.rankFrame}>
                                            <View style={styles.rankFrame}>
                                                <Text style={styles.rankLeft}>
                                                    部门排名：
                                                </Text>
                                                <Text style={styles.rankRight}>
                                                    {depRanking}
                                                </Text>
                                            </View>
                                        </View>
                                        : null
                        }

                    </View>
                </View>
                {/*{*/}
                    {/*Tools.userConfig.userInfo.department_level == 3 ?*/}
                        {/*<ItemRowTitle text1={"本月提成"}*/}
                                      {/*frameStyle={styles.pushMoneyFrame}*/}
                                      {/*viewRight={*/}
                                          {/*<View style={styles.pushMoneyRightFrame}>*/}
                                              {/*<Text style={styles.pushMoneyLeftText}>*/}
                                                  {/*{pushMoneyTotal}元*/}
                                              {/*</Text>*/}
                                              {/*<Text style={styles.pushMoneyRightText}>*/}
                                                  {/*截止{new Date().getDate()}号*/}
                                              {/*</Text>*/}
                                          {/*</View>*/}
                                      {/*}/>*/}
                        {/*:*/}
                        {/*null*/}
                {/*}*/}

                <View style={styles.myCourseFrame}>
                    <ItemRowTitle text1={"我的课程"}
                                  frameStyle={styles.titleResultFrame}/>
                    <View style={styles.myCourseFrame_1}>
                        <View style={styles.myCourseFrame_1_1}>
                            <TextIconBg isInner={false}
                                        size={150}
                                        color={Theme.Colors.themeColor}
                                        unfilledColor={Theme.Colors.themeColorLight1}
                                        renderInnerUI={()=>this.renderInnerUI(cosPoint,"我的学分",150)}
                                        progress={progressScoreStudy}/>
                        </View>

                        <View style={styles.myCourseFrame_1_2}>
                            <View style={styles.myCourseFrame_1_2_1}>
                                <TextIconBg isInner={false}
                                            size={100}
                                            color={Theme.Colors.themeColor}
                                            unfilledColor={Theme.Colors.themeColorLight1}
                                            renderInnerUI={()=>this.renderInnerUI(totalNumber,"我的课程",100)}
                                            progress={1}/>
                            </View>
                            <View style={styles.myCourseFrame_1_2_2}>
                                <TitleBlockList isScroll={false}
                                                frameStyle={styles.myCourseFrame_1_2_2_1}
                                                dataList={[
                                                    {
                                                        textDown:'已读',
                                                        textCenter:learnedNumber,
                                                        textRight:'门',
                                                        color:Theme.Colors.themeColor
                                                    },
                                                    {
                                                        textDown:'未读',
                                                        textCenter:unlearnedNumber,
                                                        textRight:'门',
                                                        color:Theme.Colors.appRedColor
                                                    }
                                                ]}/>
                            </View>
                        </View>
                    </View>
                </View>

                <ItemRowTitle text1={"版本说明"}
                              isShowIcon={true}
                              onPress={this.onPressVersion}
                              frameStyle={styles.pushMoneyFrame}/>

                <ItemRowTitle text1={"更改密码"}
                              isShowIcon={true}
                              onPress={this.onPressPassword}
                              frameStyle={styles.pushMoneyFrame}/>

                <MenuBottom btnList={this.btnList}
                            isVisibleClose={false} />

            </ViewTitle>
        );
    }

}

const styles = StyleSheetAdapt.create({
    hLeft:{
        width:30,
        height:30,
        marginLeft:10,
    },
    sign:{
        flexDirection:'row',
        height:150,
        backgroundColor:'white',
        marginTop:10
    },
    sign1:{
        flexDirection:'row',
        height:150,
        backgroundColor:'white',
        marginTop:10
    },
    Icon:{
        width:120,
        height:120
    },
    Image:{
        width:60,
        height:60
    },
    Text:{
        marginTop:20,
        fontSize:20,
        color:'#6F6F6F'
    },
    TouchableOpacity:{
        marginTop:30,
        flex:1,
        width:130,
        marginRight:20,
        height:130
    },
    View:{
        marginLeft:40,
        marginTop:5,
        flex:5
    },
    Text1:{
        marginLeft:5,
        fontSize:25,
        color:Theme.Colors.themeColor,
        marginTop:10
    },

    Image1:{
        flex:0.90,
        height:10
    },
    ImageChange: {
        width:120,
        height:120,
        marginLeft:20,
        marginTop:15,
        // resizeMode:'cover',
        flex:1},
    myIntegralImage:{
        width:150,
        resizeMode: 'cover'
    },
    myIntegralView:{
        width:200,
        height:50,
        backgroundColor:Theme.Colors.backgroundColorBtn,
    },
    circleInnerTextDown:{
        color:Theme.Colors.minorColor,
    },
    circleInnerTextTop:{
        color:Theme.Colors.themeColor,
    },
    circleInnerFrame:{
        alignItems:'center',
        justifyContent:'center',
    },
    myCourseFrame_1_2_2_1:{
        // margin:10,
        // padding:10,
    },
    myCourseFrame_1_2_2:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
        borderTopWidth:Theme.Border.borderWidth,
        borderTopColor:Theme.Colors.themeColor,
        margin:10,
        padding:10,
        paddingTop:20,

    },
    myCourseFrame_1_2_1:{
        flex:2,
        alignItems:'center',
        justifyContent:'center',
    },
    myCourseFrame_1_2:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    myCourseFrame_1_1:{
        flex:1,
        borderRightColor:Theme.Colors.themeColor,
        borderRightWidth:Theme.Border.borderWidth,
        alignItems:'center',
        justifyContent:'center',
    },
    myCourseFrame_1:{
        flex:1,
        marginTop:10,
        marginBottom:10,
        flexDirection:'row',
        height:200,
    },
    myCourseFrame:{
        flex:1,
        backgroundColor:Theme.Colors.foregroundColor,
        padding:10,
        marginTop:10,
    },

    pushMoneyRightText:{
        fontSize:Theme.Font.fontSize_1_1,
        marginRight:10,
        color:Theme.Colors.minorColor,
    },
    pushMoneyLeftText:{
        fontSize:Theme.Font.fontSize1,
        color:Theme.Colors.themeColor,
        marginRight:10,
    },
    pushMoneyRightFrame:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
    },
    pushMoneyFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginLeft:-10,
    },

    rankRight:{
        fontSize:Theme.Font.fontSize2,
        color:Theme.Colors.themeColor,
    },
    rankLeft:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.themeColor,
    },
    rankTextLeftFrame:{
        borderRightWidth:Theme.Border.borderWidth,
        borderRightColor:Theme.Colors.themeColor,
    },
    rankFrame:{
        alignItems:'center',
        justifyContent:'center',
        flex:1,
        flexDirection:'row',
    },
    titleResultFrame:{
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth,
        margin:10,
    },
    textCenterTop:{
        color:Theme.Colors.themeColor,
        fontSize:Theme.Font.fontSize_1,
        marginBottom:5,
    },
    textCenterStyle:{
        color:Theme.Colors.minorColor,
        fontSize:Theme.Font.fontSize_2,
    },
    resultFrame_1_2:{
        flex:6,
        alignItems:'center',
        justifyContent:'center',
    },
    resultFrame_1_1:{
        flex:4,
        borderRightWidth:Theme.Border.borderWidth,
        borderRightColor:Theme.Colors.themeColor,
    },
    resultFrame_1_1_1_0:{
        marginTop:-10,
    },
    resultFrame_1_1_1:{
        flexDirection:'row',
        margin:10,
        padding:10,
        borderBottomWidth:Theme.Border.borderWidth,
        borderBottomColor:Theme.Colors.minorColor,
    },
    resultFrame_1_2_1_0:{
        marginTop:10,
    },
    resultFrame_1_2_1:{
        flex:3.5,
    },
    text3:{
        width:50,
        // marginRight:60,
        marginLeft:-25,
    },
    text2:{
        width:250,
    },
    resultFrame_1:{
        // flexDirection:'row',
        marginTop:10,
        marginBottom:10,
    },
    iconResultStyle:{
        width:35,
        height:'35dw',
    },
    resultFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        // alignItems:'center',
        // justifyContent:'center',
    },

    textFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth,
    },
    textStyle1:{
        color:Theme.Colors.themeColor,
    },
    textBtn:{
        fontSize:Theme.Font.fontSize_1_1,
    },
    titleFrame_btn: {
        width: 70,
        height: 25,
        padding: 0,
    },
    modelBtn:{
        marginRight:20,
    },
    modelBtnFrame:{
        flexDirection:'row',
    },
    textIcon:{
        // marginRight:50,
        alignItems:'center',
        justifyContent:'center',
    },
    backpackImage:{
        // width:Theme.Font.fontSize_1,
        // height:Theme.Font.fontSize_1 + "dw",
        width:100,
        height:100 + 'dw',
        // marginRight:5,
    },
    backpackText:{
        fontSize:Theme.Font.fontSize1,
        marginRight:30,
    },
    backpackText1:{
        color:Theme.Colors.appRedColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
        padding:0,
        // marginTop:5,
    },
    backpack:{
        // marginTop:5,
        padding:5,
        flexDirection:'row',
        alignItems:'center',
        // justifyContent:'center',
    },
    iconFrame:{
        width:160,
        height:'160dw',
    },
    iconStyle:{
        width:160,
        height:'160dw',
    },
    userFrame:{
        flex:3.5,
        // backgroundColor:"yellow",
    },
    image:{
        // backgroundColor:'red',
        flex:2.5,
    },
    mineFrame:{
        flexDirection:'row',
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        alignItems:'center',
        justifyContent:'center',
    },
    userRight:{
        flex:4,
        alignItems:'center',
        justifyContent:'center',
        // backgroundColor:"red",
    },
    myHarvest:{
        width:200,
        resizeMode:'contain',
    },


    frame:{
        //borderTopWidth:0.5,
        borderBottomWidth:0.5,
        borderBottomColor:"#5b5b5b",

    },
    versionTable:{
        borderWidth:0.5,
        borderBottomWidth:0,
        //borderColor:"#5b5b5b",
        margin:30,
        marginTop:0,
    },
    versionItem:{
        borderBottomWidth:0.5,
        //backgroundColor: "red",
        padding:0,
    },
    versionRow:{
        padding: 10,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        borderBottomColor:"#5b5b5b",
    },
    versionRowText:{
        fontSize:20,
        //color:"#000000",
    },
    versionRowIcon:{
        width:20,
        height:20,
        resizeMode:"contain",
    },
    versionRowDescription:{
        borderRightWidth:0.5,
        borderBottomWidth:0.5,
        borderColor:"#5b5b5b",
    },
    frameStyleLeft:{
        flex:1,
        //flexDirection: 'column',
        //backgroundColor: "blue",
        alignItems:"center",
        justifyContent:"center",
        /*borderRightWidth:0.5,
         borderBottomWidth:0.5,
         borderColor:"#5b5b5b",*/
    },
    frameStyleRight:{
        flex:3,
        borderLeftWidth:0.5,
        //flexDirection: 'column',
        //backgroundColor: "yellow",
        alignItems:"flex-start",
        margin:0,
    },

});
