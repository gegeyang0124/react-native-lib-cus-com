import {
    Http,
    HttpUrls,
    Tools,
} from "com-api";

/**
 *
 * **/
export class Service {
    /**
     * 获取现金出库额和出库毛利额
     * @param isShow bool,//是否显示加载条，true:显示，false：不显示
     * **/
    static get() {

        return Http.post(HttpUrls.urlSets.urlOutboundAndProfitMoneyTotal, {},false)
            .then((retJson) => {

                return retJson.retData;

            });

    }

    /**
     * 获取业绩预估
     * @param month string,//YYYY-MM
     * **/
    static getResultEstimate(month){
        return Http.post(HttpUrls.urlSets.urlProgressResultEstimateGet, {
            month:month
        },false)
            .then((retJson) => retJson.retData);
    }

    /**
     * 设置业绩预估
     * **/
    static setResultEstimate(day15,day20,day25){
        return Http.post(HttpUrls.urlSets.urlProgressResultEstimateSet, {
            day15:day15,
            day20:day20,
            day25:day25

        },false)
            .then((retJson) => retJson.retData);
    }

    /**
     * 获取业绩目标 数据
     * @param month string,//YYYY-MM
     * **/
    static getTarget(month){
        return Http.post(HttpUrls.urlSets.urlResultProgressCenter,{
            month:month,//查询月份
            //完成参数
            pageNumber: 1,
            pageSize: 10000
        },false)
            .then((retJson) => {
                return retJson.retData
            });
    }

    /**
     * 获取个人排名
     * @param month string,//YYYY-MM
     * **/
    static getPersonRanking(month){
        var rankArea = Tools.userConfig.userInfo .position_name == "客户经理" ? 1 :
                        Tools.userConfig.userInfo.position_name == "省区总监" ? 2 :
                            Tools.userConfig.userInfo.position_name == "大区总监" ? 3 : "";

        // console.info("Tools.userConfig.userInfo .position_name",Tools.userConfig.userInfo .position_name);

        /*if(rankArea == ""){
            return;
        }*/
        return Http.get(HttpUrls.urlSets.urlPersonRanking,{
            month:month,//查询月份
            rankArea:rankArea,
        },false)
            .then(retJson=>retJson.retData);
    }

    /**
     * 获取学分
     * **/
    static getStudyIntegral(val){

        return Http.get(HttpUrls.urlSets.urlSchoolGetStudyIntegral,{
            phone:val
        },false)
            .then(retJson=>retJson.retData);
    }

    /**
     * 获取积分
     * **/
    static getIntegral(){

        return Http.post(HttpUrls.urlSets.urlGetIntegralInfo,{},false)
            .then(retJson=>retJson.retData);
    }
    /**
     * 获取签到签退
     * **/
    static getSign(){
        return Http.post(HttpUrls.urlSets.urlSign,{},false)
            .then(retJson=>{

            retJson.retListData.forEach((v,i)=>{
                v.create_time=Tools.timeFormatConvert(v.create_time,"YYYY-MM-DD HH:mm",true)
            })
            console.log(retJson.retListData)
            // console.log(retJson.retListData[0])
            return retJson.retListData

        });
    }

    /**
     * 新增签到签退
     */
    static addSign(address,lat,lng,timestamp,photo,type){
        return Http.post(HttpUrls.urlSets.urlAddSign,
            {address:address,address_latitude:lat,
                address_longitude:lng,photo:photo,
                create_time:timestamp,type:type},false);

    }
    /**
     * 获取我的课程
     * **/
    static getMyCourse(val){
        return Http.get(HttpUrls.urlSets.urlMyCourse,{
            phone:val
        },false)
            .then(retJson=>retJson.retData);
    }

    /**
     * 获取提成数据
     * **/
    static getPushMoney(){

       return Http.post(HttpUrls.urlSets.urlOutboundProfitMoneyDetail, {
            profitpageindex: 1,
            outwarehouseindex: 1,
            pageSize: 10000,
            date:null//日期"YYYY-MM"
        },false).then((retJson)=>{
            var resultObj = Tools.earningCalculateClass().get(retJson,0);
            var perObj = {};
            switch (Tools.userConfig.userInfo.position_name){
                case '客户经理' :{
                    perObj = {
                        container:0.0250,
                        instrument:0.0500,
                        goodsFirst:0.0780,
                        goodsSupplement:0.1300,
                    };
                    break;
                }
                case '省区总监' :{
                    perObj = {
                        container:0.0125,
                        instrument:0.0250,
                        goodsFirst:0.0348,
                        goodsSupplement:0.0580,
                    };
                    break;
                }
                case '运营助理' :{
                    perObj = {
                        container:0.0034,
                        instrument:0.0070,
                        goodsFirst:0.0108,
                        goodsSupplement:0.0180,
                    };
                    break;
                }
            }
            var pushMoneyObj = {
                containerMoney : parseInt(resultObj.outboundAmountObj.containerMoney
                    * (perObj.container * 10000) / 100) / 100,
                instrumentMoney : parseInt(resultObj.outboundAmountObj.instrumentMoney
                    * (perObj.instrument * 10000) / 100) / 100,
                goodsFirstMoney : parseInt(resultObj.outboundProfitObj.goodsFirstMoney
                    * (perObj.goodsFirst * 10000) / 100) / 100,
                goodsSupplementMoney : parseInt(resultObj.outboundProfitObj.goodsSupplementMoney
                    * (perObj.goodsSupplement * 10000) / 100) / 100,
                pushMoneyTotal:0,
            }

            pushMoneyObj.pushMoneyTotal = (pushMoneyObj.containerMoney * 100)
                + (pushMoneyObj.instrumentMoney * 100)
                + (pushMoneyObj.goodsFirstMoney * 100)
                + (pushMoneyObj.goodsSupplementMoney * 100);

            pushMoneyObj.pushMoneyTotal = parseInt(pushMoneyObj.pushMoneyTotal) / 100;
            return pushMoneyObj;

        });
    }

    /**
     * 根据职位等级进入周报页面
     */

    static getLevel(){
        return new Promise(resolve => resolve(Tools.userConfig.userInfo.job_grade));
        return Http.post(HttpUrls.urlSets.urlLoginInfo).then(retJson=>retJson.retData.job_grade

        )
    }

}