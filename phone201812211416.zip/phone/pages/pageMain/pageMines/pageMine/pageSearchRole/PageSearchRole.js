import React, { Component } from 'react';
import {
    View,
    Modal,
    TextInput,
    TouchableOpacity,
    Text,
    Image,
} from 'react-native';
import RootSiblings from 'react-native-root-siblings';
import {
    StyleSheetAdapt,
    Tools,
    Theme,
    ButtonChange,
    FlatListView,
    DbMgr,
    BaseComponent,
} from "com";
import {Service} from "./Service";

let showingDialog = null;


export default class PageSearchRoleApi extends Component{

    /**
     * 显示搜索
     * @param cd func,//回调函数
     */
    static show(cd){
        if(showingDialog != null){
            return showingDialog;
        }

        showingDialog = new RootSiblings(<PageSearchRole />);

        return showingDialog;
    }

    /**
     * 隐藏底部菜单
     */
    static hide(){
        if (showingDialog != null && showingDialog instanceof RootSiblings) {
            // showingDialog.update(<ActivityIndicatorContent
            //     animated={KActivityIndicator.animated}
            //     message={KActivityIndicator.message}
            //     isHide={true}
            //
            // />)
            //
            // showingDialog = null;
            showingDialog.destroy();
            showingDialog = null;
        }

        // if (AIV instanceof RootSiblings) {
        //
        //     AIV.update(<ActivityIndicatorContent
        //         animated={KActivityIndicator.animated}
        //         message={KActivityIndicator.message}
        //         isHide={true}
        //     />)
        // }
    }

    /**
     * 更新菊花文字
     * @param AIV 需要更新文字的菊花
     * @param message 文字内容
     */
    static  updateMessage(AIV,message){
        /* AIV.update(<ActivityIndicatorContent
             animated={KActivityIndicator.animated}
             message={message}
         />)*/
    }

};

class PageSearchRole extends Component {

    // 构造
    constructor(props) {
        super(props);

        // 初始状态
        this.state = {
            text:null,

            isIconBottom:true,
            title2:"清空历史记录",
            title1:"历史记录",
            visible: true,
            dataList:[],//显示数据
            historyList:[],
            searchList:[],
            searchList5:[],
        };
    }

    componentWillMount(){

        /*Tools.userConfig.userCutAccount = [
            {
                name:"l袄子，拉力",
                id_child:"325",
                department:"dfsafasdfsafsa",
            },
            {
                name:"sadfsdafsad",
                id_child:"325",
                department:"dfsafasdfsafsa",
            }, {
                name:"l袄子，拉力",
                id_child:"325",
                department:"dfsafasdfsafsa",
            }, {
                name:"sadfsdafsad",
                id_child:"325",
                department:"dfsafasdfsafsa",
            }
        ];*/
        DbMgr.queryTableRole()
            .then(results=>{
                this.setState({
                    dataList:results,
                    historyList:results
                });
                /*this.setState({
                    dataList:Tools.userConfig.userCutAccount,
                    historyList:Tools.userConfig.userCutAccount
                });*/
            });
    }

    onRequestClose(){
        // this.show(false);
    }

    onChangeText = (text,type)=>{
        if(text && text != "")
        {
            let dataList = [];
            let dataList5 = [];
            Tools.userConfig.userCutAccount
                .forEach((v,i,a)=>{
                    if(v.name.indexOf(text) > -1){
                        dataList.push(v);
                        if(dataList.length < 6){
                            dataList5.push(v);
                        }
                    }
                });

            this.setState({
                isIconBottom:false,
                text:text,
                title2:dataList.length > 5 ? "查看更多" : null,
                dataList:dataList5,
                searchList:dataList,
                searchList5:dataList5
            });
        }
        else
        {
            this.setState({
                isIconBottom:true,
                title2:"清空历史记录",
                text:text,
                dataList:this.state.historyList
            });
        }
    }

    onPressItem(item,i){

        PageSearchRoleApi.hide();
        if(item.id_child == Tools.userConfig.userInfo.id){
            return;
        }
        Service.get(item.id_child)
            .then(results=>{
                let is = false;
                this.state.historyList
                    .forEach((v,i,a)=>{
                        if(v.id_child == item.id_child){
                            is = true;
                        }
                    });

                if(false){
                    DbMgr.uptateTableRole({
                        time: new Date().getTime()
                    },item.id).then(rows=>{

                        // Tools.baseComponent.goPage("PageLogin");
                        // Tools.baseComponent.goPage("PageHome");
                        BaseComponent.navigationer.push("PageMain");
                    });
                }
                else {
                    DbMgr.insertTableRole([
                        item.id_parent,
                        item.id_child,
                        item.name,
                        item.department,
                        new Date().getTime()
                    ]).then(rows=>{
                        // sel.goPage("PageLogin");
                        // sel.goPage("PageHome");
                        // Tools.baseComponent.goPage("PageHome");
                        BaseComponent.navigationer.push("PageMain");
                    });
                }

            });
    }

    renderText = (text,i)=>{

        return(
            <Text key={i}
                  style={[styles.itemRowText,i==1?{color:Theme.Colors.themeColor}:{}]}>
                {text}
            </Text>
        );
    }

    renderItem = (item,index)=>{

        let name = [];

        if(this.state.text && this.state.text != ""){
            let i = item.name.indexOf(this.state.text);
            name.push(item.name.substring(0,i));
            name.push(item.name.substring(i,i + this.state.text.length));
            if((i + this.state.text.length) != item.name.length){
                name.push(item.name.substring(i + this.state.text.length));
            }
        }

        // console.info("name",name);
        // console.info("this.state.text",this.state.text);

        return(
            <View key={index}
                  style={styles.itemRow}>
                <Text style={[styles.itemRowText]}>
                    {
                        name.length > 0 ? name.map(this.renderText) : item.name
                    }
                </Text>

                <Text style={[styles.itemRowText,styles.itemRowText2]}>
                    {item.department}
                </Text>
                <ButtonChange text={"切换角色"}
                              onPress={()=>this.onPressItem(item,index)}
                              frameStyle={styles.itemRowBtn}/>
            </View>
        );
    }

    onPressBottom = ()=>{
        if(this.state.isIconBottom){
            DbMgr.delDataTbRole();
            PageSearchRoleApi.hide();
        }
        else {
            this.setState({
                dataList:this.state.dataList.length > 5
                    ? this.state.searchList5
                    : this.state.dataList,
                title2:this.state.dataList.length > 5
                    ? "收起"
                    : "查看更多"
            });
        }
    }

    render() {
        const {visible,title2,title1,isIconBottom,
            dataList} = this.state;

        return(
            <Modal animationType={"slide"}
                   transparent = {true}
                   visible={visible}
                   onRequestClose={()=> this.onRequestClose()}>

                <TouchableOpacity style={styles.cont0}
                                  onPress={()=>PageSearchRoleApi.hide()}/>

                <View style={styles.modal}>
                    <View style={styles.cnt2}>
                        <View style={styles.cnt2_1}>
                            <View style={styles.cnt2_2}>
                                <TextInput style={styles.tput}
                                           autoCapitalize={"none"}
                                           onChangeText={this.onChangeText}
                                           placeholder={"请输入角色"}/>
                                <Image source={require("images/search2.png")}
                                       style={styles.img1}/>
                            </View>
                        </View>

                        <View>
                            {
                                isIconBottom&&<Text style={[styles.itemRowTitle]}>
                                    {title1}
                                </Text>
                            }

                            <FlatListView  data={dataList}
                                           style={styles.flatList}
                                           keyExtractor = {(item, index) => ("key" + index)}
                                           renderItem={({item,index}) => this.renderItem(item,index)}/>
                        </View>

                        {
                            title2&& <TouchableOpacity style={styles.cnt3}
                                                       onPress={this.onPressBottom}>
                                {
                                    isIconBottom&&<Image source={require("images/trash.png")}
                                                         style={styles.img1}/>
                                }
                                <Text style={styles.txt}>
                                    {
                                        title2
                                    }
                                </Text>
                            </TouchableOpacity>
                        }

                    </View>

                    <TouchableOpacity style={styles.cont1}
                                      onPress={()=>PageSearchRoleApi.hide()}/>
                </View>

            </Modal>
        );

    }

}


const styles = StyleSheetAdapt.create({
    flatList:{
        height:'0.6h',
    },

    txt:{
        marginLeft:10,
        color:Theme.Colors.themeColor,
        fontSize:Theme.Font.fontSize,
    },
    cnt3:{
        alignItems:"center",
        justifyContent:"center",
        backgroundColor:Theme.Colors.themeColorLight1,
        height:50,
        flexDirection:"row",
        marginTop:10,
    },

    itemRowTitle:{
        marginLeft:20,
        marginTop:20,
        fontSize:Theme.Font.fontSize,
    },
    itemRowBtn:{
        right:30,
        position:'absolute',
    },
    itemRowText2:{
        marginLeft:50,
    },
    itemRowText:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.minorColor,
    },
    itemRow:{
        flexDirection:"row",
        padding:20,
        alignItems:"center",
    },

    tput:{
        width:335,
        height:40,
        // backgroundColor:"red",
        marginLeft:20,
        fontSize:Theme.Font.fontSize_2,
        textAlign:"center",
    },
    cnt2_2:{
        height:50,
        backgroundColor:Theme.Colors.foregroundColor,
        width:400,
        // justifyContent:"center",
        alignItems:"center",
        flexDirection:"row",
        borderRadius:25,
        borderWidth:Theme.Border.borderWidth,
        borderColor:Theme.Colors.themeColor,
    },
    img1:{
        resizeMode:"contain",
        width:30,
        height:"30w",
        marginLeft:5,
    },
    cnt2_1:{
        height:100,
        justifyContent:"center",
        alignItems:"center",
        backgroundColor:Theme.Colors.themeColorLight1,

        borderTopWidth:Theme.Border.borderWidth,
        borderBottomWidth:Theme.Border.borderWidth,
        borderTopColor:Theme.Colors.themeColor,
        borderBottomColor:Theme.Colors.themeColor,
    },
    cnt2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    cont1:{
        flex:1,
        // backgroundColor:"red",
    },
    cont0:{
        height:90,
    },
    modal:{
        // backgroundColor:Theme.Colors.backgroundColor1,
        flex:1,
        // marginTop:90,
    },
});