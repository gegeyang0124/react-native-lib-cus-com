import {
    Tools,
    Http,
    HttpUrls,
    LocalStorage,
    JPush,
} from "com-api";
import DeviceInfo from 'react-native-device-info';

/**
 * 登陆页接口处理
 * **/
export class Service {

    /**
     * 切换获取token
     * **/
    static get(id) {

        return  new Promise(function (resolve, reject){
            Tools.userConfig.userInfo.id = id + "";
            Http.get(HttpUrls.urlSets.urlCutRole)
                .then((retJson) => {
                    //alert(JSON.stringify(retJson))
                    Tools.userConfig.token = retJson.retData.token;
                    Tools.cutLogin = true;

                    Http.post(HttpUrls.urlSets.urlLoginInfo)
                        .then((retJson) => {

                            retJson.retData["token"] = Tools.userConfig.token;
                            retJson.retData["count"] = Tools.userConfig.userInfo.count;
                            retJson.retData["password"] = Tools.userConfig.userInfo.password;
                            retJson.retData["id"] = retJson.retData.userid;
                            retJson.retData["full_name"] = retJson.retData.username;
                            retJson.retData["position_name"] = retJson.retData.position;
                            retJson.retData["department_id"] = retJson.retData.framework_id;
                            retJson.retData["isDoorInvest"] = Tools.isDoorInvest(retJson.retData.framework_id);
                            retJson.retData["department_name"] = retJson.retData.framework_name;
                            //department_level:1、运营中心；2、大区；3、省区（个人）
                            retJson.retData.phone = retJson.retData.isDoorInvest
                                ? Tools.replaceStr(retJson.retData.phone, 3, 7)
                                : retJson.retData.phone;

                            Tools.userConfig.userInfo = retJson.retData;

                            resolve(retJson.retData);

                        })
                        .catch((status) => {
                            reject(status);
                        });

                })
                .catch((status) => {
                    reject(status);
                });
        });


    }


}