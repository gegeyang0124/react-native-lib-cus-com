import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTripApply,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageMinePassword extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.selectedValue = {
            oldPsw:null,
            psw:null,
            confirmPsw:null
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }


    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
    }

    componentWillReceiveProps(){
    }

    onChangeText(text,type){

        switch (type){
            case 0:{
                this.selectedValue.oldPsw = text;
                break;
            }
            case 1:{
                this.selectedValue.psw = text;
                break;
            }
            case 2:{
                this.selectedValue.confirmPsw = text;
                break;
            }
        }
    }

    onPressBottom = ()=>{
        if(this.selectedValue.oldPsw !== Tools.userConfig.userInfo.password){
            Tools.toast("原始密码错误！");
            return;
        }
        else if(this.selectedValue.psw !== this.selectedValue.confirmPsw){
            Tools.toast("新密码不一致！");
            return;
        }
        else if(this.selectedValue.psw == null || this.selectedValue.psw == ''){
            Tools.toast("密码不能为空！");
            return;
        }
        Service.putIn(this.selectedValue)
            .then(retJson=>{
                Tools.toast("提交成功");
            });
    }

    render() {

        return (
            <ViewTitle viewBottom={ "提交"}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"原  密  码:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"input"}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              secureTextEntry:true,
                                              placeholder:'请填写原密码',
                                              onChangeText:(text)=>this.onChangeText(text,0)
                                          }
                                      }/>

                    <ItemRowTripApply text={"新  密  码:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop2}
                                      viewCenter={"input"}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              secureTextEntry:true,
                                              placeholder:'请填写新密码',
                                              onChangeText:(text)=>this.onChangeText(text,1)
                                          }
                                      }/>

                    <ItemRowTripApply text={"确认密码:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"input"}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              secureTextEntry:true,
                                              placeholder:'请再次填写新密码',
                                              onChangeText:(text)=>this.onChangeText(text,2)
                                          }
                                      }/>

                </View>


            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    itemRowLabel:{
        flex:2.5,
    },

    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },
    titleFrameTop2:{
        marginTop:40,
    },

});