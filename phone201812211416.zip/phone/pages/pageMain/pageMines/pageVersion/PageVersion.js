import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    ScrollViewRowList,
    Theme,
    Tools,
    ItemRowTripApply,
    ItemRowGuideTripApply,
} from "com";



type Props = {};
export default class PageVersion extends BaseComponent<Pro>{
    constructor(props){
        super(props)
        this.state={
            name:'Tony',
            dataList:[

                {

                        time:'2018/08/31',
                        version:'V2.0.0',
                        text:'1.运营通全面升级'

                },
            ]}

        this.setParams({
            headerLeft:true,
            headerRight:false
            }
        )
    }



    render(){
        const {dataList}=this.state
        return(
            <ViewTitle frameStyle={styles.cont}>

                <View style={styles.content}>
                    <ItemRowGuideTripApply text1='更新日期'
                                           text2='版本'
                                           text3='说明'/>

                    {dataList.map((item,index)=>
                        <ItemRowGuideTripApply  frameStyle={styles.View}

                                                key={index}
                                                text1={item.time}
                                                text2={item.version}
                                                text3={item.text}/>)}

                </View>
            </ViewTitle>

        )
    }
}
const styles=StyleSheetAdapt.create({
    cont:{
        backgroundColor:Theme.Colors.foregroundColor,
    },

    content:{
        margin:10,
        marginTop:20,
        borderTopWidth:Theme.Border.borderWidth,
        borderLeftWidth:Theme.Border.borderWidth,
        borderColor:Theme.Colors.borderColor,

    },
})