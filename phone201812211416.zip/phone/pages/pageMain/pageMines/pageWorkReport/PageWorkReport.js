/**
 * Created by Administrator on 2018/4/30.
 */
import {
    Theme
} from "com";
import {
    TabNavigator,
} from "comThird";

import {
    PageWorkReportWeekDetail,
    PageWorkReportWeek,

} from "./pageWorkReportWeek/PageWorkReportWeek";
import {

    PageWorkReportWeekP,
}from "./pageWorkReportWeek/PageWorkReportWeekP"
import {
    PageWorkReportMonthDetail,
    PageWorkReportMonth
} from "./pageWorkReportMonth/PageWorkReportMonth";

const TabRouteConfigs = {
    PageWorkReportWeek: {
        screen: PageWorkReportWeek,
    },
    PageWorkReportWeekP: {
        screen: PageWorkReportWeekP,
    },
    PageWorkReportMonth: {
        screen: PageWorkReportMonth,
    },
    PageWorkReportMonthDetail: {
        screen: PageWorkReportMonthDetail,
        navigationOptions: {
            title:'月报详情',
            tabBarLabel : '月报详情',
        },
    },
    PageWorkReportWeekDetail: {
        screen: PageWorkReportWeekDetail,
        navigationOptions: {
            title:'周报详情',
            tabBarLabel : '周报详情',
        },
    },
}


const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);


module.exports = pages;