/**
 * Created by Administrator on 2018/4/30.
 */
import {
    Theme
} from "com";
import {
    TabNavigator,
} from "comThird";

import PageWorkReportMonthListSend from "./pageWorkReportMonthListSend/PageWorkReportMonthListSend";
import PageWorkReportMonthListReceive from "./pageWorkReportMonthListReceive/PageWorkReportMonthListReceive";
import PageWorkReportMonthDetail from "./pageWorkReportMonthDetail/PageWorkReportMonthDetail";

/**
 * 工具页面页面 引入集合
 **/
const TabRouteConfigs = {
    PageWorkReportMonthListReceive: {
        screen: PageWorkReportMonthListReceive,
        navigationOptions: {
            title:'月报',
            tabBarLabel : '接收',
        },
    },
    PageWorkReportMonthListSend: {
        screen: PageWorkReportMonthListSend,
        navigationOptions: {
            title:'月报',
            tabBarLabel : '发送',
        },
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigsTop);


module.exports = {
    get PageWorkReportMonth(){
        return pages;
    },
    get PageWorkReportMonthDetail(){
        return PageWorkReportMonthDetail;
    }
};