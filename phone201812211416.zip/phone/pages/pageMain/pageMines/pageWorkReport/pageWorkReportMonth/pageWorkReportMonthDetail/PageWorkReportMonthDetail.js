import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTripApply,
    TextInputLabel,
    ItemRowTitle,
    ItemRowGuideTripApply,
    ButtonTime,
    ScrollSelectOptions,
    ButtonChange,
    ModalTextInput,
} from "com";

import {Service} from "./Service";

type Props = {};
export default class PageWorkReportMonthDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.selectedValue = {
            thisWork:{
                weekReportId:null,//周报ID
                isThisWeek:true,//是否是本周 true：本周
                /**
                 * 成员：{
                       content:'',//内容描述
                       type:0,//0未完成，1已完成
                       resaon:'',//未完成需要填写理由
                       finishTime:'YYYY-MM-DD HH:mm:ss',完成时间
             }
                 * **/
                planLists:[],//工作安排
            },
            nextWeek:{
                weekReportId:null,//周报ID
                isThisWeek:false,//是否是本周 true：本周
                /**
                 * 成员：{
                       content:'',//内容描述
                       //type:0,//0未完成，1已完成
                       //resaon:'',//未完成需要填写理由
                       finishTime:'YYYY-MM-DD HH:mm:ss',完成时间
             }
                 * **/
                planLists:[],//工作安排
            },
            match:{
                id:null,//周报ID
                sorce:null,// 评价分数
                reason:null,//评价理由
            }

        };

        this.state = {
            id:null,//周报ID
            thisWorkList:[],//本周工作
            nextWeekList:[],//下周工作

            resultList:[],//业绩数据

            weekReportTime:Tools.getTimeByRank(new Date().getTime()),

            isEdit:false,
            submit_time:Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM-DD HH:mm"),// 填写时间
            parent_name:null,//接收人名称

            isAudit:false,//是否是可审核
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }


    componentWillEnter(params,action,page){
        if(params){
            // this.state.id = "7b9c512a-214a-4c8a-9428-01fd36420178";
            this.state.id = params.id;
            this.selectedValue.thisWork.weekReportId = this.state.id;
            this.selectedValue.match.id = this.state.id;
            this.selectedValue.nextWeek.weekReportId = this.state.id;
            this.getData();
        }

    }

    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
        // Tools.toast(this.state.submit_time)
    }

    componentWillReceiveProps(){}

    getData(){

        Service.getWeekReportResultDetail(
            Tools.timeFormatConvert(this.state.weekReportTime.time1,"YYYY-MM-DD HH:mm:ss"),
            Tools.timeFormatConvert(this.state.weekReportTime.time2,"YYYY-MM-DD HH:mm:ss")
        ).then(retJson=>{
            this.setState({
                resultList:retJson
            });
        });

        Service.getMonthReportInfoDetail(this.state.id)
            .then(retJson=>{
                this.setState({
                    submit_time:Tools.timeFormatConvert(retJson.baseInfo.submit_time ? retJson.baseInfo.submit_time : new Date().getTime(),"YYYY-MM-DD HH:mm"),// 填写时间
                    parent_name:retJson.baseInfo.parent_name,//接收人名称
                    isEdit:retJson.baseInfo.userid == Tools.userConfig.userInfo.id
                        ? retJson.baseInfo.status < 2
                            ? true
                            : false
                        : false,
                    isAudit:retJson.baseInfo.userid != Tools.userConfig.userInfo.id
                        ?  retJson.baseInfo.status == 3
                            ? true
                            : false
                        : false,
                    // isAudit:true,
                    thisWorkList:retJson.thisWorkList,
                    nextWeekList:retJson.nextWeekList
                });
            });
    }

    onPressBottom = ()=>{
        const {thisWorkList,nextWeekList,isAudit} = this.state;
        if(isAudit){
            ModalTextInput.show();
            return;
        }
        let isNotPut = true;

        if(thisWorkList.length > 0){
            isNotPut = false;
            this.selectedValue.thisWork.planLists = thisWorkList;
            Service.putIn(this.selectedValue.thisWork)
                .then(retJson=>{
                    if(nextWeekList.length == 0){
                        Tools.toast("提交成功！");
                    }
                });
        }

        if(nextWeekList.length > 0){
            isNotPut = false;
            Service.putIn()
            this.selectedValue.nextWeek.planLists = nextWeekList;
            Service.putIn(this.selectedValue.nextWeek)
                .then(retJson=>{
                    Tools.toast("提交成功！");
                });
        }

        if(isNotPut){
            Tools.toast("主人，你没有填写周报哦！")
        }
    }

    onChangeText(text,i,type){

        switch (type){
            case 0:{
                this.setState(preState=>{
                    preState.thisWorkList[i].content = text;
                    return {
                        thisWorkList:JSON.parse(JSON.stringify(preState.thisWorkList))
                    }
                });
                break;
            }
            case 1:{
                this.setState(preState=>{
                    preState.thisWorkList[i].resaon = text;
                    return {
                        thisWorkList:JSON.parse(JSON.stringify(preState.thisWorkList))
                    }
                });
                break;
            }
            case 2:{
                this.setState(preState=>{
                    preState.nextWeekList[i].content = text;
                    return {
                        nextWeekList:JSON.parse(JSON.stringify(preState.nextWeekList))
                    }
                });
                break;
            }
        }
    }

    onPressAddWork(type){
        if(type == 0){

            this.setState(preState=>{
                let l = [{
                    content:'',//内容描述
                    type:1,//0未完成，1已完成
                    resaon:'',//未完成需要填写理由
                    finishTime:Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM-DD HH:mm:ss"),//完成时间
                }];

                l = l.concat(preState.thisWorkList);
                // console.info("l",l);
                // return {thisWorkList:preState.thisWorkList};
                return {
                    thisWorkList:l
                };
            });
        }
        else {
            this.setState(preState=>{
                let l = [{
                    content:'',//内容描述
                    finishTime:Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM-DD HH:mm:ss"),//完成时间
                }];
                l = l.concat(preState.nextWeekList);

                return {
                    nextWeekList:l
                };
            });
        }
    }

    onPressDelWork(i,type){
        if(type == 0){
            this.setState(preState=>{

                preState.thisWorkList.splice(i,1);
                return {
                    thisWorkList:JSON.parse(JSON.stringify(preState.thisWorkList))
                }
            });
        }
        else {
            this.setState(preState=>{

                preState.nextWeekList.splice(i,1);
                return {
                    nextWeekList:JSON.parse(JSON.stringify(preState.nextWeekList))
                }
            });
        }
    }

    onChangeTime(timestamp,i,type){
        if(type == 0){
            this.setState(preState=>{

                preState.thisWorkList[i].finishTime = Tools.timeFormatConvert(timestamp,"YYYY-MM-DD HH:mm:ss");
                return {
                    thisWorkList:JSON.parse(JSON.stringify(preState.thisWorkList))
                }
            });
        }
        else {
            this.setState(preState=>{
                preState.nextWeekList[i].finishTime = Tools.timeFormatConvert(timestamp,"YYYY-MM-DD HH:mm:ss");
                return {
                    nextWeekList:JSON.parse(JSON.stringify(preState.nextWeekList))
                }
            });
        }
    }

    onChangeChecked(isChecked,i,index){
        this.setState(preState=>{
            // type:0,//0未完成，1已完成
            preState.thisWorkList[i].type = index == 0 && isChecked ? 1 : 0;
            return {
                thisWorkList:JSON.parse(JSON.stringify(preState.thisWorkList))
            }
        });
    }

    renderThisWork = (item,i)=>{
        const {isEdit} = this.state;

        return (
            <View key={i}
                  style={styles.weekCurWorkFrame_1}>
                <TextInputLabel textInputProps={{
                    style:styles.textInputWork,
                    placeholder:'具体工作内容',
                    value:item.content,
                    editable:isEdit,
                    onChangeText:(text)=>this.onChangeText(text,i,0)
                }}
                                labelUI={
                                    <View style={styles.labelFrame}>
                                        <Text style={styles.labelText}>
                                            具体工作内容
                                        </Text>

                                        {
                                            isEdit
                                            && <ButtonChange text={"删除"}
                                                             onPress={()=>this.onPressDelWork(i,0)}
                                                             frameBtnStyle={styles.labelBtn}
                                                             frameStyle={styles.labelBtnFrame}/>
                                        }
                                    </View>
                                }
                />

                <View style={styles.workFinishFrame}>
                    <View style={styles.workFinishFrame_1}>
                        <TextInputLabel textLabel={"是否完成"}
                                        viewUI={
                                            <ScrollSelectOptions isScroll={false}
                                                                 isReset={2}
                                                                 mode={isEdit ? "answer" : "check"}
                                                                 onChange={(isChecked,type,item,index)=>this.onChangeChecked(isChecked,i,index)}
                                                                 chkFrame={styles.chkFrame}
                                                                 dataList={[
                                                                     {
                                                                         text:'是',
                                                                         isChecked:item.type == 1 ? true : false
                                                                     },
                                                                     {
                                                                         text:'否',
                                                                         isChecked:item.type == 1 ? false : true
                                                                     }
                                                                 ]}/>
                                        }/>
                    </View>

                    <View style={styles.workFinishFrame_1}>
                        <TextInputLabel textLabel={"完成日期"}
                                        viewUI={
                                            <ButtonTime mode={"date"}
                                                        isReset={true}
                                                        disabled={!isEdit}
                                                        defaultText={Tools.timeFormatConvert(item.finishTime,"YYYY-MM-DD")}
                                                        onChange={({timestamp})=>this.onChangeTime(timestamp,i,0)}
                                                        frameBtnStyle={styles.frameBtnStyle}/>
                                        }/>
                    </View>

                    <View style={styles.workFinishFrame_1}>
                        <TextInputLabel textLabel={"原因"}
                                        textInputProps={{
                                            style:styles.reason,
                                            placeholder:'完成/未完成原因',
                                            value:item.reason,
                                            editable:isEdit,
                                            onChangeText:(text)=>this.onChangeText(text,i,1)
                                        }}/>
                    </View>
                </View>
            </View>
        );

    }

    renderNextWork = (item,i)=>{
        const {isEdit} = this.state;
        return (
            <View key={i}
                  style={styles.weekCurWorkFrame_1}>
                <TextInputLabel labelUI={
                    <View style={styles.labelFrame}>
                        <Text style={styles.labelText}>
                            具体工作内容
                        </Text>

                        {
                            isEdit
                            && <ButtonChange text={"删除"}
                                             onPress={()=>this.onPressDelWork(i,1)}
                                             frameBtnStyle={styles.labelBtn}
                                             frameStyle={styles.labelBtnFrame}/>
                        }

                    </View>
                }
                                textInputProps={{
                                    style:styles.textInputWork,
                                    placeholder:'具体工作内容',
                                    value:item.content,
                                    editable:isEdit,
                                    onChangeText:(text)=>this.onChangeText(text,i,2)
                                }}/>

                <TextInputLabel textLabel={"预计完成日期"}
                                viewUI={
                                    <ButtonTime mode={"date"}
                                                isReset={true}
                                                disabled={!isEdit}
                                                defaultText={Tools.timeFormatConvert(item.finishTime,"YYYY-MM-DD")}
                                                onChange={({timestamp})=>this.onChangeTime(timestamp,i,1)}
                                                frameBtnStyle={styles.frameBtnStyle}/>
                                }/>
            </View>
        );
    }

    renderResult = (item,i)=>{
        return (
            <ItemRowGuideTripApply key={i}
                                   text1={item.storeType == 1 ? "新客户" : "老客户"}
                                   text2={item.storeName}
                                   text3={item.reorderMoney}
                                   text4={item.salesOrderMoney}
                                   text5={item.storeOrderMoney}
                                   text6={false}
                                   text7={false}/>
        );
    }

    onChangeTextMatch(text,type){
        if(type == 0){
            this.selectedValue.match.sorce = text;
        }
        else {
            this.selectedValue.match.reason = text;
        }
    }

    onPressMatch = ()=>{
        Service.putInMatch(this.selectedValue.match)
            .then(()=>{
                Tools.toast("提交成功！");
            });
    }

    render() {

        const {thisWorkList,nextWeekList,resultList,isEdit,parent_name,submit_time,
            isAudit} = this.state;

        return (
            <ViewTitle viewBottom={isAudit ? "点评" : isEdit ? "提交" : null}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>

                    <View style={styles.txtInptLabelframe}>
                        <TextInputLabel textLabel={"填写人"}
                                        textInputProps={{
                                            style:styles.textInputStyle,
                                            multiline:false,
                                            defaultValue:Tools.userConfig.userInfo.full_name,
                                            editable:false,
                                        }}/>
                    </View>

                    <View style={styles.txtInptLabelframe}>
                        <TextInputLabel textLabel={"职位"}
                                        textInputProps={{
                                            style:styles.textInputStyle,
                                            multiline:false,
                                            defaultValue:Tools.userConfig.userInfo.position_name,
                                            editable:false,
                                        }}/>
                    </View>

                    <View style={styles.txtInptLabelframe}>
                        <TextInputLabel textLabel={"填写时间"}
                                        textInputProps={{
                                            style:styles.textInputStyle2,
                                            multiline:false,
                                            defaultValue:submit_time,
                                            editable:false,
                                        }}/>
                    </View>

                    <View style={styles.txtInptLabelframe}>
                        <TextInputLabel textLabel={"接收人"}
                                        textInputProps={{
                                            style:styles.textInputStyle,
                                            multiline:false,
                                            defaultValue:parent_name,
                                            editable:false,
                                        }}/>
                    </View>
                </View>

                <View style={styles.resultFrame}>
                    <ItemRowTitle text1={"本月业绩"}/>

                    <View style={styles.table}>
                        <ItemRowGuideTripApply text1={"类型"}
                                               text2={"门店名称"}
                                               text3={"返单(元)"}
                                               text4={"门店采购(元)"}
                                               text5={"门店销售(元)"}
                                               text6={false}
                                               text7={false}/>

                        {
                            resultList.map(this.renderResult)
                        }
                    </View>
                </View>

                <View style={styles.resultFrame}>

                    <ItemRowTitle text1={"本月工作总结"}
                                  onPressRight={()=>this.onPressAddWork(0)}
                                  text2={isEdit ? "添加" : null}/>

                    <View style={styles.weekCurWorkFrame}>

                        {
                            thisWorkList.map(this.renderThisWork)
                        }

                    </View>

                </View>

                <View style={styles.resultFrame}>

                    <ItemRowTitle text1={"下月工作计划"}
                                  onPressRight={()=>this.onPressAddWork(1)}
                                  text2={isEdit ? "添加" : null}/>

                    <View style={styles.weekCurWorkFrame}>
                        {
                            nextWeekList.map(this.renderNextWork)
                        }
                    </View>

                </View>

                <ModalTextInput title={"评价"}
                                onChangeText1={(text)=>this.onChangeTextMatch(text,0)}
                                onChangeText={(text)=>this.onChangeTextMatch(text,1)}
                                onPressRight={this.onPressMatch}
                                simpleMode={false}/>

            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    labelBtn:{
        width:70,
        paddingTop:5,
        paddingBottom:5,
    },
    labelBtnFrame:{
        alignItems:'flex-end',
        flex:1,
        marginRight:10,
    },
    labelText:{
        fontSize:Theme.Font.fontSize,
    },
    labelFrame:{
        flexDirection:'row',
    },

    reason:{
        width:200,
        height:30,
    },
    frameBtnStyle:{
        width:160
    },
    chkFrame:{
        alignItems:'flex-start',
    },
    weekCurWorkFrame_1:{
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth,
    },
    workFinishFrame_1:{
        flex:1,
        // alignItems:'center',
        justifyContent:'center',
    },
    workFinishFrame:{
        flex:1,
        flexDirection:'row',
    },
    textInputWork:{
        height:50,
    },
    weekCurWorkFrame:{
        margin:20,
        marginTop:0,
    },

    table:{
        // margin:10,
        // borderTopWidth:Theme.Border.borderWidth,
        // borderLeftWidth:Theme.Border.borderWidth,
    },
    resultFrame:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    txtInptLabelframe:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    textInputStyle:{
        width:150,
        height:30,
    },
    textInputStyle2:{
        width:180,
        height:30,
    },
    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingBottom:20,
        flexDirection:'row',

    },

});