import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 周报详情 业绩
     * @param beginDate string,//开始时间
     * @param endDate string,//结束时间
     * **/
    static getWeekReportResultDetail(beginDate,endDate){
        return Http.get(HttpUrls.urlSets.urlWeekReportDetail2,{
            beginDate:beginDate,
            endDate:endDate
        }).then(retJson=>{
            return retJson.retData.list;
        });
    }

    /**
     * 周报详情 周报信息
     * @param taskId string,//任务ID
     * **/
    static getWeekReportInfoDetail(taskId){
        return Http.post(HttpUrls.urlSets.urlWeekReportDetail,{
            id:taskId,
        }).then(retJson=>{

            retJson.retData.thisWorkList = [];
            if(retJson.retData.weekPlan){
                retJson.retData.weekPlan.forEach((v,i,a)=>{
                    let item = {
                        id:v.id,
                        content:v.content,//内容描述
                        type:v.type,//0未完成，1已完成
                        resaon:v.resaon,//未完成需要填写理由
                        finishTime:v.finish_time,//完成时间
                    }
                    retJson.retData.thisWorkList.push(item);
                });
            }

            retJson.retData.nextWeekList = [];
            if(retJson.retData.nextWeekPlan){
                retJson.retData.nextWeekPlan.forEach((v,i,a)=>{
                    let item = {
                        id:v.id,
                        content:v.content,//内容描述
                        finishTime:v.finish_time,//完成时间
                    }
                    retJson.retData.nextWeekList.push(item);
                });
            }

            return retJson.retData;
        });
    }

    /**
     * 提交本周或下周周报
     * @param selectedValue json,//提交数据
     * **/
    static putIn(selectedValue){

        return Http.post(HttpUrls.urlSets.urlWeekReportMgrAddCnt,
            selectedValue)
            .then(retJson=>retJson);
    }


    /**
     * 提交 点评
     * @param selectedValue json,//提交数据
     * **/
    static putInMatch(selectedValue){
        return Http.post(HttpUrls.urlSets.urlWorkReportMatch,
            selectedValue)
            .then(retJson=>retJson.retData);
    }
}