import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        pageNumber:1,
    };//传入参数


    /**
     * 获取出差数据列表
     * @param selectValue object,//搜索参数
     * selectValue = {
            status:null,//0未填写,1待提交,2待点评,3已点评
            username:null,//姓名
            company_id:null,//大区id
            dept_id:null, //区域id
            startTime:'',// 开始时间 ，
            endTime:''//结束时间
        }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static getWeekReport(selectValue,init){

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retJson.retListData = [];
        }

        return Http.post(HttpUrls.urlSets.urlWeekReportMgr, {
            pageNumber:this.base.paramsFetch.pageNumber,
            pageSize: 20,
            sort:'create_time',
            order:'desc',
            filter:selectValue
        },init)
            .then((retJson) => {

                this.base.retJson.total = retJson.retData.total;

                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                retJson.retListData.forEach((v,i,a)=>{
                    /*v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY-MM-DD HH:mm");
                    v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY-MM-DD HH:mm");*/

                    this.base.retJson.retListData.push(v);
                });

                return  this.base.retJson;
            })
            .catch((status) => {
                return status;
            });
    }

    /**
     * 获取1/二级部门选择列表
     * @param parent_id string,//一级部门ID
     * **/
    static getDepartments(parent_id){

        return Http.post(HttpUrls.urlSets.urlGetDepartmentListByParentId,{
            parent_id:parent_id
        },false)
            .then((retJson)=>{
                return retJson.retListData;
            });

        // modelTrip.set("area",'');

    }

    /**
     * 发送工作报告提醒
     * **/
    static sendWorkReportRemind(id){

        return Http.post(HttpUrls.urlSets.urlWeekAndMonthReportRemind,{
            type:1,//1、周报 2、月报
            object_id:id //周报/月报ID
        })
            .then((retJson)=>retJson);

        // modelTrip.set("area",'');

    }

}
