/**
 * Created by Administrator on 2018/4/30.
 */
import {
    Theme,
    Tools,
    Http,
    HttpUrls
} from "com";
import {
    TabNavigator,
} from "comThird";

import PageWorkReportWeekListSend from "./pageWorkReportWeekListSend/PageWorkReportWeekListSend";
import PageWorkReportWeekDetail from "./pageWorkReportWeekDetail/PageWorkReportWeekDetail";

// const TabRouteConfigs = {
//     PageWorkReportWeekListReceive: {
//         screen: PageWorkReportWeekListReceive,
//         navigationOptions: {
//             title:'周报',
//             tabBarLabel : '接收',
//         },
//     },
//     PageWorkReportWeekListSend: {
//         screen: PageWorkReportWeekListSend,
//         navigationOptions: {
//             title:'周报',
//             tabBarLabel : '发送',
//         },
//     },
// }
//
//
// const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigsTop);
//
//
// module.exports = {
//     get PageWorkReportWeek(){
//         return pages;
//     },
//     get PageWorkReportWeekDetail(){
//         return PageWorkReportWeekDetail;
//     }
// };

// Http.post(HttpUrls.urlSets.urlLoginInfo, {}).then(resJson=>{
/*const level ={
    level:Tools.getLevel()
}*/
/* if(Tools.userConfig.job_grade){
     const TabRouteConfigs = {
         PageWorkReportWeekListSend: {
             screen: PageWorkReportWeekListSend,
             navigationOptions: {
                 title:'周报',
                 tabBarLabel : '发送',
             },
         },
     }


     const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigsTop);


     module.exports = {
         get PageWorkReportWeek(){
             console.log(Tools.userConfig.job_grade)
             return pages;
         },
         get PageWorkReportWeekDetail(){
             return PageWorkReportWeekDetail;
         }
     };

 }*/
// else{
const TabRouteConfigs = {
    PageWorkReportWeekListSend: {
        screen: PageWorkReportWeekListSend,
        navigationOptions: {
            title:'周报',
            tabBarLabel : '发送',
        },
    },
}


const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigsTop);


module.exports = {
    get PageWorkReportWeekP(){
        return pages;
    },
    get PageWorkReportWeekDetail(){
        return PageWorkReportWeekDetail;
    }
};

// }
// })