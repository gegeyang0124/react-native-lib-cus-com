/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    FlatListView,
    ItemRowGoods,
    ItemRowTitle,
    SearchDDDIpt,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageWorkReportWeekListSend extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.state = {
            dataList:[],//任务列表

            departmentOneList:[],
            departmentTwoList:[],
            clearDropTwo:true,
            month:Tools.timeFormatConvert(new Date().getTime(),"YYYY-MM"),//月份
            total:'',//总条数
        };

        this.config = {
            statusList:[
                {
                    id:null,
                    name:'全部'
                }
            ].concat(Tools.statusConvertWorkReport()),
            timeMonthObj:Tools.getTimeByRank(new Date().getTime()),
            executing:false,
            execFirst:true,
        };

        this.selectedValue = {
            status:null,//0未填写,1待提交,2待点评,3已点评
            username:null,//姓名
            company_id:null,//大区id
            dept_id:null, //区域id
            startTime:Tools.timeFormatConvert(this.config.timeMonthObj.time1,"YYYY-MM-DD HH:mm:ss"),// 开始时间 ，"YYYY-MM-DD HH:mm:ss"
            endTime:Tools.timeFormatConvert(this.config.timeMonthObj.time2,"YYYY-MM-DD HH:mm:ss"),//结束时间 "YYYY-MM-DD HH:mm:ss"
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });

    }

    getData() {
        if(!this.config.executing){

            this.config.executing = true;

            if(!this.config.execFirst)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
            }

            Service.getWeekReport(this.selectedValue,this.config.execFirst)
                .then(retJson=>{
                    this.config.executing = false;
                    if(!this.config.execFirst && !retJson.has)
                    {
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);

                    }
                    else
                    {
                        this.config.execFirst = false;
                        this.setState({
                            total:retJson.total,
                            dataList:retJson.retListData
                        });
                        // Tools.toast(JSON.stringify(retJson))

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }
                })
                .catch((status) =>{
                    this.config.executing = false;
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }
    }

    getDepartments(parentId,type = 1){
        Service.getDepartments(parentId)
            .then(retJson=>{
                let lst = [
                    {
                        name:Tools.userConfig.userInfo.department_level == 1 && type == 0
                            ? '大区'
                            : '省区',
                        id:null
                    }
                ];

                retJson = lst.concat(retJson);

                let obj = {};
                if(Tools.userConfig.userInfo.department_level == 1 && type == 0){
                    obj.departmentOneList = retJson;
                }
                else {
                    obj.departmentTwoList = retJson;
                    obj.clearDropTwo = true;
                }

                this.setState(obj);
            });
    }

    componentWillMount(){


    }

    componentDidMount() {
        this.getData();

        /*if(Tools.userConfig.userInfo.department_level != 3){
            this.getDepartments(Tools.userConfig.userInfo.department_id,0);
        }*/
    }

    componentWillEnter(){
        this.config.execFirst = true;
        this.getData();

    }

    onPressItem(item,btnObj){
        this.goPage("PageWorkReportWeekDetail", {id: item.id,dept_id:item.dept_id});
    }

    componentWillReceiveProps(){

    }

    onSelectDrop(val,i,type){
        switch (type){
            case 0:{
                this.selectedValue.status = val.id;
                break;
            }
            case 1:{
                this.selectedValue.company_id = val.id;
                this.getDepartments(this.selectedValue.company_id);
                break;
            }
            case 2:{
                this.selectedValue.dept_id = val.id;
                if(this.state.clearDropTwo){
                    this.setState({
                        clearDropTwo:false
                    });
                }
                break;
            }
        }

    }

    onChangeText = (text)=>{
        this.selectedValue.username = text;
    }

    onShowMonPicker = ()=>{
        // PickerCustome.pickMonth();
        Tools.pickMonth(retJson =>{
            let timeObj = Tools.getTimeByRank((new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime());



            this.selectedValue.startTime = Tools.timeFormatConvert(timeObj.time1,"YYYY-MM-DD HH:mm:ss");
            this.selectedValue.endTime = Tools.timeFormatConvert(timeObj.time2,"YYYY-MM-DD HH:mm:ss");

            this.setState({
                month:Tools.timeFormatConvert(timeObj.time1,"YYYY-MM")
            });
            // this.forceUpdate();//强制刷新
        });

        return false;
    }

    renderItem = ({item,index})=>{

        let status = Tools.statusConvertWorkReport(item.status,item.userid);
        // console.log(item)

        return(
            <ItemRowGoods key={index}
                          frameStyle={styles.itemRowFrame}
                          onPress={()=>this.onPressItem(item,status.btnList[0])}
                          isShowIcon={false}
                          text1_2={"状态：" + status.text}
                          text1_2_Style={styles.textRow2}
                          btnFrameStyle={{backgroundColor:status.btnList[0].backgroundColor}}
                          textBtn={"      " + status.btnList[0].text + "      "}
                          text2_1={"填写人：" + item.username}
                          text2_2={"接受人：" + item.parent_name}
                          textStyle={styles.textStyle}
                          text1_1={"日    期：" + Tools.timeFormatConvert(item.create_time,"YYYY-MM-DD")}/>
        );
    }

    onPressSearch = ()=>{
        this.config.execFirst = true;
        this.getData();
    }

    render() {
        const {dataList,departmentOneList,departmentTwoList,clearDropTwo,
            month,total} = this.state;
        const {statusList} = this.config;


        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c}>

                <View style={styles.titleSearchFrame}>
                    <SearchDDDIpt isPickDropdown1={false}
                                  options2={{
                                      frameStyle:styles.pdFrame,
                                      style:styles.titleSearchP1,
                                      defaultValue:'状态',
                                      options:statusList,
                                      onSelect:(i,val)=>this.onSelectDrop(val,i,0),
                                  }}
                                  options3={{
                                      frameStyle:styles.pdFrame,
                                      style:styles.titleSearchP1,
                                      clearDrop:true,
                                      defaultValue:month,
                                      onDropdownWillShow:this.onShowMonPicker
                                  }}
                                  placeholder={"--姓名--"}
                                  inputStyle={
                                      Tools.userConfig.userInfo.department_level == 3
                                          ? {}
                                          : styles.inputStyle
                                  }
                                  isTextInput={false}
                                  textChange={this.onChangeText}
                                  onPressSearch={this.onPressSearch}
                                  isPickDropdown4={false}/>

                    {
                       /* Tools.userConfig.userInfo.department_level < 3
                        &&  <SearchDDDIpt isTextInput={false}
                                          frameStyle={styles.searchFrame}
                                          options1={{
                                              frameStyle:styles.pdFrame,
                                              style:styles.titleSearchP1,
                                              defaultValue:"大区",
                                              options:departmentOneList,
                                              onSelect:(i,val)=>this.onSelectDrop(val,i,1),
                                          }}
                                          options2={{
                                              frameStyle:styles.pdFrame,
                                              style:styles.titleSearchP1,
                                              clearDrop:clearDropTwo,
                                              defaultValue:'省区',
                                              options:departmentTwoList,
                                              onSelect:(i,val)=>this.onSelectDrop(val,i,2),
                                          }}
                                          isPickDropdown1={
                                              Tools.userConfig.userInfo.department_level == 1
                                                  ? true
                                                  : false
                                          }
                                          isPickDropdown3={false}
                                          onPressSearch={this.onPressSearch}
                                          isPickDropdown4={false}/>*/
                    }
                </View>

                <ItemRowTitle text1={"共有" + total + "份周报"}
                              frameStyle={styles.titleWorkFrame}/>

                <FlatListView style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={this.renderItem}
                              onEndReached={() =>this.getData()}/>

            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    searchFrame:{
        justifyContent:'flex-start',
        marginLeft:25,

    },
    inputStyle:{
        width:200,
    },
    pdFrame2:{
        marginRight:30,
    },
    pdFrame:{
        marginRight:60,
    },
    titleSearchP1:{
        width:160,
    },
    titleSearchFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        // marginTop:10,
    },

    textStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.fontcolor_1,
        padding:5,
    },
    itemRowFrame:{
        borderBottomColor:Theme.Colors.themeColor,
        margin:10,
    },
    textRow2:{
        color:Theme.Colors.themeColor,
    },
    titleWorkFrame:{
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth1,
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },
    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginBottom:10,
    },
});


