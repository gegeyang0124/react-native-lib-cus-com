import React, {Component} from 'react';
import {
    ScrollView,
} from 'react-native';
import {
    StyleSheetAdapt,
    Theme,
}from "com";
import {
    DrawerNavigator,
    DrawerItems,
    TabNavigator,
} from '../../../componentThird/component'
import {
    PageTrips,
    PageTripList
} from './pageTrips/PageTrips';
import PageGuides from './pageGuides/PageGuides';
import {
    PageSurveyPSQs,
    PageSurveyPSQList
} from "./pageSurveyPSQs/PageSurveyPSQs";
import {
    PageImportmentCases,
    PageImportmentCaseList
} from "./pageImportmentCases/PageImportmentCases";
import {
    PageAddressAuditList,
    PageAddressAuditDetail,
} from './pageAddressAudit/PageAddressAudit';
import {
    PageProj1111OperateList,
    PageProj1111OperateDetails,
} from './pageProj1111Operate/PageProj1111Operate';
import {
    PageOpenAuditList,
    PageOpenAuditDetail,
} from './pageOpenAudit/PageOpenAudit';

import PageIndex from './pageIndex/PageIndex'
const DrawerRouteConfigs = {
    PageIndex:{
        screen:PageIndex,
        navigationOptions: ({navigation}) => ({
            title : '任务主页',
            drawerLabel : '任务主页',
            swipeEnabled:false,
        }),
    },

    PageTripList: {
        screen: PageTripList,
        navigationOptions: ({navigation}) => ({
            title : '出差管理',
            drawerLabel : '出差管理',
            swipeEnabled:false,
        }),
    },
    PageImportmentCaseList: {
        screen: PageImportmentCaseList,
        navigationOptions: {
            title : '重点专案',
            drawerLabel : '重点专案',
            /*drawerIcon : ({focused, tintColor}) => (
                <Image
                    tintColor={tintColor}
                    focused={focused}
                    style={styles.iconTab}
                    source={require('./../../res/images/fightPlan.png')}
                />
            ),*/
        },

    },
    PageSurveyPSQList: {
        screen: PageSurveyPSQList,
        navigationOptions: {
            title : '调查问卷',
            drawerLabel : '调查问卷',
            /*drawerIcon : ({focused, tintColor}) => (
                <Image
                    tintColor={tintColor}
                    focused={focused}
                    style={styles.iconTab}
                    source={require('./../../res/images/trip.png')}
                />
            ),*/
        },

    },
    PageAddressAudit: {
        screen: PageAddressAuditList,
        navigationOptions: {
            title : '新店审核',
            drawerLabel : '新店审核',
        },

    },
    PageProj1111OperateList: {
        screen: PageProj1111OperateList,
        navigationOptions: {
            title : '1111工程',
            drawerLabel : '1111工程',
        },

    },
    PageOpenAuditList: {
        screen: PageOpenAuditList,
        navigationOptions: {
            title : '开业审核',
            drawerLabel : '开业审核',
        },

    }
};

/**
 * 侧滑菜单返回按钮bug问题，修改底层底层
 * addNavigationHelpers.js
 * **/
const DrawerNavigatorConfigs = {
    // initialRouteName: 'PageTrip',
    // initialRouteName: 'none',
    // initialRoute: 'none',
    // contentComponent: DrawerItems,
    contentComponent:  props => <ScrollView><DrawerItems {...props} /></ScrollView>,
    drawerPosition: 'left',
    lazy: true,
    swipeEnabled:true,
    animationEnabled:true,
    drawerWidth:StyleSheetAdapt.getWidth(170),
    // headerMode:'none',
    // backBehavior: 'none', // 按 back 键是否跳转到第一个Tab(首页)， none 为不跳转
    contentOptions: {
        activeTintColor:Theme.Colors.themeColor,
        style:{
            marginTop:StyleSheetAdapt.getHeight(20),
        },
        labelStyle:{
            fontSize:StyleSheetAdapt.getWidth(Theme.Font.fontSize),
            marginTop:StyleSheetAdapt.getHeight(20),
        }
        // backBehavior:'none',
    }
};

const PageTaskDrawer = DrawerNavigator(DrawerRouteConfigs, DrawerNavigatorConfigs);


const TabRouteConfigs = {
    PageTaskDrawer: {
        // screen: PageTrip,
        screen: PageTaskDrawer,
        navigationOptions: {
            headerLeftDrawer:true,//true执行策划菜单打开或关闭，false或未设置执行默认返回 需要修改底层header的_navigateBack
            swipeEnabled:false,
            // header:null,
            // headerMode:'none',
            // headerLeftDrawer:true,//true执行策划菜单打开或关闭，false或未设置执行默认返回 需要修改底层header的_navigateBack
            /*title : '出差管理',
            tabBarLabel : '出差管理',*/
            // swipeEnabled:false,
            /* tabBarIcon : ({focused, tintColor}) => (
                 <Image
                     tintColor={tintColor}
                     focused={focused}
                     style={[styles.iconTab,{
                         tintColor:tintColor
                     }]}
                     source={require('./../../res/images/trip.png')}
                 />
             ),*/
        },

    },
    PageTrips: {
        screen: PageTrips,
        navigationOptions: ({navigation}) => ({
            // swipeEnabled:false,
            /*title : '巡店任务',
            tabBarLabel : '巡店任务',*/
            // swipeEnabled:false,
        }),
    },
    PageGuides: {
        screen: PageGuides,
        navigationOptions: ({navigation}) => ({
            // swipeEnabled:false,
            /*title : '巡店任务',
            tabBarLabel : '巡店任务',*/
            // swipeEnabled:false,
        }),
    },
    PageSurveyPSQs: {screen: PageSurveyPSQs},
    PageImportmentCases: {screen: PageImportmentCases},
    PageAddressAuditDetail: {screen: PageAddressAuditDetail},
    PageAddressAuditDetails: {screen: PageProj1111OperateDetails},
    PageOpenAuditDetail: {screen: PageOpenAuditDetail},
    PageIndex: {screen: PageIndex},
}

const PageTask = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = PageTask;


