import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird';


import PageAddressAuditList from "./pageAddressAuditList/PageAddressAuditList";
import PageAddressAuditDetailCheckPerson from "./pageAddressAuditDetailCheckPerson/PageAddressAuditDetailCheckPerson";
import PageAddressAuditDetailExePerson from "./pageAddressAuditDetailExePerson/PageAddressAuditDetailExePerson";

const TabRouteConfigs = {
    PageAddressAuditDetailExePerson: {
        screen: PageAddressAuditDetailExePerson,
        navigationOptions: {
            title : '店址详情',
            tabBarLabel : '执行人详情',
        },

    },
    PageAddressAuditDetailCheckPerson: {
        screen: PageAddressAuditDetailCheckPerson,
        navigationOptions: {
            title : '店址详情',
            tabBarLabel : '执行人详情',
        },

    }
}

const page = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = {
    get PageAddressAuditList(){
        return PageAddressAuditList;
    },
    get PageAddressAuditDetail(){
        return page;
    }
};
