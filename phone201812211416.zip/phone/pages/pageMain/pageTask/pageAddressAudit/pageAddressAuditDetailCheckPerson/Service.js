import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
// import {ServiceCommon} from './../../ServiceCommon';

/**
 * 接口
 * **/
export class Service {


    static base;

    static retJson = {
        id:null,//任务ID
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
    };//后台返回数据

    constructor() {
        Service.base = this;
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * **/
    static getDetail(taskId){


        return Http.get(HttpUrls.urlSets.urlTaskShopAdressAuditDetail,{
            taskSelectAddressId:taskId,
        })
            .then(retJson=>{
                // console.log(retJson)
                let retObj = {
                    distance5Num:0,
                    distance10Num:0,
                    replyList:[]
                };



                let selectGps = retJson.retData.selectGps;
                selectGps = selectGps.split(",");
                selectGps = {
                    lat:Math.abs(parseFloat(selectGps[0])),
                    lng:Math.abs(parseFloat(selectGps[1]))
                };
                retJson.retData.selectGps = selectGps;

                retJson.retData.storeGpsList
                    .forEach((v,i,a)=>{
                       /* v = v.split(",");
                        v = {
                            lat:parseFloat(v[0]),
                            lng:parseFloat(v[1])
                        };*/
                       v.lat = parseFloat(v.latitude);
                       v.lng = parseFloat(v.longitude);

                       if(v.lat == selectGps.lat && v.lng == selectGps.lng){
                           v.isSelected = true;
                       }
                       else {
                           v.isSelected = false;
                       }

                        v.distance = Tools.getDistanceByGps(selectGps,v);
                        if(v.distance <= 5){
                            retObj.distance5Num++;
                            // retObj.distance10Num++;
                        }
                        if(v.distance <= 10){
                            // retObj.distance5Num++;
                            retObj.distance10Num++;
                        }
                    });
                retObj.distance5Num = retObj.distance5Num > 0 ? retObj.distance5Num - 1 : retObj.distance5Num;
                retObj.distance10Num = retObj.distance10Num > 0 ? retObj.distance10Num - 1 : retObj.distance10Num;
                retJson.retData.distance5Num = retObj.distance5Num;
                retJson.retData.distance10Num = retObj.distance10Num;

                retJson.retData.replyList.forEach((v,i,a)=>{
                    retObj.replyList.push( {
                        _id: v.id,
                        text: v.msg,
                        // createdAt:v.createTime ? v.createTime : new Date().getTime(),
                        createdAt:v.createTime,
                        user: {
                            _id: v.sendUserId,
                            name: v.userPostName + "-" + v.userName,
                            avatar: v.userPicture,
                        }
                    });
                });

                retJson.retData.replyList = retObj.replyList;

                return  retJson.retData;
            });
    }


    /**
     * 提交数据
     * **/
    static putIn(taskId,msg,status){
        return new Promise(resolve => {
            Http.post(HttpUrls.urlSets.urlTaskShopAdressAuditTaskAudit,{
                id:taskId,//必填 选址审核数据id
                status:status,//必填 任务状态：1.待审核 2.通过 3.不通过
                msg:msg//审核不通过时必填 不通过原因
            })
                .then(retJson=>retJson);
        });
    }

}