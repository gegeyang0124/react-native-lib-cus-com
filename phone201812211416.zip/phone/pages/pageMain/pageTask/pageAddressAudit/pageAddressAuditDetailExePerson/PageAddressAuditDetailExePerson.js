/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTitle,
    MenuBottom,
    Media,
    ImageList,
    MapView,
    Marker,
    Circle,
    TextIcon,
    SearchDDDIpt,
    ButtonChange,
    Http,
} from "com";
import {
    GiftedChat
} from "comThird";

import {Service} from "./Service";

import ImageLogo from "images/icon.png";


type Props = {};
export default class PageAddressAuditDetailExePerson extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.init();

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });

    }

    init(){
        this.btnList = [
            {
                text:'拍摄',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.selectedValue = {
            id:null,//类型：String  必有字段  备注：巡店选址数据id
            gps:null,//类型：String  可有字段  备注：移动后的新地址gps (没修改时传 null)
            address:null,//类型：String  可有字段  备注：移动后的新地址详细地址 (没修改时传 null)
            fileList:[],//类型：Array  可有字段  备注：更改后的 文件列表 (没修改时传空数组)
            msg:null,//类型：String  可有字段  备注：回复
        };

        this.selectedValue2 = {
            record_id:null,//客户id
            consignee:null,// 收货人,
            consignee_tel:null,// 收货人电话,
            consignee_province:null,// 收货人省份,
            consignee_city:null,//  收货人城市,
            shipping_address:null,// 收货地址,
        };

        this.configData = {
            execFirst:true,
            type:null,//拍照选择图片类型值
        };

        this.state = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            distance5Num:0,//5公里范围内的店铺数量
            distance10Num:0,//10公里范围内的店铺数量
            selectGps:Tools.userConfig.position
                ? Tools.userConfig.position
                : {
                    lat:23.157003,
                    lng:113.264531
                },
            replyList:[
                /*{
                    _id: 2,
                    text: 'Hello developer',

                    createdAt: new Date(),
                    user: {
                        _id: 1,
                        name: 'React Native',
                        avatar: Tools.userConfig.userInfo.picture,
                    },
                }*/
            ],//反馈数据
            isPast:true,
            lastUpdateTime:null,
            storeGpsList:[
               /* {
                    isSelected:true,
                    lat:23.157003,
                    lng:113.264531,
                    address:"吉林省长春市二道区吉林大路二道小商品批发城M-111号门市"

                },
                {
                    isSelected:false,
                    lat:23.157003,
                    lng:113.224531,
                    address:"吉林省长春市二道区吉林大路二道小商品批发城M-111号门市"

                }*/
            ],//店铺地址
            fileList:[
                /*{
                    fileId:"1a84fff9-570d-4a4d-a805-26f576c49d1c",
                    fileName:"shang",
                    files:[
                        {
                            icon:"http://lxfile.honey-lovely.com/operative/jpg/20180322_5ab37b5db0c20.jpg",
                            id:"1a84fff9-570d-4a4d-a805-26f576c49d1c",
                        }
                    ]
                }*/
            ], //附件列

            provinceList:[],//省份
            cityList:[],//城市
            clearDropOne:true,
            clearDropTwo:true,
            status:"",
            taskName:null,
        };
    }

    componentWillEnter(param){

         if(param){
             this.selectedValue.id = param.id;
             this.state.id = param.id;

             this.getData();
             console.log(this.state.status)
         }
    }

    onGetPic = (item,i)=>{

        if(this.state.fileList[this.configData.type].length > 5){
            Tools.toast("照片数量已达到上线");
        }else{
            if(i == 0){
                Media.takeImage(this.state.taskName,true,()=>{
                    MenuBottom.show(false);
                }).then(retJson=>{

                        let stepFileList = [];
                        this.state.fileList.forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        stepFileList[this.configData.type].files.push({
                            id:this.state.fileList[this.configData.type].fileId,
                            icon:retJson.path
                        });

                        this.setState({
                            fileList:stepFileList
                        });
                    });
            }else if(i == 1){
                MenuBottom.show(false);
                Media.pickImage(false,this.state.taskName).then(retJson=>{

                    let stepFileList = [];
                    this.state.fileList.forEach((v,i,a)=>{
                        stepFileList.push(v);
                    });
                    stepFileList[this.configData.type].files.push({
                        id:this.state.fileList[this.configData.type].fileId,
                        icon:retJson.path
                    });

                    this.setState({
                        fileList:stepFileList
                    });
                });

            }
        }


    }

    showMenu(type){
        this.configData.type = type;

        MenuBottom.show(true);

    }

    onDelImage(index,item,i){
        this.state.fileList[index].files.splice(i, 1);
        let stepFileList = [];
        this.state.fileList.forEach((v,i,a)=>{
            stepFileList.push(v);
        });
        this.setState({
            fileList:stepFileList
        });
    }

    getData(){
        Service.getDetail(this.state.id)
            .then(retJson=>{
                this.selectedValue2.record_id = retJson.recordId;
                this.selectedValue2.consignee_province = retJson.selectProvince;
                this.selectedValue2.consignee_city = retJson.selectCity;
                this.selectedValue2.shipping_address = retJson.selectAddress;
                retJson.clearDropOne = true;
                retJson.clearDropTwo = true;
                retJson.cityList = [];
                // this.setState({status:retJson.taskStatus})
                // console.log(retJson)
                this.setState(retJson);
            });

    }

    componentDidMount() {
        // this.getData();
        this.getProvince();
    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = (text,index)=>{
        if(index == 0){
            this.setState({isPast:false});
            this.win.scrollToEnd();
        }
        else {
            this.selectedValue.fileList = [];
            this.state.fileList.forEach((v,i,a)=>{
                v.files.forEach((v1,i1,a1)=>{
                    if(v1.icon.indexOf("http") != 0){
                        this.selectedValue.fileList.push({
                            localPath:v1.icon,
                            id:v1.id
                        })
                    }
                });
            });

            Service.putIn(this.selectedValue,true)
                .then(retJson=>{

                    Tools.toast("成功！");
                    BaseComponent.backRefresh = true;
                    this.goBack();
                });
        }
    };

    renderItem = (item,i)=>{

        return(
            <View key={i}
                  style={[styles.bodyFrame,styles.bodyFrame2]}>
                <ItemRowTitle text1={item.fileName}
                              text2={"上传附件"}
                              onPressRight={()=>this.showMenu(i)}/>

                <ImageList dataList={item.files}
                           isShowText={false}
                           text={"删除"}
                           onPressDel={(item2,index)=>this.onDelImage(i,item2,index)}
                           textStyle={styles.imageTextStyle}
                           iconStyle={styles.imageStyle}/>

            </View>
        );
    }

    onSend = ()=>{

        Service.putIn({
            id:this.selectedValue.id,//类型：String  必有字段  备注：巡店选址数据id
            gps:null,//类型：String  可有字段  备注：移动后的新地址gps (没修改时传 null)
            address:null,//类型：String  可有字段  备注：移动后的新地址详细地址 (没修改时传 null)
            fileList:[],//类型：Array  可有字段  备注：更改后的 文件列表 (没修改时传空数组)
            msg:this.selectedValue.msg,//类型：String  可有字段  备注：回复
        })
            .then(retJson=>{
                this.setState(previousState => ({
                    replyList: GiftedChat.append(previousState.replyList, [
                        {
                            _id:Tools.userConfig.userInfo.id + "_put",
                            text: this.selectedValue.msg,

                            createdAt: new Date(),
                            user: {
                                _id: Tools.userConfig.userInfo.id,
                                name: Tools.userConfig.userInfo.position_name
                                + "-"
                                + Tools.userConfig.userInfo.full_name,
                                avatar: Tools.userConfig.userInfo.picture,
                            }
                        }
                    ]),
                }))

            });
    }

    onInputTextChanged(text){
        this.selectedValue.msg = text;
    }

    onPressMark(type){
        if(type == 1){
            Service.putInRecipient(this.selectedValue2)
                .then(retJson=>{
                    Tools.toast("提交成功");
                });
        }
    }

    onSelectPd = (i,item,type)=>{

        if(type == 0){
            this.selectedValue2.consignee_province = item.id;
            this.setState({
                cityList:[],
                clearDropOne:false,
            });
            Service.getCities(this.selectedValue.consignee_province)
                .then(retJson=>{
                    // this.configData.cityClearDrop = true;
                    // alert(JSON.stringify(retJson))
                    this.selectedValue2.consignee_city = retJson[0].id;
                    this.setState({
                        cityList:retJson,
                        clearDropTwo:true
                    });
                });
        }
        else
        {
            this.selectedValue2.consignee_city = item.id;

            if(this.state.clearDropTwo)
            {
                // this.configData.cityClearDrop = false;
                this.setState({
                    clearDropTwo:false
                });
            }

        }
    }

    onChangeTextAddres = (text)=>{
        this.selectedValue2.shipping_address = text;
    }

    getGpsAddress(pos){
        this.selectedValue.gps = pos.latitude + "," + pos.longitude;
        Http.getAddress(pos.latitude,pos.longitude).then(retJson=>{
            this.selectedValue.address = retJson.address;
            // console.info("this.selectedValue",this.selectedValue);
        });
    }

    renderItemMark = (item,i)=>{
        const {provinceList,cityList,clearDropOne,clearDropTwo} = this.state;

        return(
            <Marker key={i}
                    draggable={item.isSelected}
                    title={item.address}
                    flat={true}
                    color={item.isSelected ? "green" : 'red'}
                    onDragEnd={({ nativeEvent }) =>{
                        // console.log(`${nativeEvent.latitude}, ${nativeEvent.longitude}`)
                        this.getGpsAddress(nativeEvent);
                    }}
                    onInfoWindowPress={(e)=>{
                        // alert(JSON.stringify(e));
                    }}
                    coordinate={{
                        latitude: item.lat,
                        longitude: item.lng
                    }}>
                {
                    item.isSelected
                    &&<View style={styles.mapCusFrame}>
                        <SearchDDDIpt isSearch={false}
                                      options1={
                                          {
                                              style:styles.dropdownStyle,
                                              defaultValue:this.selectedValue2.consignee_province,
                                              options:provinceList,
                                              clearDrop:clearDropOne,
                                              onSelect:(i,item)=>this.onSelectPd(i,item,0)
                                          }
                                      }
                                      options2={
                                          {
                                              style:styles.dropdownStyle,
                                              defaultValue:this.selectedValue2.consignee_city,
                                              options:cityList,
                                              clearDrop:clearDropTwo,
                                              onSelect:(i,item)=>this.onSelectPd(i,item,1)
                                          }
                                      }
                                      isTextInput={false}
                                      isPickDropdown4={false}
                                      isPickDropdown3={false}/>

                        <View style={styles.markTextFrame}>
                            <TextInput defaultValue={this.selectedValue2.shipping_address}
                                       onChangeText={this.onChangeTextAddres}
                                       style={styles.markText}/>
                        </View>

                        <View style={styles.markFrameBtn}>
                            <ButtonChange text={"确定"}
                                          onPress={()=>this.onPressMark(1)}/>
                        </View>
                    </View>
                }


            </Marker>
        );
    }

    getProvince(){
        Service.getProvinces()
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    render() {
        // console.log(this.state.selectGps)
        const {distance5Num,distance10Num,selectGps,isPast,replyList,
            lastUpdateTime,storeGpsList,fileList} = this.state;

        return (
            <ViewTitle viewBottom={isPast ? ["反馈","提交"] : null}
                       ref={com=>this.win = com}
                       onPressBottom={this.onPressBottom}>

                {/*<View style={styles.topFrame}>
                    <Text style={styles.topTextTime}>
                        更新时间:{lastUpdateTime}
                    </Text>
                </View>*/}

                <View style={styles.map}>
                    <MapView style={styles.map}
                             showsTraffic={false}
                             coordinate={{
                                 latitude:selectGps.lat,
                                 longitude: selectGps.lng
                             }}
                             showsScale={false}
                             locationEnabled={true}
                             mapType={"standard"}>

                        {
                            storeGpsList.map(this.renderItemMark)
                        }

                        <Circle  coordinate={
                            {
                                latitude:selectGps.lat,
                                longitude: selectGps.lng
                            }
                        }
                                 fillColor={Theme.Colors.backgroundColorYellow2}
                                 radius={10000}/>

                        <Circle  coordinate={
                            {
                                latitude:selectGps.lat,
                                longitude: selectGps.lng
                            }
                        }
                                 fillColor={Theme.Colors.themeColor2}
                                 radius={5000}/>

                        <TextIcon icon={ImageLogo}
                                  iconStyle={styles.mapLogo}
                                  frameStyle={styles.mapLogoFrame}
                                  textStyle={styles.mapText}
                                  text={
                                      "注：5公里内已有" + distance5Num
                                      + "家店铺，10公里内已有"
                                      + distance10Num
                                      + "家店铺"
                                  }/>
                    </MapView>
                </View>

                {
                    fileList.map(this.renderItem)
                }

                <View style={styles.msgFrame}>

                    <ItemRowTitle text1={"审核反馈"}/>

                    <GiftedChat messages={replyList}
                                user={{
                                    _id: Tools.userConfig.userInfo.id,
                                    name: Tools.userConfig.userInfo.position_name
                                    + "-"
                                    + Tools.userConfig.userInfo.full_name,
                                    avatar: Tools.userConfig.userInfo.picture,
                                }}

                                onInputTextChanged={(text)=>{this.onInputTextChanged(text)}}
                                onSend={this.onSend}
                                leftContentStyle={styles.chatText}
                                showUserAvatar={true}
                                imageStyle={
                                    {
                                        left:styles.imageUser,
                                        right:styles.imageUser
                                    }
                                }
                                onCancel={()=> this.setState({isPast:true})}
                                isShowInput={!isPast}
                                placeholder={"请输入原因"}/>

                </View>


                <MenuBottom btnList={this.btnList}
                            isVisibleClose={false} />


            </ViewTitle>
        );

    }

}

const styles = StyleSheetAdapt.create({
    dropdownStyle:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    markTextFrame:{
        backgroundColor:Theme.Colors.themeColor3,
        margin:10,
        padding:5,
    },
    markText:{
        fontSize:Theme.Font.fontSize_1,
        // margin:10,
    },
    markFrameBtn:{
        flexDirection:'row',
        justifyContent:'center',
        alignItems:'center',
    },

    mapCusFrame:{
        backgroundColor:Theme.Colors.themeColor2,
        padding:5,
    },

    topFrame:{
        padding:5,
        backgroundColor:Theme.Colors.themeColor2,
        position:"absolute",
        zIndex:111,
    },
    topTextTime:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.foregroundColor,
    },

    imageUser:{
        width:60,
        height:"60dw",
        borderRadius:30,
    },

    chatText:{
        backgroundColor:Theme.Colors.barGreen,
    },

    msgFrame:{
        marginTop:10,
        height:400,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    mapText:{
        marginBottom:10,
        marginLeft:10,
    },
    mapLogo:{
        width:70,
        height:"70dw",
    },
    mapLogoFrame:{
        // marginTop:230,
        alignItems:'flex-end',
        // height:70,
        // justifyContent:'center',
    },
    map: {
        // width: 'w',
        // height: 300,
        height: 400,
        justifyContent:'flex-end',
    },



    frameStyle:{
        marginTop:10,
    },

    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },

    bodyIamge:{
        width:'w',
        height:200,
        // backgroundColor:'blue'
    },

    toastFrame:{
        marginLeft:-55,
        alignItems:'center',
        justifyContent:'center',
    },
    toastFrame_1:{
        alignItems:'center',
        justifyContent:'center',
        // backgroundColor:'white',
        width:'0.35w',
        height:180,
        marginLeft:-40,
    },
    toastText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.foregroundColor,
        fontWeight:'900',
    },

    mainFrame:{

        borderTopWidth:Theme.Border.borderWidth,
        borderTopColor:Theme.Colors.minorColor,
    },

    titleTextFrame:{
        marginLeft:20,
    },
    titleText1:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    titleText2:{
        fontSize:Theme.Font.fontSize2,
        color:Theme.Colors.themeColor,
    },


});
