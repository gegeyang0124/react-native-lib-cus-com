import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:Tools.userConfig.userInfo.department_level == 2
                ? Tools.userConfig.userInfo.department_id
                : '',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 3
                ? Tools.userConfig.userInfo.department_id
                : '',//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取出差数据列表
     * @param selectValue object,//搜索参数
     * selectValue = {
        type1:'',//下拉选中值 一级部门
        type2:'',//下拉选中值 二级部门
        type3:'',//下拉选中值 年月
        name:'',//人名称输入值
    }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static getAuditList(selectValue,init){

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(selectValue != undefined)
        {
            selectValue.type2 = selectValue.type2 != '' ? selectValue.type2 : this.base.paramsFetch.selectValue.type2;
            this.base.paramsFetch.selectValue = selectValue;
        }

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retJson.retListData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        return Http.post(HttpUrls.urlSets.urlTaskShopAdressAudit, {
            pageNumber:this.base.paramsFetch.pageNumber,//类型：Number  可有字段  备注：分页参数
            pageSize:20,//类型：Number  必有字段  备注：分页参数
            filter:{ //类型：Object  必有字段  备注：过滤参数
                task_status: this.base.paramsFetch.selectValue.type4,//类型：String  必有字段  备注：审核状态：1.待审核 2.通过 3.不通过
                companyId: this.base.paramsFetch.selectValue.type1,//类型：String  必有字段  备注：一级部门id 大区id
                regionId: this.base.paramsFetch.selectValue.type2,//类型：String  必有字段  备注：二级部门id 省区id
                executorName: this.base.paramsFetch.selectValue.name, //类型：String  必有字段  备注：申请人姓名右模糊
                createMonth:Tools.timeFormatConvert(this.base.paramsFetch.selectValue.type3.endTime,"YYYY-MM") //类型：String  必有字段  备注：月份 yyyy-MM},//查询条件
            }
        },init)
            .then((retJson) => {

                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                retJson.retListData.forEach((v,i,a)=>{
                    /*v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY-MM-DD HH:mm");
                    v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY-MM-DD HH:mm");*/
                    // v.isProTask = Tools.userConfig.userInfo.id ==  v.executor_id ? true : false;

                    this.base.retJson.retListData.push(v);
                });

                return  this.base.retJson;
            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });
    }

    /**
     * 获取一级部门选择列表
     * **/
    static getDepartmentsOne(){

        /** department_level:1、运营中心；2、分公司；3、区域
         **/
        return new Promise((resolve, reject)=>{
            Http.post(HttpUrls.urlSets.urlGetDepartmentListByType2,{
                userId:Tools.userConfig.userInfo.id
            })
                .then((retJson)=>{

                    var obj = {
                        branchOfficeLst:[{
                            name:'一级部门',
                            id:''
                        }],
                        branchOffice:'',
                        area:'',
                        nameOne:'一级部门',
                        nameTwo:'二级部门',
                        areaLst:[{
                            name:'二级部门',
                            id:''
                        }],
                    };

                    if(retJson.retListData.length > 0)
                    {

                        var lst = [{
                            name:'一级部门',
                            id:''
                        }];

                        retJson.retListData = lst.concat(retJson.retListData);
                        obj.branchOfficeLst = retJson.retListData;
                        if(Tools.userConfig.userInfo.department_level == 1)
                        {
                            // retJson.retListData = lst.concat(retJson.retListData);
                            resolve(obj);
                        }
                        else
                        {
                            obj.branchOffice = retJson.retListData[1].id;
                            obj.nameOne = retJson.retListData[1].name;
                        }

                        // modelTrip.set(obj);

                        // if(retJson.retListData.length == 1)
                        if(Tools.userConfig.userInfo.department_level != 1)
                        {
                            this.getDepartmentsTwo(obj.branchOffice)
                                .then((retJson2)=>{
                                    var obj2 = {
                                        areaLst:[{
                                            name:'二级部门',
                                            id:''
                                        }],
                                        area:'',
                                        name:'二级部门'
                                    };

                                    // obj2.areaLst = obj2.areaLst.concat(retJson2.retListData);
                                    obj2.areaLst = retJson2;
                                    obj.areaLst = obj2.areaLst;
                                    obj.area = obj2.area;
                                    if(Tools.userConfig.userInfo.department_level == 2)
                                    {

                                        // retJson.retListData = obj2.areaLst.concat(retJson.retListData);
                                    }
                                    // obj2.areaLst = retJson.retListData;

                                    if(Tools.userConfig.userInfo.department_level == 3)
                                    {
                                        obj.area = retJson2 != undefined
                                        && retJson2 != 'null'
                                        && retJson2 != null
                                            ? retJson2[1].id : '' ;

                                        obj.nameTwo = retJson2[1].name;

                                    }
                                    resolve(obj);
                                    // modelTrip.set(obj2);
                                })
                                .catch((status)=>{
                                    reject(status);
                                });


                        }


                    }
                    else
                    {
                        resolve(obj);
                    }

                })
                .catch((status)=>{
                    reject(status);
                });
        });

    }

    /**
     * 获取二级部门选择列表
     * @param parent_id string,//一级部门ID
     * **/
    static getDepartmentsTwo(parent_id){

        return Http.post(HttpUrls.urlSets.urlGetDepartmentListByParentId,{
            parent_id:parent_id,
            userId:Tools.userConfig.userInfo.id
        },false)
            .then((retJson)=>{
                // alert(HttpUrls.urlSets.urlGetDepartmentListByParentId)
                // setTimeout(()=>{Tools.progress.show(false)},500);
                var lst = [
                    {
                        name:'二级部门',
                        id:''
                    }
                ];
                retJson.retListData = lst.concat(retJson.retListData);
                // modelTrip.set("areaLst",retJson.retListData);

                return retJson.retListData;
            });

        // modelTrip.set("area",'');

    }

}
