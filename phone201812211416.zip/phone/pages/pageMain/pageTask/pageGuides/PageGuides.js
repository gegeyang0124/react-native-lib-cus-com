/**
 * Created by Administrator on 2018/4/30.
 */

import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird'
import PageGuideApply from "./pageGuideApply/PageGuideApply";
import PageGuideDetail from "./pageGuideDetail/PageGuideDetail";
import PageOldShopGuide from "./pageOldShopGuide/PageOldShopGuide";
import PageNewShopOpen from "./pageNewShopOpen/PageNewShopOpen";
import PageNewShopAddress from "./pageNewShopAddress/PageNewShopAddress";
import PageGuideList from "./pageGuideList/PageGuideList";

const TabRouteConfigs = {
    PageGuideList: {
        screen: PageGuideList,
        navigationOptions: {
            title : '巡店任务',
            tabBarLabel : '巡店任务',
            swipeEnabled:false,
        },
    },
    PageGuideApply: {
        screen: PageGuideApply,
        navigationOptions: {
            title : '新增任务',
            tabBarLabel : '新增任务',
        },

    },
    PageGuideDetail: {
        screen: PageGuideDetail,
        navigationOptions: {
            title : '巡店详情',
            tabBarLabel : '巡店详情',
        },

    },
    PageOldShopGuide: {
        screen: PageOldShopGuide,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '老店下店',
        },

    },
    PageNewShopOpen: {
        screen: PageNewShopOpen,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '新店开业',
        },

    },
    PageNewShopAddress: {
        screen: PageNewShopAddress,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '新店选址',
        },

    },
}

const PageGuides = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = PageGuides;
