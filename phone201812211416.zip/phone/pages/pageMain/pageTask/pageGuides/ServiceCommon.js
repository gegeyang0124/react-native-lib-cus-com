import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class ServiceCommon {

    static retJson = {
        id:null,//任务ID
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
        taskName:null,
    };//后台返回数据

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * **/
    static getCurStepDetail(taskId){

        return Http.post(HttpUrls.urlSets.urlTaskPatrol, {
            taskId:taskId
        })
            .then(retJson=>{

                let steps = [];
                let currentIndex = 0;
                retJson.retData.steps.forEach((v,i,a)=>{
                    if(v == retJson.retData.name){
                        currentIndex = i
                    }
                    steps.push({
                        text:v.length > 2
                            ? v.substring(0,2) + "\n" + v.substring(2,v.length)
                            : v,
                        status:0
                    });
                });
                steps.forEach((v,i,a)=>{

                    v.status = currentIndex > i
                        ? -1
                        : currentIndex < i
                            ? 0
                            : 1;
                });

                this.retJson = {
                    id:taskId,//任务ID
                    steps:steps,//提示步骤名
                    pageCode:retJson.retData.front_code,//要进入页面的编码
                    currentTaskId:retJson.retData.id,//当前步骤ID，
                    event_list:retJson.retData.event_list,//操作事件数据数组
                    taskName:retJson.retData.taskName,//任务名称
                };

                return this.retJson;
            });
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * @param currentTaskId string,//当前步骤ID
     * **/
    static goNextStep(taskId,currentTaskId){

        currentTaskId = currentTaskId == undefined ? this.retJson.currentTaskId : currentTaskId;
        taskId = taskId == undefined ? this.retJson.id : taskId;

        return Http.post(HttpUrls.urlSets.urlStep, {
            currentTaskId:currentTaskId,//当前步骤ID
            taskId:taskId
        })
            .then((retJson)=>{
                if(retJson.retData.result && retJson.retData.result == 'completed'){
                    return {
                        pageCode:'888',
                    };
                }else{
                    return {
                        id:taskId,
                        pageCode:retJson.retData.front_code,
                        currentTaskId:retJson.retData.id,
                        event_list:retJson.retData.event_list,
                    };
                }
            });
    }

}