/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    ImageBackground,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    FlatListView,
    ItemRowTripApply,
    ItemRowGuideApplyType,
    SearchDDDIpt,
    DatePicker,
    ItemRowFeedback,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageGuideApply extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            btn:null,
            isRenderItemFirst:true,
        };

        this.selectValueParam = {
            type1:'',//省份
            type2:'',//城市
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        };

        this.selectValue = {
            template_id:null,//任务类型id
            number:null,//加载时获取的任务编号
            name:'',//任务名称
            department_id:Tools.userConfig.userInfo.department_id,//部门id
            executor:Tools.userConfig.userInfo.id,//申请人id
            auditor:null,//审核人id
            priority:'1',//优先级值
            begin_time:Tools.timeFormatConvert(this.configData.currentTime,"YYYY-MM-DD HH:mm:ss"),//开始时间
            end_time:Tools.timeFormatConvert(this.configData.currentTime + Tools.ONE_DAY_TIME - 1000 ,"YYYY-MM-DD HH:mm:ss"),//结束时间
            prop_array:[
                {
                    key:'task_relation',//键值
                    value:''//值，逗号分割的巡店任务id字符串
                }
            ],//额外数据

            object_id:null,//客户ID
            selectStepIds:null,//自定义类型 数组
            typeName:'',
        };

        this.state = {
            defaultTaskName:'',
            dataList:[],//任务列表
            provinceList:[],//省份数据列表
            cityList:[],//任务类型列表
            taskTypeList:[],//城市数据列表
            custemrName:'正在加载',//选中客户名
            isShowCustom:false,//是否显示自定义列表
            defaultValueType:'正在加载',//任务类型默认值
            beginTime:Tools.timeFormatConvert(this.selectValue.begin_time,"YYYY-MM-DD HH:mm"),
            endTime:Tools.timeFormatConvert(this.selectValue.end_time,"YYYY-MM-DD HH:mm"),
            taskTypeCustome:[],//自定义类型选择列表
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }


    setTime = (date)=>{
        let time1 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm:ss");
        let time2 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm");
        /* this.date = "date:" + date + "\ntime1: " + time1
             + "\n e:" + this.selectValue.end_time + "\n et:" + Tools.timeFormatConvert(this.selectValue.end_time);
         this.setState({
             beginTime:this.selectValue.begin_time
         });*/
        if(this.configData.isStartTime)
        {
            if(date < Tools.timeFormatConvert(this.selectValue.end_time))
            {
                this.selectValue.begin_time = time1;
                this.setState({
                    beginTime:time2
                });
            }
            else
            {
                Tools.toast("开始时间必须小于结束时间");
            }
        }
        else
        {
            if(date > Tools.timeFormatConvert(this.selectValue.begin_time))
            {
                this.selectValue.end_time = time1;
                this.setState({
                    endTime:time2
                });
            }
            else
            {
                Tools.toast("结束时间必须大于开始时间");
            }

        }
    }

    onSelectDrop(val,i,type){
        let customerName = this.state.custemrName;
        if(customerName != '正在加载' && customerName != "" && type == 1){
            this.setState({
                defaultTaskName:val.name+"-"+customerName,
                defaultValueType:val.name,
            });
        }

        switch (type){
            case 1:{
                this.selectValueParam.type1=i.code;
                Service.getCities(this.selectValueParam.type1).then((retJson)=>{
                    this.setState({
                        cityList:retJson
                    });
                });

                this.selectValue.template_id =  val.id;
                if(this.selectValue.template_id == Tools.userConfig.taskTypeIdGuideCustome)
                {
                    if(!this.state.isShowCustom){
                        this.setState({
                            isShowCustom:true,
                        });
                    }

                }else{
                    this.selectValue.selectStepIds = null;
                    if(this.state.isShowCustom)this.selectValueParam.type1=i.code
                    {
                        this.setState({
                            isShowCustom:false
                        });
                    }
                }

                break;
            }
            case 2: {
                this.selectValueParam.type2=i.code
                break;
            }
            case 3 :{
                this.selectValueParam.type1=i.code;
                Service.getCities(this.selectValueParam.type1).then((retJson)=>{
                    this.setState({
                        cityList:retJson
                    });
                });
                break;
            }
            case 4: {
                this.selectValue.auditor = val.id;

                break;
            }
            case 5: {
                this.configData.isStartTime = val;
                this.datePicker.show();
                break;
            }
            case 6: {
                break;
            }
        }
    }

    onSearch = ()=>{
        // alert("search");
        this.selectValueParam.execFirst = true;
        this.selectValue.object_id = null;
        this.configData.btn = null;
        this.configData.isRenderItemFirst = true;
        // Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[],
            custemrName:'正在加载'
        });
        this.getData();
    };

    onItemPressCustomer(btn,item,i){

        this.configData.isRenderItemFirst = false;

        this.configData.btn && this.configData.btn.setNativeProps({
            style: {
                backgroundColor:Theme.Colors.transparent
            }
        });

        btn.setNativeProps({
            style: {
                backgroundColor:Theme.Colors.themeColor
            }
        });

        this.configData.btn = btn;

        this.selectValue.object_id = item.storecode;
        let typeName = this.state.defaultValueType;
        this.setState({
            custemrName:item.name,
            defaultTaskName:typeName + "-" + item.name,
        });

    }

    getData() {


        Service.getCustomerList(this.selectValueParam,this.selectValueParam.execFirst)
            .then(retJson =>{

                if(!this.selectValueParam.execFirst && !retJson.has)
                {
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                }
                else
                {
                    let object_id = this.selectValue.object_id;
                    let custemrName = this.state.custemrName;

                    if(this.selectValueParam.execFirst)
                    {
                        if(retJson.has)
                        {
                            // retJson.retListData[0].frameStyle = styles.flatListView_ItemFirst;
                            object_id = retJson.retListData[0].storecode;
                            custemrName = retJson.retListData[0].name;
                        }
                        else
                        {
                            object_id = null;
                            custemrName = "没有数据";
                        }
                    }

                    this.selectValueParam.execFirst = false;
                    this.selectValue.object_id = object_id;
                    let type = this.state.defaultValueType;
                    this.setState({
                        total:retJson.total,
                        dataList:retJson.retListData,
                        custemrName:custemrName,
                        defaultTaskName:type != '正在加载' ? type + "-" + custemrName : '',
                    });

                    // Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                }

            })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });
    }

    getSelectData(){
        Service.getProvinces().then((retJson)=>{
            this.setState({
                provinceList:retJson
            });
        });


        Service.getTaskTypes().then((retJson)=>{
            if(retJson.length > 0)
            {
                this.selectValue.template_id = retJson[0].id;
            }

            let custemrName = this.state.custemrName;

            this.setState({
                taskTypeList:retJson,
                defaultValueType:retJson.length > 0 ? retJson[0].name : "没有数据",
                defaultTaskName:retJson.length > 0 ? retJson[0].name+ "-" + custemrName : "",
            });
        });

        Service.getGuideTaskTypeCustome().then((retJson)=>{
            this.setState({
                taskTypeCustome:retJson
            });
        });

    }

    getDepartments(){
        Service.getDepartmentsOne()
            .then((retJson)=>{
                // retJson.forEach()

                this.selectValue.type1 = retJson.branchOffice;
                this.selectValue.type2 = retJson.area;
                this.setState({
                    departmentOneList:retJson.branchOfficeLst,
                    departmentOneDefault:retJson.nameOne,
                    departmentTwoList:retJson.areaLst,
                    departmentTwoDefault:retJson.nameTwo,
                    departmentOneDisable:this.selectValue.type1 == '' ? false : true,
                    departmentTwoDisable:this.selectValue.type2 == '' ? false : true
                });
            });
    }

    renderItemViewCustomer(item,i){

        return(
            <ItemRowFeedback id={i}
                             frameStyle={this.configData.isRenderItemFirst ?
                                 i == 0 ?
                                     styles.flatListView_ItemFirst :
                                     {} :
                                 {}}

                             isShowIcon={false}
                             onPress={(btn)=>{
                                 this.onItemPressCustomer(btn,item,i);
                             }}
                             text1_1={"客户姓名:" + item.name}
                             text1_2={
                                 {
                                     text_1:item.customer_status,
                                     text_2:item.contract_status,
                                     text_3:item.store_zf,

                                     text_4:item.diagnosticScore == null ? undefined : item.diagnosticScore,
                                     text_5:item.bgStore ? "标杆" : null,
                                     text_6:item.demoStore ? "样板" : null}
                             }
                             text2_1={"签约时间:" + item.sign_time}
                             text3_1={"店铺地址:" + item.store_address}/>
        );
    }

    onShowMonPicker = ()=>{
        // PickerCustome.pickMonth();
        Tools.pickMonth(retJson =>{
            let val = (new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime();

            this.selectValue.type3.startTime = Tools.timeFormatConvert(val,"YYYY-MM-DD HH:mm:ss");

            let beginDate = new Date(val);
            if(beginDate.getMonth() == 11)
            {
                val = (new Date(beginDate.getFullYear() + 1,0,1,0,0,0)).getTime();
            }
            else
            {
                val = (new Date(beginDate.getFullYear(), beginDate.getMonth() + 1,1,0,0,0)).getTime();
            }

            this.selectValue.type3.endTime = Tools.timeFormatConvert(val - 1000,"YYYY-MM-DD HH:mm:ss");


            this.setState({
                pickedDate:retJson[0] + "-" + (retJson[1] > 10 ? retJson[1] : '0' + retJson[1])
            });
        });
    }

    onChangeText = (text)=>{
        // console.log(text)
        this.selectValue.name = text;
    }

    textChange=(text)=>{
        this.selectValueParam.name=text
    }

    onSelectedType = (isChecked,item)=>{

        if(isChecked)
        {
            if(this.selectValue.selectStepIds == null)
            {
                this.selectValue.selectStepIds = [];
            }

            this.selectValue.selectStepIds.push(item.id);
        }
        else
        {
            this.selectValue.selectStepIds.remove(item.id);
            // this.selectValue.selectStepIds.push(item.id);
        }
        // alert(JSON.stringify(this.selectValue.selectStepIds))
    }

    onPressBottom = ()=>{
        // console.info("seleced",this.selectValue);
        /* this.goBack(null,{paramData:[{
                 beginTime:"sdfd",
                 customerName:"sdafdsaf",
                 description:'注意此参数是一个比值而非像素单位。比如，0.5表示距离内容最底部的距离为当前列表可见长度的一半时触发',
                 endTime:'fsadfsad',
                 taskId:'fdsaf',
                 taskName:'fsdaf',
                 taskType:"dsaffsa"
             }]});
         return;*/

        this.selectValue.name = this.state.defaultTaskName;
        if(this.selectValue.name == '') {
            Tools.toast("请填写任务名称");
            return;
        }

        if(this.selectValue.template_id == null) {
            Tools.toast("请选择任务类型");
            return;
        }

        if(this.selectValue.object_id == null) {
            Tools.toast("请选择客户");
            return;
        }

        if(this.selectValue.template_id == Tools.userConfig.taskTypeIdGuideCustome)
        {
            if(this.selectValue.selectStepIds == null) {
                Tools.toast("请选择自定义类型");
                return;
            }

            Service.addTaskGuideCustome(this.selectValue).then((retJson)=>{
                BaseComponent.backRefresh = true;
                // this.goBack(null,{paramData:JSON.parse(JSON.stringify(retJson))});

                this.goBack(null,{paramData:retJson});
            });
        }
        else
        {
            // console.info("seleced",this.selectValue);
            Service.addTaskGuide(this.selectValue).then((retJson)=>{
                BaseComponent.backRefresh = true;
                // this.goBack();
                retJson.id=retJson[0].taskId
                this.goBack(null,{paramData:retJson});
                // this.goBack(null,{paramData:JSON.parse(JSON.stringify(retJson))});
            });
        }
    };

    componentWillMount(){

    }

    componentDidMount() {
        this.getData();
        this.getSelectData();

        setTimeout(()=>{

            let type = this.state.defaultValueType;
            let name = this.state.custemrName;

            this.setState({
                defaultTaskName:type + "-" + name,
            });
        },1000);
    }

    render() {
        const {dataList,beginTime,endTime,custemrName,provinceList,cityList,
            taskTypeList,isShowCustom,defaultValueType,taskTypeCustome} = this.state;

        return (
            <ViewTitle viewBottom={"提交"}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"任务名称:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"input"}
                                      viewCenterProps={{
                                          placeholder:'请输入任务名称',
                                          onChangeText:this.onChangeText,
                                          defaultValue:this.state.defaultTaskName,
                                      }}/>

                    <ItemRowTripApply text={"任务类型:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenterProps={{
                                          defaultValue:defaultValueType,
                                          options:taskTypeList,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                      }}/>

                    {
                        isShowCustom ?
                            <View style={[styles.typeFrame,styles.titleFrameTop]}>
                                <View style={[styles.typeFrame_1]}>
                                    <View style={styles.typeFrame_1_1}>

                                    </View>
                                    <View style={styles.typeFrame_1_2}>
                                        <View style={styles.typeItemRowFrame}>
                                            <ItemRowGuideApplyType text1={"选择"}
                                                                   text2={"节点"}
                                                                   textStyle={styles.typeItemRowFrame_Text}/>
                                            {
                                                taskTypeCustome.map((item,index)=>{
                                                    return( <ItemRowGuideApplyType key={"" + index}
                                                                                   text2={item.name}
                                                                                   onPress={(isChecked)=>this.onSelectedType(isChecked,item)}/>);
                                                })
                                            }

                                        </View>

                                    </View>
                                    <View style={styles.typeFrame_1_3}>

                                    </View>
                                </View>
                            </View> :
                            null
                    }

                    <ItemRowTripApply text={"客户名称:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenterProps={{
                                          defaultValue:custemrName,
                                          disabled:true,
                                          imgDirection:"down",
                                          clearDrop:true,
                                          options: [],
                                      }}/>


                    <View style={[styles.typeFrame,styles.titleFrameTop]}>
                        <View style={[styles.typeFrame_1]}>
                            <View style={styles.typeFrame_1_1}>

                            </View>

                            <View style={styles.typeFrame_1_2}>
                                <View style={[styles.typeItemRowFrame,styles.customerItemFrame]}>

                                    <SearchDDDIpt options1={{
                                        defaultValue:"省份",
                                        options:provinceList,
                                        // clearDrop:this.dropList.types1.clearDrop,
                                        onSelect:(i,val)=>this.onSelectDrop(i,val,3)
                                    }}
                                                  frameStyle={styles.customerItemFrame_1}
                                                  placeholder={"--姓名--"}
                                                  options2={{
                                                      defaultValue:'城市',
                                                      options:cityList,
                                                      // clearDrop:this.state.clearDrop,
                                                      onSelect:(i,val)=>this.onSelectDrop(i,val,2)
                                                  }}
                                                  isPickDropdown3={false}
                                                  textChange={this.textChange}
                                                  onPressSearch={this.onSearch}/>


                                    <FlatListView
                                        style={styles.flatListView}
                                        data={dataList}
                                        keyExtractor = {(item, index) => ("key" + index)}
                                        renderItem={({item,index}) => this.renderItemViewCustomer(item,index)}
                                        onEndReached={() =>this.getData()}/>

                                </View>

                            </View>

                            <View style={styles.typeFrame_1_3}>

                            </View>
                        </View>
                    </View>

                    <TouchableOpacity style={styles.titleFrameTop}
                                      onPress={()=>{this.onSelectDrop(true,0,5)}}>
                        <ItemRowTripApply text={"开始时间:"}
                                          viewCenterProps={{
                                              defaultValue:beginTime,
                                              options:[beginTime],
                                              selectedIndex:0,
                                              textStyle:styles.titleFrame_timeBtnText,
                                              disabled:true,
                                              // onSelect:(i,val)=>this.onSelectDrop(val,i,3)
                                          }}/>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.titleFrameTop}
                                      onPress={()=>{this.onSelectDrop(false,0,5)}}>

                        <ItemRowTripApply text={"结束时间:"}
                            // frameStyle={styles.titleFrameTop}
                                          viewCenterProps={{
                                              defaultValue:endTime,
                                              // clearDrop:checkPersonClearDrop,
                                              selectedIndex:0,
                                              options:[endTime],
                                              textStyle:styles.titleFrame_timeBtnText,
                                              disabled:true,
                                              // onSelect:(i,val)=>this.onSelectDrop(val,i,4)
                                          }}/>
                    </TouchableOpacity>

                </View>


                <DatePicker ref={(compoent)=>{
                    this.datePicker = compoent;
                }}
                            onDateChange={this.setTime}/>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    titleFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        alignItems: 'center',
        justifyContent: 'center',
        height: Theme.Height.height1,

    },
    titleFrame_btn: {
        width: 100,
        height: Theme.Height.height1,
        padding: 0,
    },
    titleFrame_timeBtnFrame:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        borderRadius:Theme.Border.borderRadius,
    },
    titleFrame_timeBtn:{
        width: '0.3w',
        height: Theme.Height.height1,
        padding: 0,
        backgroundColor:Theme.Colors.transparent,
    },
    titleFrame_timeBtnText:{
        color:Theme.Colors.minorColor
    },
    titleFrame_timeText:{
        color:Theme.Colors.themeColor,
        marginLeft:10,
        marginRight:10,
        fontSize:Theme.Font.fontSize,
    },
    titleFrame1:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },


    typeFrame:{
        flex:1,
        // backgroundColor:'yellow',
    },
    itemRowText:{
        color:Theme.Colors.minorColor,
        fontSize:Theme.Font.fontSize_1,
    },

    typeFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        // backgroundColor:"blue",

    },
    typeFrame_1_1: {
        flex: 1.5,
        alignItems: 'flex-end',
        justifyContent: 'center',
        // backgroundColor:'yellow',
    },
    typeFrame_1_2: {
        flexDirection: 'row',
        flex: 8,
        // alignItems: 'flex-start',
        alignItems: 'center',
        justifyContent: 'center',
        // backgroundColor:'green',
    },
    typeFrame_1_3: {
        flex: 0.5,
        alignItems: 'flex-start',
        justifyContent: 'center',
        // backgroundColor:'red',
    },
    typeItemRowFrame:{
        /* alignItems: 'flex-start',
         justifyContent: 'center',*/
        // marginLeft: 5,
        width: StyleSheetAdapt.getWidth("0.72w") + StyleSheetAdapt.getWidth(Theme.Height.height1) + "n",
        borderTopColor:Theme.Colors.themeColor,
        borderTopWidth:Theme.Border.borderWidth1,
        borderLeftColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth,
    },
    typeItemRowFrame_Text: {
        color: Theme.Colors.fontcolor,
        fontSize: Theme.Font.fontSize,
        // alignSelf: "stretch",
        // textAlign:"auto"
    },

    customerItemFrame:{
        borderLeftWidth:0,
    },
    customerItemFrame_1:{
        marginTop:10,
    },

    flatListView:{
        height:400,
    },
    flatListView_ItemFirst:{
        backgroundColor:Theme.Colors.themeColor
    },

});
