import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "./../../../../../component/api/api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//省份
            type2:'',//城市
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:0,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取出差数据列表
     * @param selectValue object,//搜索参数
     * selectValue = {
         type1:'',//省份
            type2:'',//城市
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
    }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    // static getCustomerList(selectValue,init){
    //
    //     init = init == undefined ? false : init;
    //     if(init || this.base == undefined)
    //     {
    //         new Service();
    //     }
    //
    //     if(selectValue != undefined)
    //     {
    //         selectValue.type2 = selectValue.type2 != '' ? selectValue.type2 : selectValue.type1;
    //         this.base.paramsFetch.selectValue = selectValue;
    //     }
    //
    //     if(init){
    //         this.base.paramsFetch.pageNumber = 1;
    //         this.base.retJson.retListData = [];
    //     }
    //
    //     if(this.base.paramsFetch.executing){
    //         return new Promise((resolve,reject)=>{
    //             reject({status:Theme.Status.executing});
    //         });
    //     }
    //     else
    //     {
    //         this.base.paramsFetch.executing = true;
    //     }
    //
    //     return Http.post(HttpUrls.urlSets.urlInfoFeedBackProprietor, {
    //         pageNumber: this.base.paramsFetch.pageNumber,
    //         pageSize: 20,
    //         filiale_id:'',//分公司id
    //         province:this.base.paramsFetch.selectValue.type1,//省份
    //         city:this.base.paramsFetch.selectValue.type2,//城市
    //         name:this.base.paramsFetch.selectValue.name,//客户姓名 搜索
    //         showAllData:Tools.userConfig.userInfo.showAllData,
    //         sign_time:'',//签约时间
    //     },false)
    //         .then((retJson) => {
    //             if(retJson.retListData == undefined || retJson.retListData.length == 0)
    //             {
    //                 retJson.retListData = [];
    //                 this.base.retJson.has = false;
    //             }
    //             else
    //             {
    //                 this.base.paramsFetch.pageNumber++;
    //                 this.base.retJson.has = true;
    //             }
    //
    //             this.base.paramsFetch.executing = false;
    //
    //             retJson.retListData.forEach((v,i,a)=>{
    //                 v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY-MM-DD HH:mm");
    //                 v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY-MM-DD HH:mm");
    //                 // v.isProTask = Tools.userConfig.userInfo.id ==  v.executor_id ? true : false;
    //
    //                 this.base.retJson.retListData.push(v);
    //             });
    //             console.log(this.base.retJson)
    //             return  this.base.retJson;
    //         })
    //         .catch((status) => {
    //             this.base.paramsFetch.executing = false;
    //             return status;
    //         });
    // }
    static getCustomerList(selectValue,init) {

            init = init == undefined ? false : init;
            if(init || this.base == undefined)
            {
                new Service();
            }

            if(selectValue != undefined)
            {
                selectValue.type2 = selectValue.type2 != '' ? selectValue.type2 : selectValue.type1;
                this.base.paramsFetch.selectValue = selectValue;
            }

            if(init){
                this.base.paramsFetch.pageNumber = 0;
                this.base.retJson.retListData = [];
            }

            if(this.base.paramsFetch.executing){
                return new Promise((resolve,reject)=>{
                    reject({status:Theme.Status.executing});
                });
            }
            else
            {
                this.base.paramsFetch.executing = true;
            }

            return Http.get(HttpUrls.urlSets.urlCustomerListGet, {
                    jobGrade:Tools.userConfig.userInfo.job_grade,
                    addTask:true,

                number: this.base.paramsFetch.pageNumber,
                    // customerStatus:customerStatus,
                    // needScore:val.needScore,
                showAllData:Tools.userConfig.userInfo.showAllData,
                size: 10,
                    // pageNumber: this.base.paramsFetch.pageNumber,
                    //  filiale_id:'',//分公司id
                provincialId:this.base.paramsFetch.selectValue.type1,//省份
                cityId:this.base.paramsFetch.selectValue.type2,//城市
                customerName:this.base.paramsFetch.selectValue.name,//客户姓名 搜索
                    //  showAllData:Tools.userConfig.userInfo.showAllData,
            },false)
                .then(retJson => {
                        if(retJson.retData.content == undefined || retJson.retData.content.length == 0)
                                    {
                                        retJson.retListData = [];
                                        this.base.retJson.has = false;
                                    }
                                    else
                                    {

                                        this.base.paramsFetch.pageNumber++;
                                        this.base.retJson.has = true;
                                    }

                                    this.base.paramsFetch.executing = false;

                                // retJson.retListData.forEach((v,i,a)=>{
                                //     v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY-MM-DD HH:mm");
                                //     v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY-MM-DD HH:mm");
                                //     // v.isProTask = Tools.userConfig.userInfo.id ==  v.executor_id ? true : false;
                                //
                                //     this.base.retJson.retListData.push(v);
                                // });

                                retJson.retData.content.forEach((v,i)=>{
                                    this.base.retJson.retListData.push(v);
                                })
                    // console.log(retJson.retData)
                    return this.base.retJson
                });

    }
    /**
     * 获取关联任务
     * **/
    static getRelatedTaskList(){


        return Http.post(HttpUrls.urlSets.urlTripLine,{
            /*map.put("1", "巡店任务");
             map.put("2", "出差任务");
             map.put("3", "流程任务");
             map.put("4", "回访任务");
             map.put("5", "工作汇报");
             map.put("6", "临时任务");
             */
            type:'2',//类型
            executor:Tools.userConfig.userInfo.id,//
        })
            .then((retJson)=>{

                return retJson.retListData;
            });

    }

    /**
     * 获取省份
     * **/
    // static getProvinces(){
    //
    //     return Http.post(HttpUrls.urlSets.urlProvinceList,{})
    //         .then((retJson)=>{
    //
    //             // retJson.retListData = lst.concat(retJson.retListData);
    //             // modelTrip.set("areaLst",retJson.retListData);
    //             let lst = ["省份"];
    //             lst = lst.concat(retJson.retData);
    //             return lst;
    //         });
    //
    //     // modelTrip.set("area",'');
    //
    // }
    static getProvinces(){

        return Http.get(HttpUrls.urlSets.urlGetProvince,{jobGrade:Tools.userConfig.userInfo.job_grade})
            .then((retJson)=>{

                let lst = ["省份"];
                lst = lst.concat(retJson.retData);
                return lst;
            });

    }

    /**
     * 获取城市
     * **/
    static getCities(value){

        return Http.get(HttpUrls.urlSets.urlCustomerGet,
            {jobGrade:Tools.userConfig.userInfo.job_grade,
                queryType:3,
                parentCode:value
            },false)
            .then((retJson)=>{

                // retJson.retListData = lst.concat(retJson.retListData);
                // modelTrip.set("areaLst",retJson.retListData);

                let lst = ["城市"];
                lst = lst.concat(retJson.retData);
                return lst;
            });

        // modelTrip.set("area",'');

    }
    //获取大区
    static getArea(){
        return Http.get(HttpUrls.urlSets.urlGetProvince,{jobGrade:Tools.userConfig.userInfo.job_grade}).then(retJson=>
        console.log(retJson))
    }
    /**
     * 获取任务类型
     * **/
    static getTaskTypes()
    {
        return Http.post(HttpUrls.urlSets.urlTripType,{
            type:'1'
        })
            .then((retJson)=>{


                /*retJson.retListData.forEach((v,i,a)=>{

                });*/

                /*let lst = [{
                    name:'自定义',
                    id:Tools.userConfig.taskTypeIdGuideCustome,
                }];
                lst = retJson.retListData.concat(lst);*/
                return retJson.retListData;
            });
    }

    /**
     * 获取负责人
     * @param framework_id string,// 部门id
     * **/
    static getChargePeople(framework_id)
    {

        return Http.post(HttpUrls.urlSets.urlChargePersonList,{
            framework_id:framework_id
        },false)
            .then((retJson)=>{


                retJson.retListData.forEach((v,i,a)=>{
                    v.name = v.username;
                    v.id = v.userid;
                });

                return retJson.retListData;
            });
    }

    /**
     * 获取自定义任务类型
     * **/
    static getGuideTaskTypeCustome()
    {

        return Http.post(HttpUrls.urlSets.urlGuideTaskTypeCustome,{
            id: Tools.userConfig.taskTypeIdGuideCustome // 任务类型id

        })
            .then((retJson)=>{

                /* retJson.retListData.forEach((v,i,a)=>{
                     v.name = v.username;
                     v.id = v.userid;
                 });*/

                return retJson.retData.stepTaskList;
            });
    }

    /**
     * 提交巡店向导任务数据 新增巡店任务
     * @param selectValue object,//提交参数
     * **/
    static addTaskGuide(selectValue){
        return new Promise((resolve, reject) => {

            Http.post(HttpUrls.urlSets.urlOnload)
                .then((retJson)=>{

                    selectValue.number = retJson.retData.task_number;

                    Http.post(HttpUrls.urlSets.urlTripAdd,selectValue)
                        .then((retJson)=>{
                            // resolve(retJson.retData.id);
                            // selectValue
                            Http.post(HttpUrls.urlSets.urlGetRelationTask,{
                                taskId:null,
                                taskIds:[retJson.retData.id]
                            })
                                .then((retJson)=>{
                                    resolve(retJson.retListData);
                                });
                        });

                });

        });
    }

  /**
     * 提交巡店向导任务数据 新增巡店任务 自定义类型
     * @param selectValue object,//提交参数
     * **/
    static addTaskGuideCustome(selectValue){
        return new Promise((resolve, reject) => {

            Http.post(HttpUrls.urlSets.urlOnload)
                .then((retJson)=>{

                    selectValue.number = retJson.retData.task_number;

                    Http.post(HttpUrls.urlSets.urlGuideTaskAddCustome,selectValue)
                        .then((retJson)=>{
                            // resolve(retJson.retData.id);
                            Http.post(HttpUrls.urlSets.urlGetRelationTask,{
                                taskId:null,
                                taskIds:[retJson.retData.id]
                            })
                                .then((retJson)=>{
                                    resolve(retJson.retListData);
                                });
                        });
                });

        });
    }

}