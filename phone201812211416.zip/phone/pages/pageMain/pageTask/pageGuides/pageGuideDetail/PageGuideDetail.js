/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTripApply,
    ItemRowTitle,
    Media,
    MenuBottom,
    ImageList,
    VideoList,
    DatePicker,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageGuideDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            // currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            execFirst:true,
            i:0,//附件数组地址
            isVideo:false,//是否是视频？
        };

        this.btnList = [
            {
                text:'拍摄',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.state = {
            id:null,  //任务id
            // id:"d3172fc6-8729-4e46-a763-a67637b82930",  //任务id

            number:null,//任务编码
            name:null,//任务名称
            templateNameParent:null,//任务类型 大类名称
            clientId:null,
            clientName:null,
            position:null,//职位名称
            template_id:null, //巡店类型id
            templateName:null,//巡店任务类型名称
            department_id:null,//部门名称id
            department_name:null,//部门名称
            executor:null,//申请人id
            executorName:null, //申请人
            isProTask:false, //是否是个人任务
            begin_time:null,//开始时间
            end_time:null,//结束时间
            priority:null,//优先级
            timeLengVisitShop:null,//巡店总用时
            signIn:'',//签到
            signOut:'',//签退
            stepFileList:[],//附件数组
            taskName:null,

            showList:[],//显示数据
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    getData() {
        Service.getGuideDetail(this.state.id).then(retJson=>{
            // this.selectValue = retJson.selectValue;
            // retJson.retData.statusHandle = Tools.statusConvert(retJson.retData.status,this.selectValue.executor);

            this.setState(retJson.retData);
        });
    }

    onDelImage(imageList,item,i,i2){
        this.state.stepFileList[i2].attachmentAddressList.splice(i, 1);
        let stepFileList = [];
        this.state.stepFileList.forEach((v,i,a)=>{
            stepFileList.push(v);
        });
        this.setState({
            stepFileList:stepFileList
        });
    }

    showMenu(isVideo,i){
        this.configData.i = i;
        this.configData.isVideo = isVideo;

        MenuBottom.show(true);

    }

    onGetPic = (item,i)=>{

        if(this.state.stepFileList[this.configData.i].attachmentAddressList.length > 5){
            Tools.toast("照片数量已达到上线");
        }else{

            if(i == 0){
                if(this.configData.isVideo){
                    MenuBottom.show(false);
                    Media.takeVideo().then(retJson=>{

                            let stepFileList = [];
                            this.state.stepFileList.forEach((v,i,a)=>{
                                stepFileList.push(v);
                            });
                            stepFileList[this.configData.i].attachmentAddressList.push(retJson.uri)

                            this.setState({
                                stepFileList:stepFileList
                            });
                        });
                }
                else {
                    Media.takeImage(this.state.taskName,true,()=>{
                        MenuBottom.show(false);
                    }).then(retJson=>{

                            let stepFileList = [];
                            this.state.stepFileList.forEach((v,i,a)=>{
                                stepFileList.push(v);
                            });
                            stepFileList[this.configData.i].attachmentAddressList.push(retJson.path)

                            this.setState({
                                stepFileList:stepFileList
                            });
                        });
                }

            }
            else if(i == 1)
            {
                if(this.configData.isVideo){
                    MenuBottom.show(false);
                    Media.pickVideo().then(retJson=>{

                        let stepFileList = [];
                        this.state.stepFileList.forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        stepFileList[this.configData.i].attachmentAddressList.push(retJson.path)

                        this.setState({
                            stepFileList:stepFileList
                        });

                    })
                }
                else {
                    MenuBottom.show(false);
                    Media.pickImage(false,this.state.taskName).then(retJson=>{

                        let stepFileList = [];
                        this.state.stepFileList.forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        stepFileList[this.configData.i].attachmentAddressList.push(retJson.path)

                        this.setState({
                            stepFileList:stepFileList
                        });

                    });
                }

            }
        }


    }

    renderItem = (item,i)=>{
        const {isProTask} = this.state;
        let imageList = [];
        let isVideo = false;
        item.attachmentAddressList.forEach((v,i,a)=>{
            if(v.indexOf(".mp4") > -1){
                isVideo = true;
                imageList.push({
                    uri:v
                });
            }
            else {
                imageList.push({
                    icon:v
                });
            }
        });

        return(
            <View key={i}
                  style={styles.titleFrame_1_1}>
                <ItemRowTitle text1={item.name}
                              text2={isProTask ? "上传附件" : null}
                              onPressRight={()=>this.showMenu(isVideo,i)}/>
                {
                    imageList.length > 0
                        ? isVideo
                        ? <VideoList dataList={imageList}
                                     text={isProTask ? "删除" : null}
                                     onPressText={(item2,index)=>this.onDelImage(imageList,item2,index,i)}
                                     textStyle={styles.imageTextStyle}
                                     iconStyle={styles.imageStyle}/>
                        : <ImageList dataList={imageList}
                                     isShowText={isProTask}
                                     text={"删除"}
                                     onPressText={(item2,index)=>this.onDelImage(imageList,item2,index,i)}
                                     textStyle={styles.imageTextStyle}
                                     iconStyle={styles.imageStyle}/>
                        : null
                }

            </View>
        );
    };

    showDate(val){
        this.configData.isStartTime = val;
        this.datePicker.show();
    }

    setTime = (date)=>{
        let time = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm:ss");

        if(this.configData.isStartTime)
        {
            if(date < Tools.timeFormatConvert(this.state.end_time))
            {
                this.setState({
                    begin_time:time
                });
            }
            else
            {
                Tools.toast("开始时间必须小于结束时间");
            }
        }
        else
        {
            if(date > Tools.timeFormatConvert(this.state.begin_time))
            {
                this.setState({
                    end_time:time
                });
            }
            else
            {
                Tools.toast("结束时间必须大于开始时间");
            }

        }
    }

    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
    }

    componentWillReceiveProps(){

    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        Service.alterGuideTask(this.state).then(retJson=>{
            Tools.toast("提交成功");
            this.getData();
        });
    };

    render() {
        const {number,name,clientName,position,templateName, department_name,
            executorName,begin_time,end_time,timeLengVisitShop,signIn,signOut,
            stepFileList,templateNameParent,isProTask} = this.state;

        let param = this.getPageParams();
        // if(true){
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                this.getData();
            }

            return (
                <ViewTitle viewBottom={isProTask ? "提交" : null}
                           onPressBottom={this.onPressBottom}>

                    <View style={styles.titleFrame}>

                        <View style={styles.itemRow}>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"任务编码:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={number}/>
                            </View>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"客户姓名:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={clientName}/>
                            </View>
                        </View>

                        <View style={styles.itemRow}>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"任务名称:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={name}/>
                            </View>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"岗        位:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={position}/>
                            </View>
                        </View>

                        <View style={styles.itemRow}>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"任务类型:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={templateNameParent}/>
                            </View>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"巡店类型:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={templateName}/>
                            </View>
                        </View>

                        <View style={styles.itemRow}>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"部        门:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  viewCenter={"text"}
                                                  isStar={false}
                                                  text2={department_name}/>
                            </View>
                            <View style={styles.itemRow}>
                                <ItemRowTripApply text={"执  行  人:"}
                                                  frameLabelStyle={styles.itemRowLabel}
                                                  frameStyle={styles.titleFrameTop}
                                                  isStar={false}
                                                  viewCenter={"text"}
                                                  text2={executorName}/>
                            </View>
                        </View>

                        <ItemRowTripApply text={"任务计划开始时间:"}
                                          frameLabelStyle={styles.itemRowLabel_1}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          onPressRight={()=>this.showDate(true)}
                                          text2={Tools.timeFormatConvert(begin_time,"YYYY-MM-DD HH:mm")}/>

                        <ItemRowTripApply text={"任务计划结束时间:"}
                                          frameLabelStyle={styles.itemRowLabel_1}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          onPressRight={()=>this.showDate(false)}
                                          text2={Tools.timeFormatConvert(end_time,"YYYY-MM-DD HH:mm")}/>

                        <ItemRowTripApply text={"本次巡店总用时:"}
                                          frameLabelStyle={styles.itemRowLabel_2}
                                          textStyle={styles.itemRowLabelText}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={timeLengVisitShop}/>

                        <ItemRowTripApply text={"门店签到:"}
                            // frameLabelStyle={styles.itemRowLabel_2}
                                          textStyle={styles.itemRowLabelText}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={signIn}/>

                        <ItemRowTripApply text={"门店签退:"}
                            // frameLabelStyle={styles.itemRowLabel_2}
                                          textStyle={styles.itemRowLabelText}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={signOut}/>

                    </View>

                    <View style={styles.titleFrame_1}>

                        {
                            stepFileList.map(this.renderItem)
                        }


                    </View>

                    <MenuBottom btnList={this.btnList}
                                isVisibleClose={false} />

                    <DatePicker ref={(compoent)=>{
                        this.datePicker = compoent;
                    }}
                                onDateChange={this.setTime}/>

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }


    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    itemRow:{
        flex:1,
        flexDirection: 'row',
    },
    itemRowLabel:{
        // backgroundColor:'yellow',
        flex:4,
    },
    itemRowLabelText:{
        color:Theme.Colors.fontcolor,
    },
    itemRowLabel_1:{
        // backgroundColor:'yellow',
        flex:3.3,
    },
    itemRowLabel_2:{
        // backgroundColor:'yellow',
        flex:2.8,
    },
    titleFrame_1: {
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titleFrame_1_1:{
        marginBottom:10,
    },
    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },
});
