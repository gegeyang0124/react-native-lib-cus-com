import {
    Http,
    HttpUrls,
    Tools,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    /**
     * 获取巡店任务详情
     * @param taskId string,//任务ID
     * **/
    static getGuideDetail(taskId){

        return new Promise((resolve, reject) => {

            Http.post(HttpUrls.urlSets.urlTaskDetail, {
                showNullValue: 1,//附件，1:显示为空的元素 2:不显示为空的元素
                task_id:taskId,//任务id
            })
                .then((retJson)=>{

                    let retObj = {
                        /* selectValue:{
                         id:retJson.retData.baseinfo[0].fid,  //任务id
                         template_id:retJson.retData.baseinfo[0].ftemplate_id, //出差类型id
                         number:retJson.retData.baseinfo[0].fnumber,//加载时获取的任务编号
                         name:retJson.retData.baseinfo[0].fname,//任务名称
                         department_id:retJson.retData.baseinfo[0].fdepartment_id,//部门id
                         executor:retJson.retData.baseinfo[0].fexecutor,//申请人id
                         auditor:retJson.retData.baseinfo[0].fauditor,//审核人id
                         priority:retJson.retData.baseinfo[0].fpriority,//优先级值
                         begin_time:Tools.timeFormatConvert(retJson.retData.baseinfo[0].fbegin_time,"YYYY-MM-DD HH:mm:ss"),//开始时间
                         end_time:Tools.timeFormatConvert(retJson.retData.baseinfo[0].fend_time,"YYYY-MM-DD HH:mm:ss"),//结束时间
                         /!* prop_array:[
                         {
                         key:'task_relation',//键值
                         value:''//值，逗号分割的巡店任务id字符串
                         }
                         ],//额外数据*!/
                         task_relation:'',//关联任务
                         },*/
                        retData:{
                            id:retJson.retData.task.id,  //任务id
                            number:retJson.retData.task.number,//任务编码
                            name:retJson.retData.task.name,//任务名称
                            template_id:retJson.retData.task.template_id, //巡店类型id
                            templateName:retJson.retData.templateName,//巡店任务类型名称
                            // isOpenTime:retJson.retData.practice_time == null || data.retData.practice_time == undefined || data.retData.practice_time == 'null' ? false : true,//是否显示开业时间，true显示，false隐藏
                            /* practice_time:retJson.retData.practice_time == null || data.retData.practice_time == undefined || data.retData.practice_time == 'null'
                             ? '' : timeFormatConvert(data.retData.practice_time, "YYYY年MM月DD日"),//开业时间
                             */
                            clientId:retJson.retData.customer.id,
                            clientName:retJson.retData.customer.name,
                            position:retJson.retData.user.position,//职位名称
                            templateNameParent:Tools.taskStatusConvert(retJson.retData.task.task_type),//任务类型 大类名称
                            department_id:retJson.retData.user.framework_id,//部门名称id
                            department_name:retJson.retData.user.framework_name,//部门名称
                            executor:retJson.retData.user.userid,//申请人id
                            executorName:retJson.retData.user.username, //申请人

                            isProTask:(retJson.retData.user.userid + '') == (Tools.userConfig.userInfo.id + '') ? true : false,

                            begin_time:Tools.timeFormatConvert(retJson.retData.task.begin_time,"YYYY-MM-DD HH:mm:ss"),//开始时间
                            end_time:Tools.timeFormatConvert(retJson.retData.task.end_time,"YYYY-MM-DD HH:mm:ss"),//结束时间
                            priority:retJson.retData.task.priority,//优先级
                            timeLengVisitShop:retJson.retData.time,//巡店总用时

                            signIn:retJson.retData.stepFileList.length > 0
                                // ? retJson.retData.stepFileList[0].file_name.replace('签到拍照：', '')
                                ? retJson.retData.stepFileList[0].file_name.substring(
                                    retJson.retData.stepFileList[0].file_name.indexOf("：") + 1
                                )
                                : null,//签到
                            /*signOut:retJson.retData.stepFileList.length > 0
                                ? retJson.retData.stepFileList[retJson.retData.stepFileList.length - 1].file_name.replace('门店签退：', '')
                                : null,//签退*/
                            signOut:retJson.retData.signOutInfo,//签退
                            stepFileList:[],//附件数组
                           /* stepFileList:[{
                                id:'',//id
                                name: '店铺图片', //附件名称
                                attachmentAddressList: [
                                    'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
                                    'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg'
                                ], //附件文件地址集合(图片)
                            },
                                {
                                    id:'',//id
                                    name: '店铺尺寸草图', //附件名称
                                    attachmentAddressList: [
                                        'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
                                        'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg'
                                    ], //附件文件地址集合(图片)
                                },
                                {
                                    id:'',//id
                                    name: '店铺尺寸草图', //附件名称
                                    attachmentAddressList: [
                                        'https://pic.ibaotu.com/00/11/93/525888piCU7a.mp4',
                                        'https://pic.ibaotu.com/00/11/93/525888piCU7a.mp4'
                                    ], //附件文件地址集合(图片)
                                }
                            ],//附件数组*/
                        }
                    };

                    retJson.retData.stepFileList.forEach((v,i,a)=>{
                        // if(!(v.file_name.indexOf("门店签退：") > -1)){
                        if(true){
                            let item = {
                                id:v.file_id,//id
                                // name: v.file_name.indexOf("签到拍照：") > -1
                                //     ? v.file_name.substring(0,v.file_name.indexOf(":"))
                                //     : v.file_name, //附件名称
                                name:v.file_name,
                                attachmentAddressList:v.fvalue == undefined || v.fvalue == ''
                                    ? []
                                    : v.fvalue.split(","), //附件文件地址集合(图片)
                            }; //步骤成员附件，即本次拜访资料签收

                            retObj.retData.stepFileList.push(item);
                        }
                    });

                    // console.info("retObj",retObj);
                    resolve(retObj);
                });
        });

    }

    /**
     * 修改巡店任务
     * @param selectObj json,//任务ID
     {
           // id:null,  //任务id
           id:"d3172fc6-8729-4e46-a763-a67637b82930",  //任务id

           number:null,//任务编码
           name:null,//任务名称
           templateNameParent:null,//任务类型 大类名称
           clientId:null,
           clientName:null,
           position:null,//职位名称
           template_id:null, //巡店类型id
           templateName:null,//巡店任务类型名称
           department_id:null,//部门名称id
           department_name:null,//部门名称
           executor:null,//申请人id
           executorName:null, //申请人
           begin_time:null,//开始时间
           end_time:null,//结束时间
           priority:null,//优先级
           timeLengVisitShop:null,//巡店总用时
           signIn:'',//签到
           signOut:'',//签退
           stepFileList:[],//附件数组
           }
    * **/
    static alterGuideTask(selectObj){
        let stepFileList = [];
        selectObj.stepFileList.forEach((v,i,a)=>{
            v.attachmentAddressList.forEach((v1,i1,a1)=>{
                stepFileList.push({
                    id:v.id,
                    name:v.name,
                    localPath:v1
                });
            });
        });

        return new Promise((resolve, reject) => {

            Http.upLoadFileToService(stepFileList)
                .then(retJson=>{
                    let requestData = {
                        taskId:selectObj.id,//任务id
                        event_value_array:[]
                    };
                    retJson.forEach((v,i,a)=>{
                        let item = {
                            task_operation_event_id:v.id,//id
                            value:[]//值
                        };

                        let isPush = true;
                        requestData.event_value_array.forEach((v1,i1,a1)=>{
                            if(item.task_operation_event_id == v1.task_operation_event_id){
                                isPush = false;
                            }
                        });

                        if(isPush){
                            requestData.event_value_array.push(item);
                        }

                    });

                    requestData.event_value_array.forEach((v,i,a)=>{

                        retJson.forEach((v1,i1,a1)=>{
                            if(v.task_operation_event_id == v1.id){
                                v.value.push(v1.servicePath);
                            }
                        });
                    });

                    requestData.event_value_array.forEach((v,i,a)=>{
                        v.value = v.value.toString();
                    });

                    Http.post(HttpUrls.urlSets.urlUpdateTaskTime, {
                        id:selectObj.id,//任务id
                        begin_time:selectObj.begin_time,
                        end_time:selectObj.end_time
                    })
                        .then((retJson)=>{
                            Http.post(HttpUrls.urlSets.urlViewSupplementAttachment, requestData)
                                .then((retJson)=>{
                                    resolve(retJson);
                                });
                        });
                });
        });

    }

}