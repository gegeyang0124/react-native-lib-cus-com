/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
/*import SwipeableListView from 'SwipeableListView';
 import SwipeableQuickActions from 'SwipeableQuickActions';
 import SwipeableQuickActionButton from 'SwipeableQuickActionButton';*/
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    FlatListView,
    ItemRowTripTask,
} from "com";
import {Service} from "./Service";
import {ServiceCommon} from "./../ServiceCommon";

type Props = {};
export default class PageGuideList extends BaseComponent<Props> {

    constructor(props) {
        super(props);
        this.config = {
            execFirst:true
        };
        this.state = {
            dataList:[],//任务列表
            id:this.getPageParams().id
        };
        this.setParams({
            headerLeft:true,
            headerRight:false,
            title : '巡店任务',
        });

    }

    componentWillEnter(params){
        // console.info("componentWillEnter",params);
        if(params || this.state.id){
            if(params){
                this.state.id = params.id;
            }
            this.getData();
        }

    }

    /**
     * @param taskId string,//出差任务ID
     * **/
    getData(taskId) {
        // alert("grt")

        /**
         * 只处理状态：0，3，4
         * **/
        Service.getRelatedTaskList(this.state.id)
        // Service.getRelatedTaskList("2ca88cd8-7d23-454f-b095-967b60334f9f")
            .then(retJson=>{
                if(retJson.length == 0){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                }
                this.setState({
                    dataList:retJson,
                });
            })
            .catch((status) =>{

            });

    }

    componentWillMount(){


    }

    componentDidMount() {
        // this.getData();
    }

    onItemPress(item){

        if(item.taskStatus == '0'){
            this.goPage("PageGuideDetail",{id:item.taskId});
        }
        else {
            ServiceCommon.getCurStepDetail(item.taskId)
                .then(retJson=>{
                    // Tools.toast("" + retJson.pageCode)
                    Tools.stepInPage(retJson.pageCode,{id:item.taskId},true);
                });
            // this.goPage("PageGuideDetail",{id:item.taskId});
        }
    }

    onItemPressBtn(item,v){
        // alert(JSON.stringify(item))
        /*this.setState({
            dataList:[]
        });*/
        Service.deleteTask(item.taskId)
            .then(retJson=>{
                this.getData();
            });
    }

    renderItemView(item,i){
        let statusObj = Tools.statusConvert(item.taskStatus,item.executor_id);
        /*  let text4_2 = <ButtonChange text={"进入巡店"}
         frameStyle={styles.itemTripBtn}
         style={styles.titleFrame_btn}
         onPress={()=>this.onItemPressBtn(item)}/>;*/
        // console.log(statusObj)
        let btnList = [];
        if(statusObj.status == '3' || statusObj.status == '4'){
            btnList.push({
                onPress:()=>this.onItemPress(item),
                text:'执行任务',
                backgroundColor:Theme.Colors.themeColor
            });
        }

        /*btnList.push({
            onPress:()=>this.onItemPressBtn(item),
            text:'删除',
            backgroundColor:Theme.Colors.appRedColor
        });*/

        return(
            <ItemRowTripTask  key={i}
                              disableRightSwipe={false}
                              isItemRowIconLeft={true}
                              btnList={btnList}
                              text1_1={item.taskName}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={statusObj.text}
                              text2_1={"执行人:" + item.executorName}
                              text2_1_Style={styles.text2_1_Style}
                              text3_1={"客户姓名:" + item.customerName}
                              text4_1={"出差开始/结束时间:" + item.beginTime
                              + " ~ " + item.endTime}
                              onPress={() => this.onItemPress(item)}
                              text1_2_Style={{color:statusObj.color}}
                              itemRowIcon={false}
                              text1_2_Icon={statusObj.icon}/>
        );
    }

    componentWillReceiveProps(){

    }

    render() {
        const {dataList} = this.state;
        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c}>


                <FlatListView style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,i}) => this.renderItemView(item,i)}
                />

            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
        height:100,
    },
    titleFrame_1:{
        flexDirection:'row',
        flex:1,
        height:50,
    },
    titleFrame_1_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            padding:0,
            paddingLeft:10,
            paddingBottom:10,
            marginTop:15,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    titleFrame_btnFrame:{
        width:Theme.Width.width1 + Theme.Height.height1,
    },
    titleFrame_btn:{
        width:100,
        height:Theme.Height.height1,
        padding:0,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginBottom:10,
    },
    itemTripBtn:{
        marginRight:"0.05w",
    },
});


