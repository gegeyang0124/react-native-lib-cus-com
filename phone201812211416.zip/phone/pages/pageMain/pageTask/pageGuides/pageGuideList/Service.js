import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取单个出差任务的关联巡店任务详情或查询指定巡店任务的ID {
            taskId:taskId,//出差任务ID：string
            taskIds:null//巡店任务ID：array
        }
     * @param taskId string,//出差任务ID
     * **/
    static getRelatedTaskList(taskId){


       return Http.post(HttpUrls.urlSets.urlGetRelationTask,{
            taskId:taskId,
            taskIds:null
        })
            .then((retJson)=>{
                return retJson.retListData;
            });

    }

    /**
     * 删除任务，
     * @param taskIdsList array/string,//删除任务数组列表
     * **/
    static deleteTask(taskIdsList){

        taskIdsList = taskIdsList.constructor == Array ? taskIdsList : [taskIdsList];
        // alert(JSON.stringify(taskIdsList))
        return Http.post(HttpUrls.urlSets.urlDeleteTask,{
            taskIds:taskIdsList
        })
            .then((retJson)=>{
                return retJson;
            });

    }

}
