import {
    Theme,
} from 'com'
import {
    TabNavigator,
} from 'comThird'
import PageNewShopAddressSign from "./pageNewShopAddressSign/PageNewShopAddressSign";
import PageNewShopAddressFind from "./pageNewShopAddressFind/PageNewShopAddressFind";
import PageNewShopAddressAjust from "./pageNewShopAddressAjust/PageNewShopAddressAjust";
import PageNewShopAddressPlan from "./pageNewShopAddressPlan/PageNewShopAddressPlan";
import PageNewShopAddressExit from "./pageNewShopAddressExit/PageNewShopAddressExit";
import PageNewShopAddressDesign from "./pageNewShopAddressDesign/PageNewShopAddressDesign";
import PageNewShopAddressMaterial from "./pageNewShopAddressMaterial/PageNewShopAddressMaterial";

const TabRouteConfigs = {
    PageNewShopAddressSign: {
        screen: PageNewShopAddressSign,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '签到',
            // swipeEnabled:false,
        },

    },
    PageNewShopAddressFind: {
        screen: PageNewShopAddressFind,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '找店',
            // swipeEnabled:false,
        },

    },
    PageNewShopAddressAjust: {
        screen: PageNewShopAddressAjust,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '市调',
            // swipeEnabled:false,
        },

    },
    PageNewShopAddressPlan: {
        screen: PageNewShopAddressPlan,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '规划',
            // swipeEnabled:false,
        },

    },
    PageNewShopAddressDesign: {
        screen: PageNewShopAddressDesign,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '图纸设计',
            // swipeEnabled:false,
        },

    },
    PageNewShopAddressMaterial: {
        screen: PageNewShopAddressMaterial,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '资料签收',
            // swipeEnabled:false,
        },

    },
    PageNewShopAddressExit: {
        screen: PageNewShopAddressExit,
        navigationOptions: {
            title : '新店选址',
            tabBarLabel : '签退',
            // swipeEnabled:false,
        },

    },

}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;


