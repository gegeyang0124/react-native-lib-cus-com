/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    GuideImageHint,
    ItemRowTitle,
    MenuBottom,
    Media,
    ImageList,
    TextIcon,
    ItemRowTripApply,
    SearchDDDIpt,
    PickDropdown,
} from "com";
import {
    CheckBox
} from "comThird";
import {Service} from "./Service";

import imageAddress from "images/address.png";

type Props = {};
export default class PageNewShopAddressFind extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.btnList = [
            {
                text:'拍摄',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.selectedValue = {
            record_id:null,//客户id
            consignee:null,// 收货人,
            consignee_tel:null,// 收货人电话,
            consignee_province:null,// 收货人省份,
            consignee_city:null,//  收货人城市,
            shipping_address:null,// 收货地址,
            storecode:null,
        };

        this.configData = {
            execFirst:true,
            type:null,//拍照选择图片类型值
            provinceList:[],//省份
            provinceClearDrop:false,//是否重置省的数据
        };

        this.state = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            /*imageList0:[
             'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
             'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg'
             ],*/
            imageList0:[],//门头区域 图片数组
            imageList1:[],//橱窗区域 图片数组
            imageList2:[],//服装区域(整体) 图片数组

            event_list:[],//附件列

            cityList:[],//城市
            cityClearDrop:false,//是否重置城市的数据
            consignee_tel:null,// 收货人电话,
            isChecked:true,//是否选中确认地址，默认选中

            taskGuide:null,//巡店提示
            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
            taskName:null,
            storecode:null,
        };
        /*[
         {
         // icon:require('./../../../../../../res/images/goodsImportant.png'),
         text:"签到地址:广东省广州市珠江东路6号\n签到时间:2018-06-25 15:33:33",
         icon:'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
         }
         ]*/

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    onGetPic = (item,i)=>{

            if(i == 0){
                Media.takeImage(this.state.taskNam,true,()=>{
                    MenuBottom.show(false);
                }).then(retJson=>{
                        let location = {
                            icon:null,
                            lat:retJson.lat,//维度
                            lng:retJson.lng,//经度
                            address:retJson.address,
                            text:retJson.address,
                            selected:false,
                        }

                        let stepFileList = [];
                        this.state["imageList" + this.configData.type].forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        location.icon = retJson.path;
                        stepFileList.push(location);

                        let obj = {};
                        obj["imageList" + this.configData.type] = stepFileList;
                        this.setState(obj);

                    });


            }else if(i == 1){
                MenuBottom.show(false);
                Media.pickImage(false,this.state.taskName).then(retJson=>{
                    let location = {
                        icon:null,
                        lat:retJson.lat,//维度
                        lng:retJson.lng,//经度
                        address:retJson.address,
                        text:retJson.address,
                        selected:false,
                    }

                    let stepFileList = [];
                    this.state["imageList" + this.configData.type].forEach((v,i,a)=>{
                        stepFileList.push(v);
                    });
                    location.icon = retJson.path;
                    stepFileList.push(location);
                    // console.info("stepFileList",stepFileList);
                    let obj = {};
                    obj["imageList" + this.configData.type] = stepFileList;
                    this.setState(obj);
                });

            }
    }

    showMenu(type){
        this.configData.type = type;

        this.onGetPic({},0);
        // MenuBottom.show(true);

    }

    onDelImage(imageList,item,i){
        this.state[imageList].splice(i, 1);
        let stepFileList = [];
        this.state[imageList].forEach((v,i,a)=>{
            stepFileList.push(v);
        });
        let obj = {};
        obj[imageList] = stepFileList;
        this.setState(obj);
    }

    getData(){
        this.selectedValue.record_id = this.state.id;
        Service.getCurStepDetail(this.state.id)
            .then(retJson=>{
                retJson.event_list.forEach((v,i,a)=>{
                    this.state["imageList" + i] = [];
                });
                this.setState(retJson);
            });
    }

    getProvince(){
        Service.getProvinces()
            .then(retJson=>{
                this.configData.provinceList = retJson.provinceList;
                this.configData.provinceClearDrop = true;
                retJson.cityClearDrop = true;
                this.selectedValue.consignee_province = retJson.provinceList[0].id;
                // alert(JSON.stringify(retJson))
                this.setState(retJson);
            });
    }

    onSelectPd = (i,item,type)=>{
        if(type == 0){
            this.configData.provinceClearDrop = false;
            this.selectedValue.consignee_province = item.id;

            this.setState({
                cityList:[]
            });
            Service.getCities(this.selectedValue.consignee_province)
                .then(retJson=>{
                    // this.configData.cityClearDrop = true;
                    // alert(JSON.stringify(retJson))
                    this.selectedValue.consignee_city = retJson[0].id;
                    this.setState({
                        cityList:retJson,
                        cityClearDrop:true
                    });
                });
        }
        else
        {
            this.selectedValue.consignee_city = item.id;

            if(this.state.cityClearDrop)
            {
                // this.configData.cityClearDrop = false;
                this.setState({
                    cityClearDrop:false
                });
            }

        }
    }

    onChangeText = (text,type) =>{
        switch (type){
            case 0:{
                this.selectedValue.consignee = text;
                break;
            }
            case 1:{
                text = text + "";

                this.selectedValue.consignee_tel = text;


                this.setState({consignee_tel:this.selectedValue.consignee_tel + ''});

                break;
            }
            case 2:{
                this.selectedValue.shipping_address = text;
                break;
            }
        }
    };

    componentDidMount() {
        // this.getData();
        this.getProvince();
    }

    initState(id){
        let stateInit = {
            id: id,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            /*imageList0:[
             'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
             'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg'
             ],*/
            imageList0: [],//门头区域 图片数组
            imageList1: [],//橱窗区域 图片数组
            imageList2: [],//服装区域(整体) 图片数组

            event_list: [],//附件列

            cityList: [],//城市
            cityClearDrop: false,//是否重置城市的数据
            consignee_tel: null,// 收货人电话,
            isChecked: true,//是否选中确认地址，默认选中

            taskGuide: null,//巡店提示
            steps: [],//导航提示步骤
            pageCode: null,//要进入页面的编码;
        };
        this.state = stateInit;
        this.setState(stateInit);
    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        if(this.state.storecode != null){
            this.selectedValue.storecode = this.state.storecode;
        }

        if(this.state.isChecked){

            var myreg=/^[1][2,3,4,5,6,7,8,9][0-9]{9}$/;
            if (!myreg.test(this.selectedValue.consignee_tel)) {
                Tools.toast("您输入的电话号码不正确哦！");
                return;
            }

            if(this.selectedValue.consignee == '' || this.selectedValue.consignee == null){
                 Tools.toast("您还没有填写收货人哦！");
                 return;
            }

            if(this.selectedValue.shipping_address == '' || this.selectedValue.shipping_address == null){
                 Tools.toast("您还没有填写收获地址哦！");
                return;
            }
            // console.log(this.selectedValue)
            // console.log(this.state)
           Service.putInRecipient(this.selectedValue)
                .then(retJson=>{
                    Service.putIn(this.state)
                        .then(retJson=>{
                            Tools.stepInPage(retJson.pageCode,{id:retJson.id});
                        });
                });
        }else {
            // this.selectedValue = {
            //     record_id:null,//客户id
            //     consignee:null,// 收货人,
            //     consignee_tel:null,// 收货人电话,
            //     consignee_province:null,// 收货人省份,
            //     consignee_city:null,//  收货人城市,
            //     shipping_address:null,// 收货地址,
            //     storecode:null,
            // };
            // console.log(this.state)
            Service.putIn(this.state)
                .then(retJson=>{
                    Tools.stepInPage(retJson.pageCode,{id:retJson.id});
                });
        }


    };

    renderItemBottom = (item,i)=>{
        return(
            <View style={styles.bodyFrame_2}>

                <View style={styles.bodyFrame_2_1}>
                    <TextIcon icon={imageAddress}
                              style={styles.textIconFrame}
                              iconStyle={styles.iconStyle}
                              text={item.address}
                              textStyle={styles.text}/>

                </View>
            </View>

        );
    };

    onPressImage(item,index,i){
        // alert(JSON.stringify(item) + "  \n index:"
        //     + index + "  \n i:" + i)

        let selected = !this.state["imageList" + i][index].selected

        let imgL = {};
        let imageL = [];
        this.state["imageList" + i].forEach((v,i,a)=>{
            v.imageFrameStyle = null;
            v.selected = false;
            imageL.push(v);
        });

        imageL[index].selected = selected;
        imageL[index].imageFrameStyle = selected ? styles.addressSelected : null;

        imgL["imageList" + i] = imageL;
        this.setState(imgL);
        // console.info("imageList" + i,imgL)
    }

    renderItem = (item,i)=>{
        /*let dataList = [{
         // icon:"http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg",
         icon:'http://voip.lexinvip.com:8081/lx_yyt/upload/image/152809850288028428246_src.jpg',
         lat:null,//维度
         lng:null,//经度
         address:"广州市天河区",
         text:"广州市天河区"
         }];*/

        return(
            <View key={i}
                  style={[styles.bodyFrame,styles.bodyFrame2]}>
                <ItemRowTitle text1={item.name}
                              isShowPillar={false}
                              text2={"添加店铺"}
                              textStyle={styles.titleLabel}
                              onPressRight={()=>this.showMenu(i)}/>


                <ImageList dataList={this.state["imageList" + i]}
                           isShowImage={1}
                           onPress={(it,index)=>this.onPressImage(it,index,i)}
                           renderImageBottom={(item1,i1)=>this.renderItemBottom(item1,i1)}
                           onPressDel={(item2,index)=>this.onDelImage("imageList" + i,item2,index)}
                           textStyle={styles.imageTextStyle}
                           iconStyle={styles.imageStyle}/>
            </View>
        );
    }

    onChecked = (isChecked)=>{
        this.setState({
            isChecked:isChecked
        });
    }

    componentWillEnter(params){
        if(params){

            if(params.id){
                this.initState(params.id);
                // this.state.id = params.id;
                this.getData();
            }
            else
            {
                // console.log(params.paramData)
                // this.state.id
                // this.getData();
            }


        }

    }

    render() {

        const {provinceList,provinceClearDrop} = this.configData;
        const {steps,event_list,cityList,cityClearDrop,consignee_tel,isChecked} = this.state;
        // event_list = [{name:"已经协助客户选定店铺地址"}];

      /*  let param = this.getPageParams();
        param = param == undefined ? {} : param;*/
        if(true) {
        // if(this.state.id == param.id){
        //     if(this.configData.execFirst)
            if(false)
            {
                this.configData.execFirst = false;
                this.getData();
            }


            return (
                <ViewTitle viewBottom={"下一步"}
                           onPressBottom={this.onPressBottom}>

                    <GuideImageHint frameStyle={styles.frameStyle}
                                    dataList={steps}/>

                    <View style={styles.bodyFrame1}>
                        {
                            event_list.map(this.renderItem)
                        }
                    </View>

                    <View  style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <View style={[styles.bodyFrame3,styles.bodyFrame3_d]}>
                            <CheckBox rightText={"未找到合适的店铺地址"}
                                      style={styles.bodyFrame3_chk}
                                      rightTextStyle={styles.chkText}
                                      isChecked={!isChecked}
                                      onClick={(isChecked)=>{this.onChecked(!isChecked)}}
                                      imageStyle={styles.chkImage}
                                      checkBoxColor={Theme.Colors.themeColor}/>

                            <CheckBox rightText={"已确认店铺地址"}
                                      imageStyle={styles.chkImage}
                                      isChecked={isChecked}
                                      onClick={(isChecked)=>{this.onChecked(isChecked)}}
                                      style={styles.bodyFrame3_chk}
                                      rightTextStyle={styles.chkText}
                                      checkBoxColor={Theme.Colors.themeColor}/>
                        </View>

                        {
                            isChecked
                                ? <View style={styles.bodyFrame3}>
                                    <ItemRowTripApply text={"收货人:"}
                                                      viewCenterProps={
                                                          {
                                                              placeholder:'姓名',
                                                              style:styles.bodyFrame3_inputFrame,
                                                              onChangeText:(text)=>this.onChangeText(text,0)
                                                          }
                                                      }
                                                      frameLabelStyle={styles.bodyFrame3_inputFrame0}
                                                      textStyle={styles.bodyFrame3_input}
                                                      isStar={false}
                                                      viewCenter={"input"}/>

                                    <ItemRowTripApply text={"收货人:"}
                                                      viewCenterProps={
                                                          {
                                                              placeholder:'电话',
                                                              style:styles.bodyFrame3_inputFrame,
                                                              keyboardType:'numeric',
                                                              value:consignee_tel == null ? '' : consignee_tel,
                                                              onBlur:()=>{
                                                                  /* this.setState({
                                                                   consignee_tel:''
                                                                   });*/
                                                              },
                                                              onChangeText:(text)=>this.onChangeText(text,1)
                                                          }
                                                      }
                                                      frameLabelStyle={styles.bodyFrame3_inputFrame0}
                                                      textStyle={styles.bodyFrame3_input}
                                                      isStar={false}
                                                      viewCenter={"input"}/>
                                </View>
                                : null
                        }

                        {
                            isChecked
                                ? <View style={styles.bodyFrame3}>
                                    <ItemRowTripApply text={"收货地址:"}
                                                      viewCenterProps={
                                                          {
                                                              placeholder:'电话',
                                                              style:styles.bodyFrame3_inputFrame
                                                          }
                                                      }
                                                      isStar={false}

                                                      viewCenter={
                                                          <View>
                                                              <View style={styles.bodyFrame3_pdFrame}>
                                                                  <PickDropdown clearDrop={provinceClearDrop}
                                                                                frameStyle={styles.bodyFrame3_pdFrame_1}
                                                                                defaultValue={provinceList.length == 0
                                                                                    ? '正在加载'
                                                                                    : provinceList[0].name}
                                                                                options={provinceList}

                                                                                style={styles.bodyFrame3_pd}
                                                                                onSelect={(i,item)=>this.onSelectPd(i,item,0)}/>

                                                                  <PickDropdown clearDrop={cityClearDrop}
                                                                                defaultValue={cityList.length == 0
                                                                                    ? '正在加载'
                                                                                    : cityList[0].name}
                                                                                options={cityList}
                                                                                style={styles.bodyFrame3_pd}
                                                                                dropdownStyle={styles.bodyFrame3_pd2}
                                                                                onSelect={(i,item)=>this.onSelectPd(i,item,1)}/>
                                                              </View>


                                                              <SearchDDDIpt isSearch={false}
                                                                            frameStyle={styles.bodyFrame3_Frame}
                                                                            placeholder={"详细地址"}

                                                                            textChange={(text)=>this.onChangeText(text,2)}
                                                                            inputStyle={styles.bodyFrame3_input2}
                                                                            isPickDropdown1={false}
                                                                            isPickDropdown2={false}
                                                                            isPickDropdown3={false}/>
                                                          </View>
                                                      }/>
                                </View>
                                : null
                        }



                    </View>


                    <MenuBottom btnList={this.btnList}
                                isVisibleClose={false} />

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.initState(param.id);
                // this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    addressSelected:{
        backgroundColor:Theme.Colors.themeColor,
    },

    frameStyle:{
        marginTop:10,
    },

    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        // color:Theme.Colors.appRedColor,
        // backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
        // zIndex:999,
    },
    bodyFrame1:{
        flex:1,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,

    },
    bodyFrame3:{
        flexDirection:'row',
        flex:1,
        margin:10,
    },
    bodyFrame3_d:{
        borderBottomWidth:Theme.Border.borderWidth,
        borderBottomColor:Theme.Colors.themeColor,
        paddingBottom:10,
    },

    chkImage:{
        width:Theme.Font.fontSize1,
        height:Theme.Font.fontSize1 + "dw",
    },
    bodyFrame3_Frame:{
        justifyContent:"flex-start",
    },
    bodyFrame3_pdFrame:{
        flexDirection:'row',
        // marginRight:50,
    },
    bodyFrame3_pdFrame_1:{
        marginRight:50,
        marginLeft:10,
    },
    bodyFrame3_pd:{
        width:230,
    },
    bodyFrame3_pd2:{
        marginLeft:'0.7w',
    },
    bodyFrame3_input2:{
        width:570,
    },
    bodyFrame3_chk:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    bodyFrame3_input:{
        color:Theme.Colors.fontcolor,
        // width:'0.1w',
    },
    bodyFrame3_inputFrame:{
        // flex:1,
        width:'0.3w',
    },
    bodyFrame3_inputFrame0:{
        flex:3,
    },
    chkText:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.themeColor,
        marginLeft:3,
    },

    titleLabel:{
        color:Theme.Colors.themeColor,
    },

    bodyFrame_2:{
        alignItems:'center',
        justifyContent:'center',
    },
    bodyFrame_2_1:{
        marginTop:10
    },
    textIconFrame:{
        /*   borderColor:Theme.Colors.minorColor,
         borderWidth:Theme.Border.borderWidth,
         padding:10,
         borderRadius:Theme.Border.borderRadius,*/
    },
    iconStyle:{
        width:Theme.Font.fontSize_2,
        height:Theme.Font.fontSize_2 + "dw"
    },
    text:{
        fontSize:Theme.Font.fontSize_2,
        marginLeft:5,
    },

});
