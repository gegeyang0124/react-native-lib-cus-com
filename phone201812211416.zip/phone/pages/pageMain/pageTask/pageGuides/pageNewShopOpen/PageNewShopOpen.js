import {
    Theme,
} from 'com'
import {
    TabNavigator,
} from 'comThird'
import PageNewShopOpenSign from './pageNewShopOpenSign/PageNewShopOpenSign';
import PageNewShopOpenReady from "./pageNewShopOpenReady/PageNewShopOpenReady";
import PageNewShopOpenTrain from "./pageNewShopOpenTrain/PageNewShopOpenTrain";
import PageNewShopOpenOn from "./pageNewShopOpenOn/PageNewShopOpenOn";
import PageNewShopOpenMaterial from "./pageNewShopOpenMaterial/PageNewShopOpenMaterial";
import PageNewShopOpenExit from "./pageNewShopOpenExit/PageNewShopOpenExit";

const TabRouteConfigs = {
    PageNewShopOpenSign: {
        screen: PageNewShopOpenSign,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '签到',
            // swipeEnabled:false,
        },

    },
    PageNewShopOpenReady: {
        screen: PageNewShopOpenReady,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '开业准备',
            // swipeEnabled:false,
        },

    },
    PageNewShopOpenTrain: {
        screen: PageNewShopOpenTrain,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '人员培训',
            // swipeEnabled:false,
        },

    },
    PageNewShopOpenOn: {
        screen: PageNewShopOpenOn,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '人员培训',
            // swipeEnabled:false,
        },
    },
    PageNewShopOpenMaterial: {
        screen: PageNewShopOpenMaterial,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '资料签收',
            // swipeEnabled:false,
        },
    },
    PageNewShopOpenExit: {
        screen: PageNewShopOpenExit,
        navigationOptions: {
            title : '新店开业',
            tabBarLabel : '签退',
            // swipeEnabled:false,
        },
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;


