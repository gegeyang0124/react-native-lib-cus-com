import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import {ServiceCommon} from './../../ServiceCommon';

/**
 * 接口
 * **/
export class Service {


    static base;

    static retJson = {
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
    };//后台返回数据

    constructor() {
        Service.base = this;
    }

    /**
     * 提交签到
     * @param taskId string,//任务ID
     * @param commitDataList array,//需要提交的数据数组
     * **/
    static putIn(taskId,commitDataList){
        let imageSignInList = [];
        commitDataList.forEach((v,i,a)=>{
            imageSignInList.push(v.icon);
        });


        return new Promise((resolve, reject) => {

            if(imageSignInList.length == 0){
                reject({status:'无数据'});
            }

            Http.upLoadFileToService(imageSignInList,0)
                .then(retJson=>{

                    let requestData = [];
                    this.retJson.event_list.forEach((v,i,a)=>{
                        requestData.push({
                            task_operation_event_id:v.id,
                            value:v.type == '1'
                                ? retJson[0].servicePath
                                : JSON.stringify({
                                    address:commitDataList[0].address,
                                    location:{
                                        lat:commitDataList[0].lat,
                                        log:commitDataList[0].lng
                                    }
                                })
                        });
                    });

                    Http.post(HttpUrls.urlSets.urlSubmit, {
                        task_id:taskId,
                        event_value_array:requestData
                    })
                        .then((retJson)=>{

                            // resolve(retJson);
                            ServiceCommon.goNextStep(taskId, this.retJson.currentTaskId)
                                .then((retJson)=>{
                                    resolve(retJson);
                                });

                        });
                });


        });

    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * **/
    static getCurStepDetail(taskId){

        return ServiceCommon.getCurStepDetail(taskId).then(retJson=>{
            this.retJson = retJson;
            return retJson;
        });
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * @param currentTaskId string,//当前步骤ID
     * **/
    static goNextStep(taskId,currentTaskId){
        return Http.post(HttpUrls.urlSets.urlStep, {
            currentTaskId:currentTaskId,//当前步骤ID
            taskId:taskId
        })
            .then((retJson)=>{
                return {
                    pageCode:retJson.retData.front_code,
                    currentTaskId:data.retData.id,
                    event_list:data.retData.event_list,
                };
            });
    }

}