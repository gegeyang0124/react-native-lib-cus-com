import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import {ServiceCommon} from './../../ServiceCommon';

/**
 * 接口
 * **/
export class Service {


    static base;

    static retJson = {
        id:null,//任务ID
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
    };//后台返回数据

    constructor() {
        Service.base = this;
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * **/
    static getCurStepDetail(taskId){


        return new Promise((resolve, reject) => {
            ServiceCommon.getCurStepDetail(taskId)
                .then(retJson=>{
                    this.retJson = retJson;

                    Http.post(HttpUrls.urlSets.urlTaskDetail, {
                        showNullValue: 2,//附件，1:显示为空的元素 2:不显示为空的元素
                        task_id:taskId,//任务id
                    })
                        .then(retJson=>{
                            this.retJson.taskGuide = retJson.retData.taskGuide;
                            resolve(this.retJson);
                        });

                });
        });
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * @param currentTaskId string,//当前步骤ID
     * **/
    static goNextStep(taskId,currentTaskId){
        return ServiceCommon.goNextStep(this.retJson.id,this.retJson.currentTaskId)
            .then(retJson=>{
                return retJson;
            });
    }



    /**
     * 提交数据
     * @param taskId string,//任务ID
     * @param commitDataList array,//需要提交的数据数组
     * **/
    static putIn(commitDataList,taskId){
        taskId = taskId == undefined ? this.retJson.id : taskId;

        let imageSignInList = [];
        for(let i = 0; i < this.retJson.event_list.length; i++){
            commitDataList["imageList" + i].forEach((v,i1,a)=>{
                imageSignInList.push({
                    localPath:v,
                    type:i,
                    id:this.retJson.event_list[i].id
                });
            });
        }


        return new Promise((resolve, reject) => {

            /* if(imageSignInList.length == 0){
                 reject({status:'无数据'});
             }*/

            Http.upLoadFileToService(imageSignInList,0)
                .then(retJson=>{

                    let requestData = [];
                    this.retJson.event_list.forEach((v,i,a)=>{
                        let item = {
                            task_operation_event_id:v.id,
                            value:[]
                        };

                        imageSignInList.forEach((v1,i1,a1)=>{
                            if(v.id == v1.id){
                                item.value.push(v1.servicePath);
                            }

                        });
                        item.value = item.value.toString();
                        requestData.push(item);
                    });

                    Http.post(HttpUrls.urlSets.urlSubmit, {
                        task_id:taskId,
                        event_value_array:requestData
                    })
                        .then((retJson)=>{


                            ServiceCommon.goNextStep(taskId, this.retJson.currentTaskId)
                                .then((retJson)=>{
                                    resolve(retJson);
                                });

                        });
                });


        });

    }

}