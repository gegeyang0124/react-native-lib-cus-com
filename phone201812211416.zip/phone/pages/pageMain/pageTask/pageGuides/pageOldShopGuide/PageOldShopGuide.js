import {
    Theme,
} from './../../../../../component/component'
import {
    TabNavigator,
} from './../../../../../componentThird/component'
import PageOldShopGuideSign from './pageOldShopGuideSign/PageOldShopGuideSign';
import PageOldShopGuideReview from './pageOldShopGuideReview/PageOldShopGuideReview';
import PageOldShopGuideCheck from './pageOldShopGuideCheck/PageOldShopGuideCheck';
import PageOldShopGuideFollow from './pageOldShopGuideFollow/PageOldShopGuideFollow';
import PageOldShopGuideMaterial from './pageOldShopGuideMaterial/PageOldShopGuideMaterial';
import PageOldShopGuideExit from './pageOldShopGuideExit/PageOldShopGuideExit';

const TabRouteConfigs = {
    PageOldShopGuideSign: {
        screen: PageOldShopGuideSign,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '签到',
            // swipeEnabled:false,
        },

    },
    PageOldShopGuideReview: {
        screen: PageOldShopGuideReview,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '客户回顾',
            // swipeEnabled:false,
        },

    },
    PageOldShopGuideCheck: {
        screen: PageOldShopGuideCheck,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '店铺检查',
            // swipeEnabled:false,
        },

    },
    PageOldShopGuideFollow: {
        screen: PageOldShopGuideFollow,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '事项跟进',
            // swipeEnabled:false,
        },

    },
    PageOldShopGuideMaterial: {
        screen: PageOldShopGuideMaterial,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '资料签收',
            // swipeEnabled:false,
        },

    },
    PageOldShopGuideExit: {
        screen: PageOldShopGuideExit,
        navigationOptions: {
            title : '老店下店',
            tabBarLabel : '签退',
            // swipeEnabled:false,
        },

    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = pages;


