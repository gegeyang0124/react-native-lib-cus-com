/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    GuideImageHint,
    Image,
    ItemRowTitle,
    MenuBottom,
    Media,
    ImageList,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageOldShopGuideCheck extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.btnList = [
            {
                text:'拍摄',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.configData = {
            execFirst:true,
            type:null,//拍照选择图片类型值
        };

        this.state = {
            id:null,//任务ID
            // id:"f7c5647d-efe4-46c8-9ea6-736edb67db95",//任务ID
            // id:"8d4e3a32-54fb-4eaa-844e-eeb64ff85c4d",//任务ID

            /*imageList0:[
                'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
                'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg'
            ],*/
            imageList0:[],//门头区域 图片数组
            imageList1:[],//橱窗区域 图片数组
            imageList2:[],//服装区域(整体) 图片数组
            imageList3:[],//促销爆品集合货架区域 图片数组
            imageList4:[],//促销区域 图片数组
            imageList5:[],//商品区域 图片数组
            imageList6:[],//服装中岛区域 图片数组
            imageList7:[],//服装高柜区域 图片数组
            imageList8:[],//物料陈列 图片数组

            taskGuide:null,//巡店提示

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
            taskName:null,
        };
        /*[
            {
                // icon:require('./../../../../../../res/images/goodsImportant.png'),
                text:"签到地址:广东省广州市珠江东路6号\n签到时间:2018-06-25 15:33:33",
                icon:'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
            }
        ]*/

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    onGetPic = (item,i)=>{

        if(this.state["imageList" + this.configData.type].length > 5) {
            Tools.toast("照片数量已达到上线");
        }else{
            if(i == 0){
                Media.takeImage(this.state.taskName,true,()=>{
                    MenuBottom.show(false);
                }).then(retJson=>{

                        let stepFileList = [];
                        this.state["imageList" + this.configData.type].forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        stepFileList.push(retJson.path)

                        let obj = {};
                        obj["imageList" + this.configData.type] = stepFileList;
                        this.setState(obj);

                    });
            }
            else if(i == 1){
                MenuBottom.show(false);
                Media.pickImage(false,this.state.taskName).then(retJson=>{

                    let stepFileList = [];
                    this.state["imageList" + this.configData.type].forEach((v,i,a)=>{
                        stepFileList.push(v);
                    });
                    stepFileList.push(retJson.path)

                    let obj = {};
                    obj["imageList" + this.configData.type] = stepFileList;
                    this.setState(obj);
                });

            }
        }


    }

    showMenu(type){
        this.configData.type = type;

        MenuBottom.show(true);

    }

    onDelImage(imageList,item,i){
        this.state[imageList].splice(i, 1);
        let stepFileList = [];
        this.state[imageList].forEach((v,i,a)=>{
            stepFileList.push(v);
        });
        let obj = {};
        obj[imageList] = stepFileList;
        this.setState(obj);
    }

    getData(){
        Service.getCurStepDetail(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    componentDidMount() {
        // this.getData();
    }

    initState(id){
        let stateInit = {
            id:id,//任务ID
            // id:"f7c5647d-efe4-46c8-9ea6-736edb67db95",//任务ID
            // id:"8d4e3a32-54fb-4eaa-844e-eeb64ff85c4d",//任务ID

            /*imageList0:[
             'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
             'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg'
             ],*/
            imageList0:[],//门头区域 图片数组
            imageList1:[],//橱窗区域 图片数组
            imageList2:[],//服装区域(整体) 图片数组
            imageList3:[],//促销爆品集合货架区域 图片数组
            imageList4:[],//促销区域 图片数组
            imageList5:[],//商品区域 图片数组
            imageList6:[],//服装中岛区域 图片数组
            imageList7:[],//服装高柜区域 图片数组
            imageList8:[],//物料陈列 图片数组

            taskGuide:null,//巡店提示

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
        };
        this.state = stateInit;
        this.setState(stateInit);
    }
    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        // Service.goNextStep();
        Service.putIn(this.state)
            .then(retJson=>{
                // this.initState();
                Tools.stepInPage(retJson.pageCode,{id:retJson.id});
            });
    };

    render() {

        const {steps,imageList0,imageList1,imageList2,imageList3,imageList4,imageList5,
            imageList6,imageList7,imageList8,taskGuide} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                this.getData();
            }


            return (
                <ViewTitle viewBottom={"下一步"}
                           onPressBottom={this.onPressBottom}>

                    <GuideImageHint frameStyle={styles.frameStyle}
                                    dataList={steps}/>

                    <View style={styles.bodyFrame}>
                        <Image source={require('images/toastGuideCheck.png')}
                               style={styles.bodyIamge}>
                            <View style={[styles.bodyIamge,styles.toastFrame]}>
                                <View style={styles.toastFrame_1}>
                                    <Text style={styles.toastText}>
                                        {taskGuide}
                                    </Text>

                                </View>
                            </View>
                        </Image>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"门头区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(0)}/>

                        <ImageList dataList={imageList0}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList0",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"橱窗区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(1)}/>

                        <ImageList dataList={imageList1}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList1",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"服装区域(整体)"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(2)}/>

                        <ImageList dataList={imageList2}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList2",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"促销爆品集合货架区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(3)}/>

                        <ImageList dataList={imageList3}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList3",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"促销区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(4)}/>

                        <ImageList dataList={imageList4}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList4",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>


                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"商品区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(5)}/>

                        <ImageList dataList={imageList5}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList5",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"服装中岛区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(6)}/>

                        <ImageList dataList={imageList6}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList6",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"服装高柜区域"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(7)}/>

                        <ImageList dataList={imageList7}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList7",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>
                        <ItemRowTitle text1={"物料陈列"}
                                      text2={"上传附件"}
                                      onPressRight={()=>this.showMenu(8)}/>

                        <ImageList dataList={imageList8}
                            // dataList={imageList0}
                                   text={"删除"}
                                   onPressText={(item2,index)=>this.onDelImage("imageList8",item2,index)}
                                   textStyle={styles.imageTextStyle}
                                   iconStyle={styles.imageStyle}/>
                    </View>

                    <MenuBottom btnList={this.btnList}
                                isVisibleClose={false} />

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.initState(param.id);
                // this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        marginTop:10,
    },

    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },

    bodyIamge:{
        width:'w',
        height:200,
        // backgroundColor:'blue'
    },

    toastFrame:{
        marginLeft:-30,
        alignItems:'center',
        justifyContent:'center',
    },
    toastFrame_1:{
        alignItems:'center',
        justifyContent:'center',
        // backgroundColor:'white',
        width:'0.4w',
        height:180,
    },
    toastText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.foregroundColor,
        fontWeight:'900',
    },

    mainFrame:{

        borderTopWidth:Theme.Border.borderWidth,
        borderTopColor:Theme.Colors.minorColor,
    },

    titleTextFrame:{
        marginLeft:20,
    },
    titleText1:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    titleText2:{
        fontSize:Theme.Font.fontSize2,
        color:Theme.Colors.themeColor,
    },


});
