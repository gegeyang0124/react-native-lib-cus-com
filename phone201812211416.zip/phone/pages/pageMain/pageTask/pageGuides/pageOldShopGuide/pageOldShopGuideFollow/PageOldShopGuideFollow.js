/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,

} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    GuideImageHint,
    TextInputLabel,
    ItemRowTripApply
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageOldShopGuideFollow extends BaseComponent<Props> {

    constructor(props) {
        super(props);


        this.configData = {
            execFirst:true,
        };

        this.selectedValue = {
            taskId:null,     //类型：String  必有字段  备注：任务id
            taskVisitInfo:null,    //类型：String  必有字段  备注：巡店回访文字
            solveProblem:null  //类型：String  必有字段  备注：本次巡店解决问题

        };


        this.state = {
            id:null,//任务ID
            // id:"8d4e3a32-54fb-4eaa-844e-eeb64ff85c4d",//任务ID

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
        };


        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }



    getData(){
        this.selectedValue.taskId = this.state.id;
        Service.getCurStepDetail(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    onChangeText(text,type){
        if(type == 0){
            //巡店回访
            this.selectedValue.taskVisitInfo = text;
        }
        if(type == 1) {
            //巡店回访
            this.selectedValue.solveProblem = text;
        }
    }

    componentDidMount() {
        // this.getData();
    }

    initState(id){
        this.selectedValue = {
            taskId:null,     //类型：String  必有字段  备注：任务id
            taskVisitInfo:null,    //类型：String  必有字段  备注：巡店回访文字
            solveProblem:null  //类型：String  必有字段  备注：本次巡店解决问题
        };
        let stateInit = {
            id:id,//任务ID
            // id:"8d4e3a32-54fb-4eaa-844e-eeb64ff85c4d",//任务ID

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
        };
        this.state = stateInit;
        this.setState(stateInit);
    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        console.log(this.selectedValue)
        this.selectedValue.taskId=this.state.id
        // alert(JSON.stringify(this.selectedValue));

        Service.putIn(this.selectedValue)
            .then(retJson=>{
                this.initState();
                Tools.stepInPage(retJson.pageCode,{id:retJson.id});
            });
    };

    render() {

        const {steps} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        console.log(param)
        console.log(this.state.id)
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                this.getData();
            }


            return (
                <ViewTitle viewBottom={"下一步"}
                           onPressBottom={this.onPressBottom}>

                    <GuideImageHint frameStyle={styles.frameStyle}
                                    dataList={steps}/>
                    <Text style={{marginLeft:10,fontSize:20,marginTop:50}}>本次巡店发现的问题</Text>
                    <View style={styles.bodyFrame}>
                        <TextInput style={styles.TextInput} multiline={true} onChangeText={(text)=>this.onChangeText(text,0)}>
                            {`    [人]

    [店]

    [货]

    [策]
`}
                        </TextInput>

                    </View>
                    <Text style={{marginLeft:10,fontSize:20,marginTop:50}}>本次巡店解决的问题</Text>

                    <View style={styles.bodyFrame}>

                        <TextInput style={styles.TextInput} multiline={true} onChangeText={(text)=>this.onChangeText(text,1)}>
                            {`    [人]

    [店]

    [货]

    [策]
`}
                        </TextInput>
                    </View>


                </ViewTitle>
            );
        }
        else {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.initState(param.id);
                // this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        marginTop:10,
    },
    TextInput:{
        height:200,
        width:600,
        borderWidth:1,
        fontSize:20
    },

    bodyFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyIamge:{
        flex:1,
        width:300,
        height:400,
        marginTop:50
        // backgroundColor:'blue'
    },
    btn:{
        marginBottom:20,
        // marginTop:20,
    },
    titleFrameTop:{
        marginTop:20,
    },
});
