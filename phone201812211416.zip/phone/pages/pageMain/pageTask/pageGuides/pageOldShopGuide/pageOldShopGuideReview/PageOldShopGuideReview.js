/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    GuideImageHint,
    Image,
    ItemRowTitle,
    ItemRowReciew,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageOldShopGuideReview extends BaseComponent<Props> {

    constructor(props) {
        super(props);


        this.configData = {
            execFirst:true,
        };

        this.state = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID
            taskName:null,
            saleInfoList:[],//门店数据
            last_record_date:null,//巡店/回访记录,上一次巡店日期
            last_phone_record_date:null,//巡店/回访记录,上一次电话回访日期
            last_record_reOrder_date:null,//巡店/回访记录,上一次返单日期
            clientBalance:null,//客户余额

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
        };
        /*[
            {
                // icon:require('./../../../../../../res/images/goodsImportant.png'),
                text:"签到地址:广东省广州市珠江东路6号\n签到时间:2018-06-25 15:33:33",
                icon:'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
            }
        ]*/

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }


    getData(){

        Service.getCurStepDetail(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
            });

        Service.getShopData(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    componentDidMount() {
        // this.getData();
    }

    initState(id){
        let stateInit = {
            id:id,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            saleInfoList:[],//门店数据
            last_record_date:null,//巡店/回访记录,上一次巡店日期
            last_phone_record_date:null,//巡店/回访记录,上一次电话回访日期
            last_record_reOrder_date:null,//巡店/回访记录,上一次返单日期
            clientBalance:null,//客户余额

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
        };
        this.state = stateInit;
        this.setState(stateInit);
    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        Service.goNextStep()
            .then(retJson=>{
                // this.initState();
                Tools.stepInPage(retJson.pageCode,{id:retJson.id});
            });
    };

    renderItem = (item,i) =>{
        return(
            <ItemRowReciew key={i}
                           dataList={item}/>
        );
    };

    render() {

        const {steps,last_record_date,last_phone_record_date,
            last_record_reOrder_date,saleInfoList,clientBalance} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                this.getData();
            }


            return (
                <ViewTitle viewBottom={"下一步"}
                           onPressBottom={this.onPressBottom}>

                    <GuideImageHint frameStyle={styles.frameStyle}
                                    dataList={steps}/>

                    <View style={styles.bodyFrame}>
                        <Image source={require('images/bgToast.png')}
                               style={styles.bodyIamge}>
                            <View style={[styles.bodyIamge,styles.toastFrame]}>
                                <View style={styles.toastFrame_1}>
                                    <Text style={styles.toastText}>
                                        上一次巡店日期：{last_record_date == "" ? "该客户暂无巡店记录" : last_record_date}
                                    </Text>
                                    <Text style={styles.toastText}>
                                        上一次电话回访日期：{last_phone_record_date == "" ? "该客户暂无回访记录" : last_phone_record_date}
                                    </Text>
                                    <Text style={styles.toastText}>
                                        上一次返单：{last_record_reOrder_date == "" ? "该客户暂无返单记录" : last_record_reOrder_date}
                                    </Text>
                                </View>
                            </View>
                        </Image>
                    </View>


                    <View style={[styles.bodyFrame,styles.bodyFrame2]}>

                        <ItemRowTitle viewLeft={
                            <View style={styles.titleTextFrame}>
                                <Text style={styles.titleText1}>
                                    账户余额
                                </Text>
                                <Text style={styles.titleText2}>
                                    {clientBalance}元
                                </Text>
                            </View>
                        }/>

                        <View style={styles.mainFrame}>

                            {
                                saleInfoList.map(this.renderItem)
                            }

                        </View>

                    </View>


                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.initState(param.id);
                // this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        marginTop:10,
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },

    bodyIamge:{
        width:'w',
        height:200,
        // backgroundColor:'blue'
    },

    toastFrame:{
        marginLeft:40,
        alignItems:'center',
        justifyContent:'center',
    },
    toastFrame_1:{
        alignItems:'flex-end',
        justifyContent:'center',
        // backgroundColor:'white',
    },
    toastText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.foregroundColor,
        fontWeight:'900',
    },

    mainFrame:{

        borderTopWidth:Theme.Border.borderWidth,
        borderTopColor:Theme.Colors.minorColor,
    },

    titleTextFrame:{
        marginLeft:20,
    },
    titleText1:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    titleText2:{
        fontSize:Theme.Font.fontSize2,
        color:Theme.Colors.themeColor,
    },
});
