import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import {ServiceCommon} from './../../ServiceCommon';

/**
 * 接口
 * **/
export class Service {


    static base;

    static retJson = {
        id:null,//任务ID
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
    };//后台返回数据

    constructor() {
        Service.base = this;
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * **/
    static getCurStepDetail(taskId){

        return ServiceCommon.getCurStepDetail(taskId)
            .then(retJson=>{
            this.retJson = retJson;
            return retJson;
        });
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * @param currentTaskId string,//当前步骤ID
     * **/
    static goNextStep(taskId,currentTaskId){
        return ServiceCommon.goNextStep(taskId,currentTaskId)
            .then(retJson=>{
                return retJson;
            });
    }

    /**
     * 获取巡店任务详情
     * @param taskId string,//任务ID
     * **/
    static getShopData(taskId){

        return new Promise((resolve, reject) => {

            Http.post(HttpUrls.urlSets.urlTaskDetail, {
                showNullValue: 2,//附件，1:显示为空的元素 2:不显示为空的元素
                task_id:taskId,//任务id
            },false)
                .then((retJson)=>{

                    let storecode = retJson.retData.task.object_id;//客户id

                    Http.post(HttpUrls.urlSets.urlShopInfo, {
                        // taskId:taskId,//任务id
                        storecode:storecode,//客户id
                    })
                        .then((retJson)=>{

                            let retObj = {
                                saleInfoList:[
                                    [
                                        {
                                            text1:'本月营业额',
                                            text2:retJson.retData.data.this_sales_amount + "元"
                                        },
                                        {
                                            text1:'上月营业额',
                                            text2:retJson.retData.data.prev_sales_amount + "元"
                                        },
                                        {
                                            text1:'环比增长率',
                                            text2:retJson.retData.data.qoq_month_sale_amount + "%"
                                        }
                                    ],
                                    [
                                        {
                                            text1:'本月客单价',
                                            text2:retJson.retData.data.this_single_price + "元"
                                        },
                                        {
                                            text1:'上月客单价',
                                            text2:retJson.retData.data.prev_single_price + "元"
                                        },
                                        {
                                            text1:'环比增长率',
                                            text2:retJson.retData.data.qoq_single_price + "%"
                                        }
                                    ],
                                    [
                                        {
                                            text1:'本月客单量',
                                            text2:retJson.retData.data.this_order_count + "元"
                                        },
                                        {
                                            text1:'上月客单量',
                                            text2:retJson.retData.data.pre_order_count + "元"
                                        },
                                        {
                                            text1:'环比增长率',
                                            text2:retJson.retData.data.qoq_order_count + "%"
                                        }
                                    ],
                                    [
                                        {
                                            text1:'本月毛利额',
                                            text2:retJson.retData.data.this_gross_profit + "元"
                                        },
                                        {
                                            text1:'',
                                            text2:""
                                        },
                                        {
                                            text1:'库存额',
                                            text2:retJson.retData.data.this_inventory_count + "元"
                                        }
                                    ],
                                    [
                                        {
                                            text1:'本月新增会员',
                                            text2:retJson.retData.data.monthMemberCount + "人"
                                        },
                                        {
                                            text1:'',
                                            text2:''
                                        },
                                        {
                                            text1:'会员总数',
                                            text2:retJson.retData.data.thisMemberCount + "人"
                                        }
                                    ]
                                ],
                                clientBalance:retJson.retData.data.clientBalance,//客户余额
                            };

                            retObj.last_record_date = retJson.retData.data.last_record_date;//巡店/回访记录,上一次巡店日期
                            retObj.last_phone_record_date = retJson.retData.data.last_phone_record_date;//巡店/回访记录,上一次电话回访日期
                            retObj.last_record_reOrder_date = retJson.retData.data.last_record_reOrder_date;//巡店/回访记录,上一次返单日期
                            resolve(retObj);
                        });
                });
        });

    }

}