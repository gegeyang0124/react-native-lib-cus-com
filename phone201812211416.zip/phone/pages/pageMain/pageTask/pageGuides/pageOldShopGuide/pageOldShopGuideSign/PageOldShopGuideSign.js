/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    GuideImageHint,
    Image,
    ButtonChange,
    ImageList,
    Media,
    MenuBottom,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageOldShopGuideSign extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.btnList = [
            {
                text:'拍照',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];


        this.configData = {
            execFirst:true,
        };

        this.state = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID
            imageSignInList:[],//签到数据

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
            taskName:null,
        };
        /*[
            {
                // icon:require('./../../../../../../res/images/goodsImportant.png'),
                text:"签到地址:广东省广州市珠江东路6号\n签到时间:2018-06-25 15:33:33",
                icon:'http://static.lexin580.com/files/ProductPicture\\fffbc94e-7dfc-4a47-95e2-2bafa8fa3392_20180503142658.jpg',
            }
        ]*/

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    onGetPic = (item,i)=>{

        let imageSignInList = [];
        if(i == 0){

            Media.takeImage(this.state.taskName,true,()=>{
                MenuBottom.show(false);
            })
                .then(retJson=>{

                let data = {
                    icon:null,
                    lat:retJson.lat,//维度
                    lng:retJson.lng,//经度
                    address:retJson.address,
                    text:"签到地址:" + retJson.address + "\n签到时间:" + Tools.timeFormatConvert(retJson.timestamp,"YYYY-MM-DD HH:mm:ss")
                }

                data.icon = retJson.path;
                imageSignInList.push(data);

                this.setState({
                    imageSignInList:imageSignInList
                });
            })

        }
        else if(i == 1){

            MenuBottom.show(false);
            Media.pickImage(false,this.state.taskName).then(retJson=>{

                let data = {
                    icon:null,
                    lat:retJson.lat,//维度
                    lng:retJson.lng,//经度
                    address:retJson.address,
                    text:"签到地址:" + retJson.address + "\n签到时间:" + Tools.timeFormatConvert(retJson.timestamp,"YYYY-MM-DD HH:mm:ss")

                }

                // MenuBottom.show(false);

                data.icon = retJson.path;
                imageSignInList.push(data);

                this.setState({
                    imageSignInList:imageSignInList
                });

            });
        }
    }

    getData(){
        Service.getCurStepDetail(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
            });
    }

    componentDidMount() {
        // this.getData();
    }

    initState(id){
        let stateInit = {
            id:id,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID
            imageSignInList:[],//签到数据

            steps:[],//导航提示步骤
            pageCode:null,//要进入页面的编码
        };
        this.state = stateInit;
        this.setState(stateInit);
    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        Service.putIn(this.state.id,this.state.imageSignInList)
            .then(retJson=>{
                // this.initState();
                Tools.stepInPage(retJson.pageCode,{id:retJson.id});
            })
            .catch((retJson)=>{
                Tools.toast("主人，你还没有签到哦！");
            });
    };

    render() {

        const {imageSignInList,steps} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                this.getData();
            }


            return (
                <ViewTitle viewBottom={"下一步"}
                           onPressBottom={this.onPressBottom}>

                    <GuideImageHint frameStyle={styles.frameStyle}
                                    dataList={steps}/>

                    <View style={styles.bodyFrame}>

                        <Image source={require('images/imageFrame.png')}
                               style={styles.bodyIamge}>
                            <ImageList dataList={imageSignInList}/>
                        </Image>

                        <ButtonChange text={"拍照定位"}
                                      onPress={()=>MenuBottom.show(true)}
                                      frameStyle={styles.btn}/>

                    </View>

                    <MenuBottom btnList={this.btnList}
                                isVisibleClose={false}/>

                </ViewTitle>
            );
        }
        else {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.initState(param.id);
                // this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        marginTop:10,
    },

    bodyFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyIamge:{
        flex:1,
        width:300,
        height:400,
        // backgroundColor:'blue'
    },
    btn:{
        marginBottom:20,
        // marginTop:20,
    },
});
