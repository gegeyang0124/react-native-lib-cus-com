
import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird'
import PageImportmentCaseAdd from "./pageImportmentCaseAdd/PageImportmentCaseAdd";
import PageImportmentCaseDetail from "./pageImportmentCaseDetail/PageImportmentCaseDetail";
import PageImportmentCaseActivityDetail from "./pageImportmentCaseActivityDetail/PageImportmentCaseActivityDetail";
import PageImportmentCaseList from "./pageImportmentCaseList/PageImportmentCaseList";
import PageImportCaseCDetail from "./pageImportCaseCDetail/PageImportCaseCDetail";

const TabRouteConfigs = {
    PageImportmentCaseAdd: {
        screen: PageImportmentCaseAdd,
        navigationOptions: ({navigation}) => ({
            title : '创建重点任务',
            tabBarLabel : '创建重点任务',
        }),
    },
    PageImportmentCaseDetail: {
        screen: PageImportmentCaseDetail,
        navigationOptions: ({navigation}) => ({
            title : '活动详情',
            tabBarLabel : '活动详情',
        }),
    },
    PageImportmentCaseActivityDetail: {
        screen: PageImportmentCaseActivityDetail,
        navigationOptions: ({navigation}) => ({
            title : '跟踪详情',
            tabBarLabel : '跟踪详情',
        }),
    },
    PageImportCaseCDetail: {
        screen: PageImportCaseCDetail,
        navigationOptions: ({navigation}) => ({
            title : 'C端活动详情',
            tabBarLabel : 'C端活动详情',
        }),
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

const PageImportmentCases = {
    get PageImportmentCases() {
        return pages;
    },
    get PageImportmentCaseList() {
        return PageImportmentCaseList;
    }
};

module.exports = PageImportmentCases;