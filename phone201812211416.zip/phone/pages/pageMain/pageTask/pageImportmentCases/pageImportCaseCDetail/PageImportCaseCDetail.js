/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTripApply,
    ItemRowTitle,
    Media,
    ImageList,
    VideoList,
    DatePicker,
    MenuBottomApi,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageImportCaseCDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            // currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            execFirst:true,
            i:0,//附件数组地址
            isVideo:false,//是否是视频？
        };

        this.btnList = [
            {
                text:'拍摄',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.state = {
            id:null,  //任务id
            name:null,//任务名称 C端活动名称
            customerName:null,//客户名称
            executorName:null, //申请人
            beginDate:null,//开始时间
            endDate:null,//结束时间
            taskStatus:null,//执行状态
            isProTask:false, //是否允许上传文件 true:允许 false:不允许
            stepFileList:[],//附件数组
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    componentWillEnter(param){
        if(param){
            this.state.id = param.id;
            this.getData();
        }
    }

    getData() {
        Service.getDetail(this.state.id).then(retJson=>{
            this.setState(retJson);
        });
    }

    onDelImage(imageList,item,i,i2){
        this.state.stepFileList[i2].fileList.splice(i, 1);
        let stepFileList = [];
        this.state.stepFileList.forEach((v,i,a)=>{
            stepFileList.push(v);
        });
        this.setState({
            stepFileList:stepFileList
        });
    }

    showMenu(isVideo,i){
        this.configData.i = i;
        this.configData.isVideo = isVideo;

        MenuBottomApi.show(this.btnList);

    }

    onGetPic = (item,i)=>{
        // MenuBottomApi.hide();
        if(this.state.stepFileList[this.configData.i].fileList.length > 5){
            Tools.toast("照片数量已达到上线");
        }else{

            if(i == 0){
                if(this.configData.isVideo){
                    //MenuBottomApi.hide();
                    Media.takeVideo().then(retJson=>{
                        MenuBottomApi.hide();
                            let stepFileList = [];
                            this.state.stepFileList.forEach((v,i,a)=>{
                                stepFileList.push(v);
                            });
                            stepFileList[this.configData.i].fileList.push(retJson.uri)

                            this.setState({
                                stepFileList:stepFileList
                            });
                        });
                }
                else {
                    Media.takeImage(this.state.taskName,false,()=>{
                        // MenuBottomApi.hide();
                    }).then(retJson=>{
                        MenuBottomApi.hide();
                            let stepFileList = [];
                            this.state.stepFileList.forEach((v,i,a)=>{
                                stepFileList.push(v);
                            });
                            stepFileList[this.configData.i].fileList.push(retJson.path)

                            this.setState({
                                stepFileList:stepFileList
                            });
                        });
                }

            }
            else if(i == 1)
            {
                if(this.configData.isVideo){
                    // MenuBottomApi.hide();
                    Media.pickVideo().then(retJson=>{
                        MenuBottomApi.hide();
                        let stepFileList = [];
                        this.state.stepFileList.forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        stepFileList[this.configData.i].fileList.push(retJson.path)

                        this.setState({
                            stepFileList:stepFileList
                        });

                    })
                }
                else {

                    Media.pickImage(false,this.state.taskName,false)
                        .then(retJson=>{
                            MenuBottomApi.hide();
                        let stepFileList = [];
                        this.state.stepFileList.forEach((v,i,a)=>{
                            stepFileList.push(v);
                        });
                        stepFileList[this.configData.i]
                            .fileList.push(retJson.path);

                        this.setState({
                            stepFileList:stepFileList
                        });

                    });
                }

            }
        }


    }

    renderItem = (item,i)=>{
        const {isProTask} = this.state;
        let imageList = [];
        let isVideo = false;
        item.fileList.forEach((v,i,a)=>{
            if(v.indexOf(".mp4") > -1){
                isVideo = true;
                imageList.push({
                    uri:v
                });
            }
            else {
                imageList.push({
                    icon:v
                });
            }
        });

        return(
            <View key={i}
                  style={styles.titleFrame_1_1}>
                <ItemRowTitle text1={item.name}
                              text2={isProTask ? "上传附件" : null}
                              onPressRight={()=>this.showMenu(isVideo,i)}/>
                {
                    imageList.length > 0
                        ? isVideo
                        ? <VideoList dataList={imageList}
                                     text={isProTask ? "删除" : null}
                                     onPressText={(item2,index)=>this.onDelImage(imageList,item2,index,i)}
                                     textStyle={styles.imageTextStyle}
                                     iconStyle={styles.imageStyle}/>
                        : <ImageList dataList={imageList}
                                     isShowText={isProTask}
                                     text={"删除"}
                                     onPressText={(item2,index)=>this.onDelImage(imageList,item2,index,i)}
                                     textStyle={styles.imageTextStyle}
                                     iconStyle={styles.imageStyle}/>
                        : null
                }

            </View>
        );
    };

    showDate(val){
        this.configData.isStartTime = val;
        this.datePicker.show();
    }

    setTime = (date)=>{
        let time = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm:ss");

        if(this.configData.isStartTime)
        {
            if(date < Tools.timeFormatConvert(this.state.end_time))
            {
                this.setState({
                    begin_time:time
                });
            }
            else
            {
                Tools.toast("开始时间必须小于结束时间");
            }
        }
        else
        {
            if(date > Tools.timeFormatConvert(this.state.begin_time))
            {
                this.setState({
                    end_time:time
                });
            }
            else
            {
                Tools.toast("结束时间必须大于开始时间");
            }

        }
    }

    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
    }

    componentWillReceiveProps(){

    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = ()=>{
        Service.alterGuideTask(this.state)
            .then(retJson=>{
            Tools.toast("提交成功");
            this.getData();
        });
    };

    render() {
        const {taskStatus,name,customerName,executorName,beginDate,endDate,
            stepFileList,isProTask} = this.state;

        return (
            <ViewTitle viewBottom={isProTask ? "提交" : null}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>
                    <ItemRowTripApply text={"C端活动:"}
                                      frameLabelStyle={styles.itemRowLabel_1}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={name}/>

                    <ItemRowTripApply text={"客户姓名:"}
                                      frameLabelStyle={styles.itemRowLabel_1}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={customerName}/>

                    <ItemRowTripApply text={"执  行  人:"}
                                      frameLabelStyle={styles.itemRowLabel_1}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      // onPressRight={()=>this.showDate(true)}
                                      text2={executorName}/>

                    <ItemRowTripApply text={"执行时间:"}
                                      frameLabelStyle={styles.itemRowLabel_1}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      // onPressRight={()=>this.showDate(false)}
                                      text2={beginDate + ' ~ ' + endDate}/>


                    <ItemRowTripApply text={"状        态:"}
                                      frameLabelStyle={styles.itemRowLabel_1}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={Tools.statusConvert(taskStatus).text}/>

                </View>

                <View style={styles.titleFrame_1}>

                    {
                        stepFileList.map(this.renderItem)
                    }


                </View>


            </ViewTitle>
        );


    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    itemRow:{
        flex:1,
        flexDirection: 'row',
    },
    itemRowLabel:{
        // backgroundColor:'yellow',
        flex:4,
    },
    itemRowLabelText:{
        color:Theme.Colors.fontcolor,
    },
    itemRowLabel_1:{
        // backgroundColor:'yellow',
        // flex:3.3,
    },
    itemRowLabel_2:{
        // backgroundColor:'yellow',
        flex:2.8,
    },
    titleFrame_1: {
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    titleFrame_1_1:{
        marginBottom:10,
    },
    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },
});
