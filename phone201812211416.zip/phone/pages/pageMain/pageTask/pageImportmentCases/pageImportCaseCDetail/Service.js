import {
    Http,
    HttpUrls,
    Tools,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据

    /**
     * 获取C端活动详情
     * @param taskId string,//任务ID
     * **/
    static getDetail(taskId){

        return Http.post(HttpUrls.urlSets.urlImportmentCaseCDetail, {
            taskId//任务id
        })
            .then((retJson)=>{
                if(!retJson.retData.stepFileList)
                {
                    let stepFileList = [];

                    let cEventPlan = {
                        filed:'cEventPlan',
                        name:"活动方案",
                        fileList:[]
                    }
                    if(retJson.retData.cEventPlan)
                    {
                        cEventPlan.fileList = retJson.retData.cEventPlan.split(',');
                    }
                    stepFileList.push(cEventPlan);

                    let cEventScenePhotos = {
                        filed:'cEventScenePhotos',
                        name:"现场照片",
                        fileList:[]
                    }
                    if(retJson.retData.cEventScenePhotos)
                    {
                        cEventScenePhotos.fileList = retJson.retData.cEventScenePhotos.split(',');
                    }
                    stepFileList.push(cEventScenePhotos);

                    retJson.retData.stepFileList = stepFileList;

                    //是否允许上传文件 1.允许 2.不允许
                    retJson.retData.isProTask
                        = retJson.retData.allowUploadFile == 1
                        ? true
                        : false;

                    return retJson.retData;
                }

            });

    }

    /**
     * 修改巡店任务
     * @param selectObj json,//任务ID
     {
           // id:null,  //任务id
           id:"d3172fc6-8729-4e46-a763-a67637b82930",  //任务id

           number:null,//任务编码
           name:null,//任务名称
           templateNameParent:null,//任务类型 大类名称
           clientId:null,
           clientName:null,
           position:null,//职位名称
           template_id:null, //巡店类型id
           templateName:null,//巡店任务类型名称
           department_id:null,//部门名称id
           department_name:null,//部门名称
           executor:null,//申请人id
           executorName:null, //申请人
           begin_time:null,//开始时间
           end_time:null,//结束时间
           priority:null,//优先级
           timeLengVisitShop:null,//巡店总用时
           signIn:'',//签到
           signOut:'',//签退
           stepFileList:[],//附件数组
           }
    * **/
    static async alterGuideTask(selectObj){

        let stepFileList = [];
        selectObj.stepFileList.forEach((v,i,a)=>{
            v.fileList.forEach((v1,i1,a1)=>{
                stepFileList.push({
                    filed:v.filed,
                    name:v.name,
                    localPath:v1
                });
            });
        });

        let retJson = await Http.upLoadFileToService(stepFileList);

        let requestData = {
            taskId:selectObj.id, //类型：String  必有字段  备注：任务id
            // cEventPlan:'', //类型：String  必有字段  备注：活动方案文件地址 多个用,隔开
            // cEventScenePhotos:'' //类型：String  必有字段  备注：现场照片地址 多个用,隔开
        };

        retJson.forEach((v,i,a)=>{

            if(!requestData[v.filed]){
                requestData[v.filed] = [];
            }

            requestData[v.filed].push(v.servicePath);
        });

        for(let key in requestData){
            if(key != "taskId"){
                requestData[key] = requestData[key].toString();
            }
        }

        return Http.post(HttpUrls.urlSets.urlImportmentCaseCPut, requestData);

    }

}