/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    GuideImageHint,
    ItemRowTitle,
    ImageList,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageImportmentCaseActivityDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.steps = [
            {text:'活动\n方案',status:0},
            {text:'异业\n联盟',status:0},
            {text:'物料',status:0},
            {text:'活动\n宣传',status:0},
            {text:'活动\n培训',status:0},
            {text:'培训\n总结',status:0}
        ];//导航提示步骤

        this.configData = {
            execFirst:true,
            type:null,//拍照选择图片类型值
        };

        this.state = {
            id:null,//任务ID
            // id:"faeea800-e510-4035-8ee0-169c0dd423b1",  //任务id

            event_list:[],//附件列

            steps:[],//导航提示步骤


        };


        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    /**
     * 获取重点专案 活动模版详情
     * @param stepName string,//步骤名称
     * **/
    getData(stepName){
        Service.getImportmentCaseAcitvityDetail(this.state.id,stepName)
            .then(retJson=>{

                let steps = [];
                this.steps.forEach((v,i,a)=>{
                    v.status = 0;
                    steps.push(v);
                });

                steps.forEach((v,i,a)=>{
                    let s = v.text;
                    // console.info("s:",s);
                    s = s.replace("\n","");
                    if(stepName == s){
                        v.status = 1;
                    }
                });

                this.setState({
                    event_list:retJson,
                    steps:steps
                });
            });
    }

    componentDidMount() {
        // this.getData();
    }

    renderItemImageList = (item,i)=>{
        return(
            <ImageList key={i}
                       dataList={item}
                       isScroll={false}
                       isShowText={false}
                       imageFrameStyle={styles.imageStyle}
                       frameStyle={styles.imageFrameStyle}
                       iconStyle={styles.imageStyle}/>
        );
    }

    renderItem = (item,i)=>{
        return(
            <View key={i}
                  style={[styles.bodyFrame,styles.bodyFrame2]}>
                <ItemRowTitle text1={item.title}/>
                {
                    item.filesList.map(this.renderItemImageList)
                }
            </View>
        );
    }

    onPressTitle = (item,i)=>{
        let stepName = item.text;
        stepName = stepName.replace("\n",'');
        this.getData(stepName);
        // alert(JSON.stringify(i))
    }

    init(){
        this.configData.execFirst = false;
        let stepName = this.steps[0].text;
        stepName = stepName.replace("\n",'');
        this.getData(stepName);
    }

    render() {

        const {steps,event_list} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.init();
            }


            return (
                <ViewTitle>

                    <GuideImageHint frameStyle={styles.frameStyle}
                                    dataList={steps}
                                    onPress={this.onPressTitle}/>

                    {
                        event_list.map(this.renderItem)
                    }

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        marginTop:10,
    },

    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:140,
        height:'140dw',
        // backgroundColor:'yellow',
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        /*alignItems:'center',
        justifyContent:'center',*/
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },

    bodyIamge:{
        width:'w',
        height:200,
        // backgroundColor:'blue'
    },

    toastFrame:{
        marginLeft:-55,
        alignItems:'center',
        justifyContent:'center',
    },
    toastFrame_1:{
        alignItems:'center',
        justifyContent:'center',
        // backgroundColor:'white',
        width:'0.5w',
        height:180,
        marginLeft:110,
        // marginTop:-50,
    },
    toastText:{
        fontSize:Theme.Font.fontSize_1_1,
        color:Theme.Colors.foregroundColor,
        fontWeight:'900',
    },

    mainFrame:{

        borderTopWidth:Theme.Border.borderWidth,
        borderTopColor:Theme.Colors.minorColor,
    },

    titleTextFrame:{
        marginLeft:20,
    },
    titleText1:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.minorColor,
    },
    titleText2:{
        fontSize:Theme.Font.fontSize2,
        color:Theme.Colors.themeColor,
    },


    imageFrameStyle:{
        marginBottom:5,
    },
    imageFrameLeftStyle:{
        alignItems:'flex-start',
        justifyContent:'flex-start',
    },
});
