import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     * 获取重点专案 活动模版详情
     * @param taskId string,//任务ID
     * @param stepName string,//步骤名称
     * **/
    static getImportmentCaseAcitvityDetail(taskId,stepName){
        return Http.post(HttpUrls.urlSets.urlImportmentCaseActivityDetail,{
            taskId:taskId, //类型：String  必有字段  备注：id
            stepName:stepName //类型：String  必有字段  备注：步骤名称
        })
            .then(retJson=>{
                let retObjList = [];
                if(retJson.retListData && retJson.retListData.length > 0){
                    if(typeof(retJson.retListData[0]) == 'string'){
                        retObjList.push({
                            title:stepName,
                            filesList:retJson.retListData
                        })
                    }
                    else {
                        retObjList = retJson.retListData;
                    }

                    retObjList.forEach((v,i,a)=>{
                        let filesList = v.filesList;
                        let count = 5;
                        let index = -1;
                        v.filesList = [];
                        filesList.forEach((v1,i1,a1)=>{
                            if((i1 % count) == 0){
                                v.filesList.push([v1]);
                                ++index;
                            }
                            else {
                                v.filesList[index].push(v1);
                            }
                        });

                        if(index > -1){
                            let len = v.filesList[index].length;
                            if(len < count){
                                for(let ii = 0; ii < count - len; ii++){
                                    v.filesList[index].push([]);
                                }
                            }
                        }
                    });
                }

                // console.info("retObjList:",retObjList);
                return retObjList;
            });
    }



}