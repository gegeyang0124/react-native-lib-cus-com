/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
    ImageBackground,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
    ItemRowTripApply,
    ItemRowGuideTripApply,
    DatePicker,
    ItemRowGuideApplyType,
    SearchDDDIpt,
    ItemRowFeedback,
    Image,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageImportmentCaseAdd extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            btn:null,
            isRenderItemFirst:true,
        };

        this.selectedValue = {
            name:"", //类型：String  必有字段  备注：重点专案名称
            department_id:Tools.userConfig.userInfo.department_id, //类型：String  必有字段  备注：区域id
            begin_time:Tools.timeFormatConvert(this.configData.currentTime,"YYYY-MM-DD HH:mm:ss"),//开始时间
            end_time:Tools.timeFormatConvert(this.configData.currentTime + Tools.ONE_DAY_TIME - 1000 ,"YYYY-MM-DD HH:mm:ss"),//结束时间
            template_id:null,//类型：String  必有字段  备注：重点专案类型
            achievementTarget:'',//类型：String  可有字段  备注：业绩目标 (类型为产品动销跟踪时必传)
            statisticalConditionsType:'2',//类型：String  可有字段  备注：统计条件类型 (类型为产品动销跟踪时必传) 分类
            statisticalConditions:null //类型：String  可有字段  备注：统计条件 (类型为产品动销跟踪时必传) Sku/品牌/品类
        };

        this.state = {
            defaultValueDptname:Tools.userConfig.userInfo.department_name,//默认部门名
            departmentList:[],//部门列
            taskTypeList:[],//任务类型列表
            isShow:false,//是否显示 业绩目标和统计条件
            productTypeList:[],//品类
            brandTypeList:[],//品牌
            clearDrop:true,//重置 品类 品牌
            beginTime:Tools.timeFormatConvert(this.selectedValue.begin_time,"YYYY-MM-DD HH:mm"),
            endTime:Tools.timeFormatConvert(this.selectedValue.end_time,"YYYY-MM-DD HH:mm"),

            typesList:[
                {name:'商品分类',id:1},
                {name:'商品品牌',id:0},
                {name:'商品SKU',id:2}
            ],//类别列选择
            isPickDropdown3:false,//统计条件 是否显示下拉框3
            isPickDropdown2:true,//统计条件 是否显示下拉框1
            isShowTextInput:false,//统计条件 是否显示Sku输入框
        };


        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    setTime = (date)=>{
        let time1 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm:ss");
        let time2 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm");
        /* this.date = "date:" + date + "\ntime1: " + time1
             + "\n e:" + this.selectedValue.end_time + "\n et:" + Tools.timeFormatConvert(this.selectedValue.end_time);
         this.setState({
             beginTime:this.selectedValue.begin_time
         });*/
        if(this.configData.isStartTime)
        {
            if(date < Tools.timeFormatConvert(this.selectedValue.end_time))
            {
                this.selectedValue.begin_time = time1;
                this.setState({
                    beginTime:time2
                });
            }
            else
            {
                Tools.toast("开始时间必须小于结束时间");
            }
        }
        else
        {
            if(date > Tools.timeFormatConvert(this.selectedValue.begin_time))
            {
                this.selectedValue.end_time = time1;
                this.setState({
                    endTime:time2
                });
            }
            else
            {
                Tools.toast("结束时间必须大于开始时间");
            }

        }
    }

    onSelectDrop(val,i,type){
        // alert(JSON.stringify(val));
        // console.info('onSelectDrop',val)

        switch (type)
        {
            case 0:{
                this.selectedValue.department_id = val.id;

                break;
            }
            case 1:{
                this.selectedValue.template_id = val.id;

                this.setState({
                    isShow:this.selectedValue.template_id == Tools.userConfig.imgportmentCaseActivityFollowId
                        ? false
                        : true
                });
                break;
            }
            case 2: {
                this.selectedValue.statisticalConditionsType = val.id + 1 + '';
                switch (val.id){
                    case 0:{

                        this.selectedValue.statisticalConditions = this.state.brandTypeList.length > 0
                            ? this.state.brandTypeList[0].id
                            : null;
                        if(!this.state.isPickDropdown3){
                            this.setState({
                                clearDrop:false,
                                isPickDropdown2:false,
                                isPickDropdown3:true,
                                isShowTextInput:false,
                            });
                        }

                        break;
                    }
                    case 1:{
                        this.selectedValue.statisticalConditions = this.state.productTypeList.length > 0
                            ? this.state.productTypeList[0].type_code
                            : null;
                        if(!this.state.isPickDropdown2){
                            this.setState({
                                clearDrop:false,
                                isPickDropdown2:true,
                                isPickDropdown3:false,
                                isShowTextInput:false,
                            });
                        }
                        break;
                    }
                    case 2:{
                        this.selectedValue.statisticalConditions = null;
                        if(!this.state.isShowTextInput){
                            this.setState({
                                clearDrop:false,
                                isPickDropdown2:false,
                                isPickDropdown3:false,
                                isShowTextInput:true,
                            });
                        }
                        break;
                    }
                }

                break;
            }
            case 3 :{
                this.selectedValue.statisticalConditions = val.type_code;
                if(this.state.clearDrop){
                    this.setState({
                        clearDrop:false,
                    });
                }

                break;
            }
            case 4: {
                this.selectedValue.statisticalConditions = val.id;
                if(this.state.clearDrop){
                    this.setState({
                        clearDrop:false,
                    });
                }

                break;
            }
            case 5: {
                this.configData.isStartTime = val;
                this.datePicker.show();
                break;
            }
            case 6: {
                // this.goPage("PageGuideApply");
                break;
            }
        }
    }

    getSelectData(){
        Service.getDepartments()
            .then(retJson=>{
                this.setState({
                    departmentList:retJson
                });
            });

        Service.getTaskTypes()
            .then(retJson=>{
                console.log(retJson)
                this.selectedValue.template_id = retJson.length > 0
                    ? retJson[0].id
                    : null;

                this.setState({
                    isShow:this.selectedValue.template_id == Tools.userConfig.imgportmentCaseActivityFollowId
                        ? false
                        : true ,
                    taskTypeList:retJson
                });
            });

        Service.getProductTypes()
            .then(retJson=>{

                this.selectedValue.statisticalConditions = retJson.length > 0
                    ? retJson[0].type_code
                    : null;
                this.setState({
                    productTypeList:retJson
                });
            });

        Service.getBrandTypes()
            .then(retJson=>{
                this.setState({
                    brandTypeList:retJson
                });
            });
    }

    onChangeText = (text,type)=>{
        switch (type){
            case 0:{
                this.selectedValue.name = text;
                break;
            }
            case 1:{
                this.selectedValue.achievementTarget = text;
                break;
            }
            case 2:{
                this.selectedValue.statisticalConditions = text;
                break;
            }
        }

    }


    onPressBottom = ()=>{

        // console.info("selectedValue:",this.selectedValue);

         if(this.selectedValue.name == '') {
             Tools.toast("请填写任务名称");
             return;
         }

         if(this.selectedValue.department_id == null
             || this.selectedValue.department_id == '') {
             Tools.toast("请选择部门");
             return;
         }

         if(this.selectedValue.template_id == null
             || this.selectedValue.template_id == '') {
             Tools.toast("请选择任务类型");
             return;
         }

        /* if(this.selectedValue.achievementTarget == '') {
             Tools.toast("请选择业绩目标");
             return;
         }

         if(this.selectedValue.statisticalConditions == ''
             || this.selectedValue.statisticalConditions == null ) {
             Tools.toast("请选择统计条件");
             return;
         }*/

        Service.putIn(this.selectedValue)
            .then((retJson)=>{
                // console.log(retJson)

                this.goBack();
        });
    };

    componentWillMount(){

    }

    componentDidMount() {
        this.getSelectData();
    }

    render() {
        const {defaultValueDptname,beginTime,endTime,departmentList,taskTypeList,
            isShow,productTypeList,brandTypeList,clearDrop,typesList,isPickDropdown3,
            isPickDropdown2,isShowTextInput} = this.state;

        return (
            <ViewTitle viewBottom={"提交"}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"任务名称:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"input"}
                                      viewCenterProps={{
                                          placeholder:'请输入任务名称',
                                          onChangeText:(text)=>this.onChangeText(text,0)
                                      }}/>

                    <ItemRowTripApply text={"部         门:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenterProps={{
                                          defaultValue:defaultValueDptname,
                                          options:departmentList,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,0)
                                      }}/>

                    <TouchableOpacity style={styles.titleFrameTop}
                                      onPress={()=>{this.onSelectDrop(true,0,5)}}>
                        <ItemRowTripApply text={"开始时间:"}
                            // frameStyle={styles.titleFrameTop}

                                          viewCenterProps={{
                                              defaultValue:beginTime,
                                              options:[beginTime],
                                              selectedIndex:0,
                                              textStyle:styles.titleFrame_timeBtnText,
                                              disabled:true,
                                              // onSelect:(i,val)=>this.onSelectDrop(val,i,3)
                                          }}/>
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.titleFrameTop}
                                      onPress={()=>{this.onSelectDrop(false,0,5)}}>

                        <ItemRowTripApply text={"结束时间:"}
                            // frameStyle={styles.titleFrameTop}
                                          viewCenterProps={{
                                              defaultValue:endTime,
                                              // clearDrop:checkPersonClearDrop,
                                              selectedIndex:0,
                                              options:[endTime],
                                              textStyle:styles.titleFrame_timeBtnText,
                                              disabled:true,
                                              // onSelect:(i,val)=>this.onSelectDrop(val,i,4)
                                          }}/>
                    </TouchableOpacity>

                    <ItemRowTripApply text={"类         型:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenterProps={{
                                          defaultValue:taskTypeList.length == 0
                                              ? "正在加载"
                                              : taskTypeList[0].name,
                                          options:taskTypeList,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                      }}/>

                    {
                        isShow&&
                       <View>
                            <ItemRowTripApply text={"业绩目标:"}
                                              isStar={false}
                                              frameStyle={styles.titleFrameTop}
                                              viewCenter={"input"}
                                              viewCenterProps={{
                                                  placeholder:'业绩目标',
                                                  onChangeText:(text)=>this.onChangeText(text,1)
                                              }}/>

                            <ItemRowTripApply text={"统计条件:"}
                                              isStar={false}
                                              frameStyle={styles.titleFrameTop}
                                              viewCenter={
                                                  <SearchDDDIpt isSearch={false}
                                                                isPickDropdown2={isPickDropdown2}
                                                                isPickDropdown3={isPickDropdown3}
                                                                isTextInput={isShowTextInput}
                                                                options1={{
                                                                    style:styles.dropdown,
                                                                    defaultValue:typesList[0].name,
                                                                    options:typesList,
                                                                    onSelect:(i,val)=>this.onSelectDrop(val,i,2)
                                                                }}
                                                                options2={{
                                                                    clearDrop:clearDrop,
                                                                    defaultValue:productTypeList.length == 0
                                                                        ? "正在加载"
                                                                        : productTypeList[0].name,
                                                                    options:productTypeList,
                                                                    style:styles.dropdown,
                                                                    dropdownStyle:styles.dropdownM,
                                                                    selectedIndex:0,
                                                                    onSelect:(i,val)=>this.onSelectDrop(val,i,3)
                                                                }}
                                                                options3={{
                                                                    clearDrop:clearDrop,
                                                                    defaultValue:brandTypeList.length == 0
                                                                        ? "正在加载"
                                                                        : brandTypeList[0].name,
                                                                    options:brandTypeList,
                                                                    style:styles.dropdown,
                                                                    dropdownStyle:styles.dropdownM,
                                                                    selectedIndex:0,
                                                                    onSelect:(i,val)=>this.onSelectDrop(val,i,4)
                                                                }}
                                                                textChange={(text)=>this.onChangeText(text,2)}
                                                                inputStyle={styles.textInput}
                                                                placeholder={"请填写SKU"}/>
                                              }/>
                        </View>
                    }

                </View>


                <DatePicker ref={(compoent)=>{
                    this.datePicker = compoent;
                }}
                            onDateChange={this.setTime}/>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    titleFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        alignItems: 'center',
        justifyContent: 'center',
        height: Theme.Height.height1,

    },
    titleFrame_btn: {
        width: 100,
        height: Theme.Height.height1,
        padding: 0,
    },
    titleFrame_timeBtnFrame:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        borderRadius:Theme.Border.borderRadius,
    },
    titleFrame_timeBtn:{
        width: '0.3w',
        height: Theme.Height.height1,
        padding: 0,
        backgroundColor:Theme.Colors.transparent,
    },
    titleFrame_timeBtnText:{
        color:Theme.Colors.minorColor
    },
    titleFrame_timeText:{
        color:Theme.Colors.themeColor,
        marginLeft:10,
        marginRight:10,
        fontSize:Theme.Font.fontSize,
    },
    titleFrame1:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },


    typeFrame:{
        flex:1,
        // backgroundColor:'yellow',
    },
    itemRowText:{
        color:Theme.Colors.minorColor,
        fontSize:Theme.Font.fontSize_1,
    },

    typeFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        // backgroundColor:"blue",

    },
    typeFrame_1_1: {
        flex: 1.5,
        alignItems: 'flex-end',
        justifyContent: 'center',
        // backgroundColor:'yellow',
    },
    typeFrame_1_2: {
        flexDirection: 'row',
        flex: 8,
        // alignItems: 'flex-start',
        alignItems: 'center',
        justifyContent: 'center',
        // backgroundColor:'green',
    },
    typeFrame_1_3: {
        flex: 0.5,
        alignItems: 'flex-start',
        justifyContent: 'center',
        // backgroundColor:'red',
    },
    typeItemRowFrame:{
        /* alignItems: 'flex-start',
         justifyContent: 'center',*/
        // marginLeft: 5,
        width: StyleSheetAdapt.getWidth("0.72w") + StyleSheetAdapt.getWidth(Theme.Height.height1) + "n",
        borderTopColor:Theme.Colors.themeColor,
        borderTopWidth:Theme.Border.borderWidth1,
        borderLeftColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth,
    },
    typeItemRowFrame_Text: {
        color: Theme.Colors.fontcolor,
        fontSize: Theme.Font.fontSize,
        // alignSelf: "stretch",
        // textAlign:"auto"
    },

    customerItemFrame:{
        borderLeftWidth:0,
    },
    customerItemFrame_1:{
        marginTop:10,
    },

    flatListView:{
        height:300,
    },
    flatListView_ItemFirst:{
        backgroundColor:Theme.Colors.themeColor
    },

    dropdown:{
        width:255,
        // marginRight:20,
    },
    dropdownM:{
        marginLeft:'0.67w'
    },
    textInput:{
        width:285,
    },
});
