import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";;

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//省份
            type2:'',//城市
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取部门
     * **/
    static getDepartments(){

        return Http.post(HttpUrls.urlSets.urlDepartmentList)
            .then(retJson=>retJson.retListData);
    }

    /**
     * 获取任务类型
     * **/
    static getTaskTypes()
    {
        return Http.post(HttpUrls.urlSets.urlTripType,{
            type:'7'
        })
            .then((retJson)=>{

                return retJson.retListData;
            });
    }

    /**
     * 获取品类
     * **/
    static getProductTypes(){
        return Http.post(HttpUrls.urlSets.urlInfoProductTypeList,{
            parent_type_code:"0"
        })
            .then(retJson=>{

                retJson.retListData
                    .forEach((v,i,a)=>{
                        v.name = v.type_name
                    });

                return retJson.retListData;
            });
    }

    /**
     * 获取品牌
     * **/
    static getBrandTypes(){
        return Http.post(HttpUrls.urlSets.urlProductBrandGet)
            .then(retJson=>{

                retJson.retListData
                    .forEach((v,i,a)=>{
                        v.name = v.brand_name;
                        v.id = v.id == undefined ? v.brand_name : v.id
                    });

                return retJson.retListData;
            });
    }

    /**
     * 提交数据
     * @param selectedValue object // 提交的数据
     * **/
    static putIn(selectedValue){
        return Http.post(HttpUrls.urlSets.urlImportmentCaseAddTask,selectedValue)
            .then(retJson=>retJson.retData);
    }


}