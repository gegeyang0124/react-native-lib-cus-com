/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ButtonChange,
    ItemRowTripApply,
    ItemRowGuideTripApply,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageImportmentCaseDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            execFirst:true,
        };

        this.state = {
            id:null,  //任务id
            // id:"faeea800-e510-4035-8ee0-169c0dd423b1",  //任务id

            name:null,//任务名称
            number:null,//类型：String  必有字段  备注：任务编码
            department_name:null,                //类型：String  必有字段  备注：销售地区

            /**
             * 成员：{//类型：Object  必有字段  备注：无
                    "deptName":"区域一广东A区",//类型：String  必有字段  备注：销售地区
                    "orderTime":"2018-05-26",//类型：String  必有字段  备注：时间
                    "orderMoney":"100000",//类型：String  必有字段  备注：金额
                    "customerName":"李杰"//类型：String  必有字段  备注：客户名称
                }
             * **/
            orderList:[],//类型：Array  必有字段  备注：门店订单列表
            templateName:null,//类型：String  必有字段  备注：类型
            achievementTarget:null,//类型：String  必有字段  备注：业绩目标
            end_time:null,//类型：Number  必有字段  备注：结束时间
            begin_time:null,//类型：Number  必有字段  备注：开始时间
            achievementFinish:null,//类型：String  必有字段  备注：已完成业绩
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    getData() {
        Service.getImportmentCaseDetail(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
        });
    }

    renderItem = (item,i)=>{

        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.deptName}
                                   text2={item.customerName}
                                   text3={false}
                                   text4={item.orderTime}
                                   text5={item.orderMoney + "元"}
                                   text6={false}
                                   text7={false}/>
        );
    }

    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
    }

    componentWillReceiveProps(){

        /*let param = this.getPageParams(true);
        if(param)
        {
            let relatedTaskList = [];
            this.state.relatedTaskList.forEach((v,i,a)=>{
                relatedTaskList.push(v);
            });
            param.paramData = param.paramData == undefined ? [] : param.paramData;
            param.paramData.forEach((v,i,a)=>{
                relatedTaskList.push(v);
            });
            this.setState({
                relatedTaskList: relatedTaskList
            });
        }*/

    }


    render() {

        const {name,department_name,number,orderList,templateName,
            end_time,begin_time,achievementFinish,achievementTarget} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;

        if(this.state.id == param.id){
        // if(true){

            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                this.getData();
            }

            return (
                <ViewTitle >

                    <View style={styles.titleFrame}>

                        <ItemRowTripApply text={"任务编码:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={number}/>

                        <ItemRowTripApply text={"任务名称:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={name}/>

                        <ItemRowTripApply text={"销售地区:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={department_name}/>

                        <ItemRowTripApply text={"类         型:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={templateName}/>

                        <ItemRowTripApply text={"业绩目标:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={achievementTarget + "元"}/>

                        <ItemRowTripApply text={"巡店时间:"}
                                          frameStyle={styles.titleFrameTop}
                                          isStar={false}
                                          viewCenter={
                                              <View style={styles.titleFrame_1}>
                                                  <ButtonChange text={begin_time}
                                                                frameStyle={styles.titleFrame_timeBtnFrame}
                                                                textStyle={styles.titleFrame_timeBtnText}
                                                                style={styles.titleFrame_timeBtn} />

                                                  <Text style={styles.titleFrame_timeText}>
                                                      结束时间:
                                                  </Text>

                                                  <ButtonChange text={end_time}
                                                                frameStyle={styles.titleFrame_timeBtnFrame}
                                                                textStyle={styles.titleFrame_timeBtnText}
                                                                style={styles.titleFrame_timeBtn} />
                                              </View>
                                          }/>


                        <ItemRowTripApply text={"已  完  成:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={achievementFinish + "元"}/>

                    </View>

                    <View style={styles.titleFrame1}>

                        <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                               frameStyleChild={styles.itemRowFrameTop}
                                               text1={"销售地区"}
                                               text2={"客户名称"}
                                               text3={false}
                                               text4={"时间"}
                                               text5={"金额"}
                                               text6={false}
                                               text7={false}/>

                        {
                            orderList.map(this.renderItem)
                        }

                    </View>

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    viewBottomStyle:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
        marginBottom:10,
    },
    viewBottomBtn:{
        width:100,
        marginRight:20,
    },

    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    titleFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        alignItems: 'center',
        justifyContent: 'center',
        height: Theme.Height.height1,

    },
    titleFrame_btn: {
        width: 100,
        height: Theme.Height.height1,
        padding: 0,
    },
    titleFrame_timeBtnFrame:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        borderRadius:Theme.Border.borderRadius,
    },
    titleFrame_timeBtn:{
        width: 150,
        height: Theme.Height.height1,
        padding: 0,
        backgroundColor:Theme.Colors.transparent,
    },
    titleFrame_timeBtnText:{
        color:Theme.Colors.minorColor
    },
    titleFrame_timeText:{
        color:Theme.Colors.themeColor,
        marginLeft:150,
        marginRight:10,
        fontSize:Theme.Font.fontSize,
    },
    titleFrame1:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },

    imageFrame:{
        flex:1,
        flexDirection:"row",
        margin:10,
        height:130,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageFrame_1:{
        // flex:1,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection:"column",
        marginLeft:10,
    },
    imageStyle:{
        width:120,
        height:120,
    },
    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },

    itemRowFrameTop:{
        // borderLeftColor:Theme.Colors.minorColor,
        // borderLeftWidth:Theme.Border.borderWidth,
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth2,
    },
    itemRowFrameLeft:{
        borderColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth,
    },
    itemRowText:{
        color:Theme.Colors.fontcolor,
        fontSize:Theme.Font.fontSize_1,
    }

});
