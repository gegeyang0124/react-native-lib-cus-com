import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据


    /**
     * 获取重点专案详情
     * @param taskId string,//任务ID
     * **/
    static getImportmentCaseDetail(taskId){
        return Http.post(HttpUrls.urlSets.urlImportmentCaseDetail,{
            taskId:taskId //类型：String  必有字段  备注：id
        })
            .then(retJson=>{

                retJson.retData.begin_time = Tools.timeFormatConvert(retJson.retData.begin_time,"YYYY-MM-DD");
                retJson.retData.end_time = Tools.timeFormatConvert(retJson.retData.end_time,"YYYY-MM-DD");
                return retJson.retData;
            });
    }



}