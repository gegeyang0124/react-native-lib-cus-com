import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
    SearchDDDIpt,
    ItemRowTitle,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageImportmentCaseList extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.monthStartAndEndDate = Tools.getTimeByRank();

        this.statusList = [{
            name:'状态',
        }];
        this.state = {
            total:0,//任务总数
            dataList:[],//任务列表
            clearDrop:false,//是否清空下拉框
            departmentOneList:[],//一级部门列表
            departmentOneDefault:'一级部门',//一级部门默认显示值
            departmentOneDisable:false,//一级部门下拉框是否可选择，true：不可以选择，false:可以选择
            departmentTwoList:[],//二级部门列表
            departmentTwoDefault:'二级部门',//一级部门默认显示值
            departmentTwoDisable:false,//二级部门下拉框是否可选择，true：不可以选择，false:可以选择
            pickedDate:Tools.timeFormatConvert(Tools.timeFormatConvert(),"YYYY-MM"),

            typeList:[
                {
                    id:'',
                    name:'请选择类型'
                }
            ],
        };

        this.selectValue = {
            type1:'',//下拉选中值 一级部门
            type2:'',//下拉选中值 二级部门
            type3:{
                startTime:Tools.timeFormatConvert(this.monthStartAndEndDate.time1,"YYYY-MM-DD HH:mm:ss"),//开始时间
                endTime:Tools.timeFormatConvert(
                    this.monthStartAndEndDate.time2,
                    "YYYY-MM-DD HH:mm:ss")//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 类型
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
            execting:false,//是否正在执行
        };

        this.setParams({
            // headerLeft:require('images/menu.png'),
            // headerLeftHandle:()=>{
            //     // this.viewTitle.openDrawer();
            //     this.props.navigation.navigate("DrawerToggle",{DrawerToggle:'DrawerToggle'});
            // },
            headerLeft:true,
            headerLeftHandle:()=> {
                this.goBack(true, null, null)
            },
            headerRight:true,
            headerRightHandle:()=>{
                // alert("PageImportmentCaseAdd申请");
                this.goPage("PageImportmentCaseAdd");
            },
            // swipeEnabled:true
        });

    }

    cutState(state){
        this.setState({
            status:state
        });
    }

    onSelectDrop(val,i,type){

        switch (type){
            case 1:{
                this.state.departmentOneDefault = val.name;
                this.selectValue.type1 = val.id;
                this.selectValue.type2 = '';
                /* this.setState({
                 departmentTwoList:[
                 {
                 name:'二级部门',
                 id:''
                 }
                 ],
                 departmentTwoDefault:'二级部门',
                 // clearDrop:true
                 });*/
                Service.getDepartmentsTwo(val.id)
                    .then((retJson)=>{
                    // this.selectValue["type2"] = '';
                    this.setState({
                        departmentTwoList:retJson,
                        departmentTwoDefault:'二级部门',
                        clearDrop:true
                    });
                });
                break;
            }
            case 2: {
                this.selectValue.type2 = val.id;
                this.state.departmentTwoDefault = val.name;
                break;
            }
            case 3: {
                // alert(JSON.stringify(val))
                this.selectValue.type4 = val.id;
                break;
            }
        }
    }

    onSearch = ()=>{

        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });

        this.getData(this.selectValue);
    };

    onItemPress(item){
        if(item.template_id == Tools.userConfig.imgportmentCaseActivityFollowId){
            this.goPage("PageImportmentCaseActivityDetail",{id:item.id});

        }
        else if(item.template_id == Tools.userConfig.C_Type_Id)
        {
            this.goPage("PageImportCaseCDetail",{id:item.id});
        }
        else {
            // Tools.toast("分类型跳转");
            this.goPage("PageImportmentCaseDetail",{id:item.id});
        }


    }

    onItemPressBtn(item,statusObj){
        if(statusObj.code == 0){
            this.goPage("PageGuide",{id:item.id});
            // alert("进入巡店列表");
        }
        else{
            this.onItemPress(item);
        }
        // alert(JSON.stringify(item));
    }

    /**
     * 获取反馈列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {
        if(selectValue != undefined){
            this.selectValue = selectValue;
        }else{
            this.selectValue.type1 = "";
            this.selectValue.type2 = "";
        }

        if(!this.selectValue.execting){
            this.selectValue.execting = true;
            if(!this.selectValue.execFirst)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
            }

            Service.getImportCaseList(this.selectValue,this.selectValue.execFirst)
                .then(retJson=>{
                    this.selectValue.execting = false;
                    if(!this.selectValue.execFirst && !retJson.has)
                    {
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);

                    }else{
                        this.selectValue.execFirst = false;
                        this.setState({
                            total:retJson.total,
                            dataList:retJson.retListData
                        });

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }
                })
                .catch((status) =>{
                    this.selectValue.execting = false;
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }



    }

    getDepartments(){
        Service.getDepartmentsOne()
            .then((retJson)=>{
                // console.info("retJson",retJson);

                this.selectValue.type1 = retJson.branchOffice;
                this.selectValue.type2 = retJson.area;
                this.setState({
                    departmentOneList:retJson.branchOfficeLst,
                    departmentOneDefault:retJson.nameOne,
                    departmentTwoList:retJson.areaLst,
                    departmentTwoDefault:retJson.nameTwo,
                    departmentOneDisable:this.selectValue.type1 == '' ? false : true,
                    departmentTwoDisable:this.selectValue.type2 == '' ? false : true
                });
            });

        Service.getTaskTypes()
            .then(typeList=>{
                typeList = this.state.typeList.concat(typeList);
                this.setState({typeList});
            });
    }

    componentWillMount(){


    }

    componentDidMount() {
        // this.getStatusList();
        this.getDepartments();
        this.getData();

    }

    renderItem(item,i){
        let endTime = new Date(item.end_time);
        let type = "进行中";
        let color = Theme.Colors.themeColor;
        let icon = require('images/status4.png');
        if(new Date() > endTime){
            type = "已过期"
            color = Theme.Colors.minorColor;
            icon = require('images/status9.png');
        }

        return(
            <ItemRowTripTask  key={i}
                              disableRightSwipe={false}
                              isItemRowIconLeft={false}

                              text1_1={item.name}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={type}
                              text1_2_Style={{color}}
                              text1_2_Icon={icon}
                              text2_1={ /^-?\d*\.\d+$/.test(item.progress)?
                                  "业绩目标:" + item.achievementTarget + "元"+
                                  "              类型:" + item.templateName
                                  :"巡店数量:" + item.achievementTarget
                              + "              类型:" + item.templateName}
                              text2_1_Style={styles.text2_1_Style}
                              text3_1={/^-?\d*\.\d+$/.test(item.progress)?
                                  "业绩完成:" + item.achievementFinish:""}


                              progress={item.progress}
                              text4_1={"开始/结束时间:" + item.begin_time
                              + " ~ " + item.end_time}
                              onPress={() => this.onItemPress(item)}
                              itemRowIcon={false}/>
        );
    }

    onShowMonPicker = ()=>{
        Tools.pickMonth(retJson =>{
            let val = (new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime();

            this.selectValue.type3.startTime = Tools.timeFormatConvert(val,"YYYY-MM-DD HH:mm:ss");

            let beginDate = new Date(val);
            if(beginDate.getMonth() == 11)
            {
                val = (new Date(beginDate.getFullYear() + 1,0,1,0,0,0)).getTime();
            }
            else
            {
                val = (new Date(beginDate.getFullYear(), beginDate.getMonth() + 1,1,0,0,0)).getTime();
            }

            this.selectValue.type3.endTime = Tools.timeFormatConvert(val - 1000,"YYYY-MM-DD HH:mm:ss");


            this.setState({
                pickedDate:retJson[0] + "-" + (retJson[1] > 10 ? retJson[1] : '0' + retJson[1])
            });

        });

        return false;
    }

    getStatusList(){
        Tools.statusConvert().forEach((v,i,a)=>{
            v.name = v.text;
            this.statusList.push(v);
        });
    };

    onChangeText = (text)=>{
        this.selectValue.name = text;
    }

    componentWillReceiveProps(){
        let param = this.getPageParams(true);
        if(param)
        {
            // alert(JSON.stringify(param.paramData));
            this.onSearch();
        }
    }

    render() {
        const {dataList,departmentOneList,departmentTwoList,departmentOneDefault,
            departmentTwoDefault,departmentTwoDisable,departmentOneDisable,pickedDate
            ,clearDrop,total,typeList} = this.state;
        // console.info("this.state",this.state);

        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c}>

                <View style={styles.titleFrame}>
                    <SearchDDDIpt isTextInput={false}
                                  frameStyle={styles.titleFrame}
                                  isSearch={false}
                                  options1={{
                                      style:styles.titleDpFrame,
                                      defaultValue:departmentOneDefault,
                                      clearDrop:departmentOneDisable,
                                      options:departmentOneList,
                                      disabled:departmentOneDisable,
                                      frameStyle:styles.pdFrame,
                                      onSelect:(i,val)=>this.onSelectDrop(val,i,1)
                                  }}
                                  options2={{
                                      style:styles.titleDpFrame,
                                      defaultValue:departmentTwoDefault,
                                      clearDrop:departmentTwoDisable
                                          ? departmentTwoDisable
                                          : clearDrop,
                                      options:departmentTwoList,
                                      disabled:departmentTwoDisable,
                                      frameStyle:styles.pdFrame,
                                      onSelect:(i,val)=>this.onSelectDrop(val,i,2)
                                  }}
                                  options3={{
                                      style:styles.titleDpFrame,
                                      defaultValue:pickedDate,
                                      selectedIndex:0,
                                      clearDrop:true,
                                      options:[pickedDate],
                                      frameStyle:styles.pdFrame,
                                      onDropdownWillShow:this.onShowMonPicker
                                  }}
                                  onPressSearch={this.onSearch}/>

                    <SearchDDDIpt isPickDropdown3={false}
                                  isPickDropdown2={false}
                                  frameStyle={styles.titleFrame}
                                  options1={{
                                      style:styles.titleDpFrame,
                                      defaultValue:typeList[0].name,
                                      options:typeList,
                                      frameStyle:styles.pdFrame,
                                      onSelect:(i,val)=>this.onSelectDrop(val,i,3)
                                  }}
                                  inputStyle={styles.iptStyle}
                                  placeholder={"执行人姓名"}
                                  btnStyle={styles.pdFrame}
                                  textChange={this.onChangeText}
                                  onPressSearch={this.onSearch}/>
                </View>


                <ItemRowTitle frameStyle={styles.titleFrame}
                              text1={"共有" + total + "个重点任务"}/>

                <FlatListView
                    style={styles.flatListView}
                    data={dataList}
                    keyExtractor = {(item, index) => ("key" + index)}
                    renderItem={({item,index}) => this.renderItem(item,index)}
                    onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    iptStyle:{
        marginLeft:30,
        marginRight:30,
        width:180,
    },
    pdFrame:{
        marginLeft:30,
        marginRight:30,
        // flex:1,
        // justifyContent:'center',
    },

    titleFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        justifyContent:'flex-start',
    },
    titleDpFrame:{
        width:150,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        marginBottom:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    itemTripBtn:{
        marginRight:"0.05w",
    },
});

