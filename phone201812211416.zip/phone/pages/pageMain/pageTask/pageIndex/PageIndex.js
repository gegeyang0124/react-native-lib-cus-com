/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    Image,
    TextInput,
    TouchableOpacity,
    ImageBackground,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,

    ItemRowTripTask,
} from "com";
import {Service} from "./Service";


type Props = {};
export default class PageIndex extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.statusList = [{
            name:'状态',
        }];
        this.state = {
            dataList:[],//任务列表
            clearDrop:false,//是否清空下拉框
            departmentOneList:[],//一级部门列表
            departmentOneDefault:'一级部门',//一级部门默认显示值
            departmentOneDisable:false,//一级部门下拉框是否可选择，true：不可以选择，false:可以选择
            departmentTwoList:[],//二级部门列表
            departmentTowDefault:'二级部门',//一级部门默认显示值
            departmentTwoDisable:false,//二级部门下拉框是否可选择，true：不可以选择，false:可以选择
            pickedDate:Tools.timeFormatConvert(Tools.timeFormatConvert(),"YYYY-MM"),
        };
        this.data=[]
        this.mount=false
        this.renderItem=true


    }

    /**
     * 获取反馈列表
     * @param selectValue object;//搜索参数
     * **/
    getData() {
        Service.get().then(retJson=>{
                this.data=retJson
                // console.log(this.data)
           if(!this.mount){
               this.setState({dataList:retJson})
           }
        }

        )

    }
    componentWillUnmount(){
        this.mount=true
    }

    componentWillEnter(params){
        this.mounted = true;
        // console.info("componentWillEnter",params);
        this.getData();
    }
    render(){
        if(this.renderItem){
            this.getData()
            this.renderItem=false
        }
        const dataList=this.data

       return(
           <ViewTitle>
               <View style={styles.model}>
                   <View style={styles.parent} >

                       <Image source={require("../../../../res/images/01.png")}
                              style={styles.topPicture}>
                       </Image>


                   </View>

                   <View style={styles.parent}>
                       <ImageBackground source={require("../../../../res/images/travel.png")}
                                        style={styles.firstRow}
                       >
                           <View style={styles.container}>
                               <Text style={styles.welcome}>
                                   <Image source={require('../../../../res/images/travelInner.png')} style={styles.imageInTextStyle}/>
                                   &nbsp;&nbsp;出差管理
                               </Text>
                               <Text style={styles.topRight}>
                                   01
                               </Text>
                           </View>
                           <TouchableOpacity
                               onPress={()=>{this.goPage("PageTripList")}}>
                               <Text style={styles.content1}>
                                   收到新消息:{dataList.task1}/个

                               </Text >
                               <Text style={styles.content}>
                                   待审核任务:{dataList.task2}/个
                               </Text>
                               <Text style={styles.content}>
                                   执行中任务:{dataList.task3}/个
                               </Text>
                               <Text style={styles.content}>
                                   已完成任务:{dataList.task4}/个
                               </Text>
                           </TouchableOpacity>

                       </ImageBackground>

                       <ImageBackground source={require("../../../../res/images/addressBackground.png")}
                                        style={styles.firstRow}>
                           <View >
                               <Text style={styles.welcome}>
                                   <Image source={require('../../../../res/images/addressInner.png')} style={styles.imageInTextStyle}/>
                                   &nbsp;&nbsp;选址审核
                               </Text>
                               <Text style={styles.topRight}>
                                   01
                               </Text>
                           </View>

                           <TouchableOpacity
                               onPress={()=>{this.goPage("PageAddressAudit")}}>
                               <Text style={styles.content2}>
                                   收到新消息:{dataList.addressAudit1}/个
                               </Text >
                               <Text style={styles.content}>
                                   待审核选址:{dataList.addressAudit2}/个
                               </Text>

                               <Text style={styles.content}>
                                   已完成选址:{dataList.addressAudit3}/个
                               </Text>
                           </TouchableOpacity>
                       </ImageBackground>

                   </View>
                   <View style={styles.parent}>
                       <ImageBackground source={require("../../../../res/images/1111background.png")}
                                        style={styles.firstRow}>
                           <View style={styles.container}>
                               <Text style={styles.welcome}>
                                   <Image source={require('../../../../res/images/1111Inner.png')}
                                          style={styles.imageInTextStyle}/>
                                   &nbsp;&nbsp;1111工程
                               </Text>
                               <Text style={styles.topRight}>
                                   01
                               </Text>
                           </View>
                           <TouchableOpacity
                               onPress={()=>{this.goPage("PageProj1111OperateList")}}>
                               <Text style={styles.content1}>
                                   收到新消息:{dataList.project1}/个
                               </Text >
                               <Text style={styles.content}>
                                   未开始任务:{dataList.project2}/个
                               </Text>
                               <Text style={styles.content}>
                                   进行中任务:{dataList.project3}/个
                               </Text>
                               <Text style={styles.content}>
                                   已完成任务:{dataList.project4}/个
                               </Text>
                           </TouchableOpacity>
                       </ImageBackground>

                       <ImageBackground source={require("../../../../res/images/open.png")}
                                        style={styles.firstRow}>
                           <View style={styles.container}>
                               <Text style={styles.welcome}>
                                   <Image source={require('../../../../res/images/openInner.png')} style={styles.imageInTextStyle}/>
                                   &nbsp;&nbsp;开业审核
                               </Text>
                               <Text style={styles.topRight}>
                                   01
                               </Text>
                               <TouchableOpacity
                                   onPress={()=>{this.goPage("PageOpenAuditList")}}>
                                   <Text style={styles.content2}>
                                       收到新消息:{dataList.openAudit1}/个

                                   </Text >
                                   <Text style={styles.content}>
                                       待审核任务:{dataList.openAudit2}/个
                                   </Text>
                                   <Text style={styles.content}>
                                       执行中任务:{dataList.openAudit3}/个
                                   </Text>
                                   <Text style={styles.content}>
                                       已完成任务:{dataList.openAudit4}/个
                                   </Text>
                               </TouchableOpacity>
                           </View>
                       </ImageBackground>

                   </View>
                   <View style={styles.parent}>

                       <ImageBackground source={require("../../../../res/images/important.png")}
                                        style={styles.firstRow}>
                           <View style={{height:75}}>
                               <Text style={styles.welcome}>
                                   <Image source={require('../../../../res/images/importantInner.png')} style={styles.imageInTextStyle}/>
                                   &nbsp;&nbsp;重点专案数据信息
                               </Text>
                               <Text style={styles.topRight}>
                                   01
                               </Text>
                           </View>


                           <TouchableOpacity
                               onPress={()=>{this.goPage("PageImportmentCaseList")}}>
                               <Text style={styles.content1}>
                                   收到新消息:{dataList.point1}/个
                               </Text >

                               <Text style={styles.content}>
                                   进行中计划:{dataList.point2}/个
                               </Text>
                               <Text style={styles.content}>
                                   已过期计划:{dataList.point3}/个
                               </Text>
                           </TouchableOpacity>
                       </ImageBackground>

                       <ImageBackground source={require("../../../../res/images/survey.png")}
                                        style={styles.firstRow}>
                           <View style={styles.container}>
                               <Text style={styles.welcome}>
                                   <Image source={require('../../../../res/images/surveyInner.png')} style={styles.imageInTextStyle}/>
                                   &nbsp;&nbsp;问卷调查
                               </Text>
                               <Text style={styles.topRight}>
                                   01
                               </Text>
                               <TouchableOpacity
                                   onPress={()=>{this.goPage("PageSurveyPSQList")}}>
                                   <Text style={styles.content2}>
                                       收到新问卷:{dataList.question1}/个

                                   </Text >
                                   <Text style={styles.content}>
                                       未查看问卷:{dataList.question2}/个
                                   </Text>
                                   <Text style={styles.content}>
                                       已查看问卷:{dataList.question3}/个
                                   </Text>
                                   <Text style={styles.content}>
                                       已提交问卷:{dataList.question4}/个
                                   </Text>
                               </TouchableOpacity>
                           </View>
                       </ImageBackground>


                   </View>
               </View>
           </ViewTitle>
       )
    }
}

const styles = StyleSheetAdapt.create({
    model:{
        marginTop:-10,
    },
    topPicture:{
        flex:1,
        height:200,
        marginTop:5
    },
    parent:{
        flexDirection:'row',
        // justifyContent:'center',
        // alignItems:'center'
    },
    firstRow:{
        marginTop:10,
        marginLeft:5,
        marginRight:5,
        flex:0.5,
        height:200
    },
    leftIcon:{
        width:20,
        height:20,

        marginLeft:20,
        marginTop:20
    },
    container: {
        flex:1,

    },

    imageInTextStyle:{

        width:20,
        height:20,
        resizeMode:'cover'
    },
    welcome:{
        marginTop:20,
        marginLeft:20,
        fontSize:20
    },
    content:{
        marginLeft:50,
        marginBottom:10,
        fontSize:17,
        color:Theme.Colors.minorColor

    },
    content1:{
        marginLeft:50,
        marginBottom:10,
        fontSize:17,
        color:Theme.Colors.themeColor

    },
    content2:{
        marginTop:40,
        marginLeft:50,
        marginBottom:10,
        fontSize:17,
        color:Theme.Colors.themeColor
    },
    topRight:{
        marginLeft:345,
        fontSize:25,
        color:'white',
        marginTop:-40
    }





})


