// import {
//     Http,
//     HttpUrls,
//     Tools,
// } from "com-api";
//
// export class Service{
//
//     static get(){
//         return Http.post(HttpUrls.urlSets.urlTaskIndex,{jobGrade:Tools.userConfig.userInfo.job_grade}).then(
//             retJson=>
//                 retJson.retData
//
//
//         )
//     }
// }


import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;

        // alert(JSON.stringify(Tools.userConfig))
    }
    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取出差数据列表
     * @param selectValue object,//搜索参数
     * selectValue = {
        type1:'',//下拉选中值 一级部门
        type2:'',//下拉选中值 二级部门
        type3:'',//下拉选中值 年月
        name:'',//人名称输入值
    }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/

    static get(){
        return Http.post(HttpUrls.urlSets.urlTaskIndex,{jobGrade:Tools.userConfig.userInfo.job_grade},false).then(
            retJson=>
                retJson.retData


        )
    }

    /**
     * 获取一级部门选择列表
     * **/



}
