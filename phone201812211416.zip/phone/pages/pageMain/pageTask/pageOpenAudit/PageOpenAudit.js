import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird';


import PageOpenAuditList from "./pageOpenAuditList/PageOpenAuditList";
import PageOpenAuditDetailExePerson from "./pageOpenAuditDetailExePerson/PageOpenAuditDetailExePerson";
import PageOpenAuditDetailCheckPerson from "./pageOpenAuditDetailCheckPerson/PageOpenAuditDetailCheckPerson";


const TabRouteConfigs = {
    PageOpenAuditDetailExePerson: {
        screen: PageOpenAuditDetailExePerson,
        navigationOptions: {
            title : '开业详情',
            tabBarLabel : '执行人详情',
        },

    },
    PageOpenAuditDetailCheckPerson: {
        screen: PageOpenAuditDetailCheckPerson,
        navigationOptions: {
            title : '开业详情',
            tabBarLabel : '执行人详情',
        },

    }
}

const page = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = {
    get PageOpenAuditList(){
        return PageOpenAuditList;
    },
    get PageOpenAuditDetail(){
        return page;
    }
};
