/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTitle,
    ImageList,
    ItemRowTripApply,
} from "com";
import {
    GiftedChat
} from "comThird";
import {Service} from "./Service";


type Props = {};
export default class PageOpenAuditDetailCheckPerson extends BaseComponent<Props> {

    constructor(props) {
        super(props);


        this.selectedValue = {
            msg:null,//类型：String  可有字段  备注：回复
        }

        this.state = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            distance5Num:null,//5公里范围内的店铺数量
            distance10Num:null,//10公里范围内的店铺数量
            selectGps:Tools.userConfig.position
                ? Tools.userConfig.position
                : {
                    lat: 23.157003,
                    lng: 113.264531
                },
            replyList:[],//反馈数据
            isPast:true,
            lastUpdateTime:null,
            storeGpsList:[],//店铺地址
            fileList:[], //附件列

            openDate:null,//开业时间
            trialOpeningDate:null,//试营业时间
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });

    }

    componentWillEnter(param){
        if(param){
            this.state.id = param.id;

            this.getData();
        }
    }

    getData(){
        Service.getDetail(this.state.id)
            .then(retJson=>{
                // console.log(retJson)
                this.setState(retJson);
            });

    }

    componentDidMount() {
        // this.getData();
        // alert(Tools.getDistanceByGps({lng1:113.264531,lat1:23.157003},{lng2:116.264531,lat2:39.91095}));
    }

    /**
     * 底部按钮操作
     * **/
    onPressBottom = (text,index)=>{
        if(index == 0){
            this.setState({isPast:false});
            this.win.scrollToEnd();
        }
        else {
            Service.putIn(this.state.id,null,2)
                .then(retJson=>{

                });
            Tools.toast("提交成功！");
            BaseComponent.backRefresh = true;
            this.goBack();
        }
    };

    renderItem = (item,i)=>{
        // text2={"上传附件"}
        // onPressRight={()=>this.showMenu(i)}
        return(
            <View key={i}
                  style={[styles.bodyFrame,styles.bodyFrame2]}>
                <ItemRowTitle text1={item.fileName}
                />

                <ImageList dataList={item.files}
                           isShowText={false}
                           text={"删除"}
                           onPressText={(item2,index)=>this.onDelImage("imageList" + i,item2,index)}
                           textStyle={styles.imageTextStyle}
                           iconStyle={styles.imageStyle}/>

            </View>
        );
    }

    onSend = ()=>{

        Service.putIn(this.state.id,this.state.msg,3)
            .then(retJson=>{
                this.setState(previousState => ({
                    replyList: GiftedChat.append(previousState.replyList, [
                        {
                            _id:Tools.userConfig.userInfo.id + "_put",
                            text: this.selectedValue.msg,

                            createdAt: new Date(),
                            user: {
                                _id: Tools.userConfig.userInfo.id,
                                name: Tools.userConfig.userInfo.position_name
                                + "-"
                                + Tools.userConfig.userInfo.full_name,
                                avatar: Tools.userConfig.userInfo.picture,
                            }
                        }
                    ]),
                }))

            });
    }

    onInputTextChanged(text){
        this.selectedValue.msg = text;
    }

    render() {

        const {isPast,replyList,fileList,openDate,trialOpeningDate} = this.state;

        return (
            <ViewTitle viewBottom={isPast ? ["不通过","通过"] : null}
                       ref={com=>this.win = com}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.timeFrame}>

                    <ItemRowTripApply text={"开业时间:"}
                                      frameStyle={styles.btnTimeFrame}
                                      frameLabelStyle={styles.openTimeLabelFrame}
                                      viewCenter={"text"}
                                      text2={openDate}
                                      isStar={false}/>

                    <ItemRowTripApply text={"试营业时间:"}
                                      frameStyle={styles.btnTimeFrame}
                                      frameLabelStyle={styles.openTimeLabelFrame2}
                                      viewCenter={"text"}
                                      text2={trialOpeningDate}
                                      isStar={false}/>

                </View>

                {
                    fileList.map(this.renderItem)
                }

                <View style={styles.msgFrame}>

                    <ItemRowTitle text1={"审核反馈"}/>

                    <GiftedChat messages={replyList}
                                user={{
                                    _id: Tools.userConfig.userInfo.id,
                                    name: Tools.userConfig.userInfo.position_name
                                    + "-"
                                    + Tools.userConfig.userInfo.full_name,
                                    avatar: Tools.userConfig.userInfo.picture,
                                }}

                                onInputTextChanged={(text)=>{this.onInputTextChanged(text)}}
                                onSend={this.onSend}
                                leftContentStyle={styles.chatText}
                                showUserAvatar={true}
                                imageStyle={
                                    {
                                        left:styles.imageUser,
                                        right:styles.imageUser
                                    }
                                }
                                onCancel={()=> this.setState({isPast:true})}
                                isShowInput={!isPast}
                                placeholder={"请输入原因"}/>

                </View>

            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    textStyle1:{
        width:250,
    },
    timeFrame:{
        flexDirection:'row',
    },
    btnTimeFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },
    openTimeLabelFrame:{
        flex:3.5,
    },
    openTimeLabelFrame2:{
        flex:4.5,
    },

    topFrame:{
        padding:5,
        backgroundColor:Theme.Colors.themeColor2,
        position:"absolute",
        zIndex:111,
    },
    topTextTime:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.foregroundColor,
    },

    imageUser:{
        width:60,
        height:"60dw",
        borderRadius:30,
    },

    chatText:{
        backgroundColor:Theme.Colors.barGreen,
    },

    msgFrame:{
        marginTop:10,
        height:400,
        backgroundColor:Theme.Colors.foregroundColor,
    },

    mapText:{
        marginBottom:10,
        marginLeft:10,
    },
    mapLogo:{
        width:70,
        height:"70dw",
    },
    mapLogoFrame:{
        // marginTop:230,
        alignItems:'flex-end',
        // height:70,
        // justifyContent:'center',
    },
    map: {
        // width: 'w',
        height: 300,
        justifyContent:'flex-end',
    },



    frameStyle:{
        marginTop:10,
    },

    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },
    imageStyle:{
        // flex:0,
        width:150,
        height:'150dw',
        // backgroundColor:'yellow',
    },

    bodyFrame:{
        flex:1,
        // backgroundColor:Theme.Colors.foregroundColor,
        alignItems:'center',
        justifyContent:'center',
        // flex:1,
        // height:'h',
        marginTop:10,
    },
    bodyFrame2:{
        backgroundColor:Theme.Colors.foregroundColor,
    },

    bodyIamge:{
        width:'w',
        height:200,
        // backgroundColor:'blue'
    },

});
