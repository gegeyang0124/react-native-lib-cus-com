import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
// import {ServiceCommon} from './../../ServiceCommon';

/**
 * 接口
 * **/
export class Service {


    static base;

    static retJson = {
        id:null,//任务ID
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
    };//后台返回数据

    constructor() {
        Service.base = this;
    }

    /**
     * 获取当前步骤数据的详情
     * @param taskId string,//任务ID
     * **/
    static getDetail(taskId){


        return Http.get(HttpUrls.urlSets.urlTaskShopAdressAuditDetail,{
            taskSelectAddressId:taskId,
        })
            .then(retJson=>{
                console.log(retJson)
                let retObj = {
                    distance5Num:0,
                    distance10Num:0,
                    replyList:[],
                    fileList:[],
                };

                /*let selectGps = retJson.retData.selectGps;
                selectGps = selectGps.split(",");
                selectGps = {
                    lat:parseFloat(selectGps[0]),
                    lng:parseFloat(selectGps[1])
                };
                retJson.retData.selectGps = selectGps;

                retJson.retData.storeGpsList
                    .forEach((v,i,a)=>{
                       /!* v = v.split(",");
                        v = {
                            lat:parseFloat(v[0]),
                            lng:parseFloat(v[1])
                        };*!/
                       v.lat = parseFloat(v.latitude);
                       v.lng = parseFloat(v.longitude);

                       if(v.lat == selectGps.lat && v.lng == selectGps.lng){
                           v.isSelected = true;
                       }
                       else {
                           v.isSelected = true;
                       }

                        v.distance = Tools.getDistanceByGps(selectGps,v);
                        if(v.distance <= 5){
                            retObj.distance5Num++;
                            // retObj.distance10Num++;
                        }
                        if(v.distance <= 10){
                            // retObj.distance5Num++;
                            retObj.distance10Num++;
                        }
                    });
                retJson.retData.distance5Num = retObj.distance5Num;
                retJson.retData.distance10Num = retObj.distance10Num;*/

                retJson.retData.replyList.forEach((v,i,a)=>{
                    retObj.replyList.push( {
                        _id: v.id,
                        text: v.msg,
                        createdAt:v.createTime,
                        user: {
                            _id: v.sendUserId,
                            name: v.userPostName + "-" + v.userName,
                            avatar: v.userPicture,
                        }
                    });
                });
                retJson.retData.replyList = retObj.replyList;

                retJson.retData.fileList.forEach((v,i,a)=>{
                    let item = {
                        fileId:v.fileId,
                        fileName:v.fileName,
                        files:[],
                    }

                    v.files.forEach((v1,i1,a1)=>{
                        item.files.push({
                            icon:v1,
                            id:v.fileId
                        });
                    });

                    retObj.fileList.push(item);
                });

                retJson.retData.fileList = retObj.fileList;

                return  retJson.retData;
            });
    }


    /**
     * 提交数据
     * @param commitDataList array,//需要提交的数据数组
     * @param isFile bool,//是否提交附件 默认false 不提交
     * **/
    static putIn(commitDataList,isFile){
        isFile = isFile == undefined ? false :isFile;
        if(isFile){
            return new Promise(resolve => {
                Http.upLoadFileToService(commitDataList.fileList)
                    .then(retJson=>{
                        let fileList = [];
                        retJson.forEach((v,i,a)=>{
                            let is = true;
                            fileList.forEach(v1=>{
                                if(v.id == v1.id){
                                    is = false;
                                }
                            });

                            if(is){
                                fileList.push({
                                    id:v.id,
                                    value:[]
                                });
                            }

                        });

                        retJson.forEach((v,i,a)=>{
                            fileList.forEach(v1=>{
                                if(v.id == v1.id){
                                    v1.value.push(v.servicePath);
                                }
                            });
                        });

                        fileList.forEach(v1=>{
                            v1.value = v1.value.toString();
                        });

                        commitDataList.fileList = fileList;

                        // console.info("commitDataList",commitDataList);

                        Http.post(HttpUrls.urlSets.urlTaskShopAdressAuditUpdateData,commitDataList)
                            .then(retJson=>{
                                resolve(retJson);
                            });
                    });
            });
        }
        else {
            return Http.post(HttpUrls.urlSets.urlTaskShopAdressAuditUpdateData,commitDataList)
                .then(retJson=>retJson);
        }

    }

    /**
     * 获取省份
     * **/
    static getProvinces(){
        return new Promise((resolve,reject)=>{
            Http.post(HttpUrls.urlSets.urlProvinceList,{},false)
                .then((retJson)=>{
                    let retObj = {
                        provinceList : []
                    };

                    retJson.retData.forEach((v,i,a)=>{
                        if(typeof(v) == 'string'){
                            retObj.provinceList.push({
                                name:v,
                                id:v
                            });
                        }
                        else
                        {
                            retObj.provinceList.push(v)
                        }
                    });

                    resolve(retObj);
                });
        });
    }

    /**
     * 获取城市
     * @param provinceId string,//城市id
     * **/
    static getCities(provinceId){
        return Http.post(HttpUrls.urlSets.urlCityList,{
            province:provinceId
        },false)
            .then((retJson)=>{
                let cityList = [];
                retJson.retData.forEach((v,i,a)=>{
                    if(typeof(v) == 'string'){
                        cityList.push({
                            name:v,
                            id:v
                        });
                    }
                    else
                    {
                        cityList.push(v);
                    }
                });

                return cityList;
            });
    }

    /**
     * 提交收件人数据
     *
     * @Param requestData json,//提交后台的数据
     * **/
    static putInRecipient(requestData){
        return Http.post(HttpUrls.urlSets.urlClientUpdateRecordMaterial,
            requestData)
            .then(retJson=>retJson);
    }

}