/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
/*import SwipeableListView from 'SwipeableListView';
 import SwipeableQuickActions from 'SwipeableQuickActions';
 import SwipeableQuickActionButton from 'SwipeableQuickActionButton';*/
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageOpenAuditList extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.statusList = [
            {
                name:'状态',
                id:null
            },
            {
                name:'通过',//1.待审核 2.通过 3.不通过
                id:2
            },
            {
                name:'不通过',
                id:3
            },
            {
                name:'待审核',
                id:1
            }
        ];
        this.state = {
            dataList:[],//任务列表
            clearDrop:false,//是否清空下拉框
            departmentOneList:[],//一级部门列表
            departmentOneDefault:'一级部门',//一级部门默认显示值
            departmentOneDisable:false,//一级部门下拉框是否可选择，true：不可以选择，false:可以选择
            departmentTwoList:[],//二级部门列表
            departmentTowDefault:'二级部门',//一级部门默认显示值
            departmentTwoDisable:false,//二级部门下拉框是否可选择，true：不可以选择，false:可以选择
            pickedDate:Tools.timeFormatConvert(Tools.timeFormatConvert(),"YYYY-MM"),
        };

        this.selectValue = {
            type1:null,//下拉选中值 一级部门
            type2:null,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:null,//下拉选中值 状态
            name:null,//人名称输入值
            execFirst:true,//是否是第一次执行
            isExecuting:false,
        };

        this.setParams({
            // headerLeft:require('images/menu.png'),
            // headerLeftHandle:()=>{
            //     // this.viewTitle.openDrawer();
            //     this.props.navigation.navigate("DrawerToggle",{DrawerToggle:'DrawerToggle'});
            // },
            headerLeft:true,
            headerLeftHandle:()=> {
                this.goBack(true, null, null)
            },
            headerRight:false
        });

    }

    componentWillEnter(){
        Tools.getLocation().then(reJson=>{
            Tools.userConfig.position = reJson;
        });
    }

    cutState(state){
        this.setState({
            status:state
        });
    }

    onSelectDrop(val,i,type){
        // alert(JSON.stringify(val));
        // console.info('onSelectDrop',val)

        switch (type)
        {
            case 1:{
                this.state.departmentOneDefault = val.name;
                this.selectValue.type1 = val.id;
                this.selectValue.type2 = '';
                /* this.setState({
                 departmentTwoList:[
                 {
                 name:'二级部门',
                 id:''
                 }
                 ],
                 departmentTowDefault:'二级部门',
                 // clearDrop:true
                 });*/
                Service.getDepartmentsTwo(val.id).then((retJson)=>{
                    // this.selectValue["type2"] = '';
                    this.setState({
                        departmentTwoList:retJson,
                        departmentTowDefault:'二级部门',
                        clearDrop:true
                    });
                });
                break;
            }
            case 2: {

                this.selectValue.type2 = val.id;
                // this.state.departmentTowDefault = val.name;
                this.setState({
                    clearDrop:false,
                    departmentTowDefault:val.name
                });
                break;
            }
            case 4: {
                // alert(JSON.stringify(val))
                this.selectValue.type4 = val.id;
                break;
            }
        }
    }

    onSearch = ()=>{
        // alert("search");
        // alert(JSON.stringify(this.selectValue));
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });
        this.getData(this.selectValue);
    };

    onItemPress(item){
        let page = "PageOpenAuditDetailCheckPerson";
        if(Tools.userConfig.userInfo.id == item.executor_id){
            page = "PageOpenAuditDetailExePerson";
        }
        this.goPage(page,{id:item.id});
    }

    onItemPressBtn(item,statusObj){
        /*if(statusObj.code == 0){
            this.goPage("PageGuide",{id:item.id});
            // alert("进入巡店列表");
        }
        else{
            this.onItemPress(item);
        }*/
        // alert(JSON.stringify(item));
    }

    /**
     * 获取反馈列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {
        if(!this.selectValue.isExecuting){

            this.selectValue.isExecuting = true;

            if(!this.selectValue.execFirst)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
            }

            Service.getAuditList(selectValue,this.selectValue.execFirst)
                .then(retJson=>{

                    this.selectValue.isExecuting = false;

                    if(!this.selectValue.execFirst && !retJson.has)
                    {
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);

                    }
                    else
                    {
                        this.selectValue.execFirst = false;
                        this.setState({
                            dataList:retJson.retListData
                        });

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }
                })
                .catch((status) =>{
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }

    }

    getDepartments(){
        Service.getDepartmentsOne()
            .then((retJson)=>{
                // console.info("retJson",retJson);

                this.selectValue.type1 = retJson.branchOffice;
                this.selectValue.type2 = retJson.area;
                this.setState({
                    departmentOneList:retJson.branchOfficeLst,
                    departmentOneDefault:retJson.nameOne,
                    departmentTwoList:retJson.areaLst,
                    departmentTowDefault:retJson.nameTwo,
                    departmentOneDisable:this.selectValue.type1 == '' ? false : true,
                    departmentTwoDisable:this.selectValue.type2 == '' ? false : true
                });
            });
    }

    componentWillMount(){


    }

    componentDidMount() {
        /*if(!Tools.platformType){
        this.getData();
        }*/

        // this.getStatusList();
        this.getDepartments();
        this.getData();

        // this.getDataGoodsTypes(0,0);
    }

    renderItemView(item,i){

        let statusObj = Tools.statusConvertAddressAudit(item.task_status,item.executor_id);

        let btnList = [];
        statusObj.btnList.forEach((v,i,a)=>{
            btnList.push({
                onPress:()=>this.onItemPressBtn(item,v),
                text:v.text,
                backgroundColor:v.backgroundColor == undefined
                    ? Theme.Colors.backgroundColorBtn1
                    : v.backgroundColor
            });
        });

        return(
            <ItemRowTripTask  key={i}
                              disableRightSwipe={true}
                              isItemRowIconLeft={false}
                              btnList={btnList}
                              text1_1={item.name}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={statusObj.text}
                              text2_1={"申请人:" + item.executorName
                              + "       审核人:" + item.auditorName}
                              text2_1_Style={styles.text2_1_Style}
                              text3_1={"出差编码:" + item.number}
                              text4_1={"出差开始/结束时间:"
                              + Tools.timeFormatConvert(item.begin_time,"YYYY-MM-DD HH:mm")
                              + " ~ " + Tools.timeFormatConvert(item.end_time,"YYYY-MM-DD HH:mm")}
                              onPress={() => this.onItemPress(item)}
                              text1_2_Style={{color:statusObj.color}}
                              itemRowIcon={false}
                              text1_2_Icon={statusObj.icon}/>
        );
    }

    onShowMonPicker = ()=>{
        // PickerCustome.pickMonth();
        Tools.pickMonth(retJson =>{
            let val = (new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime();

            this.selectValue.type3.startTime = Tools.timeFormatConvert(val,"YYYY-MM-DD HH:mm:ss");

            let beginDate = new Date(val);
            if(beginDate.getMonth() == 11)
            {
                val = (new Date(beginDate.getFullYear() + 1,0,1,0,0,0)).getTime();
            }
            else
            {
                val = (new Date(beginDate.getFullYear(), beginDate.getMonth() + 1,1,0,0,0)).getTime();
            }

            this.selectValue.type3.endTime = Tools.timeFormatConvert(val - 1000,"YYYY-MM-DD HH:mm:ss");


            this.setState({
                pickedDate:retJson[0] + "-" + (retJson[1] > 10 ? retJson[1] : '0' + retJson[1])
            });
        });
    }

    getStatusList(){
        Tools.statusConvert().forEach((v,i,a)=>{
            v.name = v.text;
            this.statusList.push(v);
        });
    };

    onChangeText = (text)=>{
        this.selectValue.name = text;
    }

    componentWillReceiveProps(){
        let param = this.getPageParams(true);
        if(param)
        {
            // alert(JSON.stringify(param.paramData));
            this.onSearch();
        }


    }

    render() {
        const {dataList,departmentOneList,departmentTwoList,departmentOneDefault,
            departmentTowDefault,departmentTwoDisable,departmentOneDisable,pickedDate
            ,clearDrop} = this.state;

        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c}>

                <View style={styles.titleFrame}>
                    <View style={styles.titleFrame_1}>
                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={departmentOneDefault}
                                           options={departmentOneList}
                                           disabled={departmentOneDisable}
                                           onSelect={(i,val)=>this.onSelectDrop(val,i,1)} />
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={departmentTowDefault}
                                           clearDrop={clearDrop}
                                           options={departmentTwoList}
                                           disabled={departmentTwoDisable}
                                           onSelect={(i,val)=>this.onSelectDrop(val,i,2)} />
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <TouchableOpacity onPress={this.onShowMonPicker}>
                                <PickDropdown  defaultValue={pickedDate}
                                               selectedIndex={0}
                                               options={[pickedDate]}
                                               disabled={true}
                                    // onSelect={(i,val)=>this.onSelectDrop(val,i,3)}
                                />
                            </TouchableOpacity>

                        </View>
                    </View>

                    <View style={styles.titleFrame_1}>
                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={this.statusList[0].name}
                                           options={this.statusList}

                                           onSelect={(i,val)=>this.onSelectDrop(val,i,4)} />
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <TextInput placeholder={"--姓名--"}
                                       onChangeText={this.onChangeText}
                                       style={styles.titleFrame_textInput}/>
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <View style={styles.titleFrame_btnFrame}>
                                <ButtonChange text={"查询"}
                                              onPress={this.onSearch}
                                              style={styles.titleFrame_btn}/>
                            </View>
                        </View>
                    </View>

                </View>

                <FlatListView style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItemView(item,index)}
                              onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
        height:100,
    },
    titleFrame_1:{
        flexDirection:'row',
        flex:1,
        height:50,
    },
    titleFrame_1_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            padding:0,
            paddingLeft:10,
            paddingBottom:10,
            marginTop:15,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    titleFrame_btnFrame:{
        width:Theme.Width.width1 + Theme.Height.height1,
    },
    titleFrame_btn:{
        width:100,
        height:Theme.Height.height1,
        padding:0,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginBottom:10,
    },
    itemTripBtn:{
        marginRight:"0.05w",
    },
});
