import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird';
import PageProj1111OperateList from "./pageProj1111OperateList/PageProj1111OperateList";
import PageProj1111OperateDetails from "./pageProj1111OperateDetails/PageProj1111OperateDetails";

module.exports = {
    get PageProj1111OperateList(){
        return PageProj1111OperateList;
    },
    get  PageProj1111OperateDetails(){
        return PageProj1111OperateDetails;
    }
};
