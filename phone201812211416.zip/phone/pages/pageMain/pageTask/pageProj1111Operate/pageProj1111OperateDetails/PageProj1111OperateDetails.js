import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird';
import PageProj1111OperateDetail from "./pageProj1111OperateDetail/PageProj1111OperateDetail";
import PageProj1111OperateDetailTarget from "./pageProj1111OperateDetailTarget/PageProj1111OperateDetailTarget";
import PageProj1111OperateDetailMode from "./pageProj1111OperateDetailMode/PageProj1111OperateDetailMode";

const TabRouteConfigs = {
    PageProj1111OperateDetail: {
        screen: PageProj1111OperateDetail,
        navigationOptions: {
            title : '1111工程详情',
            tabBarLabel : '1111工程详情',
        },
    },
    PageProj1111OperateDetailTarget: {
        screen: PageProj1111OperateDetailTarget,
        navigationOptions: {
            title : '1111工程-目标',
            tabBarLabel : '1111工程-目标',
        },
    },
    PageProj1111OperateDetailMode: {
        screen: PageProj1111OperateDetailMode,
        navigationOptions: {
            // title : '1111工程-目标',
            tabBarLabel : '1111工程-模版',
        },
    }
}

const page = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

module.exports = page;
