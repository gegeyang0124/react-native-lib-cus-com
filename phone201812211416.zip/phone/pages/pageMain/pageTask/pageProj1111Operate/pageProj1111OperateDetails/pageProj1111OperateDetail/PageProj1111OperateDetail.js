/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ButtonChange,
    ItemRowTripApply,
    ItemRowGuideTripApply,
    Charts,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageProj1111OperateDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.state = {
            id:null,  //任务id
            name:null,//任务名称
            deptName:null, //部门
            executorName:null, //申请人/执行人
            storeName:null,//客户姓名
            beginTime:null,//开始时间
            endTime:null,//结束时间
            openDate:null,//开业时间

            targetFinishList:[],//目标完成情况

            colorList:["#e85006", "#ed7d32","#ef97eb","#9fd8fc"],//颜色
            modelBtnList:[], //模版按钮
            barLegend:[
                "销售目标",
                "实际目标",
                "返单目标",
                "实际返单"
            ],//提示文本
            xAxis:["首日","首 周","首月","首季"],
            yLabel:"单位(万元)"
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    componentWillEnter(params){
        if(params){
            this.state.id = params.id;
            this.state.executorName =params.executorName
            this.getData();
        }
        this.getData();
    }

    getData() {
        Service.getProj1111Detail(this.state.id).then(retJson=>{
            let dayCount = 0;

            if(retJson.retData.openDate){
                let timeTramp = Tools.timeFormatConvert(retJson.retData.openDate);
                let d = new Date(timeTramp);
                timeTramp = new Date(d.getFullYear(),d.getMonth(),d.getDate(),0,0,0).getTime();
                let curTime = new Date().getTime();
                dayCount = (curTime - timeTramp) / Tools.ONE_DAY_TIME;
            }

            retJson.retData.modelBtnList = [
                {
                    text:'目标',
                    disabled:false,
                },
                {
                    text:'首日模板',
                    disabled:false,
                },
                {
                    text:'首周模板',
                    disabled:dayCount > 1 ? false : true,
                },
                {
                    text:'首月模板',
                    disabled:dayCount > 7 ? false : true,
                },
                {
                    text:'首季模板',
                    disabled:dayCount > 30 ? false : true,
                }
            ];

            this.setState(retJson.retData);
            // console.log(retJson.retData)
        });
    }

    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
    }

    componentWillReceiveProps(){
    }

    onPressModel(type){
        //类型：Number  必有字段  备注：类型：1.首日 2.首周 3.首月 4.首季
        switch (type){
            case 0:{
                this.goPage("PageProj1111OperateDetailTarget",{id:this.state.id});
                break;
            }
            default:{
                this.goPage("PageProj1111OperateDetailMode",{
                    id:this.state.id,
                    executorName:this.state.executorName,
                    type:type
                })

                break;
            }
        }
    }

    renderModelBtn = (item,index)=>{
        return(
            <ButtonChange key={index}
                          text={item.text}
                          disabled={item.disabled}
                          frameStyle={styles.modelBtn}
                          onPress={()=>{this.onPressModel(index)}}
                          style={[styles.titleFrame_btn,item.disabled
                              ? {
                                  backgroundColor:Theme.Colors.themeColor3
                              }
                              : {}]} />
        );
    }

    render() {
        const {name,deptName,executorName,storeName, beginTime,
            endTime,modelBtnList,targetFinishList,colorList,
            barLegend,xAxis,yLabel} = this.state;
        // console.log(this.state)

        return (
            <ViewTitle>

                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"名        称:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={name}/>

                    <ItemRowTripApply text={"部        门:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={deptName}/>

                    <ItemRowTripApply text={"执  行  人:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={executorName}/>

                    <ItemRowTripApply text={"客户姓名:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      isStar={false}
                                      text2={storeName}/>

                    <ItemRowTripApply text={"时        间:"}
                                      frameStyle={styles.titleFrameTop}
                                      isStar={false}
                                      viewCenter={
                                          <View style={styles.titleFrame_1}>
                                              <ButtonChange text={beginTime}

                                                            frameStyle={styles.titleFrame_timeBtnFrame}
                                                            textStyle={styles.titleFrame_timeBtnText}
                                                            style={styles.titleFrame_timeBtn} />

                                              <Text style={styles.titleFrame_timeText}>
                                                  ~
                                              </Text>

                                              <ButtonChange text={endTime}
                                                            frameStyle={styles.titleFrame_timeBtnFrame}
                                                            textStyle={styles.titleFrame_timeBtnText}
                                                            style={styles.titleFrame_timeBtn} />
                                          </View>
                                      }/>


                    <ItemRowTripApply text={"模        板:"}
                                      frameStyle={styles.titleFrameTop}
                                      isStar={false}
                                      viewCenter={
                                          <View style={styles.modelBtnFrame}>

                                              {
                                                  modelBtnList.map(this.renderModelBtn)
                                              }

                                          </View>
                                      }/>

                </View>

                <Charts.BarCharts colorList={colorList}
                                  xAxis={xAxis}
                                  yLabel={yLabel}
                                  barLegend={barLegend}
                                  dataList={targetFinishList}/>

            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    modelBtn:{
        marginRight:20,
    },
    modelBtnFrame:{
        flexDirection:'row',
    },

    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    titleFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        alignItems: 'center',
        justifyContent: 'center',
        height: Theme.Height.height1,

    },
    titleFrame_btn: {
        width: 100,
        height: Theme.Height.height1,
        padding: 0,
    },
    titleFrame_timeBtnFrame:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        borderRadius:Theme.Border.borderRadius,
    },
    titleFrame_timeBtn:{
        width: '0.3w',
        height: Theme.Height.height1,
        padding: 0,
        backgroundColor:Theme.Colors.transparent,
    },
    titleFrame_timeBtnText:{
        color:Theme.Colors.minorColor
    },
    titleFrame_timeText:{
        color:Theme.Colors.themeColor,
        marginLeft:10,
        marginRight:10,
        fontSize:Theme.Font.fontSize,
    },
});
