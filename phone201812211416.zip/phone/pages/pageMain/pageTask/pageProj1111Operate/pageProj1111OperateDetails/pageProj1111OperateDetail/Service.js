import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取4个1工程详情
     * @param id string,//任务ID
     * 目前图形不可维护，如需维护修改 按一下数据回传格式回传
     retData:{
          targetFinishList:[
              [],//一类数组字段 成员{x:"轴数据 可不传",y:y轴数据}
               。。。
          ],
          barLegend:[
                "销售目标",
                "实际目标",
                "返单目标",
                "实际返单"
            ],//提示文本
          xAxis:["首日","首 周","首月","首季"],x轴显示标签
          yLabel:"单位(万元)"//y轴提示文本标签
          colorList:["#e85006", "#ed7d32","#ef97eb","#9fd8fc"],//柱条显示颜色
     }
     * **/
    static getProj1111Detail(taskId){
        return Http.get(HttpUrls.urlSets.urlProj1111TaskDetail,{
            customer1111Id:taskId
        }).then(retJson=>{
            if(!retJson.retData.targetFinishList){
                retJson.retData.targetFinishList = [
                    [
                        {
                            y:retJson.retData.daySaleTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.daySaleTarget) / 100) / 100
                        },
                        {
                            y:retJson.retData.weekSaleTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.weekSaleTarget) / 100) / 100
                        },
                        {
                            y:retJson.retData.monthSaleTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.monthSaleTarget) / 100) / 100
                        },
                        {
                            y:retJson.retData.quarterSaleTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.quarterSaleTarget) / 100) / 100
                        }
                    ],
                    [
                        {
                            y:retJson.retData.daySale == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.daySale) / 100) / 100
                        },
                        {
                            y:retJson.retData.weekSale == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.weekSale) / 100) / 100
                        },
                        {
                            y:retJson.retData.monthSale == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.monthSale) / 100) / 100
                        },
                        {
                            y:retJson.retData.quarterSale == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.quarterSale) / 100) / 100
                        }
                    ],
                    [
                        {
                            y:0
                        },
                        {
                            y:retJson.retData.weekReorderTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.weekReorderTarget) / 100) / 100
                        },
                        {
                            y:retJson.retData.monthReorderTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.monthReorderTarget) / 100) / 100
                        },
                        {
                            y:retJson.retData.quarterReorderTarget == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.quarterReorderTarget) / 100) / 100
                        }
                    ],
                    [
                        {
                            y:0
                        },
                        {
                            y:retJson.retData.weekReorder == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.weekReorder) / 100) / 100
                        },
                        {
                            y:retJson.retData.monthReorder == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.monthReorder) / 100) / 100
                        },
                        {
                            y:retJson.retData.quarterReorder == null
                                ? 0
                                : parseInt(parseFloat(retJson.retData.quarterReorder) / 100) / 100
                        }
                    ]
                ];
            }

            return retJson;
        });
    }

}