/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {ScrollView, Text, View,} from 'react-native';

import {
    BaseComponent,
    ButtonChange,
    GuideImageHint,
    Image,
    ImageList,
    ItemRowGoods,
    ItemRowTitle,
    Media,
    MenuBottom,
    PickDropdown,
    StyleSheetAdapt,
    Theme,
    Tools,
    ViewTitle,
    ItemRowSwitch,
    ItemRowTripApply,
    ButtonTime,
    TextChange,
} from "com";
import {Swiper} from "comThird";
import {Service} from "./Service";

type Props = {};
export default class PageProj1111OperateDetailMode extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.selectedValue = {
            id:null,//任务ID
            type:null,
            indexParent:null,
            index:null,
            timeObj:null,//时间对象
            executorName:null,//执行人
            right:false
        };

        this.btnList = [
            {
                text:'拍照',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.configData = {
            execFirst:true,
        };

        this.state = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            modelList:[],// 主体导航数据（包含左侧导航）
            guideTopList:[],//顶部导航数据
            renderView:false,
            taskName:null,
        };


    }

    //类型：Number  必有字段  备注：类型：1.首日 2.首周 3.首月 4.首季
    componentWillEnter(params){
        /*params = {
            id:"5b5eae71e21389000cd5dabc",
            type:1,
        }*/

        if(params){
            this.selectedValue.id = params.id;
            this.selectedValue.type = params.type;
            this.selectedValue.executorName=params.executorName
            this.state.id = params.id;
            let title = "1111工程-";
            switch (this.selectedValue.type){
                case 1:{
                    title += "首日";
                    break;
                }
                case 2:{
                    title += "首周";
                    break;
                }
                case 3:{
                    title += "首月";
                    break;
                }
                case 4:{
                    title += "首季";
                    break;
                }
            }

            this.setParams({
                title:title
            });
            this.getData();
        }
        if(this.selectedValue.executorName==Tools.userConfig.userInfo.full_name){
            this.selectedValue.right=true
        }
        this.setParams({
            headerLeft:true,
            headerRight:this.selectedValue.right&&<ButtonChange text={"提交"}
                                                                onPressIn={this.onPressRight}/>
        });
    }

    componentWillExit(){
        // Tools.toast("ds");
        this.initState();
    }

    componentDidMount() {
        // this.getData();
    }

    initState(){
        let stateInit = {
            id:null,//任务ID
            // id:"05af9dc4-01dc-464b-9341-cbb3c638046d",//任务ID

            modelList:[],//左侧导航数据
            guideTopList:[],//顶部导航数据
            renderView:false
        };
        this.state = stateInit;
        this.setState(stateInit);
    }

    onDelFile = (item,i) =>{

        // console.info("item",item);
        // console.info("this.state.modelList",this.state.modelList);
        this.state.modelList[item.indexParent0]
            .main[item.indexParent1]
            .fileList[item.indexParent2]
            .fileUrl.splice(item.index, 1);

        let modelList = [];
        this.state.modelList.forEach((v, i, a) => {
            modelList.push(v);
        });


        this.setState({
            modelList:modelList
        });
    }

    addFile(item){


        let modelList = [];

        this.state.modelList.forEach((v, i, a) => {
            if (i == this.selectedValue.indexParent0) {
                v.main.forEach((v1, i1, a1) => {

                    if(i1 == this.selectedValue.indexParent1){
                        v1.fileList[this.selectedValue.index].fileUrl.push({
                            icon:item.path,
                            isPut:true,
                            id:v1.fileList[this.selectedValue.index].fileId,
                            indexParent0:this.selectedValue.indexParent0,
                            indexParent1:this.selectedValue.indexParent1,
                            indexParent2:this.selectedValue.index,
                            index:v1.fileList[this.selectedValue.index].fileUrl.length,
                        });
                    }

                });
            }

            modelList.push(v);

        });

        this.selectedValue.indexParent0 = null;
        this.selectedValue.indexParent1 = null;
        this.selectedValue.index = null;

        this.setState({
            modelList:modelList
        });
    }

    onGetPic = (item,i)=>{

        if(i == 0) {
            Media.takeImage(this.state.taskName,true,()=>{
                MenuBottom.show(false);
            }).then(retJson=>{
                this.addFile(retJson);
            });
        }else if(i == 1){
            MenuBottom.show(false);
            Media.pickImage(false,this.state.taskName).then(retJson=>{
                this.addFile(retJson);
                // MenuBottom.show(false);
            });

        }
    }

    showMenu(parent0,parent1,index){
        // this.configData.type = type;

        this.selectedValue.indexParent0 = parent0;
        this.selectedValue.indexParent1 = parent1;
        this.selectedValue.index = index;

        MenuBottom.show(true);

    }

    getData(){
        Service.getModeDetail(this.selectedValue.id,this.selectedValue.type)
            .then(retJson=>{
                // console.info("retJson",retJson);
                retJson.renderView = true;
                this.setState(retJson);
            });
    }

    onIndexChanged(index,type,pos){
        if(pos == "top"){
            switch (type){
                case 0:{
                    // alert(index)
                    let guideTopList = [];
                    this.state.guideTopList.forEach((v,i,a)=>{
                        v.status = 0;
                        if(index == i)
                        {
                            v.status = 1;
                        }

                        guideTopList.push(v);
                    });

                    this.setState({
                        guideTopList:guideTopList
                    });
                    break;
                }
            }
        }
        else
        {
            let modelList = [];
            this.state.modelList.forEach((v,i,a)=>{
                if(i == type){
                    v.guideLeftList.forEach((v1,i1,a1)=>{
                        v1.status = 0;
                        if(index == i1)
                        {
                            v1.status = 1;
                        }
                    });
                }

                modelList.push(v);
            });

            this.setState({
                modelList:modelList
            });

            // alert("index:" + index + "  type" + type);
        }

    }

    onPressCutPage(item,i,type){
        // console.info("item i=" + i + " type=" + type,item);
        switch (type)
        {
            case "top" :{
                this.refs.swiperGuideTop.scrollBy(i,true,true);
                break;
            }
            case "left":{
                this.refs["swiperGuideLeft" + item.indexParent].scrollBy(i,true,true);
            }
        }

    }

    onSelectPd(item,idx,indexParent,index){
        // Tools.toast(JSON.stringify(item));

        this.selectedValue["fileProj" + indexParent + index] = item;
        this.selectedValue["isAdd" + indexParent + index] = true;

        this.state.modelList.forEach((v,i,a)=>{
            if(i == indexParent){
                v.main.forEach((v1,i1,a1)=>{
                    if(index == i1){
                        v1.fileList
                            .forEach((v2,i2,a2)=>{
                                if(idx == i2){
                                    if(item.fileId == v2.fileId){

                                        this.selectedValue["isAdd" + indexParent + index] = false;
                                    }
                                }

                            });
                    }

                });
            }

        });

    }

    onPressAddFileProj(indexParent,index) {


        if (this.selectedValue["isAdd" + indexParent + index] == null) {
            Tools.toast("请选择文件类型");
        }
        else if (this.selectedValue["isAdd" + indexParent + index]) {

            let ref = this.refs["txtPd" + indexParent + index];
            if(ref){
                ref.setText(this.selectedValue["fileProj" + indexParent + index].fileDesc);
            }

            let modelList = [];

            this.state.modelList.forEach((v, i, a) => {
                if (i == indexParent) {
                    v.main.forEach((v1, i1, a1) => {
                        if(index == i1)
                        {
                            v1.fileList.push(this.selectedValue["fileProj" + indexParent + index]);
                        }

                    });
                }

                modelList.push(v);

            });

            this.selectedValue["isAdd" + indexParent + index] = false;
            this.setState({
                modelList:modelList
            });
        }
        else {
            Tools.toast("此文件类型已存在");
        }

    }

    getFiles(isPut = true){
        let fileList = [];
        this.state.modelList.forEach((v,i,a)=>{
            v.main.forEach((v1,i1,a1)=>{
                v1.fileList.forEach((v2,i2,a2)=>{
                    v2.fileUrl.forEach((v3,i3,a3)=>{
                        v3.isPut = v3.isPut ? isPut : v3.isPut;
                        if(v3.isPut){
                            v3.localPath = v3.icon;
                            fileList.push(v3);
                        }
                    });
                });
            });
        });

        return fileList;
    }

    onChangeTime = ({timestamp, timeformat})=>{
        this.selectedValue.timeObj = {
            timestamp:timestamp,
            timeformat:timeformat+":00"
        }
    }

    onPressRight= ()=>{

        let fileList = this.getFiles();
        // console.log(this.selectedValue.timeObj.timeformat)
        if(this.selectedValue.timeObj){
            Service.putInOpenTime(this.state.id,this.selectedValue.timeObj.timeformat)
                .then(retJson=>{
                    this.selectedValue.timeObj = null;
                    Theme.PageRefresh.PageProj1111OperateList = true;
                    if(fileList.length == 0){
                        Tools.toast("提交成功！");
                    }
                });
        }

        if(fileList.length > 0){

            Service.putIn(this.state.id,fileList)
                .then(retJson=>{
                    Tools.toast("提交成功！");
                    Theme.PageRefresh.PageProj1111OperateList = true;
                    this.getFiles(false);
                });
        }
        /*else {
            Tools.toast("主人，您没有数据要提交哦！");
        }*/

    };

    renderItemViewAddFile = (item,i)=>{

        return(
            this.selectedValue.executorName==Tools.userConfig.userInfo.full_name?<View key={i}>
                    <ItemRowTitle text1={item.name}
                                  frameStyle={styles.itemRowFrame}
                                  text2={"选择附件"}
                                  onPressRight={()=>this.showMenu(item.indexParent0,item.indexParent1,i)}/>

                    <ImageList dataList={item.fileUrl}
                               text={"删除"}
                               textStyle={styles.textImage}
                               frameStyle={styles.imageListFrame}
                               onPressText={this.onDelFile}
                               imageFrameStyle={styles.imageFileFrame}
                               iconStyle={styles.imageFile}/>
                </View>:
                <View key={i}>
                    <ItemRowTitle
                        text1={item.name}
                        frameStyle={styles.itemRowFrame}
                    />

                    <ImageList dataList={item.fileUrl}
                               frameStyle={styles.imageListFrame}
                               imageFrameStyle={styles.imageFileFrame}
                               iconStyle={styles.imageFile}/>
                </View>
        );
    }

    renderItemView = (item,i)=>{
        // console.log(this.selectedValue.executorName==Tools.userConfig.userInfo.full_name)
        return(
            this.selectedValue.executorName==Tools.userConfig.userInfo.full_name
                ? <ScrollView key={i}>
                    {
                        !item.isOpenAudit
                        && <View style={styles.bodyFrameRight_1}>

                            <ItemRowTitle text1={item.hint1}/>

                            <Image source={require("images/titleBgProj1111.png")}
                                   imageStyle={styles.image}
                                   style={styles.imageFrame}>
                                <Text style={styles.text}>
                                    {
                                        item.explain
                                    }
                                </Text>
                            </Image>


                            <ItemRowSwitch textHeaderLeft={item.hint2}
                                           isHorizontalPillar={false}
                                           isShowPillar={true}
                                           titleFrameStyle={styles.itemRowTitleFrame}
                                           frameStyle={styles.itemRowFrame}
                                           isShowChildrenDefault={true}
                                           isOpenFile={true}
                                           dataList={item.templateFileList}/>
                        </View>
                    }


                    {
                        item.needUploadfileList.length > 0
                        &&  <View style={styles.bodyFrameRight_2}>
                            {
                                !item.isOpenAudit
                                &&<TextChange ref={"txtPd" + item.indexParent + item.index}/>
                            }
                            {
                                !item.isOpenAudit
                                && <View style={styles.bodyFrameRight_2_1}>
                                    <PickDropdown options={item.needUploadfileList}
                                                  onSelect={(index,itm)=>this.onSelectPd(itm,index,item.indexParent,item.index)}
                                                  defaultValue={"文件类型"}/>

                                    <ButtonChange frameStyle={styles.btnAddFrame}
                                                  style={styles.btnText}
                                                  onPress={()=>this.onPressAddFileProj(item.indexParent,item.index)}
                                                  text={"添加"}/>
                                </View>
                            }

                            {
                                item.fileList.map(this.renderItemViewAddFile)
                            }

                        </View>
                    }

                    {
                        item.isOpenAudit
                        && <ItemRowTripApply text={"开业时间:"}
                                             frameStyle={styles.btnTimeFrame}
                                             frameLabelStyle={styles.openTimeLabelFrame}
                                             viewCenter={
                                                 <ButtonTime defaultText={"请选择时间"}
                                                             onChange={this.onChangeTime}/>
                                             }
                                             isStar={false}/>
                    }

                </ScrollView>
                : <ScrollView key={i}>
                    {
                        !item.isOpenAudit
                        && <View style={styles.bodyFrameRight_1}>

                            <ItemRowTitle text1={item.hint1}/>

                            <Image source={require("images/titleBgProj1111.png")}
                                   imageStyle={styles.image}
                                   style={styles.imageFrame}>
                                <Text style={styles.text}>
                                    {
                                        item.explain
                                    }
                                </Text>
                            </Image>

                            <ItemRowSwitch textHeaderLeft={item.hint2}
                                           isHorizontalPillar={false}
                                           isShowPillar={true}
                                           titleFrameStyle={styles.itemRowTitleFrame}
                                           frameStyle={styles.itemRowFrame}
                                           isShowChildrenDefault={true}
                                           isOpenFile={true}
                                           dataList={item.templateFileList}/>
                        </View>
                    }


                    {
                        item.needUploadfileList.length > 0
                        &&  <View style={styles.bodyFrameRight_2}>
                            {
                                !item.isOpenAudit
                                && <View style={styles.bodyFrameRight_2_1}>
                                    <PickDropdown options={item.needUploadfileList}

                                                  defaultValue={"现场照片"}/>


                                </View>
                            }

                            {
                                item.fileList.map(this.renderItemViewAddFile)
                            }

                        </View>
                    }


                </ScrollView>
        );
    }

    renderItem = (item,i)=>{


        let viewList =[];
        for(let i = 0; i < item.main.length; i++){
            viewList.push(this.renderItemView(item.main[i],i));
        }

        return(
            <View key={i}
                  style={styles.bodyFrame}>

                <View style={styles.bodyFrameLeft}>
                    <GuideImageHint frameStyle={styles.frameLeftStyle}
                                    iconType={"square"}
                                    isScroll={true}
                                    onPress={(itm,index)=>this.onPressCutPage(itm,index,"left")}
                                    frameImageListStyle={styles.frameImageListStyle}
                                    dataList={item.guideLeftList}/>
                </View>

                <View style={styles.bodyFrameRight}>

                    <Swiper loop={false}
                            ref={"swiperGuideLeft" + i}
                            onIndexChanged={(index)=>this.onIndexChanged(index,i,"left")}
                            horizontal={false}
                            showsPagination={false}>
                        {
                            viewList.map(value=>value)
                        }
                    </Swiper>

                </View>

            </View>
        );
    }

    render() {

        const {modelList,guideTopList,renderView} = this.state;

        let viewList =[];
        modelList.forEach((val,i,arr)=>{
            viewList.push(this.renderItem(val,i));
        });

        // Tools.toast(viewList.length);

        return (
            <ViewTitle isScroll={false}>

                <GuideImageHint frameStyle={styles.frameStyle}
                                textStyle={styles.titleText}
                                onPress={(item,i)=>this.onPressCutPage(item,i,"top")}
                                dataList={guideTopList}/>

                <View style={styles.cntFrame}>
                    {
                        renderView ?  <Swiper loop={false}
                                              ref={"swiperGuideTop"}
                                              horizontal={true}
                                              onIndexChanged={(index)=>this.onIndexChanged(index,0,"top")}
                                              showsPagination={false}>

                            {
                                viewList.map(value=>value)
                            }

                        </Swiper> : null
                    }

                </View>

                <MenuBottom btnList={this.btnList}
                            isVisibleClose={false} />

            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    btnTimeFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },
    openTimeLabelFrame:{
        flex:2,
    },

    itemRowTitleFrame:{
        backgroundColor:Theme.Colors.transparent
    },
    cntFrame:{
        flex:9
    },
    textRow2:{
        fontSize:Theme.Font.fontSize,
        color:Theme.Colors.themeColor,
        marginRight:20,
    },
    imageListFrame:{
        width:StyleSheetAdapt.getWidth("0.8w") - 30 + "n",
    },
    textImage:{
        fontSize:Theme.Font.fontSize_1,
        marginTop:5,
        padding:5,
        paddingLeft:15,
        paddingRight:15,
        backgroundColor:Theme.Colors.themeColor2
    },
    imageFileFrame:{
        width:150,
        height:170,
    },
    imageFile:{
        width:150,
        height:112.5,
        // backgroundColor:"yellow"
    },
    btnText:{
        padding:5,
        paddingLeft:20,
        paddingRight:20,
    },
    btnAddFrame:{
        marginLeft:50,
    },
    bodyFrameRight_2_1:{
        margin:10,
        flexDirection:'row',
        // justifyContent:"center",
        alignItems:"center",
    },
    bodyFrameRight_2:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
    },
    bodyFrameRight_1:{
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingBottom:20,
    },
    itemRowFrame:{
        margin:10,
    },
    text:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.foregroundColor,
        margin:10,
    },
    image:{
        resizeMode:"stretch",
        marginLeft:10,
    },
    imageFrame:{
        // flex:1,
        width:StyleSheetAdapt.getWidth("0.8w") - 30 + "n",
        // height:60,
        // backgroundColor:'blue',
        // paddingLeft:10,
        // paddingRight:10,
        // padding:10,
        justifyContent:"center",
        alignItems:"center",
    },
    frameLeftStyle:{
        backgroundColor:Theme.Colors.transparent,
        flex:1,
        justifyContent:"flex-start",
        alignItems:"center",
    },
    frameImageListStyle:{
        flexDirection:"column",
        // justifyContent:"flex-start",
        // alignItems:"center",
    },
    bodyFrameLeft:{
        flex:2,
        backgroundColor:Theme.Colors.themeColor1,
        justifyContent:"flex-start",
        alignItems:"center",
        marginTop:10,
    },
    bodyFrameRight:{
        flex:8,
        marginTop:10,
        marginLeft:10,
    },
    titleText:{
        fontSize:Theme.Font.fontSize_2 - 1.5,
        // marginTop:20,
    },
    bodyFrame:{
        // backgroundColor:Theme.Colors.foregroundColor,
        // alignItems:'center',
        // justifyContent:'center',
        flex:9,
        // height:'h',
        flexDirection:'row',
        // marginTop:10,
        marginBottom:10,
    },

    frameStyle:{
        padding:10,
        flex:1,
        marginTop:10,
    },
});
