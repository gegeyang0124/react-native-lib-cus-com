import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";
import ImageDoc from 'images/doc.png';
import ImagePdf from 'images/pdf.png';
import ImagePpt from 'images/ppt.png';
import ImageXls from 'images/xls.png';

/**
 * 接口
 * **/
export class Service {


    static base;

    static retJson = {
        steps:[],//提示步骤名
        pageCode:null,//要进入页面的编码
        currentTaskId:null,//当前步骤ID，
        event_list:null,//操作事件数据数组
    };//后台返回数据

    constructor() {
        Service.base = this;
    }

    /**
     * 提交签到
     * @param taskId string,//任务ID
     * @param commitDataList array,//需要提交的文件数组
     * **/
    static putIn(taskId,commitDataList){

        /*{                //类型：Object  可有字段  备注：无
               "customer_1111_id":"dba60b90-848a-4e88-8263-a0efab55d2f5",                //类型：String  必有字段  备注：客户四个一id
               "file_id":"58f04f4d-df78-4aea-828e-5d32dc1f0ec8",                //类型：String  必有字段  备注：文件id
               "executor":"931",                //类型：String  必有字段  备注：提交人userId
               "url":"https://gss2.bdstatic.com/9fo3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike150%2C5%2C5%2C150%2C50/sign=07f72b9177899e516c83324623ceb256/3812b31bb051f819b415fb26d6b44aed2e73e7ae.jpg"                //类型：String  必有字段  备注：文件地址
           }*/

        return new Promise((resolve, reject) => {

            if(commitDataList.length == 0){
                reject({status:'无数据'});
            }

            Http.upLoadFileToService(commitDataList)
                .then(retJson=>{

                    let requestData = [];
                    retJson.forEach((v,i,a)=>{
                        let isPush = true;

                        requestData.forEach((v1,i1,a1)=>{
                            if(v1.file_id == v.id){
                                isPush = false;
                                v1.url.push(v.servicePath);
                            }
                        });

                        if(isPush){
                            requestData.push({
                                customer_1111_id:taskId,
                                file_id:v.id,
                                executor:Tools.userConfig.userInfo.id,
                                url:[v.servicePath]
                            });
                        }

                    });

                    requestData.forEach((v1,i1,a1)=>{
                        v1.url = v1.url.toString();
                    });

                    Http.post(HttpUrls.urlSets.urlProj1111TaskModeFileAdd, {
                        fileList:requestData
                    })
                        .then((retJson)=>{

                            resolve(retJson);

                        });
                });


        });

    }

    /**
     * 提交开业方案时间
     * @param taskId string,//任务ID
     * @param time string,//时间 "YYYY-MM-DD HH:mm:ss"
     * **/
    static putInOpenTime(taskId,time){
        return Http.post(HttpUrls.urlSets.urlProj1111TaskUpdateTarget,{
            id:taskId,
            openDate:time
        }).then(retJson=>retJson);
    }

    /**
     * 获取模版详情
     * @param taskId string,//任务ID
     * @param type string,//请求类型：Number  必有字段  备注：类型：1.首日 2.首周 3.首月 4.首季
     *
     * 目前开业方案不可维护 level第二层回传数据isOpenAudit，true是开业审核，false不是开业审核
     * **/
    static getModeDetail(taskId,type){
        return Http.post(HttpUrls.urlSets.urlProj1111TaskModeDetail, {
            customer1111Id:taskId,//任务ID
            type:type//类型：Number  必有字段  备注：类型：1.首日 2.首周 3.首月 4.首季
        })
            .then((retJson)=>{
                let retObj = {
                    modelList:[],
                    guideTopList:[]
                };

                retJson.retData.children
                    .forEach((v,i,a)=>{
                        let s = v.name.length > 4
                            ? v.name.substring(0,4)
                            + "\n    "
                            + v.name.substring(4,v.name.length)
                            : v.name;
                        retObj.guideTopList.push({
                            text:s,
                            id:v.id,
                            index:i,
                            status:i == 0 ? 1 : 0
                        });

                        let item = {
                            guideLeftList:[],
                            main:[],
                        };
                        v.children
                            .forEach((v1,i1,a1)=>{
                                v1.indexParent = i;

                                if(!v1.isOpenAudit){
                                    v1.isOpenAudit = false;
                                    if(v1.name == "开业方案"){
                                        v1.isOpenAudit = true;
                                    }
                                }

                                v1.index = i1;
                                let s2 = v1.name.length > 2
                                    ? v1.name.substring(0,2)
                                    + "\n"
                                    + v1.name.substring(2,v1.name.length)
                                    : v1.name;
                                item.guideLeftList.push({
                                    text:s2,
                                    id:v1.id,
                                    index:i1,
                                    indexParent:i,
                                    status:i1 == 0 ? 1 : 0
                                });

                                v1.fileList = [];
                                v1.needUploadfileList
                                    .forEach((v2,i2,a2)=>{
                                        v2.name = v2.fileName;
                                        v2.indexParent0 = i;
                                        v2.indexParent1 = i1;
                                        v2.index = i2;
                                        v2.fileUrl = v2.fileUrl != null
                                            ? v2.fileUrl.split(",")
                                            : [];

                                        let fileUrl = [];
                                        v2.fileUrl.forEach((v3,i3,a3)=>{
                                            fileUrl.push({
                                                icon:v3,
                                                id:v2.fileId,
                                                isPut:false,//是否提交
                                                indexParent0:i,
                                                indexParent1:i1,
                                                indexParent2:i2,
                                                index:i3,
                                            })
                                        });

                                        v2.fileUrl = fileUrl;

                                        if(v1.isOpenAudit){
                                            v1.fileList.push(v2);
                                        }
                                        else {
                                            if(v2.fileUrl.length > 0){
                                                v1.fileList.push(v2);
                                            }
                                        }

                                    });

                                v1.templateFileList
                                    .forEach((v2,i2,a2)=>{
                                        v2.uri = v2.fileUrl;
                                        v2.title = v2.fileName;
                                        v2.icon = v2.uri.indexOf(".do") > -1
                                            ? ImageDoc
                                            : v2.uri.indexOf(".xl") > -1
                                                ? ImageXls
                                                : v2.uri.indexOf(".ppt") > -1
                                                    ? ImagePpt
                                                    : ImagePdf;

                                    });

                                item.main.push(v1);
                            });

                        retObj.modelList.push(item);
                    });

                return retObj;
            });
    }

}