import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ItemRowTripApply,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageProj1111OperateDetailTarget extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.selectedValue = {
            id:null, // id 必填
            day_sale_target:null, // 首日销售目标
            week_sale_target:null, // 首周销售目标
            week_reorder_target:null, // 首周返单目标
            month_sale_target:null, // 首月销售目标
            month_reorder_target:null, // 首月返单目标
            quarter_sale_target:null, // 首季销售目标
            quarter_reorder_target:null // 首季返单目标

        };

        this.state = {
            id:null,  //任务id
            daySaleTarget:null,//首日目标
            dayFirstEdit:"text",//首日 编辑
            weekSaleTarget:null,//首周目标
            weekReorderTarget:null,//首周返单目标
            weekFirstEdit:"text",//首周 编辑
            monthSaleTarget:null,//首月目标
            monthReorderTarget:null,//首月返单目标
            monthFirstEdit:"text",//首月 编辑
            quarterSaleTarget:null,//首季目标
            quarterReorderTarget:null,//首季返单目标
            seasonFirstEdit:"text",//首季 编辑
            isPutIn:false,
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    componentWillEnter(params){
        if(params){
            this.state.id = params.id;
            this.selectedValue.id = params.id;

            this.getData();
        }
    }

    getData() {
        Service.getProj1111Detail(this.state.id).then(retJson=>{
            console.log(retJson)
            let dayCount = 0;

            if(retJson.retData.openDate){
                let timeTramp = Tools.timeFormatConvert(retJson.retData.openDate);
                let d = new Date(timeTramp);
                timeTramp = new Date(d.getFullYear(),d.getMonth(),d.getDate(),0,0,0).getTime();
                let curTime = new Date().getTime();
                dayCount = (curTime - timeTramp) / Tools.ONE_DAY_TIME;
            }

            // retJson.retData.dayFirstEdit = !retJson.retData.openDate|| !dayCount >0
            //     ? "input"
            //     : "text";
            // retJson.retData.dayFirstEdit = dayCount > 1 && dayCount <= 7
            //     ? retJson.retData.seasonFirstEdit
            //     : "text";
            // retJson.retData.monthFirstEdit = dayCount > 7 && dayCount <= 30
            //     ? "input"
            //     : "text";
            // retJson.retData.seasonFirstEdit = dayCount > 30 && dayCount <= 90
            //     ? "input"
            //     : "text";
            retJson.retData.dayFirstEdit="input"
            retJson.retData.weekFirstEdit="input"
            retJson.retData.monthFirstEdit="input"
            retJson.retData.seasonFirstEdit="input"

            retJson.retData.isPutIn = dayCount > 90 ? false : true;


            this.setState(retJson.retData);
        });
    }

    componentWillMount(){

    }

    componentDidMount() {
        // this.getData();
    }

    componentWillReceiveProps(){
    }

    onChangeText(text,type){
        let isNumber = true;
        text = text + "";
        text = text.trim();

        switch (type){
            case 0:{
                if(isNumber){
                    this.selectedValue.day_sale_target = text;
                }
                else {
                    this.selectedValue.day_sale_target = this.state.daySaleTarget;
                }
                this.setState({
                    daySaleTarget:this.selectedValue.day_sale_target
                });
                break;
            }
            case 1:{
                if(isNumber){
                    this.selectedValue.week_sale_target = text;
                }
                else {
                    this.selectedValue.week_sale_target = this.state.weekSaleTarget;
                }
                this.setState({
                    weekSaleTarget:this.selectedValue.week_sale_target
                });
                break;
            }
            case 2:{
                if(isNumber){
                    this.selectedValue.week_reorder_target = text;
                }
                else {
                    this.selectedValue.week_reorder_target = this.state.weekReorderTarget;
                }

                this.setState({
                    weekReorderTarget:this.selectedValue.week_reorder_target
                });
                break;
            }
            case 3:{
                if(isNumber){
                    this.selectedValue.month_sale_target = text;
                }
                else {
                    this.selectedValue.month_sale_target = this.state.monthSaleTarget;
                }

                this.setState({
                    monthSaleTarget:this.selectedValue.month_sale_target
                });
                break;
            }
            case 4:{
                if(isNumber){
                    this.selectedValue.month_reorder_target = text;
                }
                else {
                    this.selectedValue.month_reorder_target = this.state.monthReorderTarget;
                }

                this.setState({
                    monthReorderTarget:this.selectedValue.month_reorder_target
                });
                break;
            }
            case 5:{
                if(isNumber){
                    this.selectedValue.quarter_sale_target = text;
                }
                else {
                    this.selectedValue.quarter_sale_target = this.state.quarterSaleTarget;
                }

                this.setState({
                    quarterSaleTarget:this.selectedValue.quarter_sale_target
                });
                break;
            }
            case 6:{
                if(isNumber){
                    this.selectedValue.quarter_reorder_target = text;
                }
                else {
                    this.selectedValue.quarter_reorder_target = this.state.quarterReorderTarget;
                }

                this.setState({
                    quarterReorderTarget:this.selectedValue.quarter_reorder_target
                });
                break;
            }
        }
    }

    onPressBottom = ()=>{
        var reg = /^[1-9][0-9]*$/;

        if(this.state.dayFirstEdit == "input" && !reg.test(this.selectedValue.day_sale_target)){
            Tools.toast("非法输入，请填写正确的首日目标！");
            return;
        }

        if(this.state.weekFirstEdit == "input"){
            if(!reg.test(this.selectedValue.week_sale_target) ||
                !reg.test(this.selectedValue.week_reorder_target)){
                Tools.toast("非法输入，请填写正确的首周目标！");
                return;
            }
        }

        if(this.state.monthFirstEdit == "input"){
            if(!reg.test(this.selectedValue.month_sale_target) ||
                !reg.test(this.selectedValue.month_reorder_target)){
                Tools.toast("非法输入，请填写正确的首月目标！");
                return;
            }
        }

        if(this.state.seasonFirstEdit == "input"){
            if(!reg.test(this.selectedValue.quarter_sale_target) ||
                !reg.test(this.selectedValue.quarter_reorder_target)){
            Tools.toast("非法输入，请填写正确的首季目标！");
            return;
            }
        }

        Service.putIn(this.selectedValue)
            .then(retJson=>{
                Tools.toast("提交成功");
            });
        this.goPage('PageProj1111OperateDetail')
    }

    render() {
        const {daySaleTarget,weekSaleTarget,weekReorderTarget,
            monthSaleTarget,monthReorderTarget,quarterSaleTarget,
            quarterReorderTarget,dayFirstEdit,weekFirstEdit,monthFirstEdit,
            seasonFirstEdit,isPutIn} = this.state;

        return (
            <ViewTitle viewBottom={isPutIn ? "提交" : null}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"首日销售目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={dayFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:daySaleTarget
                                                  ? daySaleTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,0)
                                          }
                                      }
                                      text2={daySaleTarget}/>

                    <ItemRowTripApply text={" 首周销售目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop2}
                                      viewCenter={weekFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:weekSaleTarget
                                                  ? weekSaleTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,1)
                                          }
                                      }
                                      text2={weekSaleTarget}/>

                    <ItemRowTripApply text={"首周返单目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={weekFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:weekReorderTarget
                                                  ? weekReorderTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,2)
                                          }
                                      }
                                      text2={weekReorderTarget}/>

                    <ItemRowTripApply text={"首月销售目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop2}
                                      viewCenter={monthFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:monthSaleTarget
                                                  ? monthSaleTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,3)
                                          }
                                      }
                                      text2={monthSaleTarget}/>

                    <ItemRowTripApply text={"首月返单目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={monthFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:monthReorderTarget
                                                  ? monthReorderTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,4)
                                          }
                                      }
                                      text2={monthReorderTarget}/>

                    <ItemRowTripApply text={"首季销售目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop2}
                                      viewCenter={seasonFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:quarterSaleTarget
                                                  ? quarterSaleTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,5)
                                          }
                                      }
                                      text2={quarterSaleTarget}/>

                    <ItemRowTripApply text={"首季返单目标:"}
                                      frameLabelStyle={styles.itemRowLabel}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={seasonFirstEdit}
                                      isStar={false}
                                      viewCenterProps={
                                          {
                                              keyboardType:"numeric",
                                              value:quarterReorderTarget
                                                  ? quarterReorderTarget + ""
                                                  : "",
                                              onChangeText:(text)=>this.onChangeText(text,6)
                                          }
                                      }
                                      text2={quarterReorderTarget}/>

                </View>


            </ViewTitle>
        );

    }
}

const styles = StyleSheetAdapt.create({
    itemRowLabel:{
        flex:2.5,
    },

    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },
    titleFrameTop2:{
        marginTop:40,
    },

});