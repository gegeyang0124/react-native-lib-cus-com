import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取4个1工程详情
     * @param id string,//任务ID
     * **/
    static getProj1111Detail(taskId){
        return Http.get(HttpUrls.urlSets.urlProj1111TaskDetail,{
            customer1111Id:taskId
        }).then(retJson=>{
            retJson.retData.monthSaleTarget?retJson.retData.monthSaleTarget:''
            retJson.retData.weekSaleTarget?retJson.retData.weekSaleTarget:''
            retJson.retData.monthReorderTarget?retJson.retData.monthReorderTarget:''
            retJson.retData.weekReorderTarget?retJson.retData.weekReorderTarget:''

            if(!retJson.retData.monthSaleTarget){
                retJson.retData.monthSaleTarget=''
            }
            if(!retJson.retData.weekSaleTarget){
                retJson.retData.weekSaleTarget=''
            }
            if(!retJson.retData.monthReorderTarget){
                retJson.retData.monthReorderTarget=''
            }
            if(!retJson.retData.weekReorderTarget){
                retJson.retData.weekReorderTarget=''
            }
            if(!retJson.retData.daySaleTarget){
                retJson.retData.daySaleTarget=''
            }
            if(!retJson.retData.quarterReorderTarget){
                retJson.retData.quarterReorderTarget=''
            }
            if(!retJson.retData.quarterSaleTarget){
                retJson.retData.quarterSaleTarget=''
            }

            console.log(retJson)
            return retJson;

        });
    }

    /**
     * 更新目标数据
     * **/
    static putIn(selectedValue){

        return Http.post(HttpUrls.urlSets.urlProj1111TaskUpdateTarget,
            selectedValue)
            .then(retJson=>retJson);
    }

}