/**
 * Created by Administrator on 2018/5/5.
 */

import {
    Theme,
} from "com";
import {
    TabNavigator,
} from 'comThird'
import PageSurveyPSQStatistics from "./pageSurveyPSQStatistics/PageSurveyPSQStatistics";
import PageSurveyPSQDetail from "./pageSurveyPSQDetail/PageSurveyPSQDetail";
import PageSurveyPSQList from "./pageSurveyPSQList/PageSurveyPSQList";

const TabRouteConfigs = {
    PageSurveyPSQStatistics: {
        screen: PageSurveyPSQStatistics,
        navigationOptions: ({navigation}) => ({
            title : '参与列表',
            tabBarLabel : '参与列表',
        }),
    },
    PageSurveyPSQDetail: {
        screen: PageSurveyPSQDetail,
        navigationOptions: ({navigation}) => ({
            title : '问卷详情',
            tabBarLabel : '问卷详情',
        }),
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

const pageSurveyPSQs = {
    get PageSurveyPSQs() {
        return pages;
    },
    get PageSurveyPSQList() {
        return PageSurveyPSQList;
    }
};

module.exports = pageSurveyPSQs;