/**
 * Created by Administrator on 2018/5/5.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    SearchDropIpt,
    Tools,
    Image,
    QuestionList,
} from "com";
import ImageBgSurveyPSQ from 'images/bgSurveyPSQ.png';
import { Service } from "./Service";

/**
 * 调查问卷 详情
 * **/
type Props = {};
export default class PageSurveyPSQDetail extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerLeftHandle:this.initState,
            headerRight:false,
        });

        this.configData = {
            execFirst:true
        };


        this.selectedValue = {
            id:null,//问卷ID
            /**
             * {
            questionid: "",//题目id
            questionOptionid: [],//题目答案
        }
             * **/
            questions:[],//问卷提交集合
        };//问卷提交集合

        this.state = {
            isClear:false,
            isAnswer:false,//是否答题
            id:null,//问卷ID
            // id:"4dcc52dd-4f74-42b0-88a7-ace281398ef1",//问卷ID
            name:null,//问卷名称
            time:null,//时间
            dataList:[],//数组列表
        };
    }

    initState = ()=>{
        this.selectedValue = {
            id:null,//问卷ID
            /**
             * {
            questionid: "",//题目id
            questionOptionid: [],//题目答案
        }
             * **/
            questions:[],//问卷提交集合
        };//问卷提交集合

        let state = {
            isClear:true,
            isAnswer:false,//是否答题
            id:this.state.id,//问卷ID
            // id:"4dcc52dd-4f74-42b0-88a7-ace281398ef1",//问卷ID
            name:null,//问卷名称
            time:null,//时间
            dataList:[],//数组列表
        };
        this.setState(state);
    };

    onChange = (dataList)=>{
        this.selectedValue.questions = [];
        dataList.forEach((v,i,a)=>{
            let item = {
                questionid:v.questionid,//题目id
                questionOptionid:[]//题目答案
            };

            if(v.type == "answer"){
                item.questionOptionid = v.answer ? v.answer : '';
            }
            else {
                v.answerList.forEach((v1,i1,a1)=>{
                    if(v1.isChecked){
                        // alert(JSON.stringify(item))
                        item.questionOptionid.push(v1.id);
                        // alert(JSON.stringify(v1))
                    }

                });
            }

            // console.info("v:",v)
            this.selectedValue.questions.push(item);
        });
        // console.info("dataList:",dataList);
    }

    getData(){
        Service.get(this.state.id,this.state.isAnswer)
            .then(reJson=>{
                reJson.isClear = false;
                this.setState(reJson);
            });
        /* Service.getCheck(this.state.id)
             .then(reJson=>{
                 this.setState(reJson);
             });*/
    }

    componentWillMount(){
    }

    componentDidMount(){
        // this.getData();
    }
    componentWillEnter(params){
        // console.info("params",params)
        // this.getData()
    }
    onPressBottom = ()=>{
        // console.info("selectedValue:",this.selectedValue);
        const {dataList} = this.state;
        let index = null;
        if(this.selectedValue.questions.length > 0){
            dataList.forEach((v,i,a)=>{
                if(index == null && v.isneed){
                    if(v.type === 'answer'
                        && this.selectedValue.questions[i].questionOptionid == ''){
                        index = i + 1;
                    }
                    else if(this.selectedValue.questions[i]
                            .questionOptionid.length == 0){
                        index = i + 1;
                    }
                }
            });
        }
        else {
            Tools.toast("主人你还没有答题哦！");
            return;
        }


        if(index !== null){
            Tools.toast("第" + index + "题必填");
            return;
        }

        Service.putIn(this.selectedValue)
            .then(retJson=>{
                this.initState();
                this.goBack();
            });
    }

    render() {

        const {dataList,name,time,isAnswer,isClear} = this.state;

        /* let dataList1 = [
             {
                 title:'fdsafsdaf',//标题
                 type:'select',//答题类型 单选：'select'；多选：selectMul;问答:'answer';默认是单选
                 answerList:[{text:'FFF'},{text:'QQQ'},{text:'BBB'},{text:'AAA'},{text:'ccc'},{text:'ddd'},{text:"YYY"}],//选择题供选答案，问答题可不传
             },
             {
                 title:'选择题供选答案，问答题可不传',//标题
                 type:'selectMul',//答题类型 单选：'select'；多选：selectMul;问答:'answer';默认是单选
                 answerList:[{text:'FFF'},{text:'QQQ'},{text:'BBB'},{text:'AAA'},{text:'ccc'},{text:'ddd'},{text:"YYY"}],//选择题供选答案，问答题可不传
             },
             {
                 title:'答题类型 单选：select；多选：selectMul;问答:a',//标题
                 type:'answer',//答题类型 单选：'select'；多选：selectMul;问答:'answer';默认是单选
             }
         ];*/

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.selectedValue.id = this.state.id;
                this.configData.execFirst = false;
                // this.getData();
                !isClear ? this.getData() : null;
                // console.info("isClear:",isClear);
            }

            return (
                <Image source={ImageBgSurveyPSQ}
                       imageStyle={{resizeMode:"stretch"}}
                       style={styles.bgImage}>

                    <ViewTitle frameStyle={styles.frameStyle}
                               scrollFrameStyle={[styles.scrollFrameStyle,isAnswer ? {} : styles.scrollFrameStyle1]}
                               onPressBottom={this.onPressBottom}
                               viewBottomFrameStyle={styles.viewBottomFrameStyle}
                               viewBottom={isAnswer ? "提交问卷" :null}>

                        <View style={styles.titleFrame}>
                            <Text style={styles.titleFrame_text}>
                                {name}{"\n"}
                                <Text style={styles.titleFrame_text_1}>
                                    {Tools.timeFormatConvert(time,"YYYY-MM-DD")}
                                </Text>
                            </Text>
                        </View>

                        <QuestionList dataList={dataList}
                                      isClear={isClear}
                                      mode={isAnswer ? 'answer' : 'check'}
                                      onChange={this.onChange}/>


                    </ViewTitle>
                </Image>

            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({
                    id:param.id,
                    isAnswer:param.isAnswer,
                    isClear:false
                })
            },0);


            return (
                <Image source={ImageBgSurveyPSQ}
                       imageStyle={{resizeMode:"stretch"}}
                       style={styles.bgImage}>
                </Image>
            );
        }


    }
}

const styles = StyleSheetAdapt.create({
    frameStyle:{
        backgroundColor:Theme.Colors.transparent,
    },
    bgImage:{
        width:'w',
        height:StyleSheetAdapt.getHeight() - StyleSheetAdapt.getHeight(160) + "n",

        backgroundColor:Theme.Colors.backgroundColor2,
    },
    viewBottomFrameStyle:{
        marginBottom:30,
    },
    scrollFrameStyle:{
        // backgroundColor:Theme.Colors.backgroundColor1,
        marginTop:170,
        marginBottom:10,
        marginLeft:60,
        marginRight:70,
    },
    scrollFrameStyle1:{
        marginBottom:40,
    },

    titleFrame:{
        marginTop:10,
    },
    titleFrame_text:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.themeColor,
    },
    titleFrame_text_1:{
        fontSize:Theme.Font.fontSize_2,
        color:Theme.Colors.themeColor,
    },
    questionFrame:{
        marginTop:10,
    },
    questionFrame_1:{
        marginTop:10,
        marginBottom:10,
    }

});