import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        customerName:'',
        status:'',
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 问题详情 答题
     * @param questionId string,//问卷id
     * @param isAnswer bool,//是否是答题模式
     * **/
    static get(questionId,isAnswer){
        return Http.post(isAnswer ? HttpUrls.urlSets.urlInfoSurveyQuestionnaireDetail
            : HttpUrls.urlSets.urlInfoSurveyQuestionnaireView,{
            id:questionId
        })
            .then(retJson=>{
                let retObj = {
                    /*isAnswer:retJson.retData.isAnswer
                        ? retJson.retData.isAnswer
                        : true,*/
                    name:retJson.retData.name,
                    time:retJson.retData.time,
                    dataList:[]
                };
                retJson.retData.questions.forEach((v,i,a)=>{
                    //isneed:是否必填，0非必填，其他必填
                    // v.id = v.questionid;
                    //ismultiple:1、单选；2、多选
                    v.type = v.ismultiple == 1
                        ? "select"
                        : v.ismultiple == 2
                            ? 'selectMul'
                            : 'answer';//答题类型 单选：'select'；多选：selectMul;问答:'answer';默认是单选
                    v.answerList = [];//选择题供选答案，问答题可不传
                   if(v.type != 'answer'){
                       v.options.forEach((v1,i1,a1)=>{
                           v1.text = v1.content;
                           if(!isAnswer){
                               v1.isChecked = v1.isselected == 1 ? true : false;
                           }

                           v.answerList.push(v1);
                       });
                   }

                    retObj.dataList.push(v);
                });
                    return retObj;
            });
    }

    /**
     * 问题详情 查看
     * @param questionId string,//问卷id
     * **/
    static getCheck(questionId){
        return Http.post(HttpUrls.urlSets.urlInfoSurveyQuestionnaireView,{
            id:questionId
        })
            .then(retJson=>{
                let retObj = {
                    /*isAnswer:retJson.retData.isAnswer
                        ? retJson.retData.isAnswer
                        : true,*/
                    name:retJson.retData.name,
                    time:retJson.retData.time,
                    dataList:[]
                };
                retJson.retData.questions.forEach((v,i,a)=>{
                    //isneed:是否必填，0非必填，其他必填
                    // v.id = v.questionid;
                    //ismultiple:1、单选；2、多选
                    v.type = v.ismultiple == 1
                        ? "select"
                        : v.ismultiple == 2
                            ? 'selectMul'
                            : 'answer';//答题类型 单选：'select'；多选：selectMul;问答:'answer';默认是单选
                    v.answerList = [];//选择题供选答案，问答题可不传
                    v.options.forEach((v1,i1,a1)=>{
                        v1.text = v1.content;
                        //isselected:1、 选中，其他未选中
                        v1.isChecked = v1.isselected == 1 ? true : false;
                        v.answerList.push(v1);
                    });

                    retObj.dataList.push(v);
                });
                    return retObj;
            });
    }

    /**
     * 提交答卷
     * **/
    static putIn(selectedValue){
        return Http.post(HttpUrls.urlSets.urlInfoSurveyQuestionnaireCommit,
            selectedValue)
            .then(retJson=>{
                return retJson;
            });
    }
}