/**
 * Created by Administrator on 2018/5/5.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    SearchDropIpt,
    Tools,
    ItemRowFeedback,
    FlatListView,
    ItemRowTripTask,
} from "com";
import { Service } from "./Service";

/**
 * 调查问卷
 * **/
type Props = {};
export default class PageSurveyPSQList extends BaseComponent<Props> {

    dropList = {
        keyList:["全部",'未参与','已参与'],
        keyValPair:{
            "全部":'',
            "未参与":"0",
            "已参与":"200"
        },
    };
    selectValue = {
        status:'',//下拉选中值
        customer:'',//输入搜索值
        execFirst:true,
        executing:false,//是否正在执行中 后台请求
    };

    constructor(props) {
        super(props);

        this.setParams({
            // headerLeft:require('images/menu.png'),
            // headerLeftHandle:()=>{
            //     // this.viewTitle.openDrawer();
            //     this.props.navigation.navigate("DrawerToggle",{DrawerToggle:'DrawerToggle'});
            // },
            headerLeft:true,
            headerLeftHandle:()=> {
                this.goBack()
            },
            headerRight:false,
        });

        this.state = {
            total:0,//反馈客户总数
            dataList:[]//数组列表
        }
    }

    onItemPress(item,type){
        switch (type){
            case 0:{
                this.goPage("PageSurveyPSQDetail",{
                    id:item.id,
                    isAnswer:item.isdo ? false : true,
                    isRefresh:true,
                });
                break;
            }
            case 1:{
                this.goPage("PageSurveyPSQStatistics",{
                    id:item.id
                });
                break;
            }
            case 2:{
                break;
            }
        }

        // Tools.toast(JSON.stringify(item))
    }

    renderItem(item,index){

        let statusObj = Tools.statusConvert(item.isdo ? '0' : '3', Tools.userConfig.userInfo.id);
        const btnList = [
            {
                text:"参与列表",
                onPress:()=>this.onItemPress(item,1),
                backgroundColor:Theme.Colors.themeColor,
            },
            {
                text:"我要答卷",
                onPress:()=>this.onItemPress(item,0),
                backgroundColor:Theme.Colors.appRedColor,
            }
        ];
        var text5 = "任务完成后获得奖励：鲜花 +5";
        if(item.isdo){
            text5 = undefined;
        }

        return(
            <ItemRowTripTask  key={index}
                              disableRightSwipe={false}
                              isItemRowIconLeft={true}
                              btnList={btnList}
                              text1_1={item.title}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={item.isdo ? "已完成" : "未完成"}
                              text2_1={"阅读问卷数:" + item.readNum+"人" + "\t\t\t\t完成问卷数:" + item.attendNum+"人"}
                              text2_1_Style={styles.text2_1_Style}
                              text3_1={"发布时间:" + item.publishTime}
                              text4_1={"调查结束时间:" + item.endTime}
                              text5_1={text5}
                              text5_1_Style={{color:Theme.Colors.themeColor}}
                              onPress={() => this.onItemPress(item,0)}
                              text1_2_Style={{color:Theme.Colors.themeColor}}
                              itemRowIcon={false}
                              text1_2_Icon={statusObj.icon}/>
        );

        /*  return(
              <ItemRowFeedback id={index}
                               text1_1={item.title}
                               text1_2={item.statusTxt}
                               text2_1={item.publishTime}
                               text2_2={item.add_time}
                               text3_1={item.readNum}
                               text3_2={item.attendNum}
                               onPress={() => this.onItemPress(item)}/>
          );*/
    }

    /**
     * 获取反馈列表
     * @param customerName string,//需要搜索的客户名
     * @param status string,//需要搜索的状态
     * **/
    getData(customerName,status){

        if(!this.selectValue.executing){
            this.selectValue.executing = true;
            if(!this.selectValue.execFirst)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
            }

            Service.get(customerName,status,this.selectValue.execFirst)
                .then(retJson =>{
                    this.selectValue.executing = false;
                    if(!this.selectValue.execFirst && !retJson.has)
                    {
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                    }
                    else
                    {
                        this.selectValue.execFirst = false;
                        this.setState({
                            total:retJson.total,
                            dataList:retJson.retListData
                        });

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }




                })
                .catch((status) =>{
                    this.selectValue.executing = false;
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }

    }

    onSelectDrop(i,val){
        this.selectValue.status = this.dropList.keyValPair[val];
        // Tools.toast(JSON.stringify(val));
    }

    onTextChange(val){
        // Tools.toast(JSON.stringify(val));
        this.selectValue.customer = val;
    }

    onSearch(){
        // Tools.toast("dsd");
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            total:0,
            dataList:[]
        });
        this.getData(this.selectValue.customer,this.selectValue.status);
    }

    componentWillMount(){}

    componentDidMount(){
        /*if(!Tools.platformType){
            this.getData();
        }*/
        this.getData();
    }

    componentWillEnter(params){
        this.getData()

    }

    render() {

        return (
            <ViewTitle isScroll={false}>

                <SearchDropIpt options={this.dropList.keyList}
                               frameStyle={styles.searchFrame}
                               text2={"标题："}
                               placeholder={"请输入标题"}
                               onSelect={(i,val)=>this.onSelectDrop(i,val)}
                               defaultIndex={0}
                               defaultValue={this.dropList.keyList[0]}
                               textChange={(val) => this.onTextChange(val)}
                               onPressSearch={() => this.onSearch()}/>

                {/* <View style={styles.textTotalFrame}>
                    <Text style={styles.textTotal}>共有{this.state.total}卷调查问卷</Text>
                </View>*/}

                <FlatListView style={[styles.searchFrame,styles.flatListView]}
                              data={this.state.dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItem(item,index)}
                              onEndReached={() =>this.getData()}/>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    searchFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },

    textTotalFrame:{
        backgroundColor:Theme.Colors.backgroundColorPrompt,
    },
    textTotal:{
        fontSize:Theme.Font.fontSize,
        alignSelf:'center',
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{

        marginBottom:10,
    },

});
