import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        customerName:'',
        status:'',
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取反馈列表
     * @param customerName string,//需要搜索的客户名
     * @param status string,//需要搜索的状态
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(customerName,status,init) {


        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(this.base.paramsFetch.executing){
            return new Promise((resolve,reject)=>{
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        this.base.paramsFetch.customerName = customerName == undefined
            ? this.base.paramsFetch.customerName
            : customerName;
        this.base.paramsFetch.status = status == undefined
            ? this.base.paramsFetch.status
            : status;
        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retListData = [];
        }


        return Http.post(HttpUrls.urlSets.urlInfoSurveyQuestionnaireList, {
            userId:Tools.userConfig.userInfo.id,//用户id,
            // task_id:accountInfo().id,//用户id,//测试
            sort:'create_time',
            order:'desc',
            pageNumber: this.base.paramsFetch.pageNumber,//页码
            pageSize: 20,//每页条数,
            filter:{
                type:"1",//1.市场调研 2.商品调查 3.竞品调查
                status:this.base.paramsFetch.status,//调查问卷状态查询条件 ；''查询全部; '200'查询已处理; '0'查询未处理;
                name:this.base.paramsFetch.customerName,//调查问卷 市场调研 市场调研 市场调研 搜索 输入条件值;
            },//筛选条件
        },init)
            .then((retJson) => {
                this.base.retJson.total = retJson.retData.total;
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                retJson.retListData.forEach((val,i,arr) =>{
                    val.title = val.name;
                    val.publishTime = Tools.timeFormatConvert(val.update_time,"YYYY年MM月DD日");
                    // val.endTime = "YYYY年MM月DD日";
                    val.readNum = val.readcount;
                    // val.attendNum = "参与人数：" + "20";
                    val.attendNum = val.attendNum ? val.attendNum : '';


                    //已做为true;
                    if(val.isdo == 1)
                    {
                        val.isdo = true;
                        // val["statusTxt"] = "已读";
                    }
                    else //未做为false;
                    {
                        val.isdo = false;
                        // val["statusTxt"] = "未读";
                    }

                    this.base.retJson.retListData.push(val);

                });

                // this.base.retListData.concat(retJson.retListData);
                // console.info("base:",this.base);
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }
}