/**
 * Created by Administrator on 2018/5/5.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';

import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    SearchDropIpt,
    Tools,
    ItemRowFeedback,
    FlatListView,
    ItemRowTripTask,
    ItemRowGuideTripApply,
} from "com";
import { Service } from "./Service";

/**
 * 调查问卷 参与列表
 * **/
type Props = {};
export default class PageSurveyPSQStatistics extends BaseComponent<Props> {


    constructor(props) {
        super(props);

        this.setParams({
            headerLeft: true,
            headerLeftHandle:this.initState,
            headerRight:false,
        });

        this.configData = {
            execFirst:true
        };

        this.dropList = {
            keyList:["全部",'未参与','已参与'],
            keyValPair:{
                "全部":'',
                "未参与":"0",
                "已参与":"200"
            },
            keyList2:[
                {name:'全部',id:''},
                {name:'是',id:'1'},
                {name:'否',id:'0'}
            ],
        };

        this.selectValue = {
            isFinish:'',//是否完成 是否提交，0：未提交（未完成），1：已提交（完成；''查全部
            deptId:'',//部门ID
            execFirst:true,
            executing:false,//是否正在执行中 后台请求
        };

        this.state = {
            isClear:false,
            id:null,//问卷ID
            // id:"4dcc52dd-4f74-42b0-88a7-ace281398ef1",//问卷ID
            total:0,//总数
            departmentList:[],//部门列
            pickdownClearDrop:true,
            dataList:[],//数组列表

            sum:null,//类型：String  必有字段  备注：本次调查总人数
            commitSum:null,//类型：String  必有字段  备注：已完成调查
            unCommitSum:null //类型：String  必有字段  备注：未完成调查
        };
    }

    initState = ()=>{
        this.selectValue = {
            isFinish:'',//是否完成 是否提交，0：未提交（未完成），1：已提交（完成；''查全部
            deptId:'',//部门ID
            execFirst:true,
            executing:false,//是否正在执行中 后台请求
        };

         let state = {
            isClear:true,
            id:this.state.id,//问卷ID
            total:0,//总数
            departmentList:[],//部门列
            pickdownClearDrop:true,
            dataList:[],//数组列表

            sum:null,//类型：String  必有字段  备注：本次调查总人数
            commitSum:null,//类型：String  必有字段  备注：已完成调查
            unCommitSum:null //类型：String  必有字段  备注：未完成调查
        };

        this.setState(state);
    };

    renderItem(item,index){

        return(
            <ItemRowGuideTripApply key={index}
                                   text1={item.frameworkName}
                                   text2={item.name}
                                   text6={Tools.timeFormatConvert(item.finishTime,"YYYY-MM-DD")
                                   + "\n" + Tools.timeFormatConvert(item.finishTime,"HH:mm:ss")}
                                   text4={item.isCommit == '1' ? '是' : '否'}
                                   text5={Tools.timeFormatConvert(item.readTime,"YYYY-MM-DD")
                                   + "\n" + Tools.timeFormatConvert(item.readTime,"HH:mm:ss")}
                                   text3={false}
                                   text7={false}/>
        );

    }

    /**
     * 参与列表
     * @param deptId string,//部门ID
     * @param isFinish string,//是否完成
     * **/
    getData(deptId,isFinish){

        if(!this.selectValue.executing){
            this.selectValue.executing = true;
            if(!this.selectValue.execFirst)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
            }
            else {
                // alert(this.state.id)
                Service.getSurveyPersonAmount(this.state.id)
                    .then(retJson=>{
                        this.setState(retJson);
                    })
            }

            Service.get(this.state.id,this.selectValue.deptId,
                this.selectValue.isFinish,this.selectValue.execFirst)
                .then(retJson =>{
                    this.selectValue.executing = false;
                    if(!this.selectValue.execFirst && !retJson.has)
                    {
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);
                    }
                    else
                    {
                        this.selectValue.execFirst = false;
                        this.setState({
                            // total:retJson.total,
                            dataList:retJson.retListData
                        });

                        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
                    }




                })
                .catch((status) =>{
                    this.selectValue.executing = false;
                    if(status.status != Theme.Status.executing){
                        Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                    }
                });
        }

    }

    getDept(){
        console.info("this.state.id",this.state.id)
        Service.getSurveyDept(this.state.id)
            .then(retJson=>{

                this.setState({
                    departmentList:retJson
                });
            });

        /*Service.getSurveyPersonAmount(this.state.id)
            .then(retJson=>{
                this.setState(retJson);
            })*/
    }

    onSelectDrop(i,val,type){
        if(this.state.pickdownClearDrop)
        {
            this.setState({
                pickdownClearDrop:false,
            });
        }

        if(type == 0){
            this.selectValue.deptId = val.id;
        }
        else {
            this.selectValue.isFinish = val.id;
        }

        // Tools.toast(JSON.stringify(val));
    }

    onSearch(){
        // Tools.toast("dsd");
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });
        this.getData();
    }

    componentWillMount(){
    }

    componentDidMount(){
        /*if(!Tools.platformType){
            this.getData();
        }*/
        // this.getData()
        // this.getDept()
    }
    componentWillEnter(params){
        this.getData()
        this.getDept()
    }

    render() {

        const {departmentList,pickdownClearDrop,dataList,
            unCommitSum,commitSum,sum,isClear} = this.state;

        let param = this.getPageParams();
        param = param == undefined ? {} : param;
        // if(true) {
        // console.log(param)
        if(this.state.id == param.id){
            if(this.configData.execFirst)
            {
                this.configData.execFirst = false;
                // console.info("isClear",isClear);
                this.getData();
                this.getDept();
                /*if(isClear){
                    this.getData();
                    this.getDept();
                }*/

            }

            return (
                <ViewTitle isScroll={false}>

                    <SearchDropIpt
                        frameStyle={styles.searchFrame}
                        pickDropdownProps1={{
                            options:departmentList,
                            defaultValue:departmentList.length > 0
                                ? departmentList[0].name : "正在加载",
                            clearDrop:pickdownClearDrop,
                        }}
                        text1={"部门:"}
                        text2={"是否完成:"}
                        onSelect={(i,val,type)=>this.onSelectDrop(i,val,type)}
                        pickDropdownProps2={{
                            options:this.dropList.keyList2,
                            defaultValue:this.dropList.keyList2[0].name,
                            dropdownStyle:{marginLeft:StyleSheetAdapt.getWidth('0.8w')}
                        }}
                        onPressSearch={() => this.onSearch()}/>

                    <View style={styles.searchFrame}>
                        <View style={styles.textTotalFrame_1}>
                            <View style={styles.textTotalFrame_1_1}>
                                <Text style={styles.textTotal}>
                                    本次调查总人数:{sum}
                                </Text>
                            </View>

                            <View style={styles.textTotalFrame_1_1}>
                                <Text style={styles.textTotal}>
                                    已完成调查:{commitSum}
                                </Text>
                            </View>

                            <View style={styles.textTotalFrame_1_1}>
                                <Text style={styles.textTotal}>
                                    未完成调查:{unCommitSum}
                                </Text>
                            </View>

                        </View>

                    </View>

                    <ItemRowGuideTripApply frameStyle={styles.textTotalFrame}
                                           textStyle={styles.itemRowText}
                                           frameStyleChild={styles.itemRowFrameTop}
                                           text1={"部门"}
                                           text2={"姓名"}
                                           text4={"是否完成"}
                                           text5={"阅读时间"}
                                           text6={"完成时间"}
                                           text3={false}
                                           text7={false}/>

                    <FlatListView style={[styles.flatListView]}
                                  data={dataList}
                                  keyExtractor = {(item, index)=>("key" + index)}
                                  renderItem={({item,index})=>this.renderItem(item,index)}
                                  onEndReached={() =>this.getData()}/>

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({
                    id:param.id,
                    isClear:false
                })
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }


    }
}

const styles = StyleSheetAdapt.create({
    searchFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
    },

    textTotalFrame:{
        backgroundColor:Theme.Colors.foregroundColor,
    },
    textTotalFrame_1:{
        flexDirection:'row',
        padding:10,
    },
    textTotalFrame_1_1:{
        flex:1,
    },
    textTotal:{
        fontSize:Theme.Font.fontSize,
        alignSelf:'center',
        color:Theme.Colors.themeColor,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginBottom:10,
    },

    itemRowFrameTop:{
        // borderLeftColor:Theme.Colors.minorColor,
        // borderLeftWidth:Theme.Border.borderWidth,
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth2,
    },
    itemRowFrameLeft:{
        borderColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth,
    },
    itemRowText:{
        color:Theme.Colors.fontcolor,
        fontSize:Theme.Font.fontSize_1,
    },

});