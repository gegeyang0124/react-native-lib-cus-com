import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "com-api";

/**
 * 接口处理
 * **/
export class Service{

    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        questionnaireId:'',//调查问卷ID
        frameworkId:'', //部门ID
        isCommit:'',//是否提交，0：未提交（未完成），1：已提交（完成）
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取问卷调查 参与列表数据
     * @param questionnaireId string,//调查问卷ID
     * @param frameworkId string,//部门ID
     * @param isCommit string,//是否提交，0：未提交（未完成），1：已提交（完成）
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static get(questionnaireId,frameworkId,isCommit,init) {

        console.log(frameworkId)
        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(this.base.paramsFetch.executing){
            return new Promise((resolve,reject)=>{
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        this.base.paramsFetch.questionnaireId = questionnaireId == undefined
            ? this.base.paramsFetch.questionnaireId
            : questionnaireId;
        this.base.paramsFetch.frameworkId = frameworkId == undefined
            ? this.base.paramsFetch.frameworkId
            : frameworkId;
        this.base.paramsFetch.isCommit = isCommit == undefined
            ? this.base.paramsFetch.isCommit
            : isCommit;
        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retListData = [];
        }


        return Http.post(HttpUrls.urlSets.urlInfoSurveyQuestionnaireJoinList, {
            sort:"create_time",//类型：String  必有字段  备注：无
            order:"desc",//类型：String  必有字段  备注：无
            pageNumber:this.base.paramsFetch.pageNumber,//页码
            pageSize:20,//类型：Number  必有字段  备注：无
            filter:{
                //类型：Object  必有字段  备注：无
                questionnaireId:this.base.paramsFetch.questionnaireId,//调查问卷ID
                frameworkId:this.base.paramsFetch.frameworkId,//类型：String  必有字段  备注：部门ID；''查全部
                isCommit:this.base.paramsFetch.isCommit//类型：String  必有字段
                // 备注：是否提交，0：未提交（未完成），1：已提交（完成；''查全部
            }
        },init)
            .then((retJson) => {
                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                retJson.retListData.forEach((val,i,arr) =>{

                    this.base.retJson.retListData.push(val);
                });

// this.base.retListData.concat(retJson.retListData);
// console.info("base:",this.base);
                console.log(this.base.retJson)
                return this.base.retJson;

            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });

    }

    /**
     * 获取参与调查的部门
     * @param questionnaireId string,//调查问卷ID
     * **/
    static getSurveyDept(questionnaireId){
        console.info("questionnaireId",{
            questionnaireId:questionnaireId
        });
        return Http.post(HttpUrls.urlSets.urlInfoSurveyQuestionnaireJoinDepList,{
            questionnaireId:questionnaireId
        })
            .then(retJson=>{
                console.log(retJson)
                let lst = [{
                    name:'全部',
                    id:''
                }];
                let newLst = lst.concat(retJson.retData);

                return newLst;
            });
    }

    /**
     * 获取调查人数
     * @param questionnaireId string,//调查问卷ID
     * **/
    static getSurveyPersonAmount(questionnaireId){
        return Http.post(HttpUrls.urlSets.urlInfoSurveyQuestionnaireJoinAmount,{
            questionnaireId:questionnaireId
        })
            .then(retJson=>{
                return retJson.retData;
            });
    }
}