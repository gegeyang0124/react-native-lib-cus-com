/**
 * Created by Administrator on 2018/4/30.
 */

import {
    Theme
} from "com";
import {
    TabNavigator,
} from 'comThird'
import PageTripApply from "./pageTripApply/PageTripApply";
import PageTripDetail from "./pageTripDetail/PageTripDetail";
import PageTripList from "./pageTripList/PageTripList";

const TabRouteConfigs = {
    PageTripApply: {
        screen: PageTripApply,
        navigationOptions: ({navigation}) => ({
            title : '出差申请',
            tabBarLabel : '出差申请',
        }),
    },
    PageTripDetail: {
        screen: PageTripDetail,
        navigationOptions: ({navigation}) => ({
            // title : '巡店向导',
            tabBarLabel: '出差详情',
        }),
    },
}

const pages = TabNavigator(TabRouteConfigs, Theme.TabNavigatorConfigs);

const pageTrips = {
    get PageTrips() {
        return pages;
    },
    get PageTripList() {
        return PageTripList;
    }
};

module.exports = pageTrips;