/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
/*import SwipeableListView from 'SwipeableListView';
 import SwipeableQuickActions from 'SwipeableQuickActions';
 import SwipeableQuickActionButton from 'SwipeableQuickActionButton';*/
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ButtonChange,
    FlatListView,
    ItemRowTripApply,
    ItemRowGuideTripApply,
    DatePicker,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageTripApply extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
        };

        this.selectValue = {
            template_id:null,//任务类型id
            number:null,//加载时获取的任务编号
            name:'',//任务名称
            department_id:Tools.userConfig.userInfo.department_id,//部门id
            executor:Tools.userConfig.userInfo.id,//申请人id
            auditor:null,//审核人id
            priority:'1',//优先级值
            begin_time:Tools.timeFormatConvert(this.configData.currentTime,"YYYY-MM-DD HH:mm:ss"),//开始时间
            end_time:Tools.timeFormatConvert(this.configData.currentTime + Tools.ONE_DAY_TIME - 1000 ,"YYYY-MM-DD HH:mm:ss"),//结束时间
            prop_array:[
                {
                    key:'task_relation',//键值
                    value:''//值，逗号分割的巡店任务id字符串
                }
            ],//额外数据
        };

        this.state = {
            departmentList:[],//部门选择列表
            chargePersonList:[],//负责人列表
            chargePersonDefault:Tools.userConfig.userInfo.username,//负责人默认显示值
            chargePersonClearDrop:false,//是否清空负责人下拉框
            checkPersonList:[],//审核人列表
            checkPersonClearDrop:false,//是否清空审核人下拉框
            checkPersonDefault:"正在加载",//负责人默认显示值
            tripTypeList:[],//出差任务类别
            beginTime:Tools.timeFormatConvert(this.selectValue.begin_time,"YYYY-MM-DD HH:mm"),
            endTime:Tools.timeFormatConvert(this.selectValue.end_time,"YYYY-MM-DD HH:mm"),

            /*relatedTaskList:[{
                beginTime:"sdfd",
                customerName:"sdafdsaf",
                description:'注意此参数是一个比值而非像素单位。比如，0.5表示距离内容最底部的距离为当前列表可见长度的一半时触发',
                endTime:'fsadfsad',
                taskId:'fdsaf',
                taskName:'fsdaf',
                taskType:"dsaffsa"
            }],//关联任务数据*/
            relatedTaskList:[],
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
        //this.setParamsTo();
    }

    setTime = (date)=>{
        let time1 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm:ss");
        let time2 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm");
        /* this.date = "date:" + date + "\ntime1: " + time1
             + "\n e:" + this.selectValue.end_time + "\n et:" + Tools.timeFormatConvert(this.selectValue.end_time);
         this.setState({
             beginTime:this.selectValue.begin_time
         });*/
        if(this.configData.isStartTime)
        {
            if(date < Tools.timeFormatConvert(this.selectValue.end_time))
            {
                this.selectValue.begin_time = time1;
                this.setState({
                    beginTime:time2
                });
            }
            else
            {
                Tools.toast("开始时间必须小于结束时间");
            }
        }
        else
        {
            if(date > Tools.timeFormatConvert(this.selectValue.begin_time))
            {
                this.selectValue.end_time = time1;
                this.setState({
                    endTime:time2
                });
            }
            else
            {
                Tools.toast("结束时间必须大于开始时间");
            }

        }
    }

    getCheckPeople(init){
        /*this.setState({
            checkPersonList:[],
            checkPersonClearDrop:true,
            checkPersonDefault:"正在加载"
        });*/
        this.selectValue.auditor = null;
        Service.getCheckPeople(this.selectValue.executor,this.selectValue.template_id,init).then((retJson)=>{
            this.selectValue.auditor = retJson.length > 0 ? retJson[0].id : this.selectValue.auditor;
            this.setState({
                checkPersonList:retJson,
                // checkPersonClearDrop:true,
                checkPersonDefault:retJson.length > 0 ? retJson[0].name : "无数据"
            });
        });
    }

    onSelectDrop(val,i,type){
        // alert(JSON.stringify(val));
        // console.info('onSelectDrop',val)

        switch (type)
        {
            case 1:{
                // this.state.departmentOneDefault = val.name;
                this.selectValue.department_id = val.id;
                this.selectValue.executor = null;

                Service.getChargePeople(val.id).then((retJson)=>{
                    this.selectValue.executor = retJson.length > 0 ? retJson[0].id : this.selectValue.executor;
                    this.setState({
                        chargePersonList:retJson,//负责人列表
                        chargePersonClearDrop:true,//是否清空负责人下拉框
                        chargePersonDefault:retJson.length > 0 ? retJson[0].name : "无数据",

                    });

                    this.getCheckPeople();
                });
                break;
            }
            case 2: {
                this.selectValue.executor = val.id;
                // this.state.departmentTowDefault = val.name;
                this.getCheckPeople();
                break;
            }
            case 3 :{
                this.selectValue.template_id = val.id;
                this.getCheckPeople();
                break;
            }
            case 4: {
                // alert(JSON.stringify(val))
                this.selectValue.auditor = val.id;

                break;
            }
            case 5: {
                this.configData.isStartTime = val
                this.datePicker.show();
                break;
            }
            case 6: {
                this.goPage("PageGuideApply",{});
                break;
            }
        }
    }

    onSearch = ()=>{
        // alert("search");
        // alert(JSON.stringify(this.selectValue));
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });
        this.getData(this.selectValue);
    };

    onItemPress = (item)=>{

        Service.deleteTask([item.taskId]).then((retJson)=>{
            let lst = [];
            this.state.relatedTaskList.remove(item);
            this.state.relatedTaskList.forEach((v,i,a)=>{
                lst.push(v);
            });
            this.setState({
                relatedTaskList:lst
            });
        });

    }

    getData() {
        Service.getTripTypes().then((retJson)=>{
            this.selectValue.template_id = retJson.length > 0 ? retJson[0].id : this.selectValue.template_id;
            this.setState({
                tripTypeList:retJson
            });

            this.getCheckPeople(true);
        });

        Service.getDepartments().then((retJson)=>{
            // this.selectValue.template_id = retJson.length > 0 ? retJson[0].id : this.selectValue.template_id;
            this.setState({
                departmentList:retJson
            });
        });

        Service.getChargePeople(Tools.userConfig.userInfo.department_id).then((retJson)=>{
            // this.selectValue.template_id = retJson.length > 0 ? retJson[0].id : this.selectValue.template_id;
            this.setState({
                chargePersonList:retJson
            });
        });

    }

    getDepartments(){
        Service.getDepartmentsOne()
            .then((retJson)=>{
                // retJson.forEach()

                this.selectValue.type1 = retJson.branchOffice;
                this.selectValue.type2 = retJson.area;
                this.setState({
                    departmentOneList:retJson.branchOfficeLst,
                    departmentOneDefault:retJson.nameOne,
                    departmentTwoList:retJson.areaLst,
                    departmentTwoDefault:retJson.nameTwo,
                    departmentOneDisable:this.selectValue.type1 == '' ? false : true,
                    departmentTwoDisable:this.selectValue.type2 == '' ? false : true
                });
            });
    }

    renderItem = (item,i)=>{
        const status = Tools.statusConvert(item.taskStatus);
        // text6={item.status}
        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.customerName ? item.customerName : ''}
                                   text2={item.taskType}
                                   text3={item.description}
                                   text4={item.beginTime}
                                   text5={item.endTime}
                                   onPress={()=>this.onItemPress(item)}
                                   text6={status.text}
                                   text7={"删除"}/>
        );
    }

    onShowMonPicker = ()=>{
        // PickerCustome.pickMonth();
        Tools.pickMonth(retJson =>{
            let val = (new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime();

            this.selectValue.type3.startTime = Tools.timeFormatConvert(val,"YYYY-MM-DD HH:mm:ss");

            let beginDate = new Date(val);
            if(beginDate.getMonth() == 11)
            {
                val = (new Date(beginDate.getFullYear() + 1,0,1,0,0,0)).getTime();
            }
            else
            {
                val = (new Date(beginDate.getFullYear(), beginDate.getMonth() + 1,1,0,0,0)).getTime();
            }

            this.selectValue.type3.endTime = Tools.timeFormatConvert(val - 1000,"YYYY-MM-DD HH:mm:ss");


            this.setState({
                pickedDate:retJson[0] + "-" + (retJson[1] > 10 ? retJson[1] : '0' + retJson[1])
            });
        });
    }

    onChangeText = (text)=>{
        this.selectValue.name = text;
    }

    componentWillMount(){

    }

    componentDidMount() {
        this.getData();
    }

    componentWillReceiveProps(){
        let param = this.getPageParams(true);
        if(param){
            let relatedTaskList = [];
            this.state.relatedTaskList.forEach((v,i,a)=>{
                relatedTaskList.push(v);
            });
            param.paramData = param.paramData == undefined ? [] : param.paramData;
            param.paramData.forEach((v,i,a)=>{
                relatedTaskList.push(v);
            });
            this.setState({
                relatedTaskList: relatedTaskList
            });
        }


    }

    onPressBottom = ()=>{

        if(this.selectValue.name == '') {
            Tools.toast("请填写出差名称");
            return;
        }

        if(this.selectValue.department_id == null) {
            Tools.toast("请选择部门");
            return;
        }

        if(this.selectValue.executor == null) {
            Tools.toast("请选择申请人");
            return;
        }

        if(this.selectValue.template_id == null) {
            Tools.toast("请选择任务类型");
            return;
        }

        if(this.selectValue.auditor == null) {
            Tools.toast("请选择审核人");
            return;
        }

        let lst = [];
        this.state.relatedTaskList.forEach((v,i,a)=>{
            lst.push(v.taskId);
        });

        this.selectValue.prop_array[0].value = lst.toString();

        // console.info("this.selectValue:",this.selectValue);
        Service.addTripTask(this.selectValue).then((retJson)=>{
            BaseComponent.backRefresh = true;
            this.setState({
                relatedTaskList:[],
            });
            this.goBack(null,{});
        });
    };

    render() {
        const {beginTime,endTime,departmentList,tripTypeList,chargePersonDefault,chargePersonList,
            chargePersonClearDrop,checkPersonList,checkPersonClearDrop,checkPersonDefault,relatedTaskList} = this.state;

        return (
            <ViewTitle viewBottom={relatedTaskList.length>0 ? "提交" : null}
                       onPressBottom={this.onPressBottom}>

                <View style={styles.titleFrame}>

                    <ItemRowTripApply text={"出差名称:"}

                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"input"}
                                      viewCenterProps={{
                                          placeholder:'请输入出差名称',
                                          onChangeText:this.onChangeText
                                      }}/>

                    <ItemRowTripApply text={"部        门:"}
                                      frameStyle={styles.titleFrameTop}
                                      disabled={true}
                                      viewCenter={"text"}
                                      text2={Tools.userConfig.userInfo.department_name}
                                      viewCenterProps={{
                                          defaultValue:Tools.userConfig.userInfo.department_name,
                                          options:departmentList,
                                          disabled:true,
                                          editable:false,
                                      }}
                    />

                    <ItemRowTripApply text={"申  请  人:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      text2={chargePersonDefault}
                                      viewCenterProps={{
                                          defaultValue:chargePersonDefault,
                                          clearDrop:chargePersonClearDrop,
                                          options:chargePersonList,
                                          disabled:true,
                                          editable:false,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,2)
                                      }}
                    />

                    <ItemRowTripApply text={"申请类别:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      text2={tripTypeList.length > 0 ? tripTypeList[0].name :"无数据"}
                                      viewCenterProps={{
                                          defaultValue:tripTypeList.length > 0 ? tripTypeList[0].name :"无数据",
                                          options:tripTypeList,
                                          disabled:true,
                                          editable:false,
                                          onSelect:(i,val)=>this.onSelectDrop(val,i,3)
                                      }}
                    />

                    <ItemRowTripApply text={"审  核  人:"}
                                      frameStyle={styles.titleFrameTop}
                                      viewCenter={"text"}
                                      text2={checkPersonDefault}
                                      viewCenterProps={{
                                          defaultValue:checkPersonDefault,
                                          clearDrop:checkPersonClearDrop,
                                          options:checkPersonList,
                                          editable:false
                                          // onSelect:(i,val)=>this.onSelectDrop(val,i,4)
                                      }}
                    />

                    <ItemRowTripApply text={"巡店时间:"}
                                      frameStyle={styles.titleFrameTop}
                                      isStar={false}
                                      viewCenter={
                                          <View style={styles.titleFrame_1}>
                                              <ButtonChange text={beginTime}
                                                            onPress={()=>{this.onSelectDrop(true,0,5)}}
                                                            frameStyle={styles.titleFrame_timeBtnFrame}
                                                            textStyle={styles.titleFrame_timeBtnText}
                                                            style={styles.titleFrame_timeBtn} />

                                              <Text style={styles.titleFrame_timeText}>
                                                  ~
                                              </Text>

                                              <ButtonChange text={endTime}
                                                            onPress={()=>{this.onSelectDrop(false,0,5)}}
                                                            frameStyle={styles.titleFrame_timeBtnFrame}
                                                            textStyle={styles.titleFrame_timeBtnText}
                                                            style={styles.titleFrame_timeBtn} />
                                          </View>
                                      }/>

                    <ItemRowTripApply text={"巡        店:"}
                                      frameStyle={styles.titleFrameTop}
                                      isStar={false}
                                      viewCenter={<ButtonChange text={"新增任务"}
                                                                onPress={()=>{this.onSelectDrop(0,0,6)}}
                                                                style={styles.titleFrame_btn} />}/>


                </View>

                <View style={styles.titleFrame1}>

                    <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                           frameStyleChild={styles.itemRowFrameTop}
                                           text1={"客户姓名"}
                                           text2={"巡店类型"}
                                           text3={"描述"}
                                           text4={"开始时间"}
                                           text5={"结束时间"}
                                           text6={"状态"}
                                           text7={"操作"}/>

                    {
                        relatedTaskList.map(this.renderItem)
                    }

                </View>

                <DatePicker ref={(compoent)=>{
                    this.datePicker = compoent;
                }}
                            onDateChange={this.setTime}/>

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    titleFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        alignItems: 'center',
        justifyContent: 'center',
        height: Theme.Height.height1,

    },
    titleFrame_btn: {
        width: 100,
        height: Theme.Height.height1,
        padding: 0,
    },
    titleFrame_timeBtnFrame:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        borderRadius:Theme.Border.borderRadius,
    },
    titleFrame_timeBtnFrame1:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        flex:0.98,
        borderRadius:Theme.Border.borderRadius,

    },
    titleFrame_timeBtn:{
        width: '0.3w',
        height: Theme.Height.height1,
        padding: 0,
        backgroundColor:Theme.Colors.transparent,
    },
    titleFrame_timeBtnText:{
        color:Theme.Colors.minorColor,

    },
    titleFrame_timeText:{
        color:Theme.Colors.themeColor,
        marginLeft:10,
        marginRight:10,
        fontSize:Theme.Font.fontSize,
    },
    titleFrame1:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },


    itemRowFrameTop:{
        // borderLeftColor:Theme.Colors.minorColor,
        // borderLeftWidth:Theme.Border.borderWidth,
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth2,
    },
    itemRowFrameLeft:{
        borderColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth,
    },
    itemRowText:{
        color:Theme.Colors.fontcolor,
        fontSize:Theme.Font.fontSize_1,
    },

});
