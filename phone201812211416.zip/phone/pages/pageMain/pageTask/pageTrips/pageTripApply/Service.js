import {
    Http,
    HttpUrls,
    Tools,
    Theme,
} from "./../../../../../component/api/api";

/**
 * 接口
 * **/
export class Service {


    static base;

    constructor() {
        Service.base = this;
    }

    retJson = {
        retListData:[],
        total:0,
        has:false,//是否有数据，true:有，false:没有，默认是false
    };//后台返回数据
    paramsFetch = {
        selectValue:{
            type1:'',//下拉选中值 一级部门
            type2:Tools.userConfig.userInfo.department_level == 1
                ? ''
                : Tools.userConfig.userInfo.department_id,//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态码
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        },//搜索参数
        pageNumber:1,
        executing:false,//是否正在执行中
    };//传入参数

    /**
     * 获取出差数据列表
     * @param selectValue object,//搜索参数
     * selectValue = {
        type1:'',//下拉选中值 一级部门
        type2:'',//下拉选中值 二级部门
        type3:'',//下拉选中值 年月
        name:'',//人名称输入值
    }
     * @param init bool,//是否初始化，true：初始化，false：保持原样，默认false
     * **/
    static getTripList(selectValue,init){

        init = init == undefined ? false : init;
        if(init || this.base == undefined)
        {
            new Service();
        }

        if(selectValue != undefined)
        {
            selectValue.type2 = selectValue.type2 != '' ? selectValue.type2 : selectValue.type1;
            this.base.paramsFetch.selectValue = selectValue;
        }

        if(init){
            this.base.paramsFetch.pageNumber = 1;
            this.base.retJson.retListData = [];
        }

        if(this.base.paramsFetch.executing){
            return new Promise(function (resolve,reject) {
                reject({status:Theme.Status.executing});
            });
        }
        else
        {
            this.base.paramsFetch.executing = true;
        }

        return Http.post(HttpUrls.urlSets.urlTaskLst, {
            userId:Tools.userConfig.userInfo.id,
            sort: 'create_time',
            order: 'desc',
            pageNumber:this.base.paramsFetch.pageNumber,//页码
            pageSize: 20,
            type:'1',//请求运营中心一下的分公司
            filter: {
                parent_id:'0',
                task_type: '2',
                begin_time:'',//开始时间,格式：YYYY-MM-DD HH:mm:ss
                end_time:'',//结束时间,格式：YYYY-MM-DD HH:mm:ss
                department_id:'',//分公司id
                dept_id:this.base.paramsFetch.selectValue.type2,//分公司id或区域
                dep_id:this.base.paramsFetch.selectValue.type2,//区域id
                executor:this.base.paramsFetch.selectValue.name,//搜索执行人名称
                queryType:'',//'1' 查询巡店向导，任务管理，‘2’查询任务管理‘未关闭’，‘’查询所有任务数据，‘4’查询‘出差’、‘巡店’、‘临时’三种任务；5：查询状态1，3，4，6
                startTime:this.base.paramsFetch.selectValue.type3.startTime,//任务预计开始时间 月份搜索 开始搜索的时间点
                endTime:this.base.paramsFetch.selectValue.type3.endTime,//任务预计结束时间 月份搜索 结束搜索的时间点
                number:'',//搜索任务编号
                status:this.base.paramsFetch.selectValue.type4,//状态码搜索条件，无为''
            },//查询条件
        },init)
            .then((retJson) => {

                if(retJson.retListData == undefined || retJson.retListData.length == 0)
                {
                    retJson.retListData = [];
                    this.base.retJson.has = false;
                }
                else
                {
                    this.base.paramsFetch.pageNumber++;
                    this.base.retJson.has = true;
                }

                this.base.paramsFetch.executing = false;

                retJson.retListData.forEach((v,i,a)=>{
                    v.begin_time = Tools.timeFormatConvert(v.begin_time,"YYYY-MM-DD HH:mm");
                    v.end_time = Tools.timeFormatConvert(v.end_time,"YYYY-MM-DD HH:mm");
                    // v.isProTask = Tools.userConfig.userInfo.id ==  v.executor_id ? true : false;

                    this.base.retJson.retListData.push(v);
                });

                return  this.base.retJson;
            })
            .catch((status) => {
                this.base.paramsFetch.executing = false;
                return status;
            });
    }

    /**
     * 获取关联任务
     * **/
    static getRelatedTaskList(){


        return Http.post(HttpUrls.urlSets.urlTripLine,{
            /*map.put("1", "巡店任务");
             map.put("2", "出差任务");
             map.put("3", "流程任务");
             map.put("4", "回访任务");
             map.put("5", "工作汇报");
             map.put("6", "临时任务");
             */
            type:'2',//类型
            executor:Tools.userConfig.userInfo.id,//
        })
            .then((retJson)=>{

                return retJson.retListData;
            });

    }

    /**
     * 获取出差任务类型
     * **/
    static getTripTypes(){

        return Http.post(HttpUrls.urlSets.urlTripType,{
            /*map.put("1", "巡店任务");
             map.put("2", "出差任务");
             map.put("3", "流程任务");
             map.put("4", "回访任务");
             map.put("5", "工作汇报");
             map.put("6", "临时任务");
             */
            type:'2',//类型
            executor:Tools.userConfig.userInfo.id,//
        })
            .then((retJson)=>{

                // retJson.retListData = lst.concat(retJson.retListData);
                // modelTrip.set("areaLst",retJson.retListData);

                return retJson.retListData;
            });

        // modelTrip.set("area",'');

    }

    static getDepartments()
    {
        return Http.post(HttpUrls.urlSets.urlDepartmentList)
            .then((retJson)=>{


                /*retJson.retListData.forEach((v,i,a)=>{

                });*/

                return retJson.retListData;
            });
    }

    /**
     * 获取负责人
     * @param framework_id string,// 部门id
     * **/
    static getChargePeople(framework_id)
    {

        return Http.post(HttpUrls.urlSets.urlChargePersonList,{
            framework_id:framework_id
        },false)
            .then((retJson)=>{


                retJson.retListData.forEach((v,i,a)=>{
                    v.name = v.username;
                    v.id = v.userid;
                });

                return retJson.retListData;
            });
    }

    /**
     * 获取审核人
     * @param template_id string,// 类型ID
     * @param executorId string,// 负责人id
     * @param init bool,// 是否显示正在加载
     * **/
    static getCheckPeople(executorId,template_id,init)
    {
        init = init == undefined ? false : init;
        // alert(init)
        if(template_id == null || executorId == null)
        {
            return new Promise((resolve, reject) => {
                reject({status:"参数为空"});
            });
        }

        return Http.post(HttpUrls.urlSets.urlTripMan,{
            template_id:template_id,
            executor:executorId
        },init)
            .then((retJson)=>{

                retJson.retListData.forEach((v,i,a)=>{
                    v.name = v.username;
                    v.id = v.userid;
                });

                return retJson.retListData;
            });
    }

    /**
     * 删除任务，
     * @param taskIdsList array,//删除任务数组列表
     * **/
    static deleteTask(taskIdsList){

        return Http.post(HttpUrls.urlSets.urlDeleteTask,{
            taskIds:taskIdsList
        })
            .then((retJson)=>{
                return retJson;
            });

    }

    /**
     * 提交出差任务数据
     * @param selectValue object,//提交参数
     * **/
    static addTripTask(selectValue){

        return new Promise((resolve, reject) => {

            Http.post(HttpUrls.urlSets.urlOnload,{type:"2"})
                .then((retJson)=>{

                    selectValue.number = retJson.retData.task_number;

                    Http.post(HttpUrls.urlSets.urlTripAdd,selectValue)
                        .then((retJson)=>{
                            resolve(retJson);
                            // selectValue

                        });

                });

        });
    }



}