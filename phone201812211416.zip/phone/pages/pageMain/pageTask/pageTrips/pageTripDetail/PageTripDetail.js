/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
} from 'react-native';
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    ButtonChange,
    ItemRowTripApply,
    ItemRowGuideTripApply,
    DatePicker,
    ItemRowTitle,
    TextIcon,
    Media,
    MenuBottom,
    ImageView,
    ModalTextInput,
    ModalTextInputS,
    Http,
} from "../../../../../component/component";
import {Service} from "./Service";


type Props = {};
export default class PageTripDetail extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.configData = {
            isStartTime:true,
            currentTime:Tools.timeFormatConvert(undefined,undefined,true),
            execFirst:true,
        };

        this.btnList = [
            {
                text:'拍照',
                onPress:this.onGetPic
            },
            {
                text:'选取',
                onPress:this.onGetPic
            }
        ];

        this.selectValue = {
            id:null,  //任务id
            template_id:null,//任务类型id
            number:null,//加载时获取的任务编号
            name:'',//任务名称
            department_id:Tools.userConfig.userInfo.department_id,//部门id
            executor:Tools.userConfig.userInfo.id,//申请人id
            auditor:null,//审核人id
            priority:'1',//优先级值
            begin_time:Tools.timeFormatConvert(this.configData.currentTime,"YYYY-MM-DD HH:mm:ss"),//开始时间
            end_time:Tools.timeFormatConvert(this.configData.currentTime + Tools.ONE_DAY_TIME - 1000 ,"YYYY-MM-DD HH:mm:ss"),//结束时间
            task_relation:'',//关联任务
        };


        this.reason = '';//不通过的原因
        this.suggest='ok';//通过 建议

        this.state = {
            id:null,  //任务id
            name:null,//任务名称
            department_name:null, //部门
            executorName:null, //申请人
            auditorName:null, //审核人
            templateName:null, //出差类型
            begin_time:null,//开始时间
            end_time:null,//结束时间
            isCheckedGuide:true,//巡店任务是否全检查,true:全检查，false：未全检查
            /* relatedTaskList:[{
             beginTime:"2017-05-06",
             customerName:"sdafdsaf",
             description:'注意此参数是一个比值而非像素单位。比如，0.5表示距离内容最底部的距离为当前列表可见长度的一半时触发',
             endTime:"2017-05-06",
             taskId:'fdsaf',
             taskName:'fsdaf',
             taskType:"dsaffsa",
             // status:"待审核"
             }],//关联任务数据*/
            relatedTaskList:[],

            reason:'',//不过的原因 检查/审核

            imageList:[],//出差总结报告
            statusHandle:{},//状态操作
            taskName:null,
            type:'',
            taskStatus:'',
            show:true
        };

        this.setParams({
            headerLeft:true,
            headerRight:false,
        });
    }

    setTime = (date)=>{
        let time1 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm:ss");
        let time2 = Tools.timeFormatConvert(date,"YYYY-MM-DD HH:mm");
        /* this.date = "date:" + date + "\ntime1: " + time1
         + "\n e:" + this.selectValue.end_time + "\n et:" + Tools.timeFormatConvert(this.selectValue.end_time);
         this.setState({
         beginTime:this.selectValue.begin_time
         });*/
        if(this.configData.isStartTime)
        {
            if(date < Tools.timeFormatConvert(this.selectValue.end_time))
            {
                this.selectValue.begin_time = time1;
                this.setState({
                    begin_time:time2
                });
            }
            else
            {
                Tools.toast("开始时间必须小于结束时间");
            }
        }
        else
        {
            if(date > Tools.timeFormatConvert(this.selectValue.begin_time))
            {
                this.selectValue.end_time = time1;
                this.setState({
                    end_time:time2
                });
            }
            else
            {
                Tools.toast("结束时间必须大于开始时间");
            }

        }
    }

    onSelectDrop(val,i,type){
        switch (type)
        {
            case 1:{
                // this.state.departmentOneDefault = val.name;
                this.selectValue.department_id = val.id;
                this.selectValue.executor = null;

                Service.getChargePeople(val.id).then((retJson)=>{
                    this.selectValue.executor = retJson.length > 0 ? retJson[0].id : this.selectValue.executor;
                    this.setState({
                        chargePersonList:retJson,//负责人列表
                        chargePersonClearDrop:true,//是否清空负责人下拉框
                        chargePersonDefault:retJson.length > 0 ? retJson[0].name : "无数据",

                    });

                    this.getCheckPeople();
                });
                break;
            }
            case 2: {
                this.selectValue.executor = val.id;
                // this.state.departmentTowDefault = val.name;
                this.getCheckPeople();
                break;
            }
            case 3 :{
                this.selectValue.template_id = val.id;
                this.getCheckPeople();
                break;
            }
            case 4: {
                // alert(JSON.stringify(val))
                this.selectValue.auditor = val.id;

                break;
            }
            case 5: {
                this.configData.isStartTime = val
                this.datePicker.show();
                break;
            }
            case 6: {
                this.goPage("PageGuideApply");
                break;
            }
        }
    }

    onSearch = ()=>{

        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });

        this.getData(this.selectValue);
    };

    onItemPress = (item,cmd,index)=>{

        if(cmd == 0) {
            Service.deleteTask([item.taskId]).then((retJson)=>{
                let lst = [];
                this.state.relatedTaskList.remove(item);
                this.state.relatedTaskList.forEach((v,i,a)=>{
                    lst.push(v);
                });
                this.setState({
                    relatedTaskList:lst
                });
            });
        }
        else if(cmd == 1){

            Service.alterTaskCheckStatus(item.taskId)
                .then(retJson=>{
                    this.state.relatedTaskList[index].isChecked = '1';
                    let isCheckedGuide = true;
                    this.state.relatedTaskList.forEach((v,i,a)=>{
                        if(v.isChecked == '0'){
                            isCheckedGuide = false;
                        }
                    });
                    this.setState({
                        isCheckedGuide:isCheckedGuide,
                        relatedTaskList:JSON.parse(JSON.stringify(this.state.relatedTaskList))
                    },()=>{
                        this.goPage("PageGuideDetail",{id:item.taskId});
                    });
                });
        }

        else if(cmd == 2){
            this.goPage("PageGuideDetail",{id:item.taskId});
        }

    }

    getData() {
        Service.getTripDetail(this.state.id).then(retJson=>{
            this.selectValue = retJson.selectValue;
            retJson.retData.statusHandle = Tools.statusConvert(retJson.retData.status,this.selectValue.executor);
            this.state.type = retJson.retData.status;
            this.setState(retJson.retData);
            this.state.relatedTaskList.forEach((v,i)=>{
                if(v.taskStatus!='0'){
                    this.setState({show:false})
                    return
                }
            })
        });


    }

    renderItem = (item,i)=>{
        const status = Tools.statusConvert(item.taskStatus,this.selectValue.executor);
        let handle = {
            text:'删除',
            cmd:0,//0、 删除，1、检查；2、已检查 负数无命令操作
        };

        if(!status.isProTask){
            switch (status.status){
                case '0':{
                    handle.text = '查看详情';
                    handle.cmd = 1;
                    break;
                }
                case '1' :{
                    handle.text = '删除';
                    handle.cmd = 0;
                    break;
                }
                case '3' :{
                    handle.text = '删除';
                    handle.cmd = 0;
                    break;
                }
                case '4' :{
                    handle.text = '删除';
                    handle.cmd = 0;
                    break;
                }
                case '6' :{
                    /*isChecked=1 已检查
                     isChecked=0 未检查*/
                    handle.text = item.isChecked == '0' ? '检查' : '已检查';
                    handle.cmd = item.isChecked == '0' ? 1 : 2;
                    break;
                }
            }
        }else{
            switch (status.status){
                case '0':{
                    if(this.state.taskStatus == 4){
                        handle.text = '编辑';
                        handle.cmd = 1;
                        break;
                    }else{
                        handle.text = '查看详情';
                        handle.cmd = 1;
                        break;
                    }

                    /* if(this.state.taskStatus == 6 || this.state.taskStatus == 0){
                         handle.text = '--';
                         handle.cmd = -1;
                         break;
                     }else{
                         handle.text = '编辑';
                         handle.cmd = 1;
                         break;
                     }*/
                }
                case '12' :{
                    handle.text = '--';
                    handle.cmd = -1;
                    break;
                }
                case '6' :{
                    handle.text = '--';
                    handle.cmd = -1;
                    break;
                }
                case '3' :{
                    if(this.state.taskStatus == 2){
                        handle.text = '删除';
                        handle.cmd = 0;
                        break;
                    }else{
                        handle.text = '--';
                        handle.cmd = -1;
                        break;
                    }
                }
                case '4' :{
                    handle.text = '--';
                    handle.cmd = -1;
                    break;
                }
            }
        }

        if(status.status == '1'){
            handle = {
                text:'--',
                cmd:-1,//0、 删除，1、检查；2、已检查 负数无命令操作
            };
        }

        return(
            <ItemRowGuideTripApply key={i}
                                   text1={item.customerName || '' }
                                   text2={item.taskType}
                                   text3={item.description}
                                   text4={item.beginTime}
                                   text5={item.endTime}
                                   onPress={()=>this.onItemPress(item,handle.cmd,i)}
                                   text6={status.text}
                                   text7={handle.text}/>
        );
    }

    onOpenImage(imgSrc,i){
        ImageView.show(true,this.state.imageList,i);
    }

    onDelImage(imgSrc,i){
        this.state.imageList.splice(i, 1);
        let imageList = [];
        this.state.imageList.forEach((v,i,a)=>{
            imageList.push(v);
        });
        this.setState({
            imageList:imageList
        });
    }

    onGetPic = (item,i)=>{

        if(this.state.imageList.length > 2){
            Tools.toast("照片数量已达到上线");
        }else{
            if(i == 0){

                Media.takeImage(false,"",false).then(retJson=>{
                    MenuBottom.show(false);
                    let imageList = [];
                    this.state.imageList.forEach((v,i,a)=>{
                        imageList.push(v);
                    });
                    imageList.push(retJson.path);

                    this.setState({
                        imageList:imageList
                    });
                });
            }else if(i == 1){

                Media.pickImage(false,"",false)
                    .then(retJson=>{
                        MenuBottom.show(false);
                        let imageList = [];
                        this.state.imageList.forEach((v,i,a)=>{
                            imageList.push(v);
                        });
                        imageList.push(retJson.path);

                        this.setState({
                            imageList:imageList
                        });

                    })
            }
        }


    }

    renderItemImage = (item,i)=>{

        const {statusHandle} = this.state;
        let viewCtrl = {
            text:"删除",
            isHandle:true,
        }

        if(statusHandle.isProTask){
            switch (statusHandle.status)
            {
                case '0':{
                    viewCtrl.text = undefined;
                    viewCtrl.isHandle = false;
                    break;
                }
                case '1' :{
                    viewCtrl.text = undefined;
                    viewCtrl.isHandle = false;
                    break;
                }
                case '2' :{
                    viewCtrl.text = undefined;
                    viewCtrl.isHandle = false;

                    break;
                }
                case '4' :{

                    break;
                }
                case '6' :{

                    viewCtrl.text = undefined;
                    viewCtrl.isHandle = false;
                    break;
                }
                case '11' :{

                    break;
                }
                case '12' :{

                    viewCtrl.text = undefined;
                    viewCtrl.isHandle = false;
                    break;
                }
            }
        }
        else {
            viewCtrl.text = undefined;
            viewCtrl.isHandle = false;
        }

        return(
            <TextIcon key={i}
                      icon={{uri:item}}
                      text={viewCtrl.text}
                      onPressImage={()=>this.onOpenImage(item,i)}
                      onPressText={()=>{
                          viewCtrl.isHandle ? this.onDelImage(item,i) : null;
                      }}
                      textStyle={styles.imageTextStyle}
                      iconStyle={styles.imageStyle}
                      style={styles.imageFrame_1}/>
        );
    }

    onShowMonPicker = ()=>{
        // PickerCustome.pickMonth();
        Tools.pickMonth(retJson =>{
            let val = (new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime();

            this.selectValue.type3.startTime = Tools.timeFormatConvert(val,"YYYY-MM-DD HH:mm:ss");

            let beginDate = new Date(val);
            if(beginDate.getMonth() == 11)
            {
                val = (new Date(beginDate.getFullYear() + 1,0,1,0,0,0)).getTime();
            }
            else
            {
                val = (new Date(beginDate.getFullYear(), beginDate.getMonth() + 1,1,0,0,0)).getTime();
            }

            this.selectValue.type3.endTime = Tools.timeFormatConvert(val - 1000,"YYYY-MM-DD HH:mm:ss");


            this.setState({
                pickedDate:retJson[0] + "-" + (retJson[1] > 10 ? retJson[1] : '0' + retJson[1])
            });
        });
    }

    componentWillMount(){
    }

    componentDidMount() {
    }

    componentWillReceiveProps(){

        let param = this.getPageParams(true);
        if(param)
        {
            let relatedTaskList = [];
            this.state.relatedTaskList.forEach((v,i,a)=>{
                relatedTaskList.push(v);
            });
            param.paramData = param.paramData == undefined ? [] : param.paramData;
            param.paramData.forEach((v,i,a)=>{
                relatedTaskList.push(v);
            });
            this.setState({
                relatedTaskList: relatedTaskList
            });
        }
    }

    /**
     * 底部按钮操作
     * @param type int; //0、提交出差任务数据，1、审核不通过；2、审核通过
     * **/
    onPressBottom = (type)=>{
        type = type == undefined ? 0 : type;
        if(type == 1){
            ModalTextInput.show();
        } else if(type == 2){
            ModalTextInputS.show();
            /* let isCheckedGuide = true;
             this.state.relatedTaskList.forEach((v,i,a)=>{
                 if(v.isChecked == '0'){
                     isCheckedGuide = false;
                 }
             });*/

        }else if(type == 3){
            if(this.state.imageList.length==0) {
                Tools.toast("请先上传提交出差总结报告")
            }
            else{
                if(this.selectValue.name == '') {
                    Tools.toast("请填写出差名称");
                    return;
                }

                if(this.selectValue.department_id == null) {
                    Tools.toast("请选择部门");
                    return;
                }

                if(this.selectValue.executor == null) {
                    Tools.toast("请选择申请人");
                    return;
                }

                if(this.selectValue.template_id == null) {
                    Tools.toast("请选择任务类型");
                    return;
                }

                if(this.selectValue.auditor == null) {
                    Tools.toast("请选择审核人");
                    return;
                }

                let lst = [];
                this.state.relatedTaskList.forEach((v,i,a)=>{
                    lst.push(v.taskId);
                });

                this.selectValue.task_relation = lst.toString();

                let imageList = [];
                this.state.imageList.forEach((v,i,a)=>{
                    /* if(v.indexOf("http") != 0)
                     {
                         imageList.push(v);
                     }*/
                    imageList.push(v);
                });


                if(imageList.length > 0){
                    Http.upLoadFileToService(imageList).then(retJson=>{

                        let lst = [];
                        retJson.forEach((v,i,a) =>{
                            lst.push(v.servicePath);
                        });

                        Service.alterTripTaskFile(this.selectValue.id,lst.toString())
                            .then(retJson=>{
                                Tools.toast("附件上传成功");
                            });
                    });
                }

                Service.alterTripTask(this.selectValue)
                    .then((retJson)=>{
                        Tools.toast("任务修改成功");
                        BaseComponent.backRefresh = true;

                        if(type!==0){
                            // this.onPressBottom(3);
                        }
                    });

                Service.alterTaskStatus(this.selectValue.id,'10')
                    .then((retJson)=>{
                        // this.goBack(null,{});
                        Tools.toast("任务已完成");
                        BaseComponent.backRefresh = true;
                        this.getData();
                        this.goPage('PageTripList')
                    });
            }
        }else {
            if(this.selectValue.name == '') {
                Tools.toast("请填写出差名称");
                return;
            }

            if(this.selectValue.department_id == null) {
                Tools.toast("请选择部门");
                return;
            }

            if(this.selectValue.executor == null) {
                Tools.toast("请选择申请人");
                return;
            }

            if(this.selectValue.template_id == null) {
                Tools.toast("请选择任务类型");
                return;
            }

            if(this.selectValue.auditor == null) {
                Tools.toast("请选择审核人");
                return;
            }

            let lst = [];
            this.state.relatedTaskList.forEach((v,i,a)=>{
                lst.push(v.taskId);
            });

            this.selectValue.task_relation = lst.toString();

            let imageList = [];
            this.state.imageList.forEach((v,i,a)=>{
                /* if(v.indexOf("http") != 0)
                 {
                     imageList.push(v);
                 }*/
                imageList.push(v);
            });

            Http.upLoadFileToService(imageList).then(retJson=>{

                let lst = [];
                retJson.forEach((v,i,a) =>{
                    lst.push(v.servicePath);
                });

                Service.alterTripTaskFile(this.selectValue.id,lst.toString())
                    .then(retJson=>{
                        Tools.toast("附件上传成功");
                    });

            });

            Service.alterTripTask(this.selectValue).then((retJson)=>{
                BaseComponent.backRefresh = true;
                if(this.state.type == 2){
                    Service.alterTaskStatus(this.selectValue.id,11).then((retJson)=>{
                        Tools.toast("任务修改成功");
                        BaseComponent.goBack();
                    });
                }else if(type!==0){
                    this.onPressBottom(3);
                }
            });
        }
    };

    onChangeText = (text)=>{
        this.reason = text;
    }

    onChangeTextMatch=(text)=>{
        this.reason=text

    }

    onPressRight = ()=>{
        Service.alterTaskStatus(this.selectValue.id,
            this.state.statusHandle.status == '1' ? 3 : 5,this.reason)
            .then(retJson=>{
                Tools.toast("任务不通过");
                BaseComponent.backRefresh = true;
                BaseComponent.goBack();
                this.getData();
            });
    }

    onPressRightS = ()=>{
        // Tools.toast(this.suggest)
        // Service.alterTaskStatus(this.selectValue.id,
        //     this.state.statusHandle.status == '1' ? 3 : 5,this.reason)
        //     .then(retJson=>{
        //         Tools.toast("任务不通过");
        //         BaseComponent.backRefresh = true;
        //         this.getData();
        //     });
        // Service.alterTaskStatus(this.selectValue.id,
        //     this.state.statusHandle.status == '1' ? 3 : 5,this.reason)
        //     .then(retJson=>{
        //         Tools.toast("任务不通过");
        //         BaseComponent.backRefresh = true;
        //         this.getData();
        //     });

        if(this.state.isCheckedGuide || this.state.statusHandle.status == "1"){
            Service.alterTaskStatus(this.selectValue.id,
                this.state.statusHandle.status == '1' ? 2 : 4,this.reason)
                .then(retJson=>{

                    Tools.toast("任务已通过");
                    BaseComponent.backRefresh = true;
                    this.getData();
                    this.goPage('PageTripList')
                });
        }
        else {
            Tools.toast("巡店任务未检查完，请检查完巡店任务");
        }

    }

    componentWillEnter(params){
        if(params){
            if(params.id){
                this.state.id = params.id;
                this.getData();

            }
            this.state.taskStatus = params.status;//出差任务状态 2、退回
            this.state.show = true;
        }

    }

    render() {
        const {name,department_name,executorName,auditorName,statusHandle,isCheckedGuide,
            templateName,begin_time,end_time,relatedTaskList,imageList,reason,show} = this.state;

        // let param = this.getPageParams();
        // if(this.state.id == param.id){
        if(true){

            // if(this.configData.execFirst)
            if(false)
            {
                this.configData.execFirst = false;
                // console.info("param",param);
                this.getData();
            }

            let viewCtrl = {
                viewBottomText: '提交',
                onPressBottom: this.onPressBottom,
                attachViewRight: <View></View>,
                isHandle:true,
            }

            if(statusHandle.isProTask) {

                switch (statusHandle.status){
                    case '0':{
                        viewCtrl.attachViewRight = <View></View>;
                        viewCtrl.isHandle = false;
                        viewCtrl.viewBottomText = undefined

                        break;
                    }
                    case '1' :{
                        // viewCtrl.attachViewRight = {};
                        viewCtrl.viewBottomText = undefined
                        viewCtrl.onPressBottom = undefined;
                        viewCtrl.attachViewRight = <View></View>;
                        viewCtrl.isHandle = false;
                        break;
                    }
                    case '2' :{
                        viewCtrl.attachViewRight = undefined;

                        break;
                    }
                    case '4' : {

                        viewCtrl.onPressBottom = undefined;
                        viewCtrl.attachViewRight =show?undefined:<View></View>
                        viewCtrl.isHandle = false;
                        viewCtrl.viewBottomText =show?<View style={styles.viewBottomStyle}>
                            <ButtonChange text={"提交"}
                                          onPress={() => this.onPressBottom()}
                                          style={styles.viewBottomBtn}/>

                            <ButtonChange text={"完成"}
                                          onPress={() => this.onPressBottom(3)}
                                          style={styles.viewBottomBtn}/>
                        </View>:undefined
                        break;


                    }
                    case '6' :{
                        viewCtrl.viewBottomText = undefined
                        viewCtrl.onPressBottom = undefined;
                        viewCtrl.attachViewRight = <View></View>;
                        viewCtrl.isHandle = false;
                        break;
                    }
                    case '10' :{
                        // viewCtrl.attachViewRight = {};
                        viewCtrl.viewBottomText = undefined
                        viewCtrl.onPressBottom = undefined;
                        viewCtrl.attachViewRight = <View></View>;
                        viewCtrl.isHandle = false;
                        break;
                    }
                    case '11' :{

                        viewCtrl.onPressBottom = undefined;
                        viewCtrl.attachViewRight =show?undefined:<View></View>
                        viewCtrl.isHandle = false;
                        viewCtrl.viewBottomText =show?<View style={styles.viewBottomStyle}>
                            <ButtonChange text={"提交"}
                                          onPress={() => this.onPressBottom()}
                                          style={styles.viewBottomBtn}/>

                            <ButtonChange text={"完成"}
                                          onPress={() => this.onPressBottom(3)}
                                          style={styles.viewBottomBtn}/>
                        </View>:undefined
                        break;
                        break;
                    }
                    case '12' :{
                        viewCtrl.viewBottomText = undefined
                        viewCtrl.onPressBottom = undefined;
                        viewCtrl.attachViewRight = <View></View>;
                        viewCtrl.isHandle = false;
                        break;
                    }
                }
            }
            else {

                if(statusHandle.status == '1' || statusHandle.status == "6"){
                    if(Tools.userConfig.userInfo.position=='大区助理'){
                        viewCtrl.viewBottomText = <View style={styles.viewBottomStyle}>
                            <ButtonChange text={"不通过"}
                                          onPress={()=>this.onPressBottom(1)}
                                          style={styles.viewBottomBtn}/>

                            <ButtonChange text={"通过"}
                                          onPress={()=>this.onPressBottom(2)}
                                          style={[
                                              styles.viewBottomBtn,statusHandle.status == '6' && !isCheckedGuide
                                                  ? {backgroundColor:Theme.Colors.minorColor}
                                                  : {}
                                          ]} />
                        </View>
                    }else{
                        viewCtrl.viewBottomText = Tools.userConfig.userInfo.full_name == auditorName ?
                            <View style={styles.viewBottomStyle}>
                                <ButtonChange text={"不通过"}
                                              onPress={()=>this.onPressBottom(1)}
                                              style={styles.viewBottomBtn}/>

                                <ButtonChange text={"通过"}
                                              onPress={()=>this.onPressBottom(2)}
                                              style={[
                                                  styles.viewBottomBtn,statusHandle.status == '6' && !isCheckedGuide
                                                      ? {backgroundColor:Theme.Colors.minorColor}
                                                      : {}
                                              ]} />
                            </View>
                            :
                            undefined;
                    }

                }
                else {
                    viewCtrl.viewBottomText = undefined;
                }

                viewCtrl.onPressBottom = undefined;
                viewCtrl.attachViewRight = <View></View>;
                viewCtrl.isHandle = false;
            }

            return (
                <ViewTitle viewBottom={viewCtrl.viewBottomText}
                           onPressBottom={viewCtrl.onPressBottom}>

                    <View style={styles.titleFrame}>

                        <ItemRowTripApply text={"出差名称:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={name}/>

                        <ItemRowTripApply text={"部        门:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={department_name}/>

                        <ItemRowTripApply text={"申  请  人:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={executorName}/>

                        <ItemRowTripApply text={"申请类别:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={templateName}/>

                        <ItemRowTripApply text={"审  核  人:"}
                                          frameStyle={styles.titleFrameTop}
                                          viewCenter={"text"}
                                          isStar={false}
                                          text2={auditorName}/>

                        <ItemRowTripApply text={"巡店时间:"}
                                          frameStyle={styles.titleFrameTop}
                                          isStar={false}
                                          viewCenter={
                                              <View style={styles.titleFrame_1}>
                                                  <ButtonChange text={begin_time}
                                                                onPress={()=>{
                                                                    viewCtrl.isHandle ? this.onSelectDrop(true,0,5) : null;
                                                                }}
                                                                frameStyle={styles.titleFrame_timeBtnFrame}
                                                                textStyle={styles.titleFrame_timeBtnText}
                                                                style={styles.titleFrame_timeBtn} />

                                                  <Text style={styles.titleFrame_timeText}>
                                                      ~
                                                  </Text>

                                                  <ButtonChange text={end_time}
                                                                onPress={()=>{
                                                                    viewCtrl.isHandle ? this.onSelectDrop(false,0,5) : null
                                                                }}
                                                                frameStyle={styles.titleFrame_timeBtnFrame}
                                                                textStyle={styles.titleFrame_timeBtnText}
                                                                style={styles.titleFrame_timeBtn} />
                                              </View>
                                          }/>

                        {
                            statusHandle.isProTask &&
                            (statusHandle.status == '2' || statusHandle.status == '11')
                                ? <ItemRowTripApply text={(statusHandle.status == '2' ? "审核驳回" : "检查驳回")}
                                                    frameStyle={styles.titleFrameTop}
                                                    viewCenter={"text"}
                                                    isStar={false}
                                                    text2={reason}/>
                                : null
                        }

                        {
                            statusHandle.isProTask &&
                            (statusHandle.status == '0' || statusHandle.status == '1'|| statusHandle.status == '3'|| statusHandle.status == '4'|| statusHandle.status == '5'|| statusHandle.status == '6'|| statusHandle.status == '7'
                                || statusHandle.status == '8'|| statusHandle.status == '9'|| statusHandle.status == '10'|| statusHandle.status == '12'|| statusHandle.status == '13')
                                ? <ItemRowTripApply text={'审核批语:'}
                                                    frameStyle={styles.titleFrameTop}
                                                    viewCenter={"text"}
                                                    isStar={false}
                                                    text2={reason}/>
                                : null
                        }



                        {
                            viewCtrl.isHandle ?
                                <ItemRowTripApply text={"巡        店:"}
                                                  frameStyle={styles.titleFrameTop}
                                                  isStar={false}
                                                  viewCenter={<ButtonChange text={"新增任务"}
                                                                            onPress={()=>{this.onSelectDrop(0,0,6)}}
                                                                            style={styles.titleFrame_btn} />}/> :
                                null
                        }



                    </View>

                    <View style={styles.titleFrame1}>

                        <ItemRowGuideTripApply textStyle={styles.itemRowText}
                                               frameStyleChild={styles.itemRowFrameTop}
                                               text1={"客户姓名"}
                                               text2={"巡店类型"}
                                               text3={"描述"}
                                               text4={"开始时间"}
                                               text5={"结束时间"}
                                               text6={"状态"}
                                               text7={"操作"}/>

                        {
                            relatedTaskList.map(this.renderItem)
                        }

                    </View>

                    {
                        viewCtrl.attachViewRight == undefined ?
                            <View style={styles.titleFrame1}>
                                <ItemRowTitle text2={"上传附件"}
                                              onPressRight={()=>MenuBottom.show(true)}
                                              viewRight={viewCtrl.attachViewRight}
                                              text1={"出差总结"}/>

                                <View style={styles.imageFrame}>

                                    {
                                        imageList.map(this.renderItemImage)
                                    }

                                </View>
                            </View> :
                            imageList.length > 0 ?
                                <View style={styles.titleFrame1}>
                                    <ItemRowTitle
                                        viewRight={viewCtrl.attachViewRight}
                                        text1={"出差总结"}/>

                                    <View style={styles.imageFrame}>

                                        {
                                            imageList.map(this.renderItemImage)
                                        }

                                    </View>
                                </View> :
                                null
                    }

                    <ModalTextInput onChangeText={this.onChangeText}
                                    onPressRight={this.onPressRight}/>

                    <ModalTextInputS onChangeText={this.onChangeTextMatch}
                                     onPressRight={this.onPressRightS}
                                     title={'批语'}
                    />

                    <MenuBottom btnList={this.btnList}
                                isVisibleClose={false} />

                    <ImageView/>

                    <DatePicker ref={(compoent)=>{
                        this.datePicker = compoent;
                    }}
                                onDateChange={this.setTime}/>

                </ViewTitle>
            );
        }
        else
        {
            this.configData.execFirst = true;
            setTimeout(()=>{
                this.setState({id:param.id})
            },0);
            return (
                <ViewTitle>
                </ViewTitle>
            );
        }

    }
}

const styles = StyleSheetAdapt.create({
    viewBottomStyle:{
        flexDirection:'row',
        alignItems:'center',
        justifyContent:'center',
        marginBottom:10,
    },
    viewBottomBtn:{
        width:100,
        marginRight:20,
    },

    titleFrame:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        // paddingTop:10,
        paddingBottom:20,
        // height:400,
    },
    titleFrameTop:{
        marginTop:20,
    },

    titleFrame_1: {
        flexDirection: 'row',
        flex: 1,
        // height:50,
        alignItems: 'center',
        justifyContent: 'center',
        height: Theme.Height.height1,

    },
    titleFrame_btn: {
        width: 100,
        height: Theme.Height.height1,
        padding: 0,
    },
    titleFrame_timeBtnFrame:{
        borderColor:Theme.Colors.minorColor,
        borderWidth:Theme.Border.borderWidth,
        borderRadius:Theme.Border.borderRadius,
    },
    titleFrame_timeBtn:{
        width: '0.3w',
        height: Theme.Height.height1,
        padding: 0,
        backgroundColor:Theme.Colors.transparent,
    },
    titleFrame_timeBtnText:{
        color:Theme.Colors.minorColor
    },
    titleFrame_timeText:{
        color:Theme.Colors.themeColor,
        marginLeft:10,
        marginRight:10,
        fontSize:Theme.Font.fontSize,
    },
    titleFrame1:{
        flex:1,
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
    },

    imageFrame:{
        flex:1,
        flexDirection:"row",
        margin:10,
        height:130,
        alignItems: 'center',
        justifyContent: 'center',
    },
    imageFrame_1:{
        // flex:1,
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection:"column",
        marginLeft:10,
    },
    imageStyle:{
        width:120,
        height:120,
    },
    imageTextStyle:{
        fontSize:Theme.Font.fontSize_1,
        color:Theme.Colors.appRedColor,
        backgroundColor:Theme.Colors.themeColorLight,
        marginTop:5,
        paddingTop:5,
        paddingBottom:5,
        paddingLeft:20,
        paddingRight:20,
        borderRadius:10,
    },

    itemRowFrameTop:{
        // borderLeftColor:Theme.Colors.minorColor,
        // borderLeftWidth:Theme.Border.borderWidth,
        borderBottomColor:Theme.Colors.themeColor,
        borderBottomWidth:Theme.Border.borderWidth2,
    },
    itemRowFrameLeft:{
        borderColor:Theme.Colors.minorColor,
        borderLeftWidth:Theme.Border.borderWidth,
    },
    itemRowText:{
        color:Theme.Colors.fontcolor,
        fontSize:Theme.Font.fontSize_1,
    }

});
