/**
 * Created by Administrator on 2018/4/30.
 */
import React, {Component} from 'react';
import {
    View,
    Text,
    TextInput,
    TouchableOpacity,
} from 'react-native';
/*import SwipeableListView from 'SwipeableListView';
 import SwipeableQuickActions from 'SwipeableQuickActions';
 import SwipeableQuickActionButton from 'SwipeableQuickActionButton';*/
import {
    StyleSheetAdapt,
    ViewTitle,
    BaseComponent,
    Theme,
    Tools,
    PickDropdown,
    ButtonChange,
    FlatListView,
    ItemRowTripTask,
} from "com";
import {Service} from "./Service";

type Props = {};
export default class PageTripList extends BaseComponent<Props> {

    constructor(props) {
        super(props);

        this.statusList = [{
            name:'状态',
        }];
        this.state = {
            dataList:[],//任务列表
            clearDrop:false,//是否清空下拉框
            departmentOneList:[],//一级部门列表
            departmentOneDefault:'一级部门',//一级部门默认显示值
            departmentOneDisable:false,//一级部门下拉框是否可选择，true：不可以选择，false:可以选择
            departmentTwoList:[],//二级部门列表
            departmentTowDefault:'二级部门',//一级部门默认显示值
            departmentTwoDisable:false,//二级部门下拉框是否可选择，true：不可以选择，false:可以选择
            pickedDate:Tools.timeFormatConvert(Tools.timeFormatConvert(),"YYYY-MM"),
            num:1
        };

        this.selectValue = {
            type1:'',//下拉选中值 一级部门
            type2:'',//下拉选中值 二级部门
            type3:{
                startTime:'',//开始时间
                endTime:''//结束时间
            },//下拉选中值 搜索时间段
            type4:'',//下拉选中值 状态
            name:'',//人名称输入值
            execFirst:true,//是否是第一次执行
        };

        this.setParams({
            // headerLeft:require('images/menu.png'),
            // headerLeftHandle:()=>{
            //     // this.viewTitle.openDrawer();
            //     this.props.navigation.navigate("DrawerToggle",{DrawerToggle:'DrawerToggle'});
            // },
            headerLeft:true,
        //     headerLeftHandle:()=>{
        //         this.goBack(true,null,null)
        // },

            headerRight:require('images/add.png'),
            headerRightHandle:()=>{
                // alert("进入巡店申请");
                this.goPage("PageTripApply");
            },
            // swipeEnabled:true
        });

    }

    cutState(state){
        this.setState({
            status:state
        });
    }

    onSelectDrop(val,i,type){

        switch (type)
        {
            case 1:{
                this.state.departmentOneDefault = val.name;
                this.selectValue.type1 = val.id;
                this.selectValue.type2 = '';
                /* this.setState({
                 departmentTwoList:[
                 {
                 name:'二级部门',
                 id:''
                 }
                 ],
                 departmentTowDefault:'二级部门',
                 // clearDrop:true
                 });*/
                Service.getDepartmentsTwo(val.id).then((retJson)=>{
                    // this.selectValue["type2"] = '';
                    this.setState({
                        departmentTwoList:retJson,
                        departmentTowDefault:'二级部门',
                        clearDrop:true
                    });
                });
                break;
            }
            case 2: {

                this.selectValue.type2 = val.id;
                // this.state.departmentTowDefault = val.name;
                this.setState({
                    clearDrop:false,
                    departmentTowDefault:val.name
                });
                break;
            }
            case 4: {
                // alert(JSON.stringify(val))
                this.selectValue.type4 = val.status;
                break;
            }
        }
    }

    onSearch = ()=>{
        this.selectValue.execFirst = true;
        Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
        this.setState({
            dataList:[]
        });
        this.getData(this.selectValue);
    };

    onItemPress(item){
        this.goPage("PageTripDetail",{id:item.id,status:item.status});
    }

    onItemPressBtn(item,statusObj){
        if(statusObj.code == 0){
            this.goPage("PageGuideList",{id:item.id});
        }
        else{
            this.onItemPress(item);
        }
    }

    /**
     * 获取反馈列表
     * @param selectValue object;//搜索参数
     * **/
    getData(selectValue) {

        if(!this.selectValue.execFirst)
        {
            Tools.flatListView.showFooter(FlatListView.showFootConfig.loading);
        }

        Service.getTripList(selectValue,this.selectValue.execFirst).then(retJson=>{
            if(!this.selectValue.execFirst && !retJson.has)
            {
                Tools.flatListView.showFooter(FlatListView.showFootConfig.noData);

            }else{
                this.setState({
                    dataList:retJson.retListData
                });
                this.selectValue.execFirst = false;

                Tools.flatListView.showFooter(FlatListView.showFootConfig.success);
            }
        })
            .catch((status) =>{
                if(status.status != Theme.Status.executing){
                    Tools.flatListView.showFooter(FlatListView.showFootConfig.error);
                }
            });
    }

    getDepartments(){
        Service.getDepartmentsOne()
            .then((retJson)=>{
                // retJson.forEach()

                // console.info("retJson",retJson);

                this.selectValue.type1 = retJson.branchOffice;
                this.selectValue.type2 = retJson.area;
                this.setState({
                    departmentOneList:retJson.branchOfficeLst,
                    departmentOneDefault:retJson.nameOne,
                    departmentTwoList:retJson.areaLst,
                    departmentTowDefault:retJson.nameTwo,
                    departmentOneDisable:this.selectValue.type1 == '' ? false : true,
                    departmentTwoDisable:this.selectValue.type2 == '' ? false : true
                });
            });
    }

    componentWillEnter(params){
        // console.info("componentWillEnter hhhh ",params);
        /*this.selectValue.execFirst = true;
        if(this.selectValue.execFirst){
            this.getData(this.selectValue);
            this.selectValue.execFirst = false;
        }*/


    }

    componentWillExit(params){
        // console.info("componentWillExit",params);
    }

    componentWillMount(){
    }

    componentDidMount() {
        /*if(!Tools.platformType){
        this.getData();
        }*/
        this.getStatusList();
        this.getDepartments();
        this.getData();
    }

    renderItemView(item,i){

        let statusObj = Tools.statusConvert(item.status,item.executor_id);
        /*  let text4_2 = <ButtonChange text={"进入巡店"}
         frameStyle={styles.itemTripBtn}
         style={styles.titleFrame_btn}
         onPress={()=>this.onItemPressBtn(item)}/>;*/

        let btnList = [];
        statusObj.btnList.forEach((v,i,a)=>{
            btnList.push({
                onPress:()=>this.onItemPressBtn(item,v),
                text:v.text,
                backgroundColor:v.backgroundColor == undefined
                    ? Theme.Colors.backgroundColorBtn1
                    : v.backgroundColor
            });
        });
        var text5 = "任务完成后获得奖励：鲜花 +5";
        if(statusObj.text == "已完成"){
            text5 = undefined;
        }
        return(
            <ItemRowTripTask  key={i}
                              disableRightSwipe={false}
                              isItemRowIconLeft={true}
                              btnList={btnList}
                              text1_1={item.name}
                              itemRowFrame={styles.itemRowFrame}
                              titleFrameStyle={styles.titleFrameStyle}
                              text1_1_Style={styles.itemTripTxt1}
                              text1_2={statusObj.text}
                              text2_1={"申请人:" + item.executor
                              + "       审核人:" + item.auditor
                              + "       巡店数量:" + item.relationTaskNum + "/个"}
                              text2_1_Style={styles.text2_1_Style}
                              text3_1={"出差编码:" + item.number}
                              text4_1={"开始/结束时间:" + item.begin_time
                              + " ~ " + item.end_time}
                              text5_1={text5}
                              text5_1_Style={{color:Theme.Colors.themeColor}}
                              onPress={() => this.onItemPress(item)}
                              text1_2_Style={{color:statusObj.color}}
                              itemRowIcon={false}
                              text1_2_Icon={statusObj.icon}/>
        );
    }

    onShowMonPicker = ()=>{
        // PickerCustome.pickMonth();
        Tools.pickMonth(retJson =>{
            let val = (new Date(retJson[0],retJson[1] - 1,1,0,0,0)).getTime();

            this.selectValue.type3.startTime = Tools.timeFormatConvert(val,"YYYY-MM-DD HH:mm:ss");

            let beginDate = new Date(val);
            if(beginDate.getMonth() == 11)
            {
                val = (new Date(beginDate.getFullYear() + 1,0,1,0,0,0)).getTime();
            }
            else
            {
                val = (new Date(beginDate.getFullYear(), beginDate.getMonth() + 1,1,0,0,0)).getTime();
            }

            this.selectValue.type3.endTime = Tools.timeFormatConvert(val - 1000,"YYYY-MM-DD HH:mm:ss");


            this.setState({
                pickedDate:retJson[0] + "-" + (retJson[1] > 10 ? retJson[1] : '0' + retJson[1])
            });
        });
    }

    getStatusList(){
        Tools.statusConvert().forEach((v,i,a)=>{
            v.name = v.text;
            this.statusList.push(v);
        });
    };

    onChangeText = (text)=>{
        this.selectValue.name = text;
    }

    componentWillReceiveProps(){
        let param = this.getPageParams(true);
        if(param)
        {
            // alert(JSON.stringify(param.paramData));
            this.onSearch();
        }


    }

    render() {
        const {dataList,departmentOneList,departmentTwoList,departmentOneDefault,
            departmentTowDefault,departmentTwoDisable,departmentOneDisable,pickedDate
            ,clearDrop} = this.state;

        return (
            <ViewTitle isScroll={false}
                       ref={c=>this.viewTitle=c}>

                <View style={styles.titleFrame}>
                    <View style={styles.titleFrame_1}>
                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={departmentOneDefault}
                                           options={departmentOneList}
                                           disabled={departmentOneDisable}
                                           onSelect={(i,val)=>this.onSelectDrop(val,i,1)} />
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={departmentTowDefault}
                                           clearDrop={clearDrop}
                                           options={departmentTwoList}
                                           disabled={departmentTwoDisable}
                                           onSelect={(i,val)=>this.onSelectDrop(val,i,2)} />
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <TouchableOpacity onPress={this.onShowMonPicker}>
                                <PickDropdown  defaultValue={pickedDate}
                                               selectedIndex={0}
                                               options={[pickedDate]}
                                               disabled={true}
                                    // onSelect={(i,val)=>this.onSelectDrop(val,i,3)}
                                />
                            </TouchableOpacity>

                        </View>
                    </View>

                    <View style={styles.titleFrame_1}>
                        <View style={styles.titleFrame_1_1}>
                            <PickDropdown  defaultValue={this.statusList[0].name}
                                           options={this.statusList}

                                           onSelect={(i,val)=>this.onSelectDrop(val,i,4)} />
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <TextInput placeholder={"--姓名--"}
                                       onChangeText={this.onChangeText}
                                       style={styles.titleFrame_textInput}/>
                        </View>
                        <View style={styles.titleFrame_1_1}>
                            <View style={styles.titleFrame_btnFrame}>
                                <ButtonChange text={"查询"}
                                              onPress={this.onSearch}
                                              style={styles.titleFrame_btn}/>
                            </View>
                        </View>
                    </View>

                </View>

                <FlatListView style={styles.flatListView}
                              data={dataList}
                              keyExtractor = {(item, index) => ("key" + index)}
                              renderItem={({item,index}) => this.renderItemView(item,index)}
                              onEndReached={() =>this.getData()}
                />

            </ViewTitle>
        );
    }
}

const styles = StyleSheetAdapt.create({
    titleFrame:{
        marginTop:10,
        backgroundColor:Theme.Colors.foregroundColor,
        paddingTop:10,
        paddingBottom:10,
        height:100,
    },
    titleFrame_1:{
        flexDirection:'row',
        flex:1,
        height:50,
    },
    titleFrame_1_1:{
        flex:1,
        alignItems:'center',
        justifyContent:'center',
    },
    titleFrame_textInput:Tools.platformType
        ? {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            borderWidth:Theme.Border.borderWidth,
            borderRadius:Theme.Border.borderRadius,
            borderColor:Theme.Colors.minorColor,
        }
        : {
            fontSize:Theme.Font.fontSize,
            width:Theme.Width.width1 + Theme.Height.height1,
            height:Theme.Height.height1,
            padding:0,
            paddingLeft:10,
            paddingBottom:10,
            marginTop:15,
            marginLeft:-20,
            // borderWidth:Theme.Border.borderWidth,
            // borderRadius:Theme.Border.borderRadius,
            // borderColor:Theme.Colors.minorColor,
        } ,
    titleFrame_btnFrame:{
        width:Theme.Width.width1 + Theme.Height.height1,
    },
    titleFrame_btn:{
        width:100,
        height:Theme.Height.height1,
        padding:0,
    },

    itemTripTxt1:{
        color:Theme.Colors.themeColor,
    },
    titleFrameStyle:{
        borderBottomColor:Theme.Colors.themeColor,
    },
    itemRowFrame:{
        borderBottomWidth:0,
    },
    text2_1_Style:{
        color:Theme.Colors.fontcolor,
    },

    flatListView:{
        backgroundColor:Theme.Colors.foregroundColor,
        marginTop:10,
        marginBottom:10,
    },
    itemTripBtn:{
        marginRight:"0.05w",
    },
});
